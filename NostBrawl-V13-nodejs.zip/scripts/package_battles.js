'use strict'
// Port of package_battles.py.
// Package source without owner credentials, accounts, dependencies or logs.
//
// Python's zipfile is replaced by the small ZIP writer/reader below (deflate
// via zlib.deflateRawSync, CRC-32, Unix permissions and DOS timestamps), so
// packaging needs Node.js only.
const fs = require('node:fs')
const path = require('node:path')
const { ZipWriter, ZipReader } = require('./native_v13/lib/zip')

const root = path.resolve(__dirname, '..')
const out = process.argv.length > 2 ? path.resolve(process.argv[2]) : path.join(path.dirname(root), 'NostBrawl-V13-servidor-em-validacao.zip')
const config = {
  ServerIP: '0.0.0.0', ServerPort: 9339, ClientMajor: 13, ClientMinor: 0, ClientBuild: 283,
  UnlockedBrawlersOption: 'StarterOnly',
  Database: { Path: 'Database/players.sqlite' },
  SCID: { Enabled: false, RemoteUrl: '', RemoteApiKey: '' },
  Store: { Enabled: false },
  Battle: { Enabled: true, BindIP: '0.0.0.0', Port: 9339, AdvertiseHost: '', MaxPlayers: 200, SessionTimeoutMs: 30000 }
}
const readme = `SERVIDOR V13 EM VALIDACAO - NAO E UMA DECLARACAO DE PROJETO CONCLUIDO

ATUALIZACAO: preserve seu config.json e toda a pasta Database. O config.json
incluido e generico para instalacao nova: nao substitua suas configuracoes
de loja, SCID, rede e contas pelas genericas.

INSTALACAO NOVA: Node18+; npm ci; npm start. No servidor atras de NAT, ajuste
Battle.AdvertiseHost para o IPv4 que o celular alcanca e libere a porta UDP.
A loja e SCID estao desabilitados na configuracao generica.

Contem o codigo integral e os assets do servidor. Nao contem seus bancos,
credenciais particulares nem node_modules. Leia BATTLES.md para os testes
executados e as pendencias reais, incluindo APK e poderes de estrela.
`

// sorted(root.rglob('*')): Path ordering compares the path components.
function walk (directory, parts, found) {
  for (const entry of fs.readdirSync(directory, { withFileTypes: true })) {
    const full = path.join(directory, entry.name); const rel = parts.concat(entry.name)
    found.push({ full, parts: rel, entry })
    if (entry.isDirectory()) walk(full, rel, found)
  }
  return found
}
function compareParts (a, b) {
  for (let i = 0; i < Math.min(a.length, b.length); i++) {
    if (a[i] !== b[i]) return a[i] < b[i] ? -1 : 1
  }
  return a.length - b.length
}

function deepEqual (a, b) { return JSON.stringify(a) === JSON.stringify(b) }

const excludedDirs = new Set(['node_modules', '.git', '__pycache__', '.pytest_cache'])
const excludedSuffixes = new Set(['.db', '.log', '.pyc', '.zip'])
const zip = new ZipWriter(out)
for (const item of walk(root, [], []).sort((a, b) => compareParts(a.parts, b.parts))) {
  const name = item.parts[item.parts.length - 1]
  if (!item.entry.isFile() || item.entry.isSymbolicLink() || item.parts.some(part => excludedDirs.has(part))) continue
  const dot = name.lastIndexOf('.'); const suffix = dot > 0 ? name.slice(dot) : ''
  if (name === 'config.json' || ['.sqlite', '.db-wal', '.db-shm'].some(s => name.includes(s)) || excludedSuffixes.has(suffix)) continue
  if (path.resolve(item.full) === out) continue
  const stat = fs.statSync(item.full)
  zip.add(['NostBrawl-V13', ...item.parts].join('/'), fs.readFileSync(item.full), { mtime: stat.mtime, mode: stat.mode })
}
zip.add('NostBrawl-V13/config.json', Buffer.from(JSON.stringify(config, null, 2) + '\n'))
zip.add('NostBrawl-V13/LEIA-ANTES-DE-INSTALAR.txt', Buffer.from(readme))
zip.close()

const check = new ZipReader(out)
if (!deepEqual(JSON.parse(check.read('NostBrawl-V13/config.json')), config)) throw new Error('AssertionError: config.json differs')
if (check.namelist().some(n => n.includes('.sqlite') || n.includes('/node_modules/'))) throw new Error('AssertionError: owner data or dependencies were packaged')
if (check.testzip() !== null) throw new Error('AssertionError: corrupt zip entry')
console.log(path.basename(out), check.namelist().length, 'files;', fs.statSync(out).size, 'bytes; generic config only, no owner databases')
