'use strict'
// Port of probe_battle_modes.py.
// Populate each enabled mode with original players/bots and run native frames.
//
// These short scenarios verify startup/encoding, not complete mode objectives,
// late waves, all interactions, UDP transport or match results.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const { kindOf } = require('./lib/battle_probe')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x8000000 }); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  R.assert(data.word(data.tables.get(3) + 0xb4) === 20, 'Original boss reload cache differs from client globals')
  const t = data.csv.get(15); const records = []; const seen = new Set()
  for (const row of t.records) {
    const location = R.zipDict(t.names, row); const mode = location.GameMode
    if (!location.AllowedMaps || location.Disabled === 'true' || seen.has(mode)) continue
    seen.add(mode)
    const kind = kindOf(mode)
    const record = { location: location.Name, gameMode: mode, kind }
    try {
      const battle = new NativeBattle(data, location.Name, kind)
      battle.add_player('ShotgunGirl', 0)
      battle.setup(); record.afterSetup = battle.describe(); record.frames = []
      for (let tick = 0; tick < 40; tick++) {
        const vision = battle.frame(); const frame = battle.describe(); frame.vision = vision; record.frames.push(frame)
      }
      R.print('populated-mode', mode, record.afterSetup.players.length, 'players;', record.afterSetup.objects.length, 'initial objects;', record.frames.length, 'original frames')
    } catch (e) {
      record.error = { message: R.errorMessage(e), pc: m.pc(), lr: m.lr() }
      R.print('blocked', mode, record.error)
    }
    records.push(record)
  }
  R.writeJson('battle-modes-vectors.json', records)
  const failed = records.filter(record => 'error' in record).length
  R.print('Original populated mode startup:', records.length, 'modes;', failed, 'blocked; short startup scenarios, no full match-end claim')
  if (failed) throw new R.SystemExit(1)
})
