'use strict'

const LogicSkinDataCommand = require('./LogicSkinDataCommand')

class LogicUnlockSkinServerCommand extends LogicSkinDataCommand {
}

module.exports = LogicUnlockSkinServerCommand
