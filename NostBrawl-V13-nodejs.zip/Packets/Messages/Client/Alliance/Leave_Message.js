'use strict'
const { ClubService, ClubError } = require('../../../../Logic/ClubService')
const { FriendService } = require('../../../../Logic/FriendService')
const PresenceService = require('../../../../Logic/PresenceService')
const AllianceDataMessage = require('../../Server/Alliance/Alliance_Data_Message')
const AllianceChatServerMessage = require('../../Server/Alliance/Alliance_Chat_Server_Message')
const AllianceLeaveOkMessage = require('../../Server/Alliance/Events/AllianceLeaveOkMessage')
const MyAllianceMessage = require('../../Server/Alliance/My_Alliance_Message')
const { BSMessageReader } = require('../../../../Utils/Reader')

class Leave_Message extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
  }

  process () {
    let result
    try {
      result = ClubService.leave(this.player)
    } catch (error) {
      if (error instanceof ClubError) {
        return String(error.message)
      }
      throw error
    }
    new AllianceLeaveOkMessage(this.client, this.player).send()
    new MyAllianceMessage(this.client, this.player, 0).send()
    const successorId = result.successorID
    if (successorId !== null && successorId !== undefined) {
      const successor = ClubService.refresh_online_player(this.player, successorId)
      if (successor !== null && successor !== undefined) {
        new MyAllianceMessage(null, successor, result.clubID).sendWithLowID(successorId)
      }
    }
    for (const memberId of result.memberIDs) {
      new AllianceDataMessage(
        this.client, this.player, 0, result.clubID, true
      ).sendWithLowID(memberId)
      new AllianceChatServerMessage(
        this.client, this.player, 4, result.clubID, false, result.entry
      ).sendWithLowID(memberId)
    }
    FriendService.push_presence(this.player)
    for (const memberId of result.memberIDs) {
      PresenceService.sync_pair(this.player, memberId)
    }
    return result
  }
}

module.exports = Leave_Message
