'use strict'

const LOGGER = {
  info: (...args) => console.log(...args),
  exception: (...args) => console.error(...args)
}

class ActiveGameSessions {
  constructor () {
    this._sessions = new Map()
  }

  register (player, client, address = null) {
    const lowId = Math.trunc((player.low_id !== undefined ? player.low_id : 0) || 0)
    if (lowId <= 0) {
      return
    }
    const remote = (Array.isArray(address) && address.length) ? address[0] : null
    const clientDict = player.ClientDict || {}
    this._sessions.set(lowId, {
      player,
      client,
      address: remote,
      token: player.token !== undefined ? player.token : '',
      account_lock: clientDict.AccountLock !== undefined ? clientDict.AccountLock : null,
      wizard_reward_delivered: false
    })
  }

  unregister (player, client) {
    const lowId = Math.trunc((player.low_id !== undefined ? player.low_id : 0) || 0)
    const current = this._sessions.get(lowId)
    if (current !== undefined && current && current.client === client) {
      this._sessions.delete(lowId)
    }
  }

  clear () {
    this._sessions.clear()
  }

  unique_at_address (address) {
    if (!address) {
      return null
    }
    const matches = Array.from(this._sessions.values()).filter(
      (value) => value.address === address
    )
    if (matches.length !== 1) {
      return null
    }
    const session = matches[0]
    return {
      low_id: Math.trunc(session.player.low_id),
      token: session.token,
      name: session.player.name !== undefined ? session.player.name : ''
    }
  }

  notify_registration (lowId) {
    lowId = Math.trunc(lowId)
    while (true) {
      const session = this._sessions.get(lowId)
      if (session === undefined || session === null) {
        return false
      }
      let retry = false
      const attempt = () => {
        if (this._sessions.get(lowId) !== session) {
          retry = true
          return false
        }
        if (session.wizard_reward_delivered) {
          return false
        }
        const player = session.player
        try {
          const { get_service } = require('./Runtime')
          const service = get_service()
          const account = service !== null && service !== undefined
            ? service.store.by_game(lowId)
            : null
          if (account === null || account === undefined) {
            return false
          }
          player.scid_account = account
          const NotificationFactory = require('../Logic/NotificationFactory')
          const { LogicAddNotificationCommand } = require('../Packets/Messages/Server/NotifAdd')
          NotificationFactory.ensure_wizard_barley(player)
          let notification = null
          for (const [value, skinId] of NotificationFactory._entries(player.Notifications)) {
            if (skinId === NotificationFactory.WIZARD_BARLEY_SKIN_ID && !NotificationFactory._read(value)) {
              notification = value
              break
            }
          }
          if (notification === null) {
            return false
          }
          new LogicAddNotificationCommand(
            session.client, player, null, notification
          ).send()
          session.wizard_reward_delivered = true
          LOGGER.info(`SCID Wizard Barley notification sent for game ${lowId}`)
          return true
        } catch (error) {
          LOGGER.exception('Could not deliver SCID registration reward', error)
          return false
        }
      }
      const accountLock = session.account_lock
      const result = accountLock ? accountLock(lowId).run(attempt) : attempt()
      if (retry) {
        continue
      }
      return result
    }
  }
}

const GAME_SESSIONS = new ActiveGameSessions()

module.exports = { ActiveGameSessions, GAME_SESSIONS }
