'use strict'
const fs = require('node:fs')
const path = require('node:path')
const crypto = require('node:crypto')
const assert = require('node:assert/strict')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
const manifest = require('../GameAssets/client_battle_assets.json')
for (const [name, entry] of Object.entries(manifest.assets)) {
  const bytes = fs.readFileSync(path.join(__dirname, '../GameAssets/csv_logic', name + '.csv'))
  assert.equal(crypto.createHash('sha256').update(bytes).digest('hex'), entry.sha256, name + ' must match supplied APK')
}
const assets = new BattleAssets()
for (const [name, id] of Object.entries(manifest.characterIds)) assert.equal(assets.named('characters', name).id, id, name)
assert.equal(assets.tables.characters.length, 73)
assert.equal(assets.heroes.length, 22)
console.log('Client APK alignment: 12 CSV tables and 73 character IDs verified; playable hero IDs preserved')
