'use strict'
const DataBase = require('../../../../Database/DatabaseManager')
const { ClubService, ClubError } = require('../../../../Logic/ClubService')
const AllianceChatServerMessage = require('../../Server/Alliance/Alliance_Chat_Server_Message')
const AllianceBotChatServerMessage = require('../../Server/AllianceBot/Alliance_Bot_Chat_Server_Message')
const LoginFailedMessage = require('../../Server/Login/LoginFailedMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AllianceChatMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
    this.bot_msg = ''
    this.msg = ''
  }

  decode () {
    this.msg = this.read_string()
  }

  _load_account () {
    const parts = this.msg.split(' ')
    if (parts.length !== 2) {
      new AllianceBotChatServerMessage(
        this.client, this.player, 'Use: /load <id>'
      ).send()
      return 'Formato /load inválido'
    }
    let nostId
    try {
      nostId = Number.parseInt(parts[1], 10)
      if (Number.isNaN(nostId)) {
        throw new Error('not a number')
      }
    } catch (error) {
      new AllianceBotChatServerMessage(
        this.client, this.player, 'Use: /load <id>'
      ).send()
      return 'ID /load inválido'
    }
    const loaded = DataBase.loadOldAccount(this, nostId)
    this.player.err_code = 1
    if (loaded) {
      new LoginFailedMessage(
        this.client,
        this.player,
        'Conta vinculada. Entre novamente para carregar os dados.'
      ).send()
      return true
    }
    new LoginFailedMessage(this.client, this.player, 'Conta não encontrada.').send()
    return false
  }

  process () {
    if (this.msg.toLowerCase().startsWith('/load')) {
      return this._load_account()
    }
    let clubId
    let entry
    try {
      ;[clubId, entry] = ClubService.chat(this.player, this.msg)
    } catch (error) {
      if (error instanceof ClubError) {
        return String(error.message)
      }
      throw error
    }
    const club = ClubService.get_club(clubId)
    new AllianceChatServerMessage(
      this.client, this.player, this.msg, clubId, false, entry
    ).send()
    for (const memberId of club.member_ids) {
      if (memberId !== this.player.low_id) {
        new AllianceChatServerMessage(
          this.client, this.player, this.msg, clubId, false, entry
        ).sendWithLowID(memberId)
      }
    }
    return entry
  }
}

module.exports = AllianceChatMessage
