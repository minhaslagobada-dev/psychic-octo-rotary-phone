'use strict'
// Port of probe_mode_initialization.py.
// Original location, random map selection and empty mode/container update.
//
// No players or match objectives are initialized. This isolates original map
// selection and location-to-mode decoding, not a playable or completed match.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x4000000 }); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const t = data.csv.get(15); const p = (a, v) => t.ptr(a, v); p(0xab42d0, data.named(27, 'Open'))
  const records = []; const seen = new Set()
  for (const row of t.records) {
    const location = R.zipDict(t.names, row)
    if (!location.AllowedMaps || location.Disabled === 'true' || seen.has(location.GameMode)) continue
    seen.add(location.GameMode)
    const battle = t.alloc(0x400); n.call(0x4328f8, battle, 1); const manager = data.ptr(battle); n.call(0x201398, manager, battle)
    n.call(0x425ef8, battle, data.named(15, location.Name)); n.call(0x13a028, battle, 17)
    const record = { location: location.Name, gameMode: location.GameMode, nativeMode: data.word(battle + 0xe8) }
    try {
      n.call(0x1e7b14, battle, 0, 1, 0, { count: 20000000 })
      const map = data.ptr(battle + 0x70)
      Object.assign(record, { width: data.word(map + 0x40), height: data.word(map + 0x44) })
      n.call(0x4cba34, battle, { count: 20000000 })
      record.emptyUpdateCompleted = true
      R.print('mode-container', record)
    } catch (e) {
      record.error = { message: R.errorMessage(e), pc: m.pc(), lr: m.lr() }
      R.print('blocked', record)
    }
    records.push(record)
  }
  R.writeJson('mode-initialization-vectors.json', records)
  const failed = records.filter(record => 'error' in record).length
  R.print('Original empty mode/location exercise:', records.length, 'names;', failed, 'blocked; no player setup, objectives or match-end claim')
  if (failed) throw new R.SystemExit(1)
})
