'use strict'

const Writer = require('../../../../Utils/Writer')

class BillingRequestFailedMessage extends Writer {
  constructor (client, player, reason, errorCode = 1) {
    super(client)
    this.id = 20121
    this.player = player
    this.reason = reason
    this.error_code = errorCode
  }

  encode () {
    this.writeInt(this.error_code)
    this.writeString(this.reason)
    this.writeInt(0)
  }
}

module.exports = BillingRequestFailedMessage
