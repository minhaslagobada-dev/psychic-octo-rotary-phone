'use strict'

const DataBase = require('../../../Database/DatabaseManager')

class LogicSetPlayerStarpowerCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.player.starpower = reader.read_Vint()
  }

  static process (reader) {
    DataBase.replaceValue(reader, 'starpower', reader.player.starpower)
    if ((Math.trunc(reader.player.room_id || 0) || 0) > 0) {
      let GameRoomService
      try {
        GameRoomService = require('../../../Logic/GameRoomService')
      } catch (error) {
        if (error && error.code === 'MODULE_NOT_FOUND') {
          return
        }
        throw error
      }
      const TeamGameroomDataMessage = require('../../Messages/Server/Gameroom/TeamGameroomDataMessage')
      const room = GameRoomService.for_player(reader.player)
      if (room !== null && room !== undefined) {
        new TeamGameroomDataMessage(reader.client, reader.player, room).send()
      }
    }
  }
}

module.exports = LogicSetPlayerStarpowerCommand
