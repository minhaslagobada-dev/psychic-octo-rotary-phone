'use strict'
const TeamStreamMessage = require('./TeamStreamMessage')

class TeamStream extends TeamStreamMessage {
}

module.exports = TeamStream
