'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { spreadTarget } = require('../Native/V13/ProjectileSpread')
const { timing } = require('../Native/V13/ProjectileTiming')
const { positionAtTick } = require('../Native/V13/ProjectilePosition')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'projectile-shoot-vectors.json')))
let points = 0
for (const v of vectors) {
  assert.deepEqual(spreadTarget({ origin: [3000, 4500], target: v.aim, spread: v.spread,
    deterministic: v.deterministic, pattern: v.pattern, data: v.data, rngState: v.rngBefore, width: 6300, height: 9900 }),
  { target: v.target, rngState: v.rngState }, JSON.stringify(v))
  assert.deepEqual(timing({ start: v.start, target: v.target, ...v.data, launch: v.launch }),
    { launch: v.launch, finish: v.finish, progressStep: v.progressStep }, v.name)
  for (const point of v.points) {
    assert.deepEqual(positionAtTick(v.data, { start: v.start, end: v.target, z: v.z, launch: v.launch, finish: v.finish }, point.tick), point.output, JSON.stringify(v))
    points++
  }
}
console.log('Native shoot integration:', vectors.length, 'launches;', points, 'trajectory points matched; spread and RNG transitions also matched')
