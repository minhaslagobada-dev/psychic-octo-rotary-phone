'use strict'

class BitStream {
  constructor (buff = null) {
    if (buff === null || buff === undefined) this.buffer = []
    else this.buffer = Array.from(Buffer.from(buff))
    this.bitIndex = 0
    this.offset = 0
  }

  getBuff () {
    return Buffer.from(this.buffer)
  }

  size () {
    return this.buffer.length
  }

  readBit () {
    if (this.offset > this.buffer.length) {
      console.log('Out of range!')
      return 0
    }
    const value = (this.buffer[this.offset] >> this.bitIndex) & 1
    this.bitIndex += 1
    if (this.bitIndex === 8) {
      this.bitIndex = 0
      this.offset += 1
    }
    return value
  }

  readBytes (length) {
    const data = []
    let index = 0
    while (index < length) {
      let value = 0
      let p = 0
      while (p < 8 && index < length) {
        value |= this.readBit() << p
        index += 1
        p += 1
      }
      data.push(value)
    }
    return Buffer.from(data)
  }

  readPositiveInt (bitsCount) {
    const data = this.readBytes(bitsCount)
    let value = 0
    for (let index = data.length - 1; index >= 0; index--) {
      value = value * 256 + data[index]
    }
    return value
  }

  readInt (bitsCount) {
    const v2 = 2 * this.readPositiveInt(1) - 1
    return v2 * this.readPositiveInt(bitsCount)
  }

  readPositiveVIntMax255 () {
    const v2 = this.readPositiveInt(3)
    return this.readPositiveInt(v2)
  }

  writeBit (data) {
    if (this.bitIndex === 0) {
      this.offset += 1
      this.buffer.push(0xFF)
    }

    let value = this.buffer[this.offset - 1]
    value &= ~(1 << this.bitIndex)
    value |= (data << this.bitIndex)
    this.buffer[this.offset - 1] = value

    this.bitIndex = (this.bitIndex + 1) % 8
  }

  dectobin (num, bitsCount) {
    const binary = num.toString(2)
    const bits = []
    for (const b of binary) {
      if (b === '0') bits.push(0)
      else bits.push(1)
    }
    return bits.reverse()
  }

  writeBits (bits, count) {
    let index = 0
    let position = 0
    while (index < count) {
      let value = 0

      let p = 0
      while (p < 8 && index < count) {
        value = (bits[position] >> p) & 1
        this.writeBit(value)
        p += 1
        index += 1
      }
      position += 1
    }
  }

  BwriteByte (value) {
    this.writePositiveInt(value, 1)
  }

  writeBoolean (value) {
    if (value) {
      this.BwriteByte(1)
    } else {
      this.BwriteByte(0)
    }
  }

  writePositiveInt (value, bitsCount) {
    const chunk = Buffer.alloc(4)
    chunk.writeUInt32LE(value >>> 0, 0)
    this.writeBits(chunk, bitsCount)
  }

  writeInt (value, bitsCount) {
    let val = value
    if (val <= -1) {
      this.writePositiveInt(0, 1)
      val = -value
    } else if (val >= 0) {
      this.writePositiveInt(1, 1)
      val = value
    }
    this.writePositiveInt(val, bitsCount)
  }

  writePositiveVInt (value, count) {
    let v3 = 1
    const v7 = value

    if (v7 !== 0) {
      if (v7 < 1) {
        v3 = 0
      } else {
        let v8 = v7
        v3 = 0

        v3 += 1
        v8 >>= 1

        while (v8 !== 0) {
          v3 += 1
          v8 >>= 1
        }
      }
    }
    this.writePositiveInt(v3 - 1, count)
    this.writePositiveInt(v7, v3)
  }

  writePVIntMax255OZ (value) {
    if (value === 0) {
      this.writePositiveInt(1, 1)
      return
    }
    this.writePositiveInt(0, 1)
    this.writePositiveVInt(value, 3)
  }

  writePVIntMax65535OZ (value) {
    if (value === 0) {
      this.writePositiveInt(1, 1)
      return
    }
    this.writePositiveInt(0, 1)
    this.writePositiveVInt(value, 4)
  }

  Ulta () {
    if (this.player.charge === 3000) {
      this.writePVIntMax255OZ(0)
    } else {
      this.writePVIntMax255OZ(1)
    }
  }
}

module.exports = BitStream
