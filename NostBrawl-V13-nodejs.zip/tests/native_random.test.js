'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { nextInt } = require('../Native/V13/Random')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'random-vectors.json')))
for (const v of vectors) assert.deepEqual(nextInt(v.state, v.bound), { value: v.value, nextState: v.nextState }, JSON.stringify(v))
console.log('Native RNG:', vectors.length, 'transitions matched original v13')
