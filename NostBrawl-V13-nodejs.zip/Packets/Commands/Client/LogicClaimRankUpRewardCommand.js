'use strict'

const TrophyRoad = require('../../../Logic/TrophyRoad')
const RewardDelivery = require('../../../Logic/RewardDelivery')
const { RewardError } = require('../../../Logic/Rewards')

class LogicClaimRankUpRewardCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    const dataReference = reader.readScId()
    reader.brawlerPowerPointsTarget = dataReference
    reader.brawlerID = dataReference[1]
  }

  static process (reader) {
    let result
    try {
      result = TrophyRoad.claim(
        reader.player, reader.brawlerID !== undefined ? reader.brawlerID : 0
      )
    } catch (error) {
      if (error instanceof RewardError) {
        return String(error.message)
      }
      throw error
    }
    let response
    if (result.rewardType === 'box') {
      response = { kind: 'box', result }
    } else if (result.rewardType === 'event') {
      return result
    } else {
      response = {
        kind: 'item',
        rewards: RewardDelivery.displays(result.rewardDetails),
        trophyRoad: result.trophyRoad
      }
    }
    RewardDelivery.send(reader.client, reader.player, response)
    return result
  }
}

module.exports = LogicClaimRankUpRewardCommand
