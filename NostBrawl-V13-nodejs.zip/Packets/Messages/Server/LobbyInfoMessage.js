'use strict'
const Writer = require('../../../Utils/Writer')

class LobbyInfoMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 23457
    this.player = player
  }

  encode () {
    this.writeVint(1)
    this.writeString()
    this.writeVint(0)
  }
}

module.exports = LobbyInfoMessage
