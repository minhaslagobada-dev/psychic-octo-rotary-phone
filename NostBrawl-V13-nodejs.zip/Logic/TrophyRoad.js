'use strict'

const Characters = require('../Files/CsvLogic/Characters')
const { readDictRows } = require('../Files/CsvLogic/CsvRows')
const Random = require('../Utils/Random')
const { apply_box_opening } = require('./BoxService')
const { RewardError, RewardTransaction } = require('./Rewards')

const REWARD_TYPES = {
  1: 'coins',
  3: 'brawler',
  6: 'box',
  7: 'tickets',
  9: 'tokenDoublers',
  10: 'box',
  12: 'powerPoints',
  13: 'event',
  14: 'box'
}
const BOX_TYPES = { 6: 10, 10: 11, 14: 12 }

function toInteger (value) {
  if (typeof value === 'bigint') {
    return Number(value)
  }
  const parsed = Number(value)
  if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
    return null
  }
  return Math.trunc(parsed)
}

function _load_rewards () {
  const rewards = []
  const values = []
  for (const row of readDictRows('GameAssets/csv_logic/milestones.csv')) {
    if (row.Type !== '6') {
      continue
    }
    try {
      const primaryType = parseInt(row.PrimaryLvlUpRewardType, 10)
      const rewardType = REWARD_TYPES[primaryType]
      if (rewardType === undefined) {
        throw new TypeError('unknown reward type')
      }
      let value
      if (rewardType === 'brawler') {
        value = Characters.get_brawler_id_by_name(row.PrimaryLvlUpRewardHero)
      } else if (rewardType === 'box') {
        value = BOX_TYPES[primaryType]
      } else if (rewardType === 'event') {
        value = parseInt(row.PrimaryLvlUpRewardExtraData || '0', 10)
      } else {
        value = parseInt(row.PrimaryLvlUpRewardCount || '0', 10)
      }
      if (value === undefined || value === null || Number.isNaN(value)) {
        throw new TypeError('invalid reward value')
      }
      rewards.push(rewardType)
      values.push(value)
    } catch (error) {
      const wrapped = new Error(`Milestone inválido: ${row.Name || '?'}`)
      wrapped.cause = error
      throw wrapped
    }
  }
  if (!rewards.length) {
    throw new Error('Nenhum milestone da Trophy Road foi encontrado')
  }
  return [rewards, values]
}

const [REWARDS, REWARD_VALUES] = _load_rewards()

function _is_unlocked (player, brawler) {
  const states = player.BrawlersUnlockedState
  if (typeof states !== 'object' || states === null || Array.isArray(states)) {
    return false
  }
  const value = states[String(brawler)] !== undefined ? states[String(brawler)] : states[brawler]
  return value === 1
}

function claim (player, brawlerTarget = 0, rng = null) {
  let position = toInteger(player.trophy_road || 0)
  if (position === null) {
    throw new RewardError('Posição da Trophy Road inválida')
  }
  if (position < 1 || position > REWARDS.length) {
    throw new RewardError('Trophy Road concluída ou posição inválida')
  }

  rng = rng || Random
  let rewardType = REWARDS[position - 1]
  const value = REWARD_VALUES[position - 1]
  const transaction = new RewardTransaction(player)
  let boxId = 100
  let boxType = 100

  if (rewardType === 'box') {
    boxType = apply_box_opening(transaction, value, rng)
    boxId = boxType
  } else if (rewardType === 'event') {
    const progression = player.progression || {}
    const unlocked = toInteger(progression.unlockedEvents || 0) || 0
    transaction.set_progression_value('unlockedEvents', unlocked + 1)
  } else if (rewardType === 'brawler') {
    if (_is_unlocked(player, value)) {
      rewardType = 'box'
      boxType = apply_box_opening(transaction, 10, rng)
      boxId = boxType
    } else {
      transaction.add_reward('Brawler', value)
    }
  } else if (rewardType === 'tokenDoublers') {
    transaction.add_reward('tokens_doubler', value)
  } else if (rewardType === 'powerPoints') {
    transaction.add_reward('UpgradePoints', value, brawlerTarget, true)
  } else if (rewardType === 'coins') {
    transaction.add_reward('Coins', value)
  } else if (rewardType === 'tickets') {
    transaction.add_reward('tickets', value)
  } else {
    throw new RewardError(`Recompensa da Trophy Road inválida: ${rewardType}`)
  }

  const nextPosition = position + 1
  transaction.set_value('trophy_road', 'leagueReward', nextPosition)
  transaction.commit()
  const result = transaction.result(boxId, boxType, nextPosition)
  result.rewardType = rewardType
  result.claimedPosition = position
  return result
}

module.exports = { REWARD_TYPES, BOX_TYPES, REWARDS, REWARD_VALUES, claim }
