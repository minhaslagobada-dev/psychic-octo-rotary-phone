'use strict'

const crypto = require('crypto')

const BoxInventory = require('./BoxInventory')
const RewardDelivery = require('./RewardDelivery')
const { RewardError, RewardTransaction } = require('./Rewards')
const ShopCatalog = require('./ShopCatalog')
const ShopService = require('./ShopService')

class BillingService {
  static _transaction_hash (values) {
    const serialized = Buffer.from(
      JSON.stringify(values.map((value) => String(value))), 'utf-8'
    )
    return crypto.createHash('sha256').update(serialized).digest('hex')
  }

  static _experience_level (player) {
    let value = player.experience_level
    if (value === null || value === undefined) {
      value = player.player_experience || 0
    }
    try {
      return Math.max(0, Math.trunc(Number(value || 0)) || 0)
    } catch (error) {
      return 0
    }
  }

  static purchase (player, values, now = null) {
    if (!Array.isArray(values) || values.length !== 6) {
      throw new RewardError('Pedido de billing inválido')
    }
    values = values.map((value) => String(value))
    const billingPackage = ShopCatalog.billing_package(values)
    now = ShopService._timestamp(now)
    const transactionId = BillingService._transaction_hash(values)
    const state = ShopService.get_state(player, now)
    const billing = state.billing
    if (transactionId in billing.transactions) {
      throw new RewardError('Transação de billing já processada')
    }
    const isBundle = [2, 3].includes(billingPackage.type)
    if (isBundle && billingPackage.name in billing.bundles) {
      throw new RewardError('Esse pacote já foi adquirido')
    }
    if (isBundle && BillingService._experience_level(player) < billingPackage.xpLevelReq) {
      throw new RewardError('O nível da conta ainda não libera esse pacote')
    }
    if (billingPackage.bigBoxCount < 0 || billingPackage.bigBoxCount > 10) {
      throw new RewardError('Quantidade de caixas do pacote inválida')
    }
    const transaction = new RewardTransaction(player)
    transaction.add_reward('gems', billingPackage.diamonds, 0, true)
    const rewards = [{ type: 2, amount: billingPackage.diamonds }]
    const storedBoxes = []
    if (billingPackage.bigBoxCount) {
      BoxInventory.add(transaction, 12, billingPackage.bigBoxCount)
      storedBoxes.push({ boxType: 12, amount: billingPackage.bigBoxCount })
    }
    billing.transactions[transactionId] = {
      product: billingPackage.name,
      processedAt: now
    }
    if (isBundle) {
      billing.bundles[billingPackage.name] = {
        transaction: transactionId,
        processedAt: now
      }
    }
    ShopService._save_state(player, state, transaction)
    transaction.commit()
    return {
      package: billingPackage,
      transactionId,
      isBundle,
      rewards,
      storedBoxes,
      responses: RewardDelivery.responses(rewards, storedBoxes)
    }
  }
}

module.exports = BillingService
