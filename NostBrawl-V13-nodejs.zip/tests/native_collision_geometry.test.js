'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const geometry = require('../Native/V13/CollisionGeometry')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'collision-geometry-vectors.json')))
for (const v of vectors) {
  if (v.kind === 'segment' || v.kind === 'circle') {
    const point = geometry[v.kind](v.input)
    assert.equal(point !== null, v.result === 1, JSON.stringify(v))
    assert.deepEqual(point || [-12345, -12345], v.point, JSON.stringify(v))
  } else assert.deepEqual(geometry.rectangle(v.input), { result: v.result, point: v.point }, JSON.stringify(v))
}
console.log('Native collision geometry:', vectors.length, 'cases matched original v13')
