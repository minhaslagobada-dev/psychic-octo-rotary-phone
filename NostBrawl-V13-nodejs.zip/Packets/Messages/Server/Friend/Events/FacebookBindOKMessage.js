'use strict'
const Writer = require('../../../../../Utils/Writer')

class FacebookBindOKMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 24201
    this.player = player
  }

  encode () {
    this.writeInt(0)
  }
}

module.exports = FacebookBindOKMessage
