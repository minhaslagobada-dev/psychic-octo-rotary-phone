'use strict'
// Port of validate_loading_native.py.
// Executes the supplied ARM64 v13 StartLoading decoder, including its actual
// BattlePlayer/LogicLong/String/ByteStream decoders. Only the CSV lookup and
// libc imports are provided by the harness; no packet reads are replaced.
const { NativeV13 } = require('./emulate_v13')
const { RuntimeError, decodeUtf8 } = require('./lib/pycompat')
const R = require('./lib/research')
const { C } = R

class NativeWireError extends RuntimeError {}

R.main(async () => {
  const n = await NativeV13.create()
  n.decrypt()
  const state = {}
  const metadata = new Map()
  const m = R.memory(n)
  const word = m.u32; const pointer = m.u64; const put = m.put32; const pp = m.put64
  const bounds = (uc, access, address, size, value, data) => {
    const start = state.payload === undefined ? -65536 : state.payload
    if (start <= address && address < start + 65536 && address + size > start + state.length) throw new NativeWireError('Native decoder read beyond the packet')
  }
  n.uc.hook_add(C.UC_HOOK_MEM_READ, bounds)
  const lookup = () => {
    const gid = Number(n.uc.reg_read(C.UC_ARM64_REG_W0))
    if (!state.references.has(gid)) throw new NativeWireError('Unexpected native data reference ' + gid)
    if (!metadata.has(gid)) {
      metadata.set(gid, n.alloc(0x200))
      n.uc.mem_write(metadata.get(gid), Buffer.alloc(0x200))
    }
    return metadata.get(gid)
  }
  n.hooks.set(0xda924, lookup)
  const invalidString = () => {
    throw new NativeWireError(`Native string decoder rejected length ${Number(n.uc.reg_read(C.UC_ARM64_REG_W1))} (maximum ${Number(n.uc.reg_read(C.UC_ARM64_REG_W2))})`)
  }
  n.hooks.set(0x25ee8c, invalidString)

  const vectors = R.vectors('loading-vectors.json')
  let passed = 0; let rejected = 0
  for (const vector of vectors) {
    for (const key of Object.keys(state)) delete state[key]
    metadata.clear(); n.heap = 0x10000000
    const obj = n.alloc(0x98); n.uc.mem_write(obj, Buffer.alloc(0x98))
    n.call(0x18efc4, obj)
    const stream = obj + 0x10
    const raw = Buffer.from(vector.hex, 'hex'); const payload = n.alloc(65536)
    n.uc.mem_write(payload, raw)
    pp(stream + 0x20, payload); put(stream + 0x14, 0); put(stream + 0x18, raw.length); put(stream + 0x10, raw.length)
    const references = new Set([15000000 + vector.mapId])
    for (const entry of vector.entries) { references.add(16000000 + entry.brawler_id); references.add(29000000 + entry.skin_id) }
    Object.assign(state, { payload, length: raw.length, references })
    try {
      n.call(0x20fe1c, obj)

      R.assert(word(stream + 0x14) === raw.length, 'Native decoder left trailing bytes')
      R.assert(word(obj + 0x4c) === vector.entries.length)
      R.assert(word(obj + 0x50) === vector.ownIndex)
      R.assert(word(obj + 0x54) === vector.ownTeam)
      R.assert(word(obj + 0x5c) === vector.loadingType)
      const players = pointer(obj + 0x80)
      R.assert(word(players + 0xc) === vector.entries.length)
      vector.entries.forEach((entry, index) => {
        const player = pointer(pointer(players) + index * 8)
        R.assert(word(player) === entry.high_id, 'Wrong LogicLong high ID')
        R.assert(word(player + 4) === entry.low_id, 'Wrong LogicLong low ID')
        const name = player + 8; const length = word(name + 4)
        const text = decodeUtf8(n.uc.mem_read(length <= 7 ? name + 8 : pointer(name + 8), length))
        R.assert(text === entry.name, 'Name was read at the wrong offset')
        R.assert(word(player + 0x20) === entry.index)
        R.assert(word(player + 0x24) === entry.team)
        R.assert(pointer(player + 0x50) === metadata.get(16000000 + entry.brawler_id))
        R.assert(pointer(player + 0x30) === metadata.get(29000000 + entry.skin_id))
      })
      R.assert(pointer(obj + 0x78) === metadata.get(15000000 + vector.mapId))
      const client = n.alloc(0x200); n.uc.mem_write(client, Buffer.alloc(0x200))
      n.call(0xcf5c4, client, word(obj + 0x5c))
      if (word(client + 12) !== vector.entries.length) throw new NativeWireError('Loading category allocates the wrong number of native slots')
      if (vector.invalid) R.assert(false, 'Broken loading packet was accepted')
      passed += 1
    } catch (e) {
      if (!(e instanceof NativeWireError)) throw e
      if (!vector.invalid) { R.print('FAILED:', vector.name); throw e }
      rejected += 1
    }
  }
  R.print('Native v13 StartLoading decode passed:', passed, 'vectors;', rejected, 'malformed/legacy packets rejected')
})
