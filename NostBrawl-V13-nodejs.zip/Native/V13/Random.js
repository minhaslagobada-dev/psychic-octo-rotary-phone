'use strict'
// Original native 0x2880b8: ASR in the second XOR is intentional.
function nextInt (state, bound) {
  state |= 0
  bound |= 0
  if (bound < 1) return { value: 0, nextState: state }
  let nextState = state === 0 ? -1 : state
  nextState ^= nextState << 13
  nextState ^= nextState >> 17
  nextState ^= nextState << 5
  const magnitude = nextState < 0 ? (-nextState | 0) : nextState
  const quotient = Math.trunc(magnitude / bound) | 0
  return { value: (magnitude - Math.imul(quotient, bound)) | 0, nextState }
}
module.exports = { nextInt }
