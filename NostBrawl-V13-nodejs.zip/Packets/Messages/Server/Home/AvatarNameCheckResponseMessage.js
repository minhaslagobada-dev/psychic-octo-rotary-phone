'use strict'

const Writer = require('../../../../Utils/Writer')

class AvatarNameCheckResponseMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 20300
    this.player = player
  }

  encode () {
    this.writeVint(0)
    this.writeInt(0)
    this.writeString(this.player.name)
  }
}

module.exports = AvatarNameCheckResponseMessage
