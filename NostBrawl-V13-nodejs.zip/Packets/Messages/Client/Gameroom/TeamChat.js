'use strict'
const TeamChatMessage = require('./TeamChatMessage')

class TeamChat extends TeamChatMessage {
}

module.exports = TeamChat
