'use strict'

const Config = require('../Utils/Config')

// Configuração da Lakey Store: bloco "Store" do config.json principal.
// Defaults seguros permitem subir o site mesmo sem bot configurado.

const DEFAULTS = {
  Enabled: true,
  PublicUrl: 'http://kg-bsz01.altare.global:25086',
  Port: 25086,
  BotToken: '',
  // Quem faz polling do bot: true = este processo, false = nunca aqui,
  // 'auto' = só no modo embedded (em 'agent' o site externo é o dono).
  BotPolling: 'auto',
  AdminIds: [],
  StarCents: 40,
  DatabasePath: 'Database/store.sqlite',
  CatalogPath: 'JSON/store_catalog.json',
  SessionDays: 30,
  Mode: 'embedded',
  InternalPort: 25087,
  InternalKey: '',
  SiteInternalUrl: '',
  TicketMinutes: 5
}

class StoreConfig {
  static _cache = null

  static load () {
    if (StoreConfig._cache !== null) {
      return StoreConfig._cache
    }
    let raw = {}
    try {
      raw = Config.GetValue().Store || {}
    } catch (error) {
      raw = {}
    }
    if (typeof raw !== 'object' || raw === null || Array.isArray(raw)) {
      raw = {}
    }
    const config = Object.assign({}, DEFAULTS, raw)
    config.Port = StoreConfig._int(config.Port, DEFAULTS.Port)
    config.StarCents = Math.max(1, StoreConfig._int(config.StarCents, DEFAULTS.StarCents))
    config.AdminIds = (Array.isArray(config.AdminIds) ? config.AdminIds : [])
      .map((id) => StoreConfig._int(id, 0))
      .filter((id) => id > 0)
    config.SessionDays = Math.max(1, StoreConfig._int(config.SessionDays, DEFAULTS.SessionDays))
    config.InternalPort = StoreConfig._int(config.InternalPort, DEFAULTS.InternalPort)
    config.InternalKey = String(config.InternalKey || '')
    config.SiteInternalUrl = String(config.SiteInternalUrl || '').replace(/\/+$/, '')
    config.TicketMinutes = Math.max(1, StoreConfig._int(config.TicketMinutes, DEFAULTS.TicketMinutes))
    config.Mode = config.Mode === 'agent' ? 'agent' : 'embedded'
    config.PublicUrl = String(config.PublicUrl || DEFAULTS.PublicUrl).replace(/\/+$/, '')
    config.BotToken = String(config.BotToken || '')
    config.BotPolling = (raw.BotPolling === true || raw.BotPolling === false)
      ? raw.BotPolling
      : 'auto'
    config.DatabasePath = String(config.DatabasePath || DEFAULTS.DatabasePath)
    config.CatalogPath = String(config.CatalogPath || DEFAULTS.CatalogPath)
    config.Enabled = raw.Enabled !== undefined ? !!raw.Enabled : DEFAULTS.Enabled
    StoreConfig._cache = config
    return config
  }

  static _int (value, fallback) {
    const parsed = Number(value)
    if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
      return fallback
    }
    return Math.trunc(parsed)
  }
}

module.exports = StoreConfig
