'use strict'
const { configureAttack } = require('./AttackSetup')
const { turnToward } = require('./Aim')
const { castingRangeBonus } = require('./SkillRange')
const { stepIdleSkill } = require('./SkillIdle')
const number = (d, name) => Number(d[name]) || 0
const yes = value => value === true || value === 'true'
const div = (a, b) => b === 0 ? 0 : Math.trunc(a / b) | 0
// Verified Attack setup branch without attached spawns of native SkillServer::tick.
// This is intentionally not exported as a complete SkillServer: attached
// summons/areas/items and other behaviors require their own native routines.
function stepAttackSkillSetup (state, owner, context, elapsedMs = 50) {
  const d = state.definition
  if (d.BehaviorType !== 'Attack' || ['SummonedCharacter', 'AreaEffectObject', 'AreaEffectObject2', 'SpawnedItem'].some(key => d[key])) {
    throw new Error('Skill requires native behavior or attached-object execution outside the attack setup branch')
  }
  if (context.mode === 11) throw new Error('Mode 11 native range modifier has not been reconstructed')
  state.pending = 0
  if (state.executing) {
    if (yes(d.Targeted)) turnToward(owner, state.target)
    if (owner.castingMs > 0) return state
    if (state.slot === 1) {
      if (owner.player) { owner.player.superCharge = 0; owner.u8['0x2f9'] = 0 }
      owner.u8['0x2fb'] = 1
      owner.skills[0].cooldownMs = (state.activeMs + number(owner.skills[0].definition, 'Cooldown')) | 0
      owner.skills[1].cooldownMs = (state.activeMs + number(owner.skills[1].definition, 'Cooldown')) | 0
    } else owner.skills[0].cooldownMs = (state.activeMs + number(d, 'Cooldown')) | 0
    if (number(d, 'MaxCharge') >= 1) state.ammo = (state.ammo - Math.imul(state.consumed, 1000)) | 0
    configureAttack(owner, { target: state.target, bonusDamage: Math.imul(div(number(d, 'Damage'), 20), state.level),
      range: number(d, 'CastingRange'), rangeBonus: castingRangeBonus(d, owner.i32['0x2fc'] < 0 ? 0 : (context.tick - owner.i32['0x2fc']) | 0), attackCount: Math.imul(state.consumed, div(number(d, 'ActiveTime'), number(d, 'MsBetweenAttacks'))),
      damage: number(d, 'Damage'), attackIntervalMs: number(d, 'MsBetweenAttacks'), spread: number(d, 'Spread'),
      pattern: number(d, 'AttackPattern'), bullets: number(d, 'NumBulletsInOneAttack'), projectile: state.projectile,
      executeFirstImmediately: yes(d.ExecuteFirstAttackImmediately), twoGuns: yes(d.TwoGuns), isSuper: state.slot === 1 }, context.tick)
    state.executing = 0
  }
  owner.ownerAttack = owner.u8['0x188'] || 0
  owner.ownerSlot = owner.i32['0x2fc']
  stepIdleSkill(state, { behavior: 0, rechargeTime: number(d, 'RechargeTime'), maxCharge: number(d, 'MaxCharge') }, owner, context, elapsedMs)
  owner.u8['0x188'] = owner.ownerAttack
  owner.i32['0x2fc'] = owner.ownerSlot
  return state
}
module.exports = { stepAttackSkillSetup }
