'use strict'
// Measures UDP transport only. This is NOT a gameplay or client rendering test.
const assert = require('node:assert/strict')
const dgram = require('node:dgram')
const { performance, monitorEventLoopDelay } = require('node:perf_hooks')
const { BattleTransport } = require('../Logic/Battle/Network/BattleTransport')
const { encodeInput, envelope, readEnvelope } = require('../Logic/Battle/Network/V13BattleCodec')
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))

async function main () {
  const count = Number(process.argv[2] || 200)
  const seconds = Number(process.argv[3] || 5)
  assert(Number.isInteger(count) && count > 0 && count <= 1000)
  assert(Number.isInteger(seconds) && seconds >= 1 && seconds <= 60)
  const transport = new BattleTransport({ BindIP: '127.0.0.1', Port: 0, MaxPlayers: count, SessionTimeoutMs: 30000 })
  const peers = []; const sessions = []; const errors = []
  const received = new Uint32Array(count)
  transport.on('transportError', error => errors.push(error.message))
  // Echo is solely a transport oracle; no fabricated VisionUpdate is produced.
  transport.on('input', (session, input) => {
    session.input.drain()
    transport.send(session, 10555, encodeInput(input))
  })
  const lag = monitorEventLoopDelay({ resolution: 10 })
  let sent = 0
  try {
    await transport.start()
    for (let i = 0; i < count; i++) {
      const peer = dgram.createSocket('udp4'); peers.push(peer)
      peer.on('error', error => errors.push(error.message))
      await new Promise(resolve => peer.bind(0, '127.0.0.1', resolve))
      const player = { low_id: i + 1, logged_in: true }
      const session = transport.attach(player, { remoteAddress: '127.0.0.1', localAddress: '127.0.0.1' })
      sessions.push(session)
      peer.on('message', packet => {
        try {
          assert.deepEqual(packet.subarray(0, 10), session.header)
          assert.equal(readEnvelope(packet.subarray(10)).type, 10555)
          received[i]++
        } catch (error) { errors.push(error.message) }
      })
    }
    lag.enable()
    const start = performance.now()
    for (let tick = 0; tick < seconds * 20; tick++) {
      const payload = envelope(10555, encodeInput({ tick, sequence: tick, inputs: [{ counter: tick, category: 1, code: 100, x: 1500, y: 1500 }] }))
      for (let i = 0; i < count; i++) {
        peers[i].send(Buffer.concat([sessions[i].header, payload]), transport.gateway.port, '127.0.0.1', error => { if (error) errors.push(error.message) })
        sent++
      }
      await sleep(Math.max(0, start + (tick + 1) * 50 - performance.now()))
    }
    // UDP can legitimately lose packets; record delivery rather than asserting 100%.
    await sleep(250)
    lag.disable()
    const delivered = received.reduce((sum, n) => sum + n, 0)
    assert.equal(errors.length, 0, JSON.stringify(errors))
    assert.equal(Array.from(received).filter(n => n === 0).length, 0, 'Every peer must receive replies')
    assert(delivered / sent >= 0.99, 'Local delivery must be at least 99%')
    assert.equal(transport.gateway.sessions.size, count)
    const metrics = {
      scope: 'UDP transport, not combat capacity', peers: count, hz: 20, seconds,
      sent, received: delivered, deliveryPercent: Number((100 * delivered / sent).toFixed(3)),
      eventLoopP99Ms: Number((lag.percentile(99) / 1e6).toFixed(3)),
      rssMiB: Number((process.memoryUsage().rss / 1048576).toFixed(2)),
      gateway: transport.gateway.metrics
    }
    await transport.close()
    assert.equal(transport.gateway.sessions.size, 0)
    assert.equal(transport.gateway.owners.size, 0)
    console.log(JSON.stringify(metrics, null, 2))
  } finally {
    lag.disable()
    for (const peer of peers) { try { peer.close() } catch (_) {} }
    await transport.close()
  }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
