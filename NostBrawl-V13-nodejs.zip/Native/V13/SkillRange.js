'use strict'
// Native 0x378534. The divisor 40 is an original ELF constant at0x82bc7c.
// The native function caps only the upper bound of elapsed aim ticks.
function castingRangeBonus (definition, elapsedAimTicks) {
  const maximum = Number(definition.MaxCastingRange) || 0
  if (maximum < 1) return 0
  const range = Number(definition.CastingRange) || 0
  const elapsed = Math.min(40, elapsedAimTicks | 0)
  return Math.trunc(Math.imul(Math.imul((maximum - range) | 0, elapsed), 100) / 40) | 0
}
module.exports = { castingRangeBonus }
