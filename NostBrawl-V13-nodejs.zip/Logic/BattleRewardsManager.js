'use strict'

const DataBase = require('../Database/DatabaseManager')
const { DailyRewards } = require('./DailyRewards')
const { EventRotation } = require('./EventRotation')
const Milestones = require('./Milestones')
const { RewardTransaction, RewardError } = require('./Rewards')

function deepCopy (value) {
  if (value === null || value === undefined) return value
  return JSON.parse(JSON.stringify(value))
}

class BattleRewardsManager {
  static get SPECIAL_MODES () { return new Set([3, 4, 6]) }

  constructor (player, db = null) {
    this.player = player
    this.db = db
    this.milestones = Milestones
    this._pending_transaction = null
  }

  static get_trophy_modifiers (trophies) {
    const ranges = [
      [0, 29, [0, 0, 6]], [30, 59, [-1, 0, 6]],
      [60, 99, [-2, 0, 6]], [100, 139, [-2, 0, 5]],
      [140, 219, [-3, 0, 5]], [220, 299, [-4, 0, 5]],
      [300, 499, [-5, 0, 5]], [500, 599, [-6, 0, 5]],
      [600, 699, [-7, 0, 4]], [700, 799, [-7, 0, 3]],
      [800, 899, [-8, 0, 3]], [900, Infinity, [-9, 0, 2]]
    ]
    for (const [low, high, modifiers] of ranges) {
      if (trophies >= low && trophies <= high) {
        return modifiers
      }
    }
    return [0, 0, 0]
  }

  static get_solo_trophy_modifiers (trophies) {
    const ranges = [
      [0, 29, [8, 7, 6, 5, 5, 4, 3, 2, 1, 0]],
      [30, 59, [8, 7, 6, 4, 3, 2, 0, -1, -2, -4]],
      [60, 99, [8, 7, 5, 4, 3, 1, 0, -2, -3, -4]],
      [100, 139, [7, 6, 5, 3, 2, 1, -1, -2, -3, -4]],
      [140, 219, [7, 6, 4, 3, 2, 0, -1, -3, -4, -5]],
      [220, 299, [7, 6, 4, 3, 1, 0, -2, -3, -4, -5]],
      [300, 499, [7, 6, 4, 2, 1, -1, -2, -4, -6, -7]],
      [500, 599, [6, 5, 3, 2, 0, -2, -3, -4, -6, -7]],
      [600, 699, [5, 4, 3, 1, -1, -2, -3, -4, -6, -7]],
      [700, Infinity, [5, 3, 2, 1, -1, -2, -4, -5, -6, -7]]
    ]
    for (const [low, high, values] of ranges) {
      if (trophies >= low && trophies <= high) {
        return values
      }
    }
    return [0, 0, 0, 0, 0, 0, 0, 0, 0, 0]
  }

  static get_duo_trophy_modifiers (trophies) {
    const ranges = [
      [0, 29, [7, 5, 4, 2, 0]], [30, 59, [7, 5, 2, -1, -3]],
      [60, 99, [7, 4, 2, -1, -4]], [100, 139, [6, 4, 1, -1, -4]],
      [140, 219, [6, 4, 1, -2, -5]], [220, 499, [6, 3, 0, -3, -6]],
      [500, 599, [6, 3, 0, -4, -6]], [600, 699, [4, 2, -1, -4, -6]],
      [700, 799, [3, 1, -1, -4, -6]], [800, 899, [3, 1, -2, -5, -7]],
      [900, Infinity, [2, 0, -3, -5, -7]]
    ]
    for (const [low, high, values] of ranges) {
      if (trophies >= low && trophies <= high) {
        return values
      }
    }
    return [0, 0, 0, 0, 0]
  }

  static _brawler_from_fields (player, fields) {
    try {
      return Math.trunc(fields.Heroes[0].Brawler.ID[1])
    } catch (error) {
      return Math.trunc(player.brawler_id || 0)
    }
  }

  static _normalize_result (result) {
    const normalized = deepCopy(result)
    const experience = normalized.exp_rewards_array || {}
    const mapped = {}
    for (const [key, value] of Object.entries(experience)) {
      mapped[Math.trunc(key)] = Math.trunc(value)
    }
    normalized.exp_rewards_array = mapped
    return normalized
  }

  static _sync_replayed_state (source, target) {
    for (const attribute of [
      'brawlers_trophies', 'brawlers_trophies_in_rank', 'trophies',
      'highest_trophies', 'player_experience', 'tokensdoubler',
      'battle_tokens', 'brawl_boxes', 'big_boxes', 'solo_wins',
      'duo_wins', 'ThreeVSThree_wins', 'progression', 'star_points',
      'tokensAnim', 'trophiesAnim', 'bigTokensAnim'
    ]) {
      if (source[attribute] !== undefined) {
        target[attribute] = deepCopy(source[attribute])
      }
    }
  }

  process_rewards (fields, battleId = null, now = null) {
    if (!battleId) {
      return this._apply_rewards(fields)
    }
    const lowId = Math.trunc(this.player.low_id || 0)
    if (lowId <= 0 || !(this.player.token || '')) {
      throw new RewardError('Conta não autenticada para recompensa persistente')
    }
    const gameMode = Math.trunc(fields.GameMode !== undefined ? fields.GameMode : 0)
    let transaction = null
    let replayed = false
    let result
    let canonical

    DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const row = connection.prepare(
        'SELECT rewards_json, game_mode FROM battle_reward_ledger ' +
        'WHERE player_id = ? AND battle_id = ?'
      ).get(lowId, String(battleId))
      canonical = Object.assign(Object.create(Object.getPrototypeOf(this.player)), this.player)
      const loaded = DataBase._load_account_from_connection(connection, canonical)
      if (!loaded) {
        throw new RewardError('Conta não encontrada no SQLite')
      }

      if (row !== undefined && row.rewards_json !== null) {
        if (Math.trunc(row.game_mode) !== gameMode) {
          throw new RewardError('Modo divergente no ledger da partida')
        }
        let stored
        try {
          stored = JSON.parse(row.rewards_json)
        } catch (error) {
          throw new RewardError('Resultado persistido da partida inválido')
        }
        if (typeof stored !== 'object' || stored === null || Array.isArray(stored)) {
          throw new RewardError('Resultado persistido da partida inválido')
        }
        result = BattleRewardsManager._normalize_result(stored)
        replayed = true
      } else {
        if (row === undefined) {
          const timestamp = Math.floor(Date.now() / 1000)
          connection.prepare(
            'INSERT INTO battle_reward_ledger (' +
            'player_id, battle_id, game_mode, created_at, updated_at' +
            ') VALUES (?, ?, ?, ?, ?)'
          ).run(lowId, String(battleId), gameMode, timestamp, timestamp)
        } else if (![-1, gameMode].includes(Math.trunc(row.game_mode))) {
          throw new RewardError('Modo divergente no ledger da partida')
        }

        const manager = new BattleRewardsManager(canonical, this.db)
        result = manager._apply_rewards(fields, battleId, connection, now)
        transaction = manager._pending_transaction
        const timestamp = Math.floor(Date.now() / 1000)
        const cursor = connection.prepare(
          'UPDATE battle_reward_ledger SET rewards_json = ?, ' +
          'game_mode = ?, updated_at = ?, completed_at = ? ' +
          'WHERE player_id = ? AND battle_id = ?'
        ).run(
          JSON.stringify(result),
          gameMode, timestamp, timestamp, lowId, String(battleId)
        )
        if (cursor.changes !== 1) {
          throw new RewardError('Falha ao concluir o ledger da partida')
        }
      }
    }, true)

    if (replayed) {
      BattleRewardsManager._sync_replayed_state(canonical, this.player)
      result._replayed = true
    } else if (transaction !== null) {
      transaction.finalize(this.player)
    }
    return result
  }

  _apply_rewards (fields, battleId = null, connection = null, now = null) {
    this._pending_transaction = null
    const player = this.player
    const gameMode = Math.trunc(fields.GameMode !== undefined ? fields.GameMode : 0)
    const rank = Math.trunc(fields.Rank !== undefined && fields.Rank !== null ? fields.Rank : (player.rank || 1)) || 0
    const victory = Math.trunc(fields.Victory !== undefined && fields.Victory !== null ? fields.Victory : (player.battle_result || 0)) || 0
    const baseResult = Math.trunc(fields.result !== undefined && fields.result !== null ? fields.result : (player.result !== undefined ? player.result : 16)) || 0
    const brawler = BattleRewardsManager._brawler_from_fields(player, fields)
    const key = String(brawler)
    const tutorial = Math.trunc(player.tutorial !== undefined ? player.tutorial : (player.tutorialState !== undefined ? player.tutorialState : 2))
    const practice = fields.Practice === true
    const isTutorialComplete = tutorial === 2 && !practice
    const special = BattleRewardsManager.SPECIAL_MODES.has(gameMode)

    const trophies = player.brawlers_trophies || {}
    const highest = player.brawlers_trophies_in_rank || {}
    const oldTrophies = Math.trunc(trophies[key] || 0)
    const oldHighest = Math.trunc(highest[key] || 0)
    const oldExperience = Math.trunc(player.player_experience || 0)
    let oldBattleTokens = Math.max(0, Math.trunc(player.battle_tokens || 0))

    let rankTrophies
    let rewardIndex
    let expRewards
    let tokenRewards
    let hasStarKey = false
    if (gameMode === 2) {
      if (!(rank >= 1 && rank <= 10)) {
        throw new RewardError('Rank solo inválido')
      }
      rankTrophies = BattleRewardsManager.get_solo_trophy_modifiers(oldTrophies)
      rewardIndex = rank - 1
      expRewards = [0, 1, 2, 3, 4, 5, 6, 9, 12, 15]
      tokenRewards = [0, 2, 4, 6, 8, 12, 16, 22, 28, 34]
      hasStarKey = rank <= 4
    } else if (gameMode === 5) {
      if (!(rank >= 1 && rank <= 5)) {
        throw new RewardError('Rank duo inválido')
      }
      rankTrophies = BattleRewardsManager.get_duo_trophy_modifiers(oldTrophies)
      rewardIndex = rank - 1
      expRewards = [0, 2, 4, 8, 14]
      tokenRewards = [0, 4, 8, 20, 32]
      hasStarKey = rank <= 2
    } else if (special) {
      if (![0, 1, 2].includes(victory)) {
        throw new RewardError('Resultado de evento inválido')
      }
      rankTrophies = [0, 0, 0]
      rewardIndex = victory - 1
      expRewards = [0, 0, 0]
      tokenRewards = [0, 0, 0]
      hasStarKey = true
    } else {
      if (![0, 1, 2].includes(victory)) {
        throw new RewardError('Resultado 3v3 inválido')
      }
      rankTrophies = BattleRewardsManager.get_trophy_modifiers(oldTrophies)
      rewardIndex = victory - 1
      expRewards = [4, 6, 8]
      tokenRewards = [10, 15, 20]
      hasStarKey = victory === 0
    }

    // Python negative index semantics: victory=0 → reward_index=-1 → last entry
    const pick = (list, index) => list[((index % list.length) + list.length) % list.length]
    let trophiesGain = isTutorialComplete ? pick(rankTrophies, rewardIndex) : 0
    let experience = isTutorialComplete ? pick(expRewards, rewardIndex) : 0
    const requestedTokens = isTutorialComplete ? pick(tokenRewards, rewardIndex) : 0

    let isPlayer
    try {
      isPlayer = Boolean(fields.Heroes[0].IsPlayer)
    } catch (error) {
      isPlayer = true
    }
    let starPlayerExp
    let expRewardsArray
    const nativeMvpKnown = typeof fields.IsMvp === 'boolean'
    if (nativeMvpKnown) {
      starPlayerExp = fields.IsMvp && !special && isTutorialComplete ? 10 : 0
      expRewardsArray = { 0: experience }
      if (starPlayerExp) expRewardsArray[8] = starPlayerExp
    } else if (isPlayer) {
      if (special) {
        starPlayerExp = 0
      } else {
        experience += isTutorialComplete ? 10 : 0
        starPlayerExp = isTutorialComplete ? 10 : 0
      }
      expRewardsArray = { 0: experience, 8: starPlayerExp }
    } else {
      starPlayerExp = 0
      expRewardsArray = { 0: experience }
    }

    const doubler = Math.max(0, Math.trunc(player.tokensdoubler || 0))
    let daily = null
    let tokensGain
    let doubledTokens
    let totalTokens
    let remainingTokens
    let remainingBattleTokens
    if (connection !== null && connection !== undefined && !practice) {
      const lowId = Math.trunc(player.low_id || 0)
      const moment = DailyRewards._moment(now)
      daily = DailyRewards.consume(connection, lowId, requestedTokens, doubler, moment)
      oldBattleTokens = daily.old_battle_tokens
      tokensGain = daily.tokens_gain
      doubledTokens = daily.doubled_tokens
      totalTokens = daily.total_tokens
      remainingTokens = daily.remaining_doubler
      remainingBattleTokens = daily.battle_tokens
      const event = EventRotation.battle_event(
        fields.MapID !== undefined ? fields.MapID : (player.map_id || 0),
        fields.MapSlot !== undefined ? fields.MapSlot : (player.locationID || 0),
        moment
      )
      hasStarKey = DailyRewards.claim_star(
        connection,
        lowId,
        fields.MapID !== undefined ? fields.MapID : (player.map_id || 0),
        battleId,
        hasStarKey && isTutorialComplete && event !== null && event !== undefined,
        moment
      )
    } else {
      tokensGain = Math.min(requestedTokens, oldBattleTokens)
      doubledTokens = Math.min(tokensGain, doubler)
      remainingTokens = doubler - doubledTokens
      totalTokens = tokensGain + doubledTokens
      remainingBattleTokens = oldBattleTokens - tokensGain
      hasStarKey = false
    }

    let resultType = baseResult
    if (hasStarKey && (baseResult !== 0 || special)) {
      resultType += 1
    }
    if (oldBattleTokens <= 0) {
      resultType += 4
    }
    if (oldExperience >= Math.trunc(player.max_experience !== undefined ? player.max_experience : 145630)) {
      resultType += 2
    }
    let starplayer
    if (nativeMvpKnown) {
      starplayer = fields.IsMvp ? 1 : 0
    } else if ([0, 1].includes(gameMode)) {
      if ([0, 2].includes(victory)) {
        starplayer = resultType >= 0 && resultType <= 15 ? 1 : 5
      } else {
        starplayer = 1
      }
    } else {
      starplayer = 1
    }

    const result = {
      tokens_gain: tokensGain,
      requested_tokens: requestedTokens,
      trophies_gain: trophiesGain,
      doubled_tokens: doubledTokens,
      remaining_tokens: remainingTokens,
      total_tokens: totalTokens,
      exp_rewards_array: expRewardsArray,
      brawler_trophies: oldTrophies,
      brawler_trophies_for_rank: oldHighest,
      experience,
      star_player_exp: starPlayerExp,
      hasStarKey: hasStarKey,
      brawler_id: brawler,
      milestonesRewardRank: 0,
      result: resultType,
      starplayer,
      old_experience: oldExperience,
      old_battle_tokens: oldBattleTokens,
      battle_tokens: remainingBattleTokens
    }
    if (daily !== null && daily !== undefined) {
      result.daily_token_day = daily.day
      result.daily_tokens_used = daily.used
      result.daily_tokens_remaining = daily.remaining
    }
    if (!isTutorialComplete) {
      return result
    }

    const newBrawlerTrophies = Math.max(0, oldTrophies + trophiesGain)
    trophiesGain = newBrawlerTrophies - oldTrophies
    result.trophies_gain = trophiesGain
    const newTotalTrophies = Math.max(
      0, Math.trunc(player.trophies || 0) + trophiesGain
    )
    const newHighest = Math.max(oldHighest, newBrawlerTrophies)
    for (const milestone of this.milestones.rankTrophies) {
      if (oldTrophies < milestone && milestone <= newBrawlerTrophies) {
        result.milestonesRewardRank = 10
      }
    }

    const transaction = new RewardTransaction(player)
    const newTrophies = deepCopy(trophies) || {}
    newTrophies[key] = newBrawlerTrophies
    transaction.set_value('brawlers_trophies', 'brawlersTrophies', newTrophies)
    const newRank = deepCopy(highest) || {}
    newRank[key] = newHighest
    transaction.set_value(
      'brawlers_trophies_in_rank', 'brawlersTrophiesForRank', newRank
    )
    transaction.set_value('trophies', 'trophies', newTotalTrophies)
    transaction.set_value(
      'highest_trophies', 'highest_trophies',
      Math.max(Math.trunc(player.highest_trophies || 0), newTotalTrophies)
    )
    transaction.set_value(
      'player_experience', 'playerExp', oldExperience + experience + starPlayerExp
    )
    transaction.set_value('tokensdoubler', 'tokensdoubler', remainingTokens)
    transaction.set_value('battle_tokens', 'battleTokens', remainingBattleTokens)
    transaction.set_value(
      'brawl_boxes', 'brawlBoxes',
      Math.trunc(player.brawl_boxes || 0) + totalTokens
    )
    transaction.set_value(
      'big_boxes', 'bigBoxes',
      Math.trunc(player.big_boxes || 0) + (hasStarKey ? 1 : 0)
    )
    if (!special) {
      if (gameMode === 2 && rank === 1) {
        transaction.set_value(
          'solo_wins', 'soloWins', Math.trunc(player.solo_wins || 0) + 1
        )
      } else if (gameMode === 5 && rank === 1) {
        transaction.set_value(
          'duo_wins', 'duoWins', Math.trunc(player.duo_wins || 0) + 1
        )
      } else if ([0, 1].includes(gameMode) && victory === 0) {
        transaction.set_value(
          'ThreeVSThree_wins', 'TvsTWins',
          Math.trunc(player.ThreeVSThree_wins || 0) + 1
        )
      }
    }
    transaction.set_progression_value('keyReward', totalTokens)
    transaction.set_progression_value('trophyReward', trophiesGain)
    transaction.set_progression_value('starKeyReward', hasStarKey ? 1 : 0)
    transaction.commit(connection)
    if (connection !== null && connection !== undefined) {
      this._pending_transaction = transaction
    }
    return result
  }
}

module.exports = { BattleRewardsManager }
module.exports.default = BattleRewardsManager
