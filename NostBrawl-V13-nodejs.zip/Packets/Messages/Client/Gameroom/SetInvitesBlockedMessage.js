'use strict'
const DataBase = require('../../../../Database/DatabaseManager')
const SetInvitesBlockedOkMessage = require('../../Server/Gameroom/SetInvitesBlockedOkMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class SetInvitesBlockedMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.blocked = false
  }

  decode () {
    this.blocked = this.read_boolean()
    this.ensure_end()
  }

  process () {
    this.player.do_not_distrub = this.blocked ? 1 : 0
    DataBase.replaceValue(this, 'DoNotDistrub', this.player.do_not_distrub)
    new SetInvitesBlockedOkMessage(this.client, this.player).send()
    return this.blocked
  }
}

module.exports = SetInvitesBlockedMessage
