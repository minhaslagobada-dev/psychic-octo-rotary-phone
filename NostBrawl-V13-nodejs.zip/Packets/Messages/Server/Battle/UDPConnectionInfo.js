'use strict'
const Writer = require('../../../../Utils/Writer')

class UDPConnectionInfo extends Writer {
  constructor (client, player) {
    super(client)
    this.enable_native_v13()
    this.id = 24112
    this.player = player
  }

  encode () {
    const transport = this.player.battleTransport
    const session = this.player.udp_session
    if (!transport || !session || session.closed) throw new Error('UDPConnectionInfo requires a live v13 session')
    this.writeVint(transport.gateway.port)
    this.writeString(session.host)
    this.writeInt(session.header.length)
    this.writeBytes(session.header)
    // A zero-length key explicitly selects the native unencrypted UDP path.
    this.writeInt(0)
  }
}

module.exports = UDPConnectionInfo
