'use strict'
// Port of probe_battle_earned_super.py.
// Automated human input only; all movement/damage/charge/Super rules are native.
//
// The test client chooses a nearby enemy, moves into range, and presses attack or
// Super through original client encoding and server decoding. HP/charge/positions
// are never assigned by the driver. This policy is not a runtime bot replacement.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const { pyInt } = require('./lib/pycompat')
const { minBy, hypot } = require('./lib/battle_probe')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x8000000, reclaim_memory: true, instruction_counting: false, timeout_us: 2000000 }); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const result = { checkpoints: [], inputPackets: 0, superObserved: false, superInputs: [] }
  try {
    const battle = new NativeBattle(data, 'Gemgrab1'); battle.add_player('ShotgunGirl', 0); battle.setup(); let counter = 1
    const limit = Number(pyInt(process.env.V13_EARNED_SUPER_TICKS || '1800'))
    let index
    for (index = 0; index < limit; index++) {
      let state = battle.describe(); const human = state.players[0]; const own = state.objects.find(o => o.id === human.characterId) || null
      if (index % 10 === 2 && own && (own.hp ?? 0) > 0) {
        const enemies = state.objects.filter(o => state.players.some(p => p.characterId === o.id && p.team !== human.team) && (o.hp ?? 0) > 0)
        if (enemies.length) {
          const target = minBy(enemies, o => (o.x - own.x) ** 2 + (o.y - own.y) ** 2)
          const dx = own.x - target.x; const dy = own.y - target.y; const distance = Math.max(1, hypot(dx, dy)); const commands = []
          if (distance > 1400) commands.push({ code: 100, x: Math.trunc(target.x + dx * 1200 / distance), y: Math.trunc(target.y + dy * 1200 / distance) })
          if (distance <= 2200) {
            if (human.superCharge === 4000) {
              commands.push({ code: 107 }, { code: 1, targetId: target.id, flag: true })
              result.superInputs.push({ tick: state.tick, charge: human.superCharge, characterId: own.id, targetId: target.id })
            } else commands.push({ code: 108 }, { code: 0, targetId: target.id, flag: true })
          }
          if (commands.length) {
            const packet = battle.encode_input_packet(commands, counter); counter += commands.length; battle.input_packet(0, packet); result.inputPackets += 1
          }
        }
      }
      const vision = battle.frame(); state = battle.describe()
      if (state.objects.some(o => o.dataId === 6000001)) {
        R.assert(result.superInputs.length, 'Super projectile appeared before a charged human command')
        R.assert(state.players[0].superCharge < 4000, 'Super command did not consume charge')
        R.assert(state.objects.filter(o => state.players.some(p => p.bot && p.characterId === o.id)).every(o => o.dataId !== 16000000), 'Another Shelly could produce this projectile')
        result.superObserved = true; state.vision = vision; result.checkpoints.push(state); break
      }
      if ((index + 1) % 100 === 0) {
        state.vision = vision; result.checkpoints.push(state)
        R.print('earned-super tick', state.tick, 'charge', state.players[0].superCharge, 'packets', result.inputPackets)
      }
    }
    if (index === limit) index = limit - 1
    result.framesProcessed = index + 1
    R.print('Original earned Super observed:', result.superObserved, 'after', result.framesProcessed, 'frames')
  } catch (e) {
    result.error = { message: R.errorMessage(e), pc: m.pc(), lr: m.lr() }
    R.print('blocked', result.error)
  }
  R.writeJson('battle-earned-super-vectors.json', result)
  if ('error' in result) throw new R.SystemExit(1)
})
