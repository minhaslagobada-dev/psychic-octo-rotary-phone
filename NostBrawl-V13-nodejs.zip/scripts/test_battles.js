'use strict'
// Existing account tests rewrite SQLite data. Always run them in a disposable
// copy so the server owner's attached databases/configuration stay intact.
const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')
const { spawnSync } = require('node:child_process')
const source = path.resolve(__dirname, '..')
const temp = fs.mkdtempSync(path.join(os.tmpdir(), 'nodebrawl-battle-tests-'))
try {
  fs.cpSync(source, temp, {
    recursive: true,
    filter: entry => {
      const name = path.basename(entry)
      return name !== 'node_modules' && name !== '.git' && !/\.sqlite(?:3)?(?:-wal|-shm)?$/.test(name)
    }
  })
  fs.symlinkSync(path.join(source, 'node_modules'), path.join(temp, 'node_modules'), 'junction')
  const filename = path.join(temp, 'config.json')
  const config = JSON.parse(fs.readFileSync(filename, 'utf8'))
  config.Database = { ...(config.Database || {}), Path: 'Database/players.sqlite' }
  config.DB_PATH = 'Database/players.sqlite'
  config.Store = { ...(config.Store || {}), Enabled: false, BotPolling: false }
  config.SCID = { ...(config.SCID || {}), Enabled: false }
  config.Battle = { Enabled: true, BindIP: '127.0.0.1', Port: 0, AdvertiseHost: '127.0.0.1', MaxPlayers: 200, SessionTimeoutMs: 30000 }
  fs.writeFileSync(filename, JSON.stringify(config, null, 2) + '\n')
  const tests = [
    'tests/battle_maps.test.js',
    'tests/battle_matchmaking.test.js',
    'tests/battle_world.test.js',
    'tests/battle_objectives.test.js',
    'tests/battle_combat.test.js',
    'tests/battle_projectiles.test.js',
    'tests/battle_bodies.test.js',
    'tests/battle_bots.test.js',
    'tests/battle_private_rooms.test.js',
    'tests/battle_result_outbox.test.js',
    'tests/battle_transport.test.js',
    'tests/battle_connection_e2e.test.js',
    'tests/battle_online_e2e.test.js',
    'tests/battle_bot_online_e2e.test.js',
    'tests/battle_tcp_online_e2e.test.js'
  ]
  if (process.argv.includes('--regression')) tests.unshift(
    'tests/crypto.test.js', 'tests/login_e2e.test.js', 'tests/fixtures_roundtrip.test.js',
    'scripts/smoke_economy.js', 'scripts/smoke_social.js', 'scripts/smoke_gameroom.js',
    'scripts/smoke_store.js', 'scripts/smoke_bot.js', 'tests/tcp_e2e.test.js', 'tests/battle_return_e2e.test.js'
  )
  for (const test of tests) {
    const result = spawnSync(process.execPath, [test], { cwd: temp, env: process.env, stdio: 'inherit', timeout: 60000 })
    if (result.error) throw result.error
    if (result.status !== 0) throw new Error(`${test} failed: ${result.signal || result.status}`)
  }
} catch (error) {
  console.error(error)
  process.exitCode = 1
} finally { fs.rmSync(temp, { recursive: true, force: true }) }
