'use strict'

const { RewardError, RewardTransaction } = require('./Rewards')

function toInteger (value) {
  if (typeof value === 'bigint') {
    return Number(value)
  }
  const parsed = Number(value)
  if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
    return null
  }
  return Math.trunc(parsed)
}

function lookup (mapping, key, defaultValue = 0) {
  if (typeof mapping !== 'object' || mapping === null) {
    return defaultValue
  }
  const value = mapping[String(key)] !== undefined ? mapping[String(key)] : mapping[key]
  return value !== undefined ? value : defaultValue
}

class BoxInventory {
  static get STATE_KEY () { return 'boxInventory' }
  static get STATE_VERSION () { return 2 }
  static get BOX_TYPES () { return [10, 11, 12] }
  static get TOKEN_BOXES () {
    return {
      10: ['brawl_boxes', 'brawlBoxes', 100],
      12: ['big_boxes', 'bigBoxes', 10]
    }
  }

  static _normalize (value) {
    let source = (typeof value === 'object' && value !== null) ? value.boxes : {}
    if (typeof source !== 'object' || source === null || Array.isArray(source)) {
      source = {}
    }
    const boxes = {}
    for (const boxType of BoxInventory.BOX_TYPES) {
      const raw = lookup(source, boxType, 0)
      let count
      try {
        count = toInteger(raw || 0)
        if (count === null) {
          count = 0
        }
      } catch (error) {
        count = 0
      }
      boxes[String(boxType)] = Math.max(0, count)
    }
    return { version: BoxInventory.STATE_VERSION, boxes }
  }

  static _balance (source, attribute) {
    try {
      let raw
      if (source instanceof RewardTransaction) {
        raw = source._value(attribute, 0)
      } else {
        raw = source[attribute] !== undefined ? source[attribute] : 0
      }
      return Math.max(0, toInteger(raw || 0) || 0)
    } catch (error) {
      return 0
    }
  }

  static _state (progression) {
    if (typeof progression !== 'object' || progression === null || Array.isArray(progression)) {
      progression = {}
    }
    return BoxInventory._normalize(progression[BoxInventory.STATE_KEY])
  }

  static counts (player) {
    const state = BoxInventory._state(player.progression || {})
    const result = Object.assign({}, state.boxes)
    result['10'] += Math.floor(BoxInventory._balance(player, 'brawl_boxes') / 100)
    result['12'] += Math.floor(BoxInventory._balance(player, 'big_boxes') / 10)
    return result
  }

  static count (player, boxType) {
    boxType = toInteger(boxType)
    if (boxType === null || !BoxInventory.BOX_TYPES.includes(boxType)) {
      throw new RewardError('Tipo de caixa inválido')
    }
    return BoxInventory.counts(player)[String(boxType)]
  }

  static _write (transaction, state) {
    transaction.set_progression_value(BoxInventory.STATE_KEY, state)
  }

  static _migrate_transaction (transaction) {
    const state = BoxInventory._state(transaction.progression)
    for (const [boxType, [attribute, column, cost]] of Object.entries(BoxInventory.TOKEN_BOXES)) {
      const key = String(boxType)
      const legacy = state.boxes[key]
      if (legacy) {
        const balance = BoxInventory._balance(transaction, attribute)
        transaction.set_value(attribute, column, balance + legacy * cost)
        state.boxes[key] = 0
      }
    }
    return state
  }

  static migrate (player) {
    const token = player.token
    if (typeof token !== 'string' || !token || token === 'None') {
      return false
    }
    const state = BoxInventory._state(player.progression || {})
    const required = Object.keys(BoxInventory.TOKEN_BOXES).some(
      (boxType) => Boolean(state.boxes[String(boxType)])
    )
    if (!required) {
      return false
    }
    const transaction = new RewardTransaction(player)
    const migrated = BoxInventory._migrate_transaction(transaction)
    BoxInventory._write(transaction, migrated)
    transaction.commit()
    return true
  }

  static _values (boxType, amount) {
    boxType = toInteger(boxType)
    amount = toInteger(amount)
    if (boxType === null || amount === null || !BoxInventory.BOX_TYPES.includes(boxType) || amount < 1) {
      throw new RewardError('Quantidade de caixas inválida')
    }
    return [boxType, amount]
  }

  static add (transaction, boxType, amount) {
    ;[boxType, amount] = BoxInventory._values(boxType, amount)
    const state = BoxInventory._migrate_transaction(transaction)
    const tokenBoxes = BoxInventory.TOKEN_BOXES
    if (boxType in tokenBoxes) {
      const [attribute, column, cost] = tokenBoxes[boxType]
      const balance = BoxInventory._balance(transaction, attribute) + amount * cost
      transaction.set_value(attribute, column, balance)
      BoxInventory._write(transaction, state)
      return Math.floor(balance / cost)
    }
    const key = String(boxType)
    state.boxes[key] += amount
    BoxInventory._write(transaction, state)
    return state.boxes[key]
  }

  static consume (transaction, boxType, amount = 1) {
    ;[boxType, amount] = BoxInventory._values(boxType, amount)
    const state = BoxInventory._migrate_transaction(transaction)
    const tokenBoxes = BoxInventory.TOKEN_BOXES
    if (boxType in tokenBoxes) {
      const [attribute, column, cost] = tokenBoxes[boxType]
      let balance = BoxInventory._balance(transaction, attribute)
      const required = amount * cost
      if (balance < required) {
        throw new RewardError('Caixas insuficientes no inventário')
      }
      balance -= required
      transaction.set_value(attribute, column, balance)
      BoxInventory._write(transaction, state)
      return Math.floor(balance / cost)
    }
    const key = String(boxType)
    if (state.boxes[key] < amount) {
      throw new RewardError('Caixas insuficientes no inventário')
    }
    state.boxes[key] -= amount
    BoxInventory._write(transaction, state)
    return state.boxes[key]
  }
}

module.exports = BoxInventory
