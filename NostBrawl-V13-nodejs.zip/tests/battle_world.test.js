'use strict'
const assert = require('node:assert/strict')
const { battleAssets } = require('../Logic/Battle/World/BattleAssets')
const { BattleWorld } = require('../Logic/Battle/Game/BattleWorld')
const { rules } = require('../Logic/Battle/World/GameModes')
const { encodeWorld } = require('../Logic/Battle/Game/V13WorldCodec')
const assets = battleAssets()
function players (mode, hero = 0) {
  return Array.from({ length: mode.capacity }, (_, index) => ({ index, team: mode.variation === 7 ? (index === 5 ? 1 : 0) : Math.floor(index / mode.teamSize),
    player: { low_id: index + 1, brawler_id: hero, skin_id: 0, Brawler_level: {} } }))
}
let maps = 0
for (const loc of assets.tables.locations.filter(l => l.AllowedMaps && l.Disabled !== 'true' && l.GameMode !== 'Tutorial')) {
  const roster = players(rules(loc.GameMode))
  const world = new BattleWorld('map-' + loc.id, assets, loc.id, roster)
  for (const entry of roster) world.input(entry, { type: 4 })
  world.step(); assert.equal(world.phase, 'running')
  for (let i = 0; i < 10; i++) world.step()
  assert.ok(encodeWorld(world, roster[0], assets).length > 10)
  maps++
}
for (const hero of assets.heroes) {
  const roster = players(rules('CoinRush'), hero.id)
  const world = new BattleWorld('hero-' + hero.id, assets, 7, roster)
  for (const entry of roster) world.input(entry, { type: 4 })
  world.step()
  const char = world.characters.get(1)
  assert.equal(world.activate(char, 0, char.x, char.y - 1000), true)
  const ammo = char.skills[0].ammo
  assert.equal(world.activate(char, 0, char.x, char.y - 1000), false, 'one attack cannot activate twice')
  assert.equal(char.skills[0].ammo, ammo)
  for (let i = 0; i < 50; i++) world.step()
  char.superCharge = 4000
  assert.equal(world.activate(char, 1, char.x, char.y - 1000), true, hero.Name)
  assert.equal(char.superCharge, 0)
  for (let i = 0; i < 220; i++) {
    world.step()
    assert.ok(encodeWorld(world, roster[0], assets).length > 10)
  }
}
// A server-calculated kill drops gems and regenerates only on server time.
const roster = players(rules('CoinRush'))
const world = new BattleWorld('damage', assets, 7, roster)
for (const entry of roster) world.input(entry, { type: 4 })
world.step()
const own = world.characters.get(1); const target = world.characters.get(4)
target.score = 3
world.damage(target, target.maxHp + 100, own)
assert.equal(target.hp, 0)
assert.equal(target.score, 0)
assert.equal(Array.from(world.objects.values()).filter(o => o.dataClass === 18 && assets.tables.items[o.dataId].Name === 'Point').length, 3)
for (let i = 0; i < 60; i++) world.step()
assert.equal(target.hp, target.maxHp)
let finishes = 0; world.on('finished', () => finishes++)
world.finish(0, 'test'); world.finish(1, 'duplicate')
assert.equal(finishes, 1)
console.log(`Battle world: ${maps} locations, ${assets.heroes.length} main attacks/supers exercised, authoritative damage/respawn passed`)
