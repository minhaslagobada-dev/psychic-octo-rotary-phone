'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamMemberStatusMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.status = 0
  }

  decode () {
    this.status = this.read_Vint()
    this.ensure_end()
  }

  process () {
    const room = GameRoomService.set_status(this.player, this.status)
    if (room !== null) {
      GameRoomGateway.broadcast_data(this.player, room, this.client)
    }
    return room
  }
}

module.exports = TeamMemberStatusMessage
