'use strict'

const { open_boxes } = require('../../../Logic/BoxService')
const { RewardError } = require('../../../Logic/Rewards')
const LogicBoxDataCommand = require('../Server/LogicBoxDataCommand')

class LogicPurchaseBoxCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    reader.box_id = reader.read_Vint()
  }

  static process (reader) {
    let result
    try {
      result = open_boxes(reader.player, reader.box_id)
    } catch (error) {
      if (error instanceof RewardError) {
        return String(error.message)
      }
      throw error
    }
    new LogicBoxDataCommand(reader.client, reader.player, result).send()
    return result
  }
}

module.exports = LogicPurchaseBoxCommand
