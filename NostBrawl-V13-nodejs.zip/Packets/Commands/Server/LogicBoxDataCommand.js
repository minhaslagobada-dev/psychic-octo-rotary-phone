'use strict'

const Boxes = require('../../../Logic/Boxes')
const Writer = require('../../../Utils/Writer')

class LogicBoxDataCommand extends Writer {
  constructor (
    client, player, boxID = 100, rewards = null, rewardNames = null,
    rewardsTargetBrawler = null, trophyRoad = 0, rewardUnits = null, initial = null
  ) {
    super(client)
    this.id = 24111
    this.player = player
    let boxType = boxID
    let boxCount = 1
    if (typeof boxID === 'object' && boxID !== null) {
      const result = boxID
      boxID = result.boxID
      boxType = result.boxType !== undefined ? result.boxType : boxID
      boxCount = result.boxCount !== undefined ? result.boxCount : 1
      rewards = result.rewards
      rewardNames = result.rewardNames
      rewardsTargetBrawler = result.rewardsTargetBrawler
      trophyRoad = result.trophyRoad !== undefined ? result.trophyRoad : 0
      rewardUnits = result.rewardUnits !== undefined ? result.rewardUnits : rewardUnits
      initial = result.initial !== undefined ? result.initial : initial
    }
    this.boxID = boxID
    this.boxType = boxType
    this.boxCount = Math.trunc(boxCount)
    this.rewards = rewards ? rewards.slice() : []
    this.rewardNames = rewardNames ? rewardNames.slice() : []
    this.rewardsTargetBrawler = rewardsTargetBrawler ? rewardsTargetBrawler.slice() : []
    this.trophyRoad = trophyRoad
    this.rewardUnits = rewardUnits ? rewardUnits.slice() : []
    this.initial = initial
  }

  getBoxType (boxID) {
    try {
      return Boxes.get_box_type(boxID)
    } catch (error) {
      return boxID
    }
  }

  static itemType (item) {
    const types = {
      Brawler: 1,
      tokens_doubler: 2,
      tickets: 3,
      StarPower: 4,
      UpgradePoints: 6,
      Coins: 7,
      gems: 8,
      Skin: 9
    }
    if (!(item in types)) {
      throw new Error(`Unknown box reward item: ${item}`)
    }
    return types[item]
  }

  static validateRewards (rewards, rewardNames, rewardsTargetBrawler) {
    if (!(rewards.length === rewardNames.length && rewardNames.length === rewardsTargetBrawler.length)) {
      throw new Error('Reward arrays have different lengths')
    }
  }

  _encode_rewards (rewards, rewardNames, rewardsTargetBrawler) {
    this.writeVint(rewards.length)
    for (let index = 0; index < rewards.length; index++) {
      const amount = Math.trunc(rewards[index])
      const name = rewardNames[index]
      const target = Math.trunc(rewardsTargetBrawler[index])
      const rewardType = LogicBoxDataCommand.itemType(name)
      if (['Coins', 'gems', 'tickets', 'tokens_doubler'].includes(name)) {
        this.writeVint(amount)
        this.writeScId(0, rewardType)
        this.writeVint(0)
        this.writeVint(0)
        continue
      }
      if (name === 'UpgradePoints') {
        this.writeVint(amount)
        this.writeScId(16, target)
        this.writeVint(rewardType)
        this.writeVint(0)
        this.writeVint(0)
        continue
      }
      this.writeVint(1)
      if (name === 'Skin') {
        this.writeVint(0)
        this.writeVint(rewardType)
        this.writeScId(29, amount)
        this.writeVint(0)
        continue
      }
      if (name === 'StarPower') {
        this.writeScId(23, amount)
      } else {
        this.writeScId(16, amount)
      }
      this.writeVint(rewardType)
      this.writeVint(0)
      this.writeVint(0)
    }
  }

  encode () {
    if (this.boxCount < 1) {
      throw new Error('Invalid box count')
    }
    let units
    let initial
    if (this.rewardUnits.length) {
      if (this.rewardUnits.length !== this.boxCount) {
        throw new Error('Box count and reward units differ')
      }
      units = this.rewardUnits
      initial = this.initial === null || this.initial === undefined ? this.boxCount : Math.trunc(this.initial)
    } else {
      units = [{
        boxType: this.boxType,
        rewards: this.rewards,
        rewardNames: this.rewardNames,
        rewardsTargetBrawler: this.rewardsTargetBrawler
      }]
      initial = this.initial === null || this.initial === undefined ? this.boxCount : Math.trunc(this.initial)
    }
    for (const unit of units) {
      LogicBoxDataCommand.validateRewards(
        unit.rewards,
        unit.rewardNames,
        unit.rewardsTargetBrawler
      )
    }
    this.writeVint(203)
    this.writeVint(initial)
    this.writeVint(units.length)
    for (const unit of units) {
      this.writeVint(this.getBoxType(unit.boxType !== undefined ? unit.boxType : this.boxType))
      this._encode_rewards(
        unit.rewards,
        unit.rewardNames,
        unit.rewardsTargetBrawler
      )
    }
    this.writeVint(Math.trunc(this.trophyRoad || 0))
    for (let index = 0; index < 5; index++) {
      this.writeVint(0)
    }
  }
}

module.exports = LogicBoxDataCommand
