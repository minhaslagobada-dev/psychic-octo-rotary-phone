'use strict'

const crypto = require('crypto')
const fs = require('fs')
const path = require('path')

const { ValueError } = require('../Utils/Errors')

class BattleEndError extends ValueError {
  constructor (message) {
    super(message)
    this.name = 'BattleEndError'
  }
}

function _read_data_reference (reader) {
  const csvId = reader.read_Vint()
  if (csvId === 0) {
    return [0, 0]
  }
  return [csvId, reader.read_Vint()]
}

class BattleParticipant {
  constructor ({ brawlerId, skinId, team, isPlayer, name, lowId, highId, powerLevel }) {
    this.brawler_id = brawlerId
    this.skin_id = skinId
    this.team = team
    this.is_player = isPlayer
    this.name = name
    this.low_id = lowId
    this.high_id = highId
    this.power_level = powerLevel
  }
}

class BattleEndData {
  constructor ({ battleResult, submittedResult, rank, mapSlot, mapId, gameMode, locationGameMode, participants, battleId, localIndex }) {
    this.battle_result = battleResult
    this.submitted_result = submittedResult
    this.rank = rank
    this.map_slot = mapSlot
    this.map_id = mapId
    this.game_mode = gameMode
    this.location_game_mode = locationGameMode
    this.participants = participants
    this.battle_id = battleId
    this.explicit_local_index = localIndex
  }

  get local_index () {
    if (Number.isInteger(this.explicit_local_index) && this.explicit_local_index >= 0 && this.explicit_local_index < this.participants.length) return this.explicit_local_index
    for (let index = 0; index < this.participants.length; index++) {
      if (this.participants[index].is_player) {
        return index
      }
    }
    throw new BattleEndError('BattleEnd não contém o participante local')
  }

  get local () {
    return this.participants[this.local_index]
  }
}

class BattleEndService {
  static get SPECIAL_MODES () { return new Set([3, 4, 6]) }

  static _locations () {
    if (BattleEndService._location_rows === null) {
      const file = path.join(__dirname, '..', 'GameAssets', 'csv_logic', 'locations.csv')
      BattleEndService._location_rows = BattleEndService._read_csv(file).slice(1)
    }
    return BattleEndService._location_rows
  }

  static _valid_card (csvName, cardId) {
    if (!(csvName in BattleEndService._card_rows)) {
      const file = path.join(__dirname, '..', 'GameAssets', 'csv_logic', `${csvName}.csv`)
      BattleEndService._card_rows[csvName] = BattleEndService._read_csv(file).slice(1)
    }
    cardId = Math.trunc(Number(cardId))
    return cardId >= 0 && cardId < BattleEndService._card_rows[csvName].length
  }

  static _read_csv (file) {
    const text = fs.readFileSync(file, 'utf-8').replace(/^﻿/, '')
    const lines = text.replace(/\r\n/g, '\n').split('\n')
    const header = lines[0].split(',').map((cell) => cell.trim().replace(/"/g, ''))
    return lines.slice(1).filter((line) => line.trim()).map((line) => {
      const cells = BattleEndService._split_csv_line(line)
      const row = {}
      for (let index = 0; index < header.length; index++) {
        row[header[index]] = cells[index] !== undefined ? cells[index] : ''
      }
      return row
    })
  }

  static _split_csv_line (line) {
    const cells = []
    let current = ''
    let quoted = false
    for (let index = 0; index < line.length; index++) {
      const char = line[index]
      if (char === '"') {
        quoted = !quoted
      } else if (char === ',' && !quoted) {
        cells.push(current)
        current = ''
      } else {
        current += char
      }
    }
    cells.push(current)
    return cells.map((cell) => cell.trim().replace(/^"|"$/g, ''))
  }

  static game_mode (mapId) {
    const rows = BattleEndService._locations()
    if (!(mapId >= 0 && mapId < rows.length)) {
      throw new BattleEndError(`Mapa V13 inválido: ${mapId}`)
    }
    const row = rows[mapId]
    const disabled = String(row.Disabled || '').trim().toLowerCase()
    if (['1', 'true', 'yes'].includes(disabled)) {
      throw new BattleEndError(`Mapa V13 desabilitado: ${mapId}`)
    }
    const locationGameMode = row.GameMode || ''
    const mode = {
      BattleRoyale: 2,
      BattleRoyaleTeam: 5,
      Survival: 3,
      BossFight: 4,
      Raid: 6
    }[locationGameMode] !== undefined ? {
      BattleRoyale: 2,
      BattleRoyaleTeam: 5,
      Survival: 3,
      BossFight: 4,
      Raid: 6
    }[locationGameMode] : 0
    return [mode, locationGameMode]
  }

  static decode (reader, initialBytes) {
    if (initialBytes.length > 16384) {
      throw new BattleEndError('BattleEnd excede o tamanho permitido')
    }
    reader.enable_native_v13()
    let battleResult
    let submittedResult
    let rank
    let mapId
    let mapSlot
    let count
    try {
      battleResult = reader.read_Vint()
      submittedResult = reader.read_Vint()
      rank = reader.read_Vint()
      mapId = reader.read_Vint()
      mapSlot = reader.read_Vint()
      count = reader.read_Vint()
    } catch (error) {
      if (error instanceof ValueError || error instanceof RangeError) {
        throw new BattleEndError('Cabeçalho BattleEnd incompleto')
      }
      throw error
    }
    if (!(count >= 1 && count <= 10)) {
      throw new BattleEndError(`Quantidade de participantes inválida: ${count}`)
    }
    const [gameMode, locationGameMode] = BattleEndService.game_mode(mapId)
    const context =
      `mapa=${mapId}, slot=${mapSlot}, modo=${locationGameMode}, ` +
      `resultado=${battleResult}, enviado=${submittedResult}, ` +
      `rank=${rank}, participantes=${count}`
    const expectedCounts = {
      2: new Set([10]),
      5: new Set([10]),
      3: new Set([6]),
      4: new Set([6]),
      6: new Set([3])
    }
    if (gameMode in expectedCounts && !expectedCounts[gameMode].has(count)) {
      throw new BattleEndError('Participantes incompatíveis com o modo: ' + context)
    }
    if (gameMode === 2) {
      if (!(battleResult >= 1 && battleResult <= 10)) {
        throw new BattleEndError('Rank inicial solo inválido: ' + context)
      }
      if (!(rank >= 1 && rank <= 10)) {
        throw new BattleEndError('Rank solo inválido: ' + context)
      }
      if (battleResult !== rank) {
        throw new BattleEndError('Ranks solo divergentes: ' + context)
      }
    } else if (gameMode === 5) {
      if (!(battleResult >= 1 && battleResult <= 5)) {
        throw new BattleEndError('Rank inicial duo inválido: ' + context)
      }
      if (!(rank >= 1 && rank <= 5)) {
        throw new BattleEndError('Rank duo inválido: ' + context)
      }
      if (battleResult !== rank) {
        throw new BattleEndError('Ranks duo divergentes: ' + context)
      }
    } else {
      if (![0, 1, 2].includes(battleResult)) {
        throw new BattleEndError('Resultado BattleEnd inválido: ' + context)
      }
      if (rank !== 0) {
        throw new BattleEndError('Rank presente fora de Showdown: ' + context)
      }
    }
    if (gameMode === 0 && mapId !== 20 && count !== 6) {
      throw new BattleEndError('Partida 3v3 exige seis participantes: ' + context)
    }

    const participants = []
    try {
      for (let index = 0; index < count; index++) {
        const [brawlerReference, brawlerId] = _read_data_reference(reader)
        const [skinReference, skinId] = _read_data_reference(reader)
        if (![0, 29].includes(skinReference)) {
          throw new BattleEndError('Referência de skin inválida')
        }
        const team = reader.read_Vint()
        const playerFlag = reader.read_boolean()
        const name = reader.read_string() || ''
        if (brawlerReference !== 16) {
          throw new BattleEndError('Referência de personagem inválida')
        }
        if (!BattleEndService._valid_card('characters', brawlerId) ||
            !BattleEndService._valid_card('skins', skinId)) {
          throw new BattleEndError('Personagem ou skin inexistente nos CSVs V13')
        }
        if (!(team >= 0 && team <= 10) || ![false, true].includes(playerFlag)) {
          throw new BattleEndError('Equipe ou marcador de jogador inválido')
        }
        if (Buffer.byteLength(name, 'utf-8') > 64) {
          throw new BattleEndError('Nome de participante muito longo')
        }
        participants.push(new BattleParticipant({
          brawlerId,
          skinId,
          team,
          isPlayer: Boolean(playerFlag),
          name
        }))
      }
    } catch (error) {
      if (error instanceof BattleEndError) {
        throw error
      }
      throw new BattleEndError('Participante BattleEnd incompleto')
    }
    if (reader.read(1).length) {
      throw new BattleEndError('BattleEnd contém dados residuais')
    }
    const localCount = participants.filter((participant) => participant.is_player).length
    if (localCount !== 1) {
      throw new BattleEndError(
        `BattleEnd offline exige um participante local; recebidos=${localCount}`
      )
    }
    const localTeam = participants.find((participant) => participant.is_player).team
    if (submittedResult !== localTeam) {
      throw new BattleEndError(
        `Equipe enviada difere da equipe local: ${context}, equipeLocal=${localTeam}`
      )
    }
    const battleId = crypto.createHash('sha256').update(initialBytes).digest('hex')
    return new BattleEndData({
      battleResult,
      submittedResult,
      rank,
      mapSlot,
      mapId,
      gameMode,
      locationGameMode,
      participants,
      battleId
    })
  }

  static apply_to_player (player, battle) {
    const local = battle.local
    player.battle_end = battle
    player.battle_end_id = battle.battle_id
    player.battle_participants = battle.participants
    player.players = battle.participants.length
    player.battle_result = battle.battle_result
    player.rank = battle.rank
    player.map_id = battle.map_id
    player.locationID = battle.map_slot
    player.brawler_id = local.brawler_id
    player.skin_id = local.skin_id
    player.team = local.team
    if (BattleEndService.SPECIAL_MODES.has(battle.game_mode)) {
      player.result = 0
    } else {
      const tutorial = Math.trunc(player.tutorial !== undefined ? player.tutorial : 2) || 0
      player.result = tutorial === 2 ? battle.submitted_result : 0
    }
    for (let index = 1; index < 10; index++) {
      const participantIndex = index < battle.participants.length ? index : null
      const participant = participantIndex !== null ? battle.participants[participantIndex] : null
      player[`bot${index}`] = participant !== null ? participant.brawler_id : 0
      player[`bot${index}_n`] = participant !== null ? participant.name : ''
      player[`bot${index}_team`] = participant !== null ? participant.team : 0
    }
    return battle
  }
}

BattleEndService._location_rows = null
BattleEndService._card_rows = {}

module.exports = { BattleEndService, BattleEndError, BattleParticipant, BattleEndData }
module.exports.default = BattleEndService
