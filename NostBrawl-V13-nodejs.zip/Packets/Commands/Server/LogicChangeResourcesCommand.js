'use strict'

const Writer = require('../../../Utils/Writer')

class LogicChangeResourcesCommand extends Writer {
  constructor (client, player, resourceGlobalId, amount) {
    super(client)
    this.id = 24111
    this.player = player
    this.resource_global_id = Math.trunc(resourceGlobalId)
    this.amount = Math.trunc(amount)
    if (this.resource_global_id < 1 || this.amount === 0) {
      throw new Error('Invalid resource change')
    }
  }

  encode () {
    this.writeVint(207)
    this.writeVint(this.resource_global_id)
    this.writeVint(this.amount)
    for (let index = 0; index < 5; index++) {
      this.writeVint(0)
    }
  }
}

module.exports = LogicChangeResourcesCommand
