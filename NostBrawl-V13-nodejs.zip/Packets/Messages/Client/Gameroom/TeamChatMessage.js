'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamChatMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.message = ''
  }

  decode () {
    this.message = this.read_string()
    this.ensure_end()
  }

  process () {
    const [room, chat] = GameRoomService.add_chat(this.player, this.message)
    if (room === null) {
      return null
    }
    GameRoomGateway.broadcast_data_and_stream(
      this.player, room, this.client, true
    )
    return { room, chat }
  }
}

module.exports = TeamChatMessage
