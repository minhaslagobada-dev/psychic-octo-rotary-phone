'use strict'
// Port of probe_projectile_tick.py.
// Execute original projectile tick including collision, with a non-character origin fixture.
// No gameplay hooks. Hero muzzle offsets are excluded by the controlled origin type.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { NativeOpenMap } = require('./native_open_map')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); t.initialize_schema(0x449b0c)
  const terrain = new NativeOpenMap(n, root)
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const battle = t.alloc(0x400); p(battle + 0x70, terrain.pointer); w(battle + 0x18, 100); w(battle + 0x20, 17)
  const manager = t.alloc(0x80); p(manager + 0x50, battle); p(battle, manager)
  const table = t.alloc(0x40); w(table + 0x28, 6)
  const origin = t.alloc(0x400)
  // Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
  p(origin, 0x74e558); w(origin + 0x30, 3000); w(origin + 0x34, 4500)
  w(origin + 0x3c, 1); w(origin + 0x40, 2)
  const records = []
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row); const meta = t.alloc(0x200); p(meta + 8, t.rows[i]); p(meta + 0x10, table)
    n.uc.mem_write(meta + 0x90, Buffer.from([d.Indirect === 'true' ? 1 : 0, d.ConstantFlyTime === 'true' ? 1 : 0]))
    w(meta + 0x94, R.int0(d.Speed)); w(meta + 0xa0, R.int0(d.Gravity))
    w(battle + 0x18, 100)
    const stack = 0x201ff000
    n.uc.mem_write(stack, R.pack('Q', 456, 0, 0, 0, battle, 0, 0))
    const obj = Number(n.call(0x4a0228, 3000, 4500, 0, origin, meta, 5317, 8429, 123))
    const flight = { start: [get(obj + 0x60), get(obj + 0x64)], end: [get(obj + 0x68), get(obj + 0x6c)], z: get(obj + 0x70), launch: get(obj + 0x20), finish: get(obj + 0x24) }
    const data = { speed: R.int0(d.Speed), constantFlyTime: d.ConstantFlyTime === 'true', gravity: R.int0(d.Gravity), bounce: R.int0(d.BouncePercent) }
    for (const tick of [100, 101, 102, 103]) {
      w(battle + 0x18, tick)
      n.call(0x3bf1d0, obj)
      records.push({ name: d.Name, flight, data, tick, x: get(obj + 0x30), y: get(obj + 0x34), z: get(obj + 0x38), state: get(obj + 0x48) })
    }
  })
  R.writeJson('projectile-tick-vectors.json', records)
  R.print('Original projectile full tick:', records.length, 'cases; controlled open map; no gameplay hooks')
})
