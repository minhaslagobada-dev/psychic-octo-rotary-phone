'use strict'

function encode_friend_entry (writer, entry) {
  writer.writeLong(entry.high_id, entry.low_id)
  writer.writeString(entry.name)
  writer.writeString(entry.facebook_id)
  writer.writeString(entry.game_center_id)
  writer.writeString('')
  writer.writeInt(entry.status !== undefined ? entry.status : 0)
  writer.writeInt(entry.trophies)
  writer.writeInt(entry.state)
  writer.writeInt(entry.origin !== undefined ? entry.origin : 0)
  writer.writeInt(0)
  writer.writeInt(0)
  const club = entry.club !== undefined ? entry.club : null
  writer.writeBoolean(club !== null && club !== undefined)
  if (club !== null && club !== undefined) {
    writer.writeLong(0, club.id)
    writer.writeInt(0)
    writer.writeString(club.name)
    writer.writeInt(0)
    writer.writeInt(0)
  }
  writer.writeString('')
  writer.writeInt(entry.profile_icon)
  writer.writeInt(entry.last_seen_seconds !== undefined ? entry.last_seen_seconds : -1)
}

function encode_addable_friend (writer, entry) {
  writer.writeInt(entry.high_id)
  writer.writeInt(entry.low_id)
  writer.writeString(entry.name)
  writer.writeInt(entry.state)
  writer.writeString(entry.facebook_id)
  writer.writeString(entry.game_center_id)
}

module.exports = { encode_friend_entry, encode_addable_friend }
