'use strict'
// Port of probe_battle_setup.py.
// Original player registration, bot fill, map setup and populated updates.
//
// This does not transmit UDP, initialize a renderer or invoke a match-end callback.
const fs = require('node:fs')
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const { pyInt } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x4000000, reclaim_memory: process.env.V13_RECLAIM_MEMORY === '1' }); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const result = {}
  const fullFrame = process.env.V13_NATIVE_FRAME === '1'
  const schedule = process.env.V13_INPUT_SCHEDULE ? JSON.parse(fs.readFileSync(process.env.V13_INPUT_SCHEDULE, 'utf8')) : []
  try {
    const battle = new NativeBattle(data, 'Gemgrab1')
    battle.add_player('ShotgunGirl', 0)
    result.beforeSetup = battle.describe(); R.print('human registered', result.beforeSetup)
    battle.setup(); result.afterSetup = battle.describe(); R.print('populated', result.afterSetup.players.length, 'players', result.afterSetup.objects.length, 'objects')
    result.frames = []
    const ticks = Number(pyInt(process.env.V13_BATTLE_TICKS || '40'))
    for (let tick = 0; tick < ticks; tick++) {
      for (const entry of schedule) if (entry.step === tick) battle.input_packet(entry.player === undefined ? 0 : entry.player, Buffer.from(entry.packet, 'hex'))
      let record
      if (fullFrame) { const vision = battle.frame(); record = battle.describe(); record.vision = vision } else { battle.step(150 + tick); record = battle.describe() }
      result.frames.push(record)
      if ((tick + 1) % 100 === 0) R.print('native frame', record.tick, 'objects', record.objects.length, 'ended', record.ended)
    }
    R.print('Original populated battle updates:', result.frames.length, 'frames; original players, bot fill, map setup and object/mode updates')
  } catch (e) {
    result.error = { message: R.errorMessage(e), pc: m.pc(), lr: m.lr() }
    R.print('blocked', result.error)
  }
  R.writeJson(schedule.length ? 'battle-input-frame-vectors.json' : fullFrame ? 'battle-frame-vectors.json' : 'battle-setup-vectors.json', result)
  if ('error' in result) throw new R.SystemExit(1)
})
