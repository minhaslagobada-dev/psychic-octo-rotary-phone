'use strict'
const { ClubService, ClubError } = require('../../../../Logic/ClubService')
const AllianceDataMessage = require('../../Server/Alliance/Alliance_Data_Message')
const AllianceEditOkMessage = require('../../Server/Alliance/Events/AllianceEditOkMessage')
const MyAllianceMessage = require('../../Server/Alliance/My_Alliance_Message')
const { BSMessageReader } = require('../../../../Utils/Reader')

class Edit_Settings_Message extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.clubDescription = this.read_string()
    this.inf2 = this.read_Vint()
    this.badgeID = this.read_Vint()
    this.inf4 = 0
    this.regionID = 0
    this.clubType = this.read_Vint()
    this.requiredTrophies = this.read_Vint()
    this.friendlyFamilly = null
  }

  process () {
    let club
    try {
      club = ClubService.edit(
        this.player,
        this.clubDescription,
        this.badgeID,
        this.clubType,
        this.requiredTrophies,
        this.friendlyFamilly
      )
    } catch (error) {
      if (error instanceof ClubError) {
        return String(error.message)
      }
      throw error
    }
    new AllianceEditOkMessage(this.client, this.player).send()
    new MyAllianceMessage(this.client, this.player, club.id).send()
    for (const memberId of club.member_ids) {
      if (memberId !== this.player.low_id) {
        new AllianceDataMessage(
          this.client, this.player, 0, club.id, true
        ).sendWithLowID(memberId)
      }
    }
    return club
  }
}

module.exports = Edit_Settings_Message
