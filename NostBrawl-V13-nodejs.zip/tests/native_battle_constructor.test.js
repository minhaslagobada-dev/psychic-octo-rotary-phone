'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'battle-constructor-vectors.json')))
assert.equal(records.length, 12)
for (const [kind, record] of records.entries()) {
  assert.equal(record.kind, kind)
  assert.equal(record.storedKind, kind)
  assert.equal(record.playerSlots, kind === 0 || kind === 6 ? 10 : kind === 3 || kind === 7 ? 3 : 6)
  assert.equal(record.tick, 0)
  assert.equal(record.managerObjects, 0)
  assert.deepEqual(record.managerFlags, [1, 1, 1, 1, 1])
  assert(record.managerBattleMatches && record.emptyPlayerSlots && record.mapPointerPresent)
}
console.log('Original battle constructor: 12 kind inputs matched initial slots, empty state, manager flags/binding and map container; complete mode initialization remains unverified')
