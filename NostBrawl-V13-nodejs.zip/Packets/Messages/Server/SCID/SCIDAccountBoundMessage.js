'use strict'

const Writer = require('../../../../Utils/Writer')

class SCIDAccountBoundMessage extends Writer {
  constructor (client, player, result, scidToken) {
    super(client)
    this.player = player
    this.id = 25165
    this.result = Math.trunc(result)
    this.scid_token = scidToken || ''
    this.enable_native_v13()
  }

  encode () {
    this.writeInt(this.result)
    this.writeCompressedString(this.scid_token)
  }
}

module.exports = SCIDAccountBoundMessage
