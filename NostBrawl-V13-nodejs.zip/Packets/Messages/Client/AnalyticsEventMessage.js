'use strict'

const Store = require('../../../Store')
const { BSMessageReader } = require('../../../Utils/Reader')

class AnalyticsEventMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.Type = this.read_string()
    this.Event = this.read_string()
  }

  process () {
    console.log('Client | ' + this.Type + ' ' + this.Event)
    try {
      if (this.Type === 'Economy' && this.Event && this.Event.startsWith('{')) {
        const ev = JSON.parse(this.Event)
        // Disparado sempre que o jogador toca num pacote de compra da loja:
        // subType: "InAppPurchase", product: "purchasing" ou "transactionstarted"
        if (ev.subType === 'InAppPurchase' && (ev.product === 'purchasing' || ev.product === 'transactionstarted')) {
          const sku = String(ev.productDetails || '').trim()
          const store = Store.get()
          if (store && sku) {
            store.handleShopClick(this.client, this.player, sku, 'Analytics 10110')
          }
        }
      }
    } catch (e) {
      // Ignora erro de parsing de analytics
    }
  }
}

module.exports = AnalyticsEventMessage
