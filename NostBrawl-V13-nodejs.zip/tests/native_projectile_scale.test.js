'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { scaleAtProgress, damageAtProgress } = require('../Native/V13/ProjectileScale')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'projectile-scale-vectors.json')))
let damageCases = 0
for (const v of vectors) {
  assert.equal(scaleAtProgress(v.definition, v.progress), v.scale, v.definition.Name)
  for (const d of v.damages) { assert.equal(damageAtProgress(v.definition, v.progress, d.input), d.output, JSON.stringify(v)); damageCases++ }
}
console.log('Native projectile scale/damage:', vectors.length, 'scale cases;', damageCases, 'damage cases matched original v13')
