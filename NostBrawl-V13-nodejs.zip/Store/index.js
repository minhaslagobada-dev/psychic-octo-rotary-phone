'use strict'

const InternalApi = require('./InternalApi')
const TelegramBot = require('./TelegramBot')
const WebServer = require('./WebServer')

// Bootstrap da Lakey Store: sobe junto com o servidor de jogo (main.js),
// compartilhando o players.sqlite para entrega e mantendo bot/site/DB no
// mesmo processo. Nunca derruba o jogo: qualquer falha é logada e isolada.

let instance = null

async function start (server) {
  const { StoreService } = require('./StoreService')
  const store = new StoreService().attach(server)
  instance = store

  try {
    const internal = new InternalApi(store)
    const internalPort = await internal.start()
    store.internal = internal
    console.log(`Store | API interna em 0.0.0.0:${internalPort} (SAÚDE: /internal/store/v1/health)`)
  } catch (error) {
    console.error('Store | Falha ao subir a API interna:', error.message)
  }

  if (store.config.Mode !== 'agent') {
    const web = new WebServer(store)
    try {
      const port = await web.start()
      console.log(`Store | Loja online em 0.0.0.0:${port} (${store.config.PublicUrl})`)
    } catch (error) {
      console.error('Store | Falha ao subir o site da loja:', error.message)
    }
  } else {
    console.log('Store | Modo agent: site hospedado externamente (entregas via /internal/store/v1/deliver)')
  }

  try {
    const bot = new TelegramBot(store)
    bot.start()
    store.bot = bot
  } catch (error) {
    console.error('Store | Falha ao iniciar o bot:', error.message)
  }

  try {
    store.reconcile()
  } catch (error) {
    console.error('Store | Reconciliação de pedidos falhou:', error.message)
  }

  return store
}

function get () {
  return instance
}

module.exports = { start, get }
