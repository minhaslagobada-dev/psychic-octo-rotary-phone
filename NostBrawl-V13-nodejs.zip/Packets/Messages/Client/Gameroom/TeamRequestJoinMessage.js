'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService, GameRoomFullError } = require('../../../../Logic/GameRoomService')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamRequestJoinMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.recipient_high_id = 0
    this.recipient_id = 0
    this.room_high_id = 0
    this.room_id = 0
  }

  decode () {
    this.recipient_high_id = this.read_int()
    this.recipient_id = this.read_int()
    this.room_high_id = this.read_int()
    this.room_id = this.read_int()
    this.ensure_end()
  }

  process () {
    if (this.recipient_high_id !== 0 || this.room_high_id !== 0) {
      return null
    }
    let room
    let request
    try {
      ;[room, request] = GameRoomService.request_join_request(
        this.player, this.recipient_id, this.room_id
      )
    } catch (error) {
      if (error instanceof GameRoomFullError) {
        new TeamErrorMessage(this.client, this.player, 45).send()
        return null
      }
      throw error
    }
    if (room === null) {
      return null
    }
    GameRoomGateway.send_data_to(this.recipient_id, this.player, room)
    return { room, request }
  }
}

module.exports = TeamRequestJoinMessage
