'use strict'

const PresenceService = require('../../../../Logic/PresenceService')
const Writer = require('../../../../Utils/Writer')

class AllianceMemberEntryMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.enable_native_v13()
    this.id = 24308
    this.version = 11
    this.player = player
  }

  encode () {
    this.writeInt(Math.trunc(this.player.club_high_id || 0))
    this.writeInt(Math.trunc(this.player.club_low_id || 0))
    this.writeInt(Math.trunc(this.player.high_id || 0))
    this.writeInt(Math.trunc(this.player.low_id || 0))
    this.writeString(this.player.name)
    this.writeVint(Math.trunc(this.player.club_role || 0))
    this.writeVint(Math.trunc(this.player.trophies || 0))
    this.writeVint(Math.trunc(this.player.trophies || 0))
    let status = Math.trunc(this.player.online || 0)
    const elapsed = PresenceService.elapsed(
      status, this.player.last_activity_at !== undefined ? this.player.last_activity_at : null
    )
    if (status === 0 && elapsed === -1) {
      status = -1
    }
    this.writeVint(status)
    this.writeVint(elapsed)
    this.writeScId(28, Math.trunc(this.player.profile_icon || 0))
  }
}

module.exports = AllianceMemberEntryMessage
