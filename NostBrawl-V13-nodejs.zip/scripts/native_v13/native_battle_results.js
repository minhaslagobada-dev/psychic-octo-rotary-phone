'use strict'
// Port of native_battle_results.py.
// Observe native eliminations and execute original offline placement readers.
//
// The offline readers require an Android scene/current-viewer context. This
// small read-only view supplies that context and area metadata; gameplay
// objects stay owned by the original server. No health, alive, spawn or rank
// state is written back to the match. The client area vtable is used only for
// its original type getter, because server/client virtual method offsets differ.
class NativePlacements {
  constructor (battle) {
    this.battle = battle; this.data = battle.data; this.native = battle.native
    this.ranks = new Map(); this.buffers = []
    const allocate = size => {
      const pointer = this.native.alloc(size); this.native.uc.mem_write(pointer, Buffer.alloc(size)); this.buffers.push(pointer); return pointer
    }
    this.mode = allocate(0x40); this.scene = allocate(0x38); this.client = allocate(0xc0)
    this.data.csv.get(15).ptr(this.mode + 0x38, battle.pointer)
    this.data.csv.get(15).ptr(this.scene + 0x30, this.client)
  }

  rank (index, team, duo) {
    const data = this.data; const n = this.native; const t = data.csv.get(15); const temporary = []
    const allocate = size => {
      const pointer = n.alloc(Math.max(size, 16)); n.uc.mem_write(pointer, Buffer.alloc(Math.max(size, 16))); temporary.push(pointer); return pointer
    }
    t.word(this.client + 0xb0, index); t.word(this.client + 0xb4, team)
    if (duo) {
      const areas = []
      const manager = this.battle.manager
      const count = data.word(manager + 0xc)
      for (let i = 0; i < count; i++) {
        const obj = data.ptr(data.ptr(manager) + i * 8); const meta = data.ptr(obj + 0x10)
        const id = data.word(meta + 0x20)
        if (id >= 17000000 && id < 18000000) areas.push([meta, data.word(obj + 0x40)])
      }
      const items = allocate(areas.length * 8); const listing = allocate(16)
      t.ptr(listing, items); t.word(listing + 0xc, areas.length); t.ptr(this.client + 0x18, listing)
      areas.forEach(([meta, owner_team], i) => {
        const view = allocate(0x48); t.ptr(view, 0x750f78); t.ptr(view + 0x10, meta); t.word(view + 0x40, owner_team); t.ptr(items + i * 8, view)
      })
    }
    const previous = n.hooks.get(0x4d2560)
    n.hooks.set(0x4d2560, () => this.scene)
    try {
      return n.call(duo ? 0x3b0078 : 0x2558e4, this.mode)
    } finally {
      if (previous === undefined) n.hooks.delete(0x4d2560)
      else n.hooks.set(0x4d2560, previous)
      for (const pointer of temporary) n.free(pointer)
    }
  }

  observe (state) {
    const mode = state.nativeMode
    if (mode !== 6 && mode !== 9) return
    if (mode === 6) {
      for (const player of state.players) {
        if (!this.ranks.has(player.index) && (!player.alive || state.ended)) {
          this.ranks.set(player.index, this.rank(player.index, player.team, false))
        }
      }
    } else {
      const alive = new Set(state.players.filter(player => player.alive).map(player => player.team))
      const manager = this.battle.manager; const data = this.data
      const count = data.word(manager + 0xc)
      for (let i = 0; i < count; i++) {
        const obj = data.ptr(data.ptr(manager) + i * 8); const meta = data.ptr(obj + 0x10)
        const id = data.word(meta + 0x20)
        if (id >= 17000000 && id < 18000000 && data.word(meta + 0x80) === 9) alive.add(data.word(obj + 0x40))
      }
      for (const player of state.players) {
        if (!this.ranks.has(player.index) && (!alive.has(player.team) || state.ended)) {
          this.ranks.set(player.index, this.rank(player.index, player.team, true))
        }
      }
    }
  }

  close () {
    for (const pointer of this.buffers) this.native.free(pointer)
    this.buffers = []
  }
}

module.exports = { NativePlacements }
