'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const tiles = require('../Native/V13/TileState')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'tile-state-vectors.json')))
const open = vectors.find(v => v.name === 'Open').definition
for (const v of vectors) {
  const state = tiles.construct(v.definition)
  assert.deepEqual(state, v.constructed, v.name)
  tiles.destroy(state, v.definition, open)
  assert.deepEqual(state, v.destroyed, v.name)
  state.timer = v.timer
  tiles.tickRespawn(state, v.definition, 10, 15, v.actors)
  assert.deepEqual(state, v.after, JSON.stringify(v))
}
console.log('Native tile constructor/destruction/respawn:', vectors.length, 'cases matched original v13')
