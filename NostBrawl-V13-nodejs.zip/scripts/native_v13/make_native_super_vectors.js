'use strict'
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR || !process.env.V13_VECTOR_DIR) throw new Error('Set V13_RESEARCH_DIR and V13_VECTOR_DIR')
const assets = new BattleAssets()
const location = assets.tables.locations.find(location => location.GameMode === 'BountyHunter')
const grid = assets.map(location.AllowedMaps)
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'earned-supers.json')))
const vectors = []
for (const record of records) {
  if (record.error || !record.cast || record.postCastFrames < 40) throw new Error('Incomplete native Super: ' + record.hero)
  for (const frame of record.checkpoints) vectors.push({
    name: `${record.hero}/Super/${frame.tick}`, nativeSnapshot: true, mode: frame.nativeMode,
    capacity: frame.players.length, ownIndex: 0, grid, hex: frame.vision[0].hex,
    objects: frame.objects.map(object => ({ nativeId: object.id, fullDataId: object.dataId, x: object.x, y: object.y }))
  })
}
fs.mkdirSync(process.env.V13_VECTOR_DIR, { recursive: true })
fs.writeFileSync(path.join(process.env.V13_VECTOR_DIR, 'world-vectors.json'), JSON.stringify({ tables: assets.tables, vectors }))
console.log('Original earned Super/aftermath snapshots:', vectors.length, 'from', records.length, 'heroes')
