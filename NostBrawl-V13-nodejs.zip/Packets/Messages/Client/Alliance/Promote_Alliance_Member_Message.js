'use strict'
const { ClubService, ClubError } = require('../../../../Logic/ClubService')
const AllianceDataMessage = require('../../Server/Alliance/Alliance_Data_Message')
const AllianceRoleChangedOKMessage = require('../../Server/Alliance/Events/AllianceRoleChangedOKMessage')
const MyAllianceMessage = require('../../Server/Alliance/My_Alliance_Message')
const { BSMessageReader } = require('../../../../Utils/Reader')

class Promote_Alliance_Member_Message extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.TargetHighID = this.read_int()
    this.TargetLowID = this.read_int()
    this.TargetedRole = this.read_Vint()
  }

  process () {
    let club
    try {
      if (this.TargetHighID !== 0) {
        throw new ClubError('Conta não encontrada')
      }
      ;[club] = ClubService.promote(
        this.player, this.TargetLowID, this.TargetedRole
      )
    } catch (error) {
      if (error instanceof ClubError) {
        return String(error.message)
      }
      throw error
    }
    const responseType = this.TargetedRole > 1 ? 0 : 1
    new AllianceRoleChangedOKMessage(this.client, this.player, responseType).send()
    new MyAllianceMessage(this.client, this.player, club.id).send()
    const target = ClubService.refresh_online_player(this.player, this.TargetLowID)
    if (target !== null && target !== undefined) {
      new MyAllianceMessage(null, target, club.id).sendWithLowID(this.TargetLowID)
    }
    for (const memberId of club.member_ids) {
      if (memberId !== this.player.low_id) {
        new AllianceDataMessage(
          this.client, this.player, 0, club.id, true
        ).sendWithLowID(memberId)
      }
    }
    return club
  }
}

module.exports = Promote_Alliance_Member_Message
