'use strict'

const DataBase = require('../../../../Database/DatabaseManager')
const BoxInventory = require('../../../../Logic/BoxInventory')
const { DailyRewards } = require('../../../../Logic/DailyRewards')
const { EventRotation } = require('../../../../Logic/EventRotation')
const EventSlots = require('../../../../Logic/EventSlots')
const NotificationFactory = require('../../../../Logic/NotificationFactory')
const SeasonService = require('../../../../Logic/SeasonService')
const ShopService = require('../../../../Logic/ShopService')
const Writer = require('../../../../Utils/Writer')

const HOME_EVENT_SLOTS = [0, 1, 2, 3, 4, 5]

function _integer (value, defaultValue = 0) {
  try {
    const parsed = Math.trunc(Number(value))
    if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
      return defaultValue
    }
    return Math.max(0, parsed)
  } catch (error) {
    return defaultValue
  }
}

function _mapping_value (mapping, key, defaultValue = 0) {
  if (typeof mapping !== 'object' || mapping === null) {
    return defaultValue
  }
  const value = mapping[String(key)] !== undefined ? mapping[String(key)] : mapping[key]
  return _integer(value !== undefined ? value : defaultValue, defaultValue)
}

class OwnHomeDataMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 24101
    this.version = 9
    this.player = player
    this._bit_index = 0
  }

  _value (name, defaultValue = 0) {
    const value = this.player[name]
    return _integer(value !== undefined && value !== null ? value : defaultValue, defaultValue)
  }

  _align () {
    this._bit_index = 0
  }

  v (value = 0) {
    this._align()
    this.writeVint(_integer(value))
  }

  i (value = 0) {
    this._align()
    this.writeInt(value)
  }

  s (value = null) {
    this._align()
    this.writeString(value)
  }

  long (high, low) {
    this._align()
    this.writeLong(high, low)
  }

  boolean (value) {
    if (this._bit_index === 0) {
      this.buffer = Buffer.concat([this.buffer, Buffer.from([0])])
    }
    if (value) {
      this.buffer[this.buffer.length - 1] = this.buffer[this.buffer.length - 1] | (1 << this._bit_index)
    }
    this._bit_index = (this._bit_index + 1) & 7
  }

  list (values) {
    this.v(values.length)
    for (const value of values) {
      this.v(value)
    }
  }

  scid (csvId, itemId) {
    this.v(csvId)
    this.v(itemId)
  }

  _unlocked_brawlers () {
    const states = this.player.BrawlersUnlockedState
    if (typeof states !== 'object' || states === null || Array.isArray(states)) {
      return []
    }
    const result = []
    for (let brawler of (this.player.brawlers_id || [])) {
      brawler = _integer(brawler)
      const state = states[String(brawler)] !== undefined ? states[String(brawler)] : states[brawler]
      if ((state || 0) === 1) {
        result.push(brawler)
      }
    }
    return result
  }

  _selected_skins () {
    const selected = this.player.brawlers_skins
    if (typeof selected !== 'object' || selected === null || Array.isArray(selected)) {
      return []
    }
    return Object.values(selected).map((skin) => _integer(skin))
  }

  _unlocked_skins () {
    let skins = this.player.UnlockedSkins !== undefined ? this.player.UnlockedSkins : {}
    if (typeof skins === 'object' && skins !== null && !Array.isArray(skins)) {
      skins = skins.Skins !== undefined ? skins.Skins : []
    }
    if (!Array.isArray(skins)) {
      return []
    }
    return skins.map((skin) => _integer(skin)).filter((skin) => skin !== 0)
  }

  _reward_animation_state () {
    const values = []
    for (const name of ['tokensAnim', 'trophiesAnim', 'bigTokensAnim']) {
      let value
      try {
        value = Math.trunc(Number(this.player[name] || 0))
        if (Number.isNaN(value)) {
          value = 0
        }
      } catch (error) {
        value = 0
      }
      values.push(value)
    }
    return values
  }

  _consume_reward_animations () {
    const expected = this._presented_rewards !== undefined ? this._presented_rewards : null
    this._presented_rewards = null
    if (expected === null) {
      return
    }
    const persisted = DataBase.consume_home_reward_animations(this.player, expected)
    if (persisted === null || persisted === undefined) {
      return
    }
    const progression = this.player.progression !== undefined ? this.player.progression : {}
    const keys = ['keyReward', 'trophyReward', 'starKeyReward']
    if (typeof progression === 'object' && progression !== null && !Array.isArray(progression)) {
      for (let index = 0; index < keys.length; index++) {
        const key = keys[index]
        if (DataBase._number(progression[key] !== undefined ? progression[key] : 0) === expected[index]) {
          progression[key] = persisted[index]
        }
      }
    }
    const names = ['tokensAnim', 'trophiesAnim', 'bigTokensAnim']
    for (let index = 0; index < names.length; index++) {
      let current
      try {
        current = Math.trunc(Number(this.player[names[index]] || 0))
        if (Number.isNaN(current)) {
          current = 0
        }
      } catch (error) {
        current = 0
      }
      if (current === expected[index]) {
        this.player[names[index]] = persisted[index]
      }
    }
  }

  _send_payload (client, crypter, rawPacket) {
    const packetLength = super._send_payload(client, crypter, rawPacket)
    this._consume_reward_animations()
    return packetLength
  }

  encode () {
    const daily = DailyRewards.sync_player(this.player)
    BoxInventory.migrate(this.player)
    const season = SeasonService.sync(this.player)
    const timestamp = Math.trunc(Date.now() / 1000)
    this._presented_rewards = this._reward_animation_state()
    this._bit_index = 0
    const highId = this._value('high_id')
    const lowId = this._value('low_id')

    this.v(timestamp)
    this.v(0)
    this.v(this._value('trophies'))
    this.v(this._value('highest_trophies'))
    this.v(0)
    this.v(this._value('trophy_road', 1))
    this.v(this._value('player_experience'))
    this.scid(28, this._value('profile_icon'))
    this.v(0)

    const selectedSkins = this._selected_skins()
    this.v(selectedSkins.length)
    for (const skin of selectedSkins) {
      this.scid(29, skin)
    }
    const unlockedSkins = this._unlocked_skins()
    this.v(unlockedSkins.length)
    for (const skin of unlockedSkins) {
      this.scid(29, skin)
    }

    this.boolean(false)
    this.v(0)
    for (const value of this._presented_rewards) {
      this.v(value)
    }
    this.v(0)
    this.v(0)
    this.boolean(daily.remaining <= 0)
    this.v(0)
    this.boolean(false)
    this.v(this._value('tokensdoubler'))
    this.v(season.remaining)
    for (let index = 0; index < 4; index++) {
      this.boolean(false)
    }
    this.v(0)
    this.v(0)
    this.v(0)
    this.boolean(false)
    ShopService.encode_home(this, this.player)
    this.v(0)
    this.v(daily.remaining)
    this.v(daily.next_refill_in)
    this.v(0)
    this.v(this._value('tickets'))
    this.v(0)
    this.scid(16, this._value('brawler_id'))

    for (const value of [timestamp, 100, 10, 30, 3, 80, 10, 50, 1000, 500, 50, EventRotation.TOKEN_WALLET_CAP]) {
      this.v(value)
    }
    this.list([0, 30, 80, 170, 350, 0])
    this.list(HOME_EVENT_SLOTS)
    const events = EventRotation.snapshot(this.player)
    this.v(events.length)
    const eventTimer = new EventSlots().Timer()
    let position = 0
    for (const event of events) {
      position += 1
      const slot = _integer(event.slot !== undefined ? event.slot : position, position)
      const mapId = _integer(event.map_id !== undefined ? event.map_id : 0)
      const tokens = _integer(event.tokens !== undefined ? event.tokens : 0)
      let configuredModifiers = event.modifiers
      if (configuredModifiers === null || configuredModifiers === undefined) {
        const configuredModifier = _integer(event.modifier !== undefined ? event.modifier : 0)
        configuredModifiers = (configuredModifier > 0 && configuredModifier < 6) ? [configuredModifier] : []
      }
      if (!Array.isArray(configuredModifiers)) {
        throw new Error('Event modifiers must be a list or tuple')
      }
      const modifiers = []
      for (let modifier of configuredModifiers) {
        modifier = _integer(modifier)
        if (!(modifier > 0 && modifier < 6)) {
          throw new Error('Invalid V13 event modifier')
        }
        modifiers.push(modifier)
      }

      this.v(mapId)
      this.v(slot)
      this.v(0)
      this.v(_integer(event.timer !== undefined ? event.timer : eventTimer, eventTimer))
      this.v(tokens)
      this.scid(15, mapId)
      this.v(_integer(event.status !== undefined ? event.status : 1, 1))
      this.s()
      this.v(0)
      this.list(modifiers)
      this.v(0)
    }
    this.v(0)
    this.list([20, 35, 75, 140, 290, 480, 800, 1250])
    this.list([1, 2, 3, 4, 5, 10, 15, 20])
    this.list([10, 30, 80])
    this.list([6, 20, 60])
    this.list([20, 50, 140])
    this.list([150, 400, 1200])

    this.v(0)
    for (const value of [daily.limit, DailyRewards.TOKEN_REFILL_AMOUNT, DailyRewards.TOKEN_REFILL_INTERVAL, 10, 5]) {
      this.v(value)
    }
    this.boolean(false)
    this.boolean(false)
    this.boolean(false)
    this.v(0)
    this.v(0)
    this.boolean(true)
    this.v(0)

    this.long(highId, lowId)
    NotificationFactory.encode(
      this, NotificationFactory.home_notifications(this.player)
    )
    this.v(0)
    this.boolean(false)
    this.v(0)

    for (let index = 0; index < 3; index++) {
      this.v(highId)
      this.v(lowId)
    }
    const name = String(this.player.name !== undefined ? this.player.name : 'Guest') || 'Guest'
    this.s(name)
    this.boolean(name !== 'Guest')
    this.s()
    this.v(8)

    const brawlers = (this.player.brawlers_id || []).map((brawler) => _integer(brawler))
    const cardIds = Array.from(this.player.card_unlock_id || [])
    const states = this.player.BrawlersUnlockedState !== undefined ? this.player.BrawlersUnlockedState : {}
    const resources = [
      [23, 0, this._value('star_points')],
      [5, 1, this._value('brawl_boxes')],
      [5, 8, this._value('gold')],
      [5, 9, this._value('big_boxes')]
    ]
    this.v(cardIds.length + resources.length)
    if (cardIds.length !== brawlers.length) {
      throw new Error('Brawler and unlock card counts differ')
    }
    for (let index = 0; index < brawlers.length; index++) {
      this.v(23)
      this.v(_integer(cardIds[index]))
      const defaultState = brawlers[index] === 0 ? 1 : 0
      this.v(_mapping_value(states, brawlers[index], defaultState))
    }
    for (const [csvId, resourceId, amount] of resources) {
      this.v(csvId)
      this.v(resourceId)
      this.v(amount)
    }

    const trophies = this.player.brawlers_trophies !== undefined ? this.player.brawlers_trophies : {}
    const rankTrophies = this.player.brawlers_trophies_in_rank !== undefined ? this.player.brawlers_trophies_in_rank : {}
    const upgradePoints = this.player.brawlers_upgradium !== undefined ? this.player.brawlers_upgradium : {}
    const powerLevels = this.player.Brawler_level !== undefined ? this.player.Brawler_level : {}

    for (const mapping of [trophies, rankTrophies]) {
      this.v(brawlers.length)
      for (const brawler of brawlers) {
        this.scid(16, brawler)
        this.v(_mapping_value(mapping, brawler))
      }
    }
    this.v(0)

    this.v(brawlers.length)
    for (const brawler of brawlers) {
      this.scid(16, brawler)
      this.v(_mapping_value(upgradePoints, brawler))
    }
    this.v(brawlers.length)
    for (const brawler of brawlers) {
      this.scid(16, brawler)
      this.v(_mapping_value(powerLevels, brawler, 1))
    }

    this.v(0)
    this.v(0)

    this.v(this._value('gems'))
    this.v(this._value('gems'))
    this.v(this._value('player_experience'))
    for (let index = 0; index < 7; index++) {
      this.v(0)
    }
    this.v(this._value('tutorial', 2))

    this.v(timestamp)
  }
}

module.exports = OwnHomeDataMessage
