'use strict'

class RelationalState {
  static get INSERT () {
    return `
        INSERT INTO player_state_entries (
            player_id, domain, path, parent_path, segment, position,
            node_type, value_integer, value_real, value_text
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
    `
  }

  static _child_path (parent, kind, segment) {
    const text = String(segment)
    const part = `${kind}${text.length}:${text}`
    return `${parent}/${part}`
  }

  static rows (playerId, domain, value) {
    const result = []

    const append = (current, path, parent, segment, position) => {
      let integer = null
      let real = null
      let text = null
      let nodeType
      if (current === null || current === undefined) {
        nodeType = 'null'
      } else if (typeof current === 'boolean') {
        nodeType = 'boolean'
        integer = current ? 1 : 0
      } else if (typeof current === 'number' && Number.isInteger(current)) {
        nodeType = 'integer'
        if (Number.isSafeInteger(current) && current >= -(2 ** 53) && current < 2 ** 53) {
          integer = current
        } else {
          text = String(current)
        }
      } else if (typeof current === 'number') {
        nodeType = 'real'
        real = current
      } else if (typeof current === 'string') {
        nodeType = 'text'
        text = current
      } else if (Array.isArray(current)) {
        nodeType = 'array'
      } else if (typeof current === 'object') {
        nodeType = 'object'
      } else {
        throw new TypeError(`Unsupported relational state value: ${typeof current}`)
      }
      result.push([
        Math.trunc(playerId), String(domain), path, parent, segment,
        Math.trunc(position), nodeType, integer, real, text
      ])
      if (nodeType === 'object') {
        let childPosition = 0
        for (const [key, child] of Object.entries(current)) {
          const childSegment = String(key)
          const childPath = RelationalState._child_path(path, 'k', childSegment)
          append(child, childPath, path, childSegment, childPosition)
          childPosition += 1
        }
      } else if (nodeType === 'array') {
        for (let childPosition = 0; childPosition < current.length; childPosition++) {
          const child = current[childPosition]
          const childSegment = String(childPosition)
          const childPath = RelationalState._child_path(path, 'i', childSegment)
          append(child, childPath, path, childSegment, childPosition)
        }
      }
    }

    append(value, '', null, null, 0)
    return result
  }

  static write (connection, playerId, domain, value) {
    connection.prepare(
      'DELETE FROM player_state_entries WHERE player_id = ? AND domain = ?'
    ).run(Math.trunc(playerId), String(domain))
    const insert = connection.prepare(RelationalState.INSERT)
    for (const row of RelationalState.rows(playerId, domain, value)) {
      insert.run(...row)
    }
  }

  static read (connection, playerId, domain, defaultValue) {
    const rows = connection.prepare(
      'SELECT path, parent_path, segment, position, node_type, ' +
      'value_integer, value_real, value_text FROM player_state_entries ' +
      'WHERE player_id = ? AND domain = ?'
    ).all(Math.trunc(playerId), String(domain))
    if (!rows.length) {
      return structuredClone(defaultValue)
    }
    const nodes = {}
    for (const row of rows) {
      nodes[row.path] = row
    }
    if (!('' in nodes)) {
      throw new Error(`Estado relacional sem raiz: ${domain}`)
    }
    const children = {}
    for (const row of rows) {
      const parent = row.parent_path
      if (parent !== null && parent !== undefined) {
        if (!children[parent]) children[parent] = []
        children[parent].push(row)
      }
    }
    for (const group of Object.values(children)) {
      group.sort((a, b) => {
        if (a.position !== b.position) return a.position - b.position
        return a.path < b.path ? -1 : (a.path > b.path ? 1 : 0)
      })
    }

    const build = (path) => {
      const row = nodes[path]
      const nodeType = row.node_type
      if (nodeType === 'null') {
        return null
      }
      if (nodeType === 'boolean') {
        return !!row.value_integer
      }
      if (nodeType === 'integer') {
        return row.value_integer !== null && row.value_integer !== undefined
          ? Math.trunc(row.value_integer)
          : Number.parseInt(row.value_text, 10)
      }
      if (nodeType === 'real') {
        return Number(row.value_real)
      }
      if (nodeType === 'text') {
        return String(row.value_text || '')
      }
      if (nodeType === 'object') {
        const out = {}
        for (const child of (children[path] || [])) {
          out[String(child.segment)] = build(child.path)
        }
        return out
      }
      if (nodeType === 'array') {
        return (children[path] || []).map((child) => build(child.path))
      }
      throw new Error(`Tipo relacional desconhecido: ${nodeType}`)
    }

    return build('')
  }
}

module.exports = RelationalState
