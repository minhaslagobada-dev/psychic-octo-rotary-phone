'use strict'

const DataBase = require('../../../../Database/DatabaseManager')
const PlayerProfileMessage = require('../../Server/Home/PlayerProfileMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AskProfileMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.high_id = this.read_int()
    this.low_id = this.read_int()
    this.hasProfileData = this.read_boolean()
    this.profileData = null
    if (this.hasProfileData) {
      this.profileData = [
        this.read_Vint(),
        [this.read_int(), this.read_int()],
        this.read_Vint(),
        this.read_boolean(),
        this.read_string(),
        this.readScId(),
        this.read_Vint(),
        this.read_Vint(),
        this.read_Vint()
      ]
    }
    this.players = DataBase.loadById(this, this.low_id)
  }

  process () {
    if (this.high_id === 0) {
      new PlayerProfileMessage(this.client, this.player, this.high_id, this.low_id, this.players).send()
    }
  }
}

module.exports = AskProfileMessage
