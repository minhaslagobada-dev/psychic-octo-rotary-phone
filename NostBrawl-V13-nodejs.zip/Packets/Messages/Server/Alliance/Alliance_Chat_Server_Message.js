'use strict'

const { ClubService } = require('../../../../Logic/ClubService')
const Writer = require('../../../../Utils/Writer')

class AllianceChatServerMessage extends Writer {
  constructor (client, player, msgContent, clubID, isbot = false, entry = null) {
    super(client)
    this.msg_content = msgContent
    this.id = 24312
    this.version = 11
    this.player = player
    this.clubID = clubID
    this.isbot = isbot
    this.client = client
    this.entry = entry
  }

  _can_deliver (lowId) {
    return ClubService.is_member(lowId, this.clubID)
  }

  _latest_entry () {
    const entries = ClubService.get_messages(this.clubID)
    if (!entries.length) {
      throw new Error('Club stream is empty')
    }
    if (typeof this.msg_content === 'number' && Number.isInteger(this.msg_content)) {
      for (let index = entries.length - 1; index >= 0; index--) {
        if (entries[index].event === 4 && entries[index].message === String(this.msg_content)) {
          return entries[index]
        }
      }
    } else {
      for (let index = entries.length - 1; index >= 0; index--) {
        if (entries[index].event === 2 && entries[index].message === String(this.msg_content)) {
          return entries[index]
        }
      }
    }
    return entries[entries.length - 1]
  }

  encode () {
    const entry = this.entry || this._latest_entry()
    this.writeVint(entry.event)
    this.writeVint(0)
    this.writeVint(this.isbot ? 1 : (entry.position !== undefined ? entry.position : entry.id))
    this.writeVint(0)
    this.writeVint(entry.player_id)
    this.writeString(entry.player_name)
    this.writeVint(entry.player_role)
    this.writeVint(0)
    this.writeVint(0)
    if (entry.event === 4) {
      this.writeVint(Math.trunc(Number(entry.message)))
      this.writeVint(1)
      this.writeVint(0)
      this.writeVint(entry.player_id)
      this.writeString(entry.player_name)
    } else {
      this.writeString(entry.message)
    }
  }
}

module.exports = AllianceChatServerMessage
