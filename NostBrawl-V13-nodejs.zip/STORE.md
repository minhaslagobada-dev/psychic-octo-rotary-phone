# Lakey Store — bot Telegram + site + carteira + ofertas pagas (v13)

## Arquitetura (nov-2026): site pode morar em OUTRO servidor

Dois modos, controlados por `Store.Mode` no `config.json` do jogo:

- **`embedded`** (padrão): o jogo serve o site na `Store.Port` (25086) e a API
  interna na `Store.InternalPort` (25087). Os dois no mesmo host.
- **`agent`**: o jogo sobe **só** a API interna (25087). O site roda no pacote
  `lakeystore-site/` em outro host, ligando-se por HTTP/HMAC.

Canal interno jogo↔site (HMAC-SHA256, headers `X-Store-Timestamp/Nonce/Signature`,
janela 300s, nonce anti-replay; chave = `Store.InternalKey`, idêntica nos dois lados):

| Direção | Rota | Função |
|---------|------|--------|
| app → jogo | `POST /internal/store/v1/intent` (sem HMAC) | clique no pacote: identidade (token ou IP) → `{ticket,url}` |
| jogo → site | `POST /internal/store/v1/ticket` | empurra o ticket pro site remoto (modo agent) |
| site → jogo | `POST /internal/store/v1/deliver` | entrega idempotente (`order_key`) no jogo |
| bot → site | `POST /internal/store/v1/offers` / `deloffer` | ADM gerencia o catálogo do site |

Fluxo do jogador: **nada é digitado**. O clique no pacote identifica a conta
no jogo; o APK abre a URL devolvida (`?t=<ticket>&pack=<sku>`), o site troca o
ticket (uso único, 5 min) por sessão. Gift cards seguem 1x-cada, resgatados no site.
Módulo `Store/` embutido no servidor de jogo. Sobe junto com `node main.js`
(sem processo extra, sem dependências novas — usa o driver SQLite do projeto).

Servidor alvo: `kg-bsz01.altare.global:25085` (jogo) · site na porta **25086**.

## Componentes

| Peça | Arquivo | Função |
|---|---|---|
| Config | `config.json → "Store"` | token do bot, ADM, porta, URL pública, conversão |
| Núcleo | `Store/StoreService.js` | vínculo, carteira, gift cards, pedidos, reconciliação |
| Catálogo | `Store/StoreCatalog.js` | SKUs reais do billing (Type 1–3) + ofertas do admin (Type 4, `lakeystore.*`) |
| Entrega | `Store/Delivery.js` | `ShopService._deliver_item` + `RewardTransaction` (online = push; offline = próximo login) |
| Site | `Store/WebServer.js` + `Store/web/` | vitrine, Purchase Popup e Redeem Gift Card (fiéis às referências) |
| Bot | `Store/TelegramBot.js` | /gift com Telegram Stars, /addoffer, /gerar, /ofertas, /deloffer |
| Hook | chat do clube `/loja` | gera o código de vínculo da conta |

## Fluxo do jogador

1. No chat do clube: **`/loja`** → recebe código de 6 caracteres (10 min, uso único).
2. Abre `http://kg-bsz01.altare.global:25086` (ou pelo pacote dentro do jogo, após o patch C) → **Vincular** → cola o código.
3. **Add balance** → cola o código do gift card (comprado com Estrelas via `/gift` no bot).
4. Toca numa oferta → **Purchase Popup** (saldo no topo, preço, **Buy**) → entrega instantânea.

## Bot (ADM `8719469905`)

- `/gift` → pergunta "Enter the number of stars:" → usuário comum recebe invoice em **Stars (XTR)**; **ADM recebe o gift card direto, sem pagar, ilimitado**. 1⭐ = $0.40.
- `/gerar 10` → gift card de $10.00 direto.
- `/addoffer` → wizard: tipo (Gemas / Brawl Box / Big Box / MEGA Box / Brawler / Power Points) → quantidade → título → preço → repetível ou 1x → registra no site **e** no `billing_packages.csv` como **Type 4**.
- `/ofertas`, `/deloffer <sku>`.

## Tipo 4 — oferta paga pelo saldo (ver `analise-apk/ANALISE-OFERTAS-PAGAS.md`)

- A v13 separa: ofertas de moeda do jogo (`currency` 0=gems, 1=gold, 2=starpoints) e
  ofertas de dinheiro real (`billing_packages.csv`, `Type` 1/2/3 + SKU).
- **Type 4** está livre, é ignorado pelo fulfillment Google (sem entrega dupla) e é o
  identificador oficial das ofertas pagas pelo saldo do site (namespace SKU `lakeystore.*`).
- Tile novo dentro do APK exige rebuild com a linha correspondente em
  `assets/csv_client/billing_packages.csv` do cliente; os pacotes já existentes
  (gempack0..5, starterpacks) funcionam hoje com os patches B/C do dex.

## Endpoints

- `GET /health` → healthcheck (estilo SCID)
- `GET /api/offers` · `GET /api/prices` (para o mock de billing do patch B)
- `POST /api/link` · `GET /api/wallet` · `POST /api/redeem` · `POST /api/purchase`
  (sessão via header `X-Store-Session`; compra com `orderKey` idempotente)

## Garantias (todas cobertas por `scripts/smoke_store.js`, 44 checks)

débito atômico condicional · gift card de uso único (race-safe) · pedidos idempotentes
(order_key único) · 1x por conta · estorno automático em falha de entrega ·
reconciliação de pendências no boot · isolamento Google↔site · sessões com expiração.

## Deploy

```bash
npm install          # blakejs + better-sqlite3 (fallback; Node >=22.5 usa node:sqlite)
npm test             # suíte completa inclui a loja
node main.js         # sobe jogo (25085) + loja (25086) + bot Telegram
```

Banco da loja: `Database/store.sqlite` (WAL). Catálogo custom: `JSON/store_catalog.json`.
Backups: incluir os dois + `players.sqlite` + `GameAssets/csv_client/billing_packages.csv`.
