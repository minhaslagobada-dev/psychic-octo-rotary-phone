'use strict'

const { EventEmitter } = require('events')
const { V13Random } = require('./V13Math')
const { spreadFor, direction, speedBonus } = require('./ProjectileGeometry')
const { worldCommand } = require('./V13Commands')
const { TileMap } = require('../World/TileMap')
const { rules } = require('../World/GameModes')
const { enabled } = require('../World/BattleAssets')
const num = (row, key, fallback = 0) => Number(row[key]) || fallback
const distance = (a, b) => Math.hypot(a.x - b.x, a.y - b.y)
const angle = (x, y) => (Math.atan2(y, x) * 180 / Math.PI + 360) % 360
const clamp = (v, lo, hi) => Math.max(lo, Math.min(hi, v))

// Authoritative, fixed 50 ms steps. Neither positions, damage, ammunition nor
// outcomes submitted by a client are accepted as world state.
class BattleWorld extends EventEmitter {
  constructor (id, assets, mapId, players, seed = 0) {
    super()
    this.id = id; this.assets = assets; this.mapId = mapId
    this.seed = seed; this.random = new V13Random(seed); this.random.rand(1)
    const { location, grid } = assets.locationMap(mapId)
    this.mode = rules(location.GameMode); this.map = new TileMap(grid, assets)
    this.players = players; this.characters = new Map(); this.objects = new Map()
    this.nextId = 1; this.tick = 0; this.phase = 'loading'; this.loadingTicks = 0
    this.baseHpPercent = [100, 100]; this.bossHpPercent = 100; this.wave = 0
    this.alivePlayers = players.length; this.aliveTeams = new Set(players.map(p => p.team)).size
    this.teamScores = [0, 0]; this.countdown = null; this.outcome = null
    const counts = new Map()
    for (const entry of players) {
      const ordinal = counts.get(entry.team) || 0; counts.set(entry.team, ordinal + 1)
      entry.score = 0; entry.kills = []; entry.rank = 0; entry.ready = Boolean(entry.bot)
      entry.brawlerId = entry.brawlerId === undefined ? entry.player.brawler_id : entry.brawlerId; entry.skinId = entry.skinId === undefined ? entry.player.skin_id || 0 : entry.skinId
      entry.powerLevel = entry.powerLevel === undefined ? clamp(Number((entry.player.Brawler_level || {})[entry.brawlerId]) || 0, 0, 9) : entry.powerLevel
      entry.spawn = this.spawnPoint(entry, ordinal)
      const char = this.character(entry.brawlerId, entry.team, entry.index, entry.spawn, entry.powerLevel)
      char.entry = entry; char.spawn = entry.spawn; this.characters.set(entry.player.low_id, char)
    }
    this.setupObjectives()
  }

  add (object, dataClass, objectClass) {
    if (this.objects.size >= 8191) throw new Error('v13 active object limit exceeded')
    while (this.objects.has(this.nextId)) this.nextId = this.nextId % 8191 + 1
    object.id = this.nextId; this.nextId = this.nextId % 8191 + 1; object.dataClass = dataClass; object.objectClass = objectClass
    object.created = this.tick; this.objects.set(object.id, object); return object
  }

  spawnPoint (entry, ordinal) {
    let points
    if ([6, 9].includes(this.mode.variation)) points = this.map.markers.get('1')
    else points = this.map.markers.get(String(entry.team + 1))
    if (!points || !points.length) throw new Error('Map lacks player spawn markers')
    const point = points[[6, 9].includes(this.mode.variation) ? entry.index % points.length : ordinal % points.length]
    return this.freePoint(point.x, point.y, 100)
  }

  freePoint (x, y, radius) {
    if (this.map.canOccupy(x, y, radius)) return { x, y }
    for (let ring = 1; ring <= Math.max(this.map.width, this.map.height); ring++) {
      for (let dy = -ring; dy <= ring; dy++) for (let dx = -ring; dx <= ring; dx++) {
        if (Math.abs(dx) !== ring && Math.abs(dy) !== ring) continue
        const px = (Math.floor(x / 300) + dx) * 300 + 150; const py = (Math.floor(y / 300) + dy) * 300 + 150
        if (this.map.canOccupy(px, py, radius)) return { x: px, y: py }
      }
    }
    throw new Error('Map has no legal spawn')
  }

  character (dataId, team, index, point, powerLevel = 0, owner = null) {
    const data = this.assets.tables.characters[dataId]
    if (!data) throw new Error('Unknown character')
    const scale = 1 + powerLevel * 0.05
    return this.add({ dataId, team, index: Math.max(0, team) * 16 + index, ...point, z: 0,
      radius: num(data, 'CollisionRadius', 100), hp: Math.round(num(data, 'Hitpoints', 1) * scale),
      maxHp: Math.round(num(data, 'Hitpoints', 1) * scale), speed: num(data, 'Speed'), powerLevel, scale,
      superCharge: 0, score: 0, owner, attackAngle: 0, moveAngle: 0, state: 0,
      lastDamage: -1000, lastAttack: -1000, lastRegen: 0, regenBlockedAt: -1000, projectileCooldowns: new Map(), statuses: [], skills: [data.WeaponSkill, data.UltimateSkill].filter(Boolean).map(name => {
        const definition = this.assets.named('skills', name)
        return { definition, activeMs: 0, cooldownMs: 0, ammo: num(definition, 'MaxCharge') * 1000, onActivate: false }
      }) }, 16, 1)
  }

  setupObjectives () {
    const v = this.mode.variation
    if (v === 0) {
      this.gemSpawn = this.freePoint(this.map.logicWidth / 2, this.map.logicHeight / 2, 0)
      this.gemSpawner = this.spawnItem('OrbSpawner', this.gemSpawn.x, this.gemSpawn.y)
      this.gemSpawner.valueA = 140; this.gemSpawner.valueB = 0
    }
    if (v === 2 || v === 8) {
      const data = this.assets.tables.characters.find(c => c.Type === 'Pvp_Base')
      const points = this.map.markers.get(v === 2 ? '8' : '5') || []
      this.bases = points.map(p => {
        const team = v === 2 && distance(p, this.map.markers.get('2')[0]) < distance(p, this.map.markers.get('1')[0]) ? 1 : 0
        return this.character(data.id, team, 15, p)
      }).sort((a, b) => a.team - b.team)
    }
    if ([6, 9].includes(v)) {
      const box = this.assets.tables.characters.find(c => c.Type === 'LootBox')
      for (const point of this.map.markers.get('4') || []) this.character(box.id, -1, 0, point)
    }
    if (v === 7) {
      const boss = Array.from(this.characters.values()).find(c => c.team === 1)
      if (boss) { boss.maxHp += this.assets.global('BOSS_HEALTH_INCREASE', 110000); boss.hp = boss.maxHp; boss.scale *= 1 + this.assets.global('BOSS_DAMAGE_PERCENT_INCREASE', 50) / 100; boss.speed += this.assets.global('BOSS_SPEED_INCREASE', 100); this.boss = boss }
    }
    if (v === 10) {
      const data = this.assets.tables.characters.find(c => c.Type === 'Npc_Boss')
      const point = (this.map.markers.get('2') || [])[0]
      if (data && point) this.boss = this.character(data.id, 1, 0, point)
    }
    if (v === 5) {
      const ball = this.assets.tables.characters.find(c => c.Type === 'LaserBall')
      this.ball = this.character(ball.id, -1, 0, this.freePoint(this.map.logicWidth / 2, this.map.logicHeight / 2, 100))
    }
  }

  input (entry, command) {
    if (command.type === 4) { entry.ready = true; return }
    if (this.phase !== 'running' || this.goalPauseUntil > this.tick) return
    const char = this.characters.get(entry.player.low_id)
    if (!char || char.hp <= 0 || char.stunUntil > this.tick) return
    if (command.type === 2) {
      char.target = { x: clamp(command.x, char.radius, this.map.logicWidth - char.radius), y: clamp(command.y, char.radius, this.map.logicHeight - char.radius) }
    } else if ((command.type === 0 || command.type === 1) && this.ball && this.ball.carrier === char) this.kickBall(char, command.x, command.y, command.type === 1)
    else if (command.type === 0 || command.type === 1) this.activate(char, command.type, command.x, command.y, command.flag)
  }

  activate (char, slot, x, y, auto = false) {
    const state = char.skills[slot]
    if (!state || state.activeMs > 0 || state.cooldownMs > 0 || char.charging || char.hp <= 0 || char.stunUntil > this.tick) return false
    const s = state.definition
    if (slot === 1 && char.entry && char.superCharge < 4000) return false
    if (num(s, 'MaxCharge') > 0 && state.ammo < 1000) return false
    if (auto) {
      const target = this.nearestEnemy(char)
      if (target) { x = target.x; y = target.y }
    }
    if (!Number.isFinite(x) || !Number.isFinite(y)) return false
    if (slot === 1) char.superCharge = 0
    if (num(s, 'MaxCharge') > 0) state.ammo -= 1000
    const range = num(s, 'CastingRange') * 100
    let dx = x - char.x; let dy = y - char.y; const length = Math.hypot(dx, dy) || 1
    const reach = enabled(s.AlwaysCastAtMaxRange) ? range : Math.min(range, length)
    state.target = { x: char.x + dx / length * reach, y: char.y + dy / length * reach }
    state.direction = Math.atan2(dy, dx); state.slot = slot; state.elapsed = 0
    state.shotsLeft = Math.max(1, Math.floor(num(s, 'ActiveTime', 50) / num(s, 'MsBetweenAttacks', 50)))
    state.shotIndex = 0
    state.nextShot = enabled(s.ExecuteFirstAttackImmediately) ? 0 : Math.max(0, num(s, 'MsBetweenAttacks'))
    state.activeMs = Math.max(50, num(s, 'ActiveTime', 50)); state.onActivate = true
    state.cooldownMs = state.activeMs + num(s, 'Cooldown'); char.attackAngle = angle(dx, dy)
    char.lastAttack = this.tick; char.invisible = false
    if (s.BehaviorType === 'Invisibility') { char.invisible = true; char.invisibleUntil = this.tick + num(s, 'ActiveTime') / 50 }
    if (s.BehaviorType === 'Charge') {
      char.charging = true; char.chargeType = num(s, 'ChargeType'); char.chargeTarget = state.target
      char.chargeSpeed = num(s, 'ChargeSpeed', 1500); char.chargeSkill = state; char.chargeHit = new Set()
      char.chargeTicks = Math.max(1, Math.floor(([2, 6].includes(char.chargeType) ? 2300 : reach) / (char.chargeSpeed / 20)))
      char.chargeTotalTicks = char.chargeTicks; char.chargeDistance = reach; char.target = null
      if (s.AreaEffectObject) this.area(s.AreaEffectObject, char, char.x, char.y, num(s, 'Damage') * char.scale, slot)
      if (s.SpawnedItem) this.spawnItem(s.SpawnedItem, char.x, char.y, char, num(s, 'Damage') * char.scale)
    }
    return true
  }

  nearestEnemy (char) {
    let nearest = null; let best = Infinity
    for (const other of this.objects.values()) if (other.dataClass === 16 && other.hp > 0 && other !== this.ball && other.team !== char.team && (other.team >= 0 || this.assets.tables.characters[other.dataId].Type === 'LootBox') && !other.invisible) {
      const d = distance(char, other); if (d < best) { best = d; nearest = other }
    }
    return nearest
  }

  shoot (char, state) {
    const s = state.definition; const count = num(s, 'NumBulletsInOneAttack', 1)
    for (let i = 0; i < count; i++) {
      const shots = Math.max(1, Math.floor(num(s, 'ActiveTime', 50) / num(s, 'MsBetweenAttacks', 50)))
      const spread = spreadFor(num(s, 'Spread'), num(s, 'AttackPattern'), state.shotIndex, shots, i, count)
      const rotation = direction(state.target.x - char.x, state.target.y - char.y, spread)
      if (s.Projectile) this.projectile(s.Projectile, char, rotation, num(s, 'Damage') * char.scale, state, char, { count, pellet: i, shot: state.shotIndex })
      else {
        for (const target of this.objects.values()) if (target.dataClass === 16 && target.team !== char.team && target.hp > 0 && distance(char, target) <= num(s, 'CastingRange') * 100 + target.radius) this.damage(target, num(s, 'Damage') * char.scale, char, state.slot)
      }
    }
    if (s.AreaEffectObject) this.area(s.AreaEffectObject, char, state.target.x, state.target.y, num(s, 'Damage') * char.scale, state.slot)
    if (!s.Projectile && s.SummonedCharacter) this.summon(s.SummonedCharacter, char, state.target)
    if (!s.Projectile && s.SpawnedItem) this.spawnItem(s.SpawnedItem, state.target.x, state.target.y, char, num(s, 'Damage') * char.scale)
  }

  projectile (name, owner, rotation, damage, skill, origin = owner, volley = {}) {
    const data = this.assets.named('projectiles', name)
    const range = num(skill.definition, 'CastingRange', 30) * 100
    const indirect = enabled(data.Indirect)
    const speed = num(data, 'Speed', 3000) + speedBonus(num(data, 'Speed', 3000), volley.count || 1, volley.pellet || 0, volley.shot || 0)
    let reach = indirect ? Math.min(range, distance(origin, skill.target)) : range
    const target = { x: origin.x + Math.cos(rotation) * reach, y: origin.y + Math.sin(rotation) * reach }
    if (indirect && num(skill.definition, 'Spread') && !num(skill.definition, 'AttackPattern') && (volley.count || 1) === 1) {
      const spread = enabled(data.ConstantFlyTime) ? 3 * num(skill.definition, 'Spread') : Math.trunc(Math.max(reach, num(data, 'MinDistanceForSpread')) * num(skill.definition, 'Spread') / 300)
      if (spread >= 3) { target.x += 2 * this.random.rand(spread) - (spread - 1); target.y += 2 * this.random.rand(spread) - (spread - 1) }
    }
    if (indirect) {
      target.x = clamp(Math.round(target.x), 1, this.map.logicWidth - 2); target.y = clamp(Math.round(target.y), 1, this.map.logicHeight - 2)
      reach = distance(origin, target)
    }
    const p = this.add({ dataId: data.id, owner, team: owner.team, index: owner.index, x: origin.x, y: origin.y, startX: origin.x, startY: origin.y, z: 0,
      angle: (rotation * 180 / Math.PI + 360) % 360, rotation, radius: num(data, 'Radius'), speed, damage,
      skill, slot: skill.slot, totalRange: reach, remaining: reach, flightTicks: Math.max(1, enabled(data.ConstantFlyTime) ? Math.round(900 * 20 / speed) : Math.floor(reach * 20 / speed)),
      indirect, target, age: 0, state: 0, hit: new Set(), bounces: 0, bounceTileIndex: null,
      fuseTick: num(data, 'TriggerWithDelayMs') ? this.tick + Math.ceil(num(data, 'TriggerWithDelayMs') / 50) : 0 }, 6, 2)
    for (let i = 0; i < num(data, 'EarlyTicks') && this.objects.has(p.id); i++) this.stepProjectile(p)
    return p
  }

  area (name, owner, x, y, damage, slot = 0) {
    const data = this.assets.named('area_effects', name)
    if (data.Damage && !['MineExplosion', 'SniperBombExplosion'].includes(name)) damage = Math.abs(Number(data.Damage)) * (owner ? owner.scale : 1)
    return this.add({ dataId: data.id, owner, team: owner.team, index: owner.index, x, y, z: 0, damage, slot, age: 0,
      radius: num(data, 'Radius', 300), duration: Math.max(1, Math.ceil(num(data, 'TimeMs', 50) / 50)), hit: new Set() }, 17, 3)
  }

  summon (name, owner, point) {
    const data = this.assets.named('characters', name)
    for (const object of this.objects.values()) if (object.owner === owner && object.dataClass === 16 && object.dataId === data.id) this.objects.delete(object.id)
    return this.character(data.id, owner.team, owner.index % 16, this.freePoint(point.x, point.y, num(data, 'CollisionRadius', 100)), owner.powerLevel, owner)
  }

  spawnItem (name, x, y, owner = null, damage = 0) {
    const data = this.assets.named('items', name)
    return this.add({ dataId: data.id, x, y, z: 0, index: owner ? owner.index : [6, 9].includes(this.mode.variation) ? 255 : 102, team: owner ? owner.team : -1, owner, damage, age: 0, remainingTicks: 0 }, 18, 4)
  }

  damage (target, amount, source, slot = 0) {
    if (this.phase === 'finished' || target.hp <= 0 || target.invulnerableUntil > this.tick || target === this.ball) return 0
    const dealt = Math.min(target.hp, Math.max(0, Math.round(amount)))
    target.hp -= dealt; target.lastDamage = this.tick
    if (source && source.team !== target.team) {
      const owner = source.entry ? source : source.owner
      if (owner) {
        const d = this.assets.tables.characters[owner.dataId]
        const factor = this.mode.cooperative ? this.assets.global('COOP_ULTI_CHARGE_MUL', 30) / this.assets.global('COOP_ULTI_CHARGE_DIV', 100) : owner === this.boss && this.mode.variation === 7 ? this.assets.global('BOSS_ULTI_CHARGE_MUL', 60) / this.assets.global('BOSS_ULTI_CHARGE_DIV', 100) : 1
        owner.superCharge = Math.min(4000, owner.superCharge + dealt * num(d, slot ? 'UltiChargeUltiMul' : 'UltiChargeMul') / 100 * factor)
      }
    }
    if (target.hp === 0) this.kill(target, source)
    return dealt
  }

  kill (target, source) {
    target.target = null; target.charging = false; target.invisible = false; target.respawnAt = this.tick + 60
    for (const state of target.skills) { state.activeMs = 0; state.cooldownMs = 0 }
    if (this.ball && this.ball.carrier === target) { target.carryingBall = false; this.ball.carrier = null; this.ball.pickupAfter = this.tick + 6 }
    const killer = source && (source.entry ? source : source.owner)
    if (target.entry) {
      if (killer && killer.entry && killer.team !== target.team) {
        killer.entry.kills.push({ victim: target.entry.index, value: 1 })
        if (this.mode.variation === 3) { const stars = Math.max(2, target.score + 2); this.teamScores[killer.team] += stars; killer.entry.score += stars; killer.score = Math.min(5, killer.score + 1) }
      }
      if (this.mode.variation === 0) {
        for (let i = 0; i < target.score; i++) {
          const point = this.freePoint(target.x + Math.cos(i * 2.4) * Math.min(240, i * 15), target.y + Math.sin(i * 2.4) * Math.min(240, i * 15), 0)
          this.spawnItem('Point', point.x, point.y)
        }
        target.score = 0; target.entry.score = 0
      }
      if ([6, 9].includes(this.mode.variation)) {
        this.spawnItem('BattleRoyaleBuff', target.x, target.y)
        if (this.mode.variation === 6) target.entry.rank = Array.from(this.characters.values()).filter(c => c.hp > 0).length + 1
        target.respawnAt = this.mode.variation === 9 ? this.tick + 300 : Infinity
        if (this.mode.variation === 9 && !Array.from(this.characters.values()).some(c => c.team === target.team && c.hp > 0)) {
          const rank = new Set(Array.from(this.characters.values()).filter(c => c.hp > 0).map(c => c.team)).size + 1
          for (const entry of this.players) if (entry.team === target.team) entry.rank = rank
        }
      }
    } else {
      if (this.assets.tables.characters[target.dataId].Type === 'LootBox') this.spawnItem('BattleRoyaleBuff', target.x, target.y)
      target.removeAt = this.tick + 20
    }
    this.emit('kill', target, killer)
  }

  stepCharacter (char) {
    if (char.hp <= 0) {
      if (char.entry && !char.entry.disconnected && char.respawnAt <= this.tick && (this.mode.variation !== 9 || Array.from(this.characters.values()).some(c => c !== char && c.team === char.team && c.hp > 0))) {
        Object.assign(char, this.freePoint(char.spawn.x, char.spawn.y, char.radius)); char.hp = char.maxHp
        char.invulnerableUntil = this.tick + 60; char.statuses = []
        for (const state of char.skills) state.ammo = num(state.definition, 'MaxCharge') * 1000
      }
      return
    }
    this.stepStatuses(char)
    if (char.hp <= 0) return
    this.stepNpc(char)
    if (char.entry && char.entry.bot) this.stepBot(char)
    char.state = char.skills.some(state => state.activeMs > 0) ? 2 : char.target ? 1 : 0
    if (char.invisibleUntil <= this.tick) char.invisible = false
    for (const state of char.skills) {
      state.onActivate = false; state.cooldownMs = Math.max(0, state.cooldownMs - 50)
      if (state.activeMs > 0) {
        if (state.definition.BehaviorType === 'Attack' && state.shotsLeft > 0 && state.elapsed >= state.nextShot) {
          this.shoot(char, state); state.shotsLeft--; state.shotIndex++; state.nextShot += Math.max(50, num(state.definition, 'MsBetweenAttacks', 50))
        }
        state.elapsed += 50; state.activeMs = Math.max(0, state.activeMs - 50)
      }
      if (state.cooldownMs === 0 && num(state.definition, 'MaxCharge') && num(state.definition, 'RechargeTime')) state.ammo = Math.min(num(state.definition, 'MaxCharge') * 1000, state.ammo + Math.trunc(50000 / (num(state.definition, 'RechargeTime') * (char === this.boss && this.mode.variation === 7 ? this.assets.global('BOSS_RELOAD_TIME_DIV', 20) / 100 : 1))))
    }
    if (char.skills.some(state => state.activeMs > 0)) char.regenBlockedAt = this.tick
    for (const [key, until] of char.projectileCooldowns) if (until <= this.tick) char.projectileCooldowns.delete(key)
    if (char.charging) {
      const target = char.chargeTarget; const d = distance(char, target); const step = Math.min(d, char.chargeSpeed / 20)
      const nx = char.x + (target.x - char.x) / (d || 1) * step; const ny = char.y + (target.y - char.y) / (d || 1) * step
      const jumping = [2, 3, 6].includes(char.chargeType)
      if (jumping) {
        const fraction = Math.min(1, (char.chargeTotalTicks - char.chargeTicks + 1) / char.chargeTotalTicks)
        const jumpStep = d / char.chargeTicks
        char.x += (target.x - char.x) / (d || 1) * jumpStep
        char.y += (target.y - char.y) / (d || 1) * jumpStep
        char.z = Math.max(0, Math.sin(fraction * Math.PI) * 600)
      }
      else {
        if (char.chargeType === 1) this.map.destroy(nx, ny, char.radius + 150, this.tick)
        const wall = this.map.trace(char.x, char.y, nx, ny, char.radius)
        const point = this.map.move(char.x, char.y, nx, ny, char.radius); char.x = point.x; char.y = point.y
        if (wall) {
          if (char.chargeType === 7) {
            const vx = (target.x - char.x) / (distance(char, target) || 1); const vy = (target.y - char.y) / (distance(char, target) || 1)
            const dot = vx * wall.nx + vy * wall.ny; const remaining = Math.max(step, (char.chargeTicks - 1) * char.chargeSpeed / 20)
            char.chargeTarget = { x: char.x + (vx - 2 * dot * wall.nx) * remaining, y: char.y + (vy - 2 * dot * wall.ny) * remaining }
          } else char.chargeTicks = 1
        }
      }
      for (const enemy of this.objects.values()) if (enemy.dataClass === 16 && enemy.hp > 0 && enemy.team !== char.team && enemy !== this.ball && distance(char, enemy) < char.radius + enemy.radius + 80 && !char.chargeHit.has(enemy.id) && !jumping) {
        char.chargeHit.add(enemy.id); this.damage(enemy, num(char.chargeSkill.definition, 'Damage') * char.scale, char, char.chargeSkill.slot)
        if (num(char.chargeSkill.definition, 'ChargePushback')) this.push(enemy, char, num(char.chargeSkill.definition, 'ChargePushback') * 6)
      }
      if (--char.chargeTicks <= 0 || (!jumping && d <= step)) {
        char.charging = false; char.z = 0; Object.assign(char, this.freePoint(char.x, char.y, char.radius))
        const s = char.chargeSkill.definition
        if (jumping) {
          if (char.chargeType === 3) {
            this.map.destroy(char.x, char.y, 800, this.tick)
            for (const enemy of this.objects.values()) if (enemy.dataClass === 16 && enemy.team !== char.team && !this.airborne(enemy) && distance(char, enemy) < 800) {
              this.damage(enemy, num(s, 'Damage') * char.scale, char, 1)
              if (num(s, 'ChargePushback')) this.push(enemy, char, num(s, 'ChargePushback') * 6)
            }
          }
          if (s.AreaEffectObject) this.area(s.AreaEffectObject, char, char.x, char.y, num(s, 'Damage') * char.scale, 1)
        }
      }
    } else if (char.target && !(char.stunUntil > this.tick) && !char.skills.some(s => s.activeMs > 0 && !enabled(s.definition.CanMoveAtSameTime))) {
      const d = distance(char, char.target); const step = Math.min(d, char.speed * (char.slowUntil > this.tick ? Math.max(0.1, 1 - char.slowPercent) : 1) / 20)
      const dx = (char.target.x - char.x) / (d || 1) * step; const dy = (char.target.y - char.y) / (d || 1) * step
      const point = this.moveBody(char, char.x + dx, char.y + dy)
      char.moveAngle = angle(dx, dy); char.x = point.x; char.y = point.y
      if (d <= step) char.target = null
    }
    if (this.tick - char.lastRegen >= 20) {
      const data = this.assets.tables.characters[char.dataId]
      if (char === this.boss && this.mode.variation === 7) {
        this.damage(char, Math.trunc(char.maxHp / this.assets.global('BOSS_HEALTH_LOSS_DIV', 300)), null)
        char.lastRegen = this.tick
      } else if (this.tick - Math.max(char.lastDamage, char.lastAttack, char.regenBlockedAt) >= 60) {
        this.heal(char, Math.trunc(char.maxHp * (data.Type === 'Hero' ? 13 : num(data, 'RegeneratePerSecond')) / 100))
        char.lastRegen = this.tick
      }
    }
  }

  stepProjectile (p) {
    const data = this.assets.tables.projectiles[p.dataId]
    if (p.indirect) { this.stepIndirectProjectile(p, data); return }
    p.age++; const length = Math.max(0, Math.min(p.remaining, p.speed / 20))
    const tx = p.x + Math.cos(p.rotation) * length; const ty = p.y + Math.sin(p.rotation) * length
    let wall = null
    wall = this.map.trace(p.x, p.y, tx, ty, p.radius, true, enabled(data.PassesEnvironment) || enabled(data.PiercesEnvironment) || enabled(data.PiercesEnvironmentLikeButter))
    if (enabled(data.PiercesEnvironmentLikeButter)) this.map.destroy(tx, ty, Math.max(150, p.radius), this.tick)
    let end = wall ? wall.t : 1
    if (!p.indirect) {
      const hits = []
      for (const target of this.objects.values()) {
        if (target.dataClass !== 16 || target.hp <= 0 || target === this.ball || this.airborne(target) || p.hit.has(target.id) ) continue
        const healing = num(data, 'HealOwnPercent') > 0
        if (healing ? target.team !== p.team : target.team === p.team || target === p.owner) continue
        const dx = tx - p.x; const dy = ty - p.y; const a = dx * dx + dy * dy
        const ox = p.x - target.x; const oy = p.y - target.y; const r = p.radius + target.radius
        const b = ox * dx + oy * dy; const disc = b * b - a * (ox * ox + oy * oy - r * r)
        if (a === 0 || disc < 0) continue
        const t = ox * ox + oy * oy <= r * r ? 0 : (-b - Math.sqrt(disc)) / a
        if (t >= 0 && t <= end) hits.push({ target, t })
      }
      hits.sort((a, b) => a.t - b.t)
      for (const { target, t } of hits) {
        const key = p.dataId + ':' + target.id
        const cooldown = num(data, 'SameProjectileCanNotDamageMS')
        if (cooldown && (p.owner.projectileCooldowns.get(key) || 0) > this.tick) continue
        if (cooldown) p.owner.projectileCooldowns.set(key, this.tick + Math.ceil(cooldown / 50))
        p.hit.add(target.id)
        this.projectileHit(p, target)
        if (!enabled(data.PiercesCharacters)) { end = t; wall = null; p.remaining = 0; break }
      }
    }
    p.x += (tx - p.x) * end; p.y += (ty - p.y) * end; p.remaining -= length * end
    if (wall) {
      if (enabled(data.IsBouncing)) {
        const vx = Math.cos(p.rotation); const vy = Math.sin(p.rotation); const dot = vx * wall.nx + vy * wall.ny
        p.rotation = Math.atan2(vy - 2 * dot * wall.ny, vx - 2 * dot * wall.nx); p.angle = angle(Math.cos(p.rotation), Math.sin(p.rotation)); p.bounces++
        p.bounceTileIndex = wall.tile ? wall.tile.index : null
        if (p.bounces <= 7) { p.remaining += num(data, 'DistanceAddFromBounce'); p.totalRange += num(data, 'DistanceAddFromBounce') }
        p.x += wall.nx * 0.1; p.y += wall.ny * 0.1
      } else p.remaining = 0
    }
    if (p.remaining <= 0 || (p.fuseTick && this.tick >= p.fuseTick)) this.explode(p)
  }

  stepIndirectProjectile (p, data) {
    p.age++
    const fraction = Math.min(1, p.age / p.flightTicks)
    let position = fraction
    const bounce = num(data, 'BouncePercent')
    if (bounce && p.age <= p.flightTicks) {
      const span = 10 * bounce; const pivot = 1000 - span; const progress = 1000 * fraction
      position = (1 + span / 1500) * (progress <= pivot ? progress / 1000 : pivot / 1000 + (progress - pivot) / 2000)
    }
    p.x = Math.round(p.startX + (p.target.x - p.startX) * position)
    p.y = Math.round(p.startY + (p.target.y - p.startY) * position)
    p.remaining = Math.max(0, p.totalRange * (1 - fraction))
    let start = 0; let end = 1
    if (bounce) { const pivot = 1 - bounce / 150; [start, end] = position < pivot ? [0, pivot] : [pivot, 1] }
    const range = Math.max(1, p.totalRange)
    const duration = Math.max(0.1, range * (end - start) / (p.speed * 0.1))
    const elapsed = range * (position - start) / (p.speed * 0.1)
    p.z = clamp(Math.trunc(elapsed * (-num(data, 'Gravity') / (Math.sqrt(range) * 40)) * (elapsed - duration) * 300), 0, 3000)
    if (p.fuseTick ? this.tick >= p.fuseTick : fraction >= 1) this.explode(p)
  }

  explode (p) {
    const data = this.assets.tables.projectiles[p.dataId]; this.objects.delete(p.id)
    for (const key of ['SpawnAreaEffectObject', 'SpawnAreaEffectObject2']) if (data[key]) this.area(data[key], p.owner, p.x, p.y, p.damage, p.slot)
    const s = p.skill.definition
    if (data.ChainBullet && num(data, 'ChainBullets') && (p.hit.size || enabled(data.ExecuteChainOnNoHit))) {
      const count = num(data, 'ChainBullets'); const spread = num(data, 'ChainSpread', 100) * 0.008
      for (let i = 0; i < count; i++) this.projectile(data.ChainBullet, p.owner, p.rotation + (count === 1 ? 0 : i / (count - 1) - 0.5) * spread, p.damage, { ...p.skill, definition: { ...s, CastingRange: num(data, 'ChainTravelDistance', 12) } }, p)
    }
    if (s.SummonedCharacter) this.summon(s.SummonedCharacter, p.owner, p)
    if (s.SpawnedItem) this.spawnItem(s.SpawnedItem, p.x, p.y, p.owner, p.damage)
    if (enabled(data.PiercesEnvironmentLikeButter)) this.map.destroy(p.x, p.y, Math.max(150, p.radius), this.tick)
  }

  visibleObjects (viewer) {
    const own = this.characters.get(viewer.player.low_id)
    return Array.from(this.objects.values()).filter(object => {
      if (object === own) return true
      if (object.removeAt <= this.tick) return false
      if (object.team !== viewer.team && object.dataClass === 16) {
        const tile = this.map.tile(Math.floor(object.x / 300), Math.floor(object.y / 300))
        const inBush = tile && enabled(tile.definition.HidesHero) && !this.map.destroyed.has(tile.index)
        const hidden = object.invisible || (inBush && this.tick - Math.max(object.lastAttack, object.lastDamage) > 20)
        if (hidden && !this.players.some(entry => {
          const ally = this.characters.get(entry.player.low_id)
          return entry.team === viewer.team && ally && ally.hp > 0 && distance(object, ally) <= 600
        })) return false
      }
      return distance(object, own) < 5500 || object.entry || object === this.boss || object === this.ball || object.dataClass === 16 && this.assets.tables.characters[object.dataId].Type === 'Pvp_Base'
    }).sort((a, b) => {
      const priority = o => o === own ? 0 : o.entry ? 1 : o === this.boss || o === this.ball || o.dataClass === 16 && this.assets.tables.characters[o.dataId].Type === 'Pvp_Base' ? 2 : 3
      return priority(a) - priority(b) || distance(a, own) - distance(b, own) || a.id - b.id
    }).slice(0, 127)
  }

  step () {
    if (this.phase === 'finished') return
    if (this.phase === 'loading') {
      this.loadingTicks++
      if (this.players.every(p => p.ready)) { this.phase = 'running'; this.emit('started') }
      else if (this.loadingTicks >= 600) this.finish(null, 'loading-timeout')
      return
    }
    this.tick++; this.map.tick(this.tick)
    for (const entry of this.players) if (entry.session) for (const input of entry.session.input.drain()) { const command = worldCommand(this, entry, input); if (command) this.input(entry, command) }
    for (const object of Array.from(this.objects.values())) {
      if (object.removeAt <= this.tick) { this.objects.delete(object.id); continue }
      if (object.dataClass === 16) this.stepCharacter(object)
      else if (object.dataClass === 6) this.stepProjectile(object)
      else if (object.dataClass === 17) this.stepArea(object)
      else if (object.dataClass === 18) this.stepItem(object)
    }
    this.stepObjectives()
  }

  stepObjectives () {
    const v = this.mode.variation
    const alive = Array.from(this.characters.values()).filter(c => c.hp > 0)
    this.alivePlayers = alive.length; this.aliveTeams = new Set(alive.map(c => c.team)).size
    if ([6, 9].includes(v)) {
      if (this.tick > 400 && this.tick % 20 === 0) {
        const inset = Math.floor((this.tick - 400) / 200) * 300
        for (const char of alive) if (char.x < inset || char.y < inset || char.x > this.map.logicWidth - inset || char.y > this.map.logicHeight - inset) this.damage(char, 1000, null)
      }
      const survivors = Array.from(this.characters.values()).filter(c => c.hp > 0)
      this.alivePlayers = survivors.length; this.aliveTeams = new Set(survivors.map(c => c.team)).size
      if (this.aliveTeams <= 1) {
        for (const entry of this.players) if (!entry.rank) entry.rank = survivors.some(c => c.team === entry.team) ? 1 : this.aliveTeams + 1
        this.finish(survivors[0] ? survivors[0].team : null, 'last-team')
      }
    } else if (v === 0) {
      if (this.tick >= this.gemSpawner.valueA) {
        this.spawnItem('Point', this.gemSpawn.x, this.gemSpawn.y)
        this.gemSpawner.valueB = this.tick; this.gemSpawner.valueA += 140
      }
      this.teamScores = [0, 1].map(team => alive.filter(c => c.team === team).reduce((n, c) => n + c.score, 0))
      const leading = this.teamScores.findIndex((n, team) => n >= 10 && n > this.teamScores[1 - team])
      if (leading < 0) this.countdown = null
      else if (!this.countdown || this.countdown.team !== leading) this.countdown = { team: leading, due: this.tick + 300 }
      if (this.countdown && this.tick >= this.countdown.due) this.finish(this.countdown.team, 'gems')
    } else if (v === 2 || v === 8) {
      for (let i = 0; i < this.bases.length; i++) this.baseHpPercent[i] = Math.ceil(this.bases[i].hp / this.bases[i].maxHp * 100)
      const dead = this.bases.findIndex(base => base.hp <= 0)
      if (dead >= 0) this.finish(v === 2 ? 1 - dead : 1, 'base-destroyed')
    } else if ((v === 7 || v === 10) && this.boss) {
      this.bossHpPercent = Math.ceil(this.boss.hp / this.boss.maxHp * 100)
      if (this.boss.hp <= 0) this.finish(0, 'boss-defeated')
    }
    if (this.phase === 'finished') return
    if (v === 5) this.stepBall()
    if (v === 8 || v === 10) this.stepCoop()
    if (this.tick >= (v === 7 ? 2400 : 3600) && ![5, 6, 8, 9, 10].includes(v)) {
      const scores = v === 2 ? this.baseHpPercent : this.teamScores
      this.finish(v === 7 ? 1 : scores[0] === scores[1] ? null : scores[0] > scores[1] ? 0 : 1, 'time-limit')
    }
  }

  finish (winner, reason) {
    if (this.phase === 'finished') return false
    this.phase = 'finished'; this.outcome = { winner, reason, tick: this.tick }
    this.emit('finished', this.outcome); return true
  }
}
Object.assign(BattleWorld.prototype, require('./CombatEffects'), require('./Objectives'), require('./BotController'), require('./Traps'), require('./BodyCollision'))
module.exports = { BattleWorld }
