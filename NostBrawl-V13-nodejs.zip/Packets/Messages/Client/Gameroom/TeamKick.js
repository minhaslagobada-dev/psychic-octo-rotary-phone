'use strict'
const TeamKickMessage = require('./TeamKickMessage')

class TeamKick extends TeamKickMessage {
}

module.exports = TeamKick
