'use strict'
const { sqrt } = require('./Math')
const yes = value => value === true || value === 'true'
const div = (a, b) => b === 0 ? 0 : Math.trunc(a / b) | 0
// CharacterServer attack configuration at 0x3fdff8..0x3fe250.
// Offset keys preserve the native layout instead of inventing semantics for
// every field. This configures an attack; it does not emit or hit projectiles.
function configureAttack (owner, options, battleTick) {
  const i = owner.i32; const b = owner.u8
  const projectile = options.isSuper && owner.superProjectileOverride ? owner.superProjectileOverride : options.projectile
  b['0x1d5'] = Number(Boolean(options.isSuper))
  owner.reference178 = null
  b['0x188'] = 1; b['0x206'] = 0
  owner.zeroedBlock348 = [0, 0, 0, 0]
  let dx; let dy
  if (projectile && yes(projectile.Indirect)) {
    i['0x180'] = options.target[0] | 0; i['0x184'] = options.target[1] | 0
    dx = (options.target[0] - owner.x) | 0; dy = (options.target[1] - owner.y) | 0
  } else {
    dx = (options.target[0] - owner.x) | 0; dy = (options.target[1] - owner.y) | 0
    const distance = sqrt((Math.imul(dx, dx) + Math.imul(dy, dy)) | 0)
    if (distance !== 0) {
      const reach = (Math.imul(options.range, 100) + options.rangeBonus) | 0
      dx = div(Math.imul(dx, reach), distance); dy = div(Math.imul(dy, reach), distance)
    }
    i['0x180'] = (owner.x + dx) | 0; i['0x184'] = (owner.y + dy) | 0
  }
  i['0xf0'] = dx; i['0xf4'] = dy
  i['0xbc'] = options.bonusDamage | 0; i['0xc0'] = options.attackCount | 0
  i['0xc4'] = 0; i['0x1dc'] = 0
  i['0xcc'] = options.damage | 0; i['0xe4'] = options.attackIntervalMs | 0
  const variableScale = projectile && ((Number(projectile.ScaleStart) || 100) !== 100 || (Number(projectile.ScaleEnd) || 100) !== 100)
  i['0xe0'] = variableScale ? 0 : options.spread | 0
  i['0xd0'] = options.pattern | 0; i['0xd4'] = options.bullets | 0
  owner.projectile = projectile
  i['0xe8'] = options.range | 0; b['0x140'] = Number(Boolean(options.twoGuns))
  i['0xf8'] = options.rangeBonus | 0; i['0xc8'] = 0; i['0x2fc'] = -1
  if (!options.executeFirstImmediately) i['0x7c'] = battleTick | 0
  if (owner.byte1cc && owner.byte3a0) {
    for (const skill of owner.skills) if (skill.behavior === 3 && skill.activeMs >= 1) skill.activeMs = 0
  }
  return owner
}
module.exports = { configureAttack }
