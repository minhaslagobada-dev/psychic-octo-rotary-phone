'use strict'
const { BSMessageReader } = require('../../../../Utils/Reader')
const ServerHelloMessage = require('../../Server/Login/ServerHelloMessage')

class ClientHelloMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.client = client
    this.player = player
    this.initial_bytes = initialBytes
    this.major = null
    this.minor = null
    this.build = null
    this.fingerprint_sha = null
  }

  decode () {
    if (!this.initial_bytes || this.initial_bytes.length === 0) {
      return
    }

    this.read_int()
    this.read_int()

    this.major = this.read_int()
    this.minor = this.read_int()
    this.build = this.read_int()
    this.fingerprint_sha = this.read_string()

    this.read_int()
    this.read_int()

    this.player.client_major = this.major
    this.player.client_minor = this.minor
    this.player.client_build = this.build
  }

  process () {
    new ServerHelloMessage(this.client, this.player).send()
  }
}

module.exports = ClientHelloMessage
