'use strict'
const Writer = require('../../../../Utils/Writer')

class MatchMakingCancelledMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 20406
    this.player = player
  }

  encode () {
  }
}

module.exports = MatchMakingCancelledMessage
