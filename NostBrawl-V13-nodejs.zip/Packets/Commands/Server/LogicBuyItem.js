'use strict'

const Writer = require('../../../Utils/Writer')

const REWARD_TYPES = {
  1: 7,
  2: 8,
  3: 3,
  4: 2,
  5: 6,
  6: 1,
  7: 9,
  8: 4,
  9: 6
}

class LogicBuyItem extends Writer {
  constructor (client, player, rewards, trophyRoad = 0, commandContext = null) {
    super(client)
    this.id = 24111
    this.player = player
    this.rewards = (rewards || []).slice()
    this.trophy_road = Math.trunc(trophyRoad || 0)
    this.command_context = (commandContext !== null && commandContext !== undefined
      ? commandContext
      : [0, 0, 0, 0, 0]).slice()
    if (!(this.rewards.length >= 1 && this.rewards.length <= 3)) {
      throw new Error('LogicBuyItem requires between one and three rewards')
    }
    if (this.command_context.length !== 5) {
      throw new Error('LogicBuyItem requires five command context values')
    }
  }

  _encode_rewards () {
    for (const reward of this.rewards) {
      const itemType = Math.trunc(reward.type)
      if (!(itemType in REWARD_TYPES)) {
        throw new Error(`Unsupported shop reward type: ${itemType}`)
      }
      const amount = Math.trunc(reward.amount !== undefined ? reward.amount : 1)
      const brawler = Math.trunc(reward.brawler !== undefined ? reward.brawler : 0)
      const skin = Math.trunc(reward.skin !== undefined ? reward.skin : 0)
      if (amount < 1) {
        throw new Error('LogicBuyItem requires positive reward amounts')
      }
      this.writeVint(amount)
      if ([5, 6, 8, 9].includes(itemType)) {
        this.writeScId(16, brawler)
      } else {
        this.writeVint(0)
      }
      this.writeVint(REWARD_TYPES[itemType])
      if (itemType === 7) {
        this.writeScId(29, skin)
      } else {
        this.writeVint(0)
      }
      this.writeVint(0)
    }
  }

  encode () {
    this.writeVint(203)
    this.writeVint(0)
    this.writeVint(1)
    this.writeVint(100)
    this.writeVint(this.rewards.length)
    this._encode_rewards()
    this.writeVint(this.trophy_road)
    for (const value of this.command_context) {
      this.writeVint(Math.trunc(value))
    }
  }
}

module.exports = LogicBuyItem
