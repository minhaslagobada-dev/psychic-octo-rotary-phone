'use strict'
// Port of validate_char_native.py.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { RuntimeError } = require('./lib/pycompat')
const R = require('./lib/research')
const { C } = R
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const m = R.memory(n)
  // Use complete client metadata and original schema/readers. In particular,
  // RaidBoss uses its actual AreaEffect reference, never a sentinel pointer.
  const registry = new NativeDataRegistry(n, path.join(R.ROOT, 'GameAssets'))
  const vectorHeap = n.heap
  const word = m.u32; const put = m.put32; const ptrput = m.put64
  const state = {}
  const bounds = (uc, a, size, d) => {
    const p = Number(uc.reg_read(C.UC_ARM64_REG_X0)); const bits = Number(uc.reg_read(C.UC_ARM64_REG_W1)); const pos = word(p + 8) * 8 + word(p + 16)
    if (pos + bits > state.bits) throw new RuntimeError(`Native overread ${pos}+${bits}>${state.bits}, lr=${R.hex(uc.reg_read(C.UC_ARM64_REG_LR))}`)
  }
  n.uc.hook_add(C.UC_HOOK_CODE, bounds, null, 0x4f4518, 0x4f4518)
  const vectors = R.vectors('char-vectors.json')
  for (const v of vectors) {
    n.heap = vectorHeap
    const obj = n.alloc(0x200); const meta = registry.named(16, v.name); const stream = n.alloc(0x30); const payload = n.alloc(512); const array = n.alloc(16)
    n.uc.mem_write(obj, Buffer.alloc(0x200)); n.uc.mem_write(stream, Buffer.alloc(0x30))
    ptrput(obj, 0x75e938); ptrput(obj + 0x10, meta); ptrput(obj + 0x68, array); put(obj + 0x74, v.skills.length)
    v.skills.forEach((s, i) => {
      const sk = n.alloc(0x30); const data = registry.named(20, s.Name)
      n.uc.mem_write(sk, Buffer.alloc(0x30))
      ptrput(sk, data); ptrput(array + i * 8, sk)
    })
    const data = Buffer.from(v.hex, 'hex'); n.uc.mem_write(payload, data); ptrput(stream + 24, payload); put(stream + 12, data.length); state.bits = v.bits
    try {
      n.call(0x45768c, obj, stream, v.own ? 1 : 0, v.mode, v.large ? 1 : 0)
      const consumed = word(stream + 8) * 8 + word(stream + 16)
      R.assert(consumed === v.bits, [consumed, v.bits])
      R.assert(word(obj + 0x30) === v.object.x)
      R.assert(word(obj + 0x34) === v.object.y)
      R.assert(word(obj + 0x58) === v.object.hp, word(obj + 0x58))
      R.assert(word(obj + 0x5c) === v.object.maxHp)
      R.assert(word(obj + 0x94) === (v.object.statuses && v.object.statuses.length ? 1 : 0))
      R.assert(Boolean(m.u8(obj + 0x88)) === v.object.invisible)
    } catch (e) {
      R.print(v.name, v.mode, v.own, 'FAIL', R.errorMessage(e)); throw e
    }
  }
  R.print('Native v13 character decode passed:', vectors.length, 'vectors; real client metadata and CSV readers')
})
