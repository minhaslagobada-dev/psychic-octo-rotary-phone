'use strict'

const { ValueError } = require('../../../Utils/Errors')
const { BSMessageReader } = require('../../../Utils/Reader')

class SetDeviceToken extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.client = client
    this.player = player
    this.device_token = Buffer.alloc(0)
    this.value = 0
  }

  decode () {
    const length = this.read_int()
    if (length > 4096) {
      throw new ValueError(`Invalid device-token length: ${length}`)
    }
    this.device_token = this._read_exact(length)
    this.value = this.read_int()
  }

  process () {
    return null
  }
}

module.exports = SetDeviceToken
