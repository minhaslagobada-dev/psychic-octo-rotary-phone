'use strict'

const { RewardError } = require('./Rewards')

class RewardDelivery {
  static get BOX_RESOURCES () {
    return {
      10: [5000001, 100],
      12: [5000009, 10]
    }
  }

  static display (detail) {
    const name = detail.name
    const amount = Math.trunc(detail.amount)
    const target = Math.trunc(detail.target || 0)
    const displays = {
      Coins: { type: 1, amount },
      gems: { type: 2, amount },
      tickets: { type: 3, amount },
      tokens_doubler: { type: 4, amount },
      UpgradePoints: { type: 5, amount, brawler: target },
      Brawler: { type: 6, amount: 1, brawler: amount },
      Skin: { type: 7, amount: 1, skin: amount },
      StarPower: { type: 8, amount: 1, brawler: target }
    }
    if (!(name in displays)) {
      throw new RewardError(`Resposta de recompensa inválida: ${name}`)
    }
    return displays[name]
  }

  static displays (details) {
    return details.map((detail) => RewardDelivery.display(detail))
  }

  static responses (rewards, storedBoxes) {
    const responses = []
    if (rewards && rewards.length) {
      responses.push({ kind: 'item', rewards: rewards.slice() })
    }
    for (const entry of storedBoxes) {
      const boxType = Math.trunc(entry.boxType)
      const amount = Math.trunc(entry.amount)
      if (boxType === 11) {
        continue
      }
      if (!(boxType in RewardDelivery.BOX_RESOURCES) || amount < 1) {
        throw new RewardError('Caixa entregue inválida')
      }
      const [resource, unitCost] = RewardDelivery.BOX_RESOURCES[boxType]
      responses.push({
        kind: 'resource',
        resource,
        amount: amount * unitCost
      })
    }
    return responses
  }

  static send (client, player, response) {
    const kind = response.kind
    if (kind === 'item') {
      const LogicBuyItem = require('../Packets/Commands/Server/LogicBuyItem')
      new LogicBuyItem(
        client,
        player,
        response.rewards,
        Math.trunc(response.trophyRoad || 0)
      ).send()
      return
    }
    if (kind === 'resource') {
      const LogicChangeResourcesCommand = require('../Packets/Commands/Server/LogicChangeResourcesCommand')
      new LogicChangeResourcesCommand(
        client, player, response.resource, response.amount
      ).send()
      return
    }
    if (kind === 'box') {
      const LogicBoxDataCommand = require('../Packets/Commands/Server/LogicBoxDataCommand')
      new LogicBoxDataCommand(client, player, response.result).send()
      return
    }
    throw new Error(`Unknown reward response: ${kind}`)
  }

  static send_many (client, player, responses) {
    for (const response of responses) {
      RewardDelivery.send(client, player, response)
    }
  }
}

module.exports = RewardDelivery
