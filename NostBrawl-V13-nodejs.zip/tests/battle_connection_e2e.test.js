'use strict'
// Actual encrypted TCP login -> native v13 24112 -> actual UDP input.
// Exercises protocol plumbing only; it does not assert rendered gameplay.
const assert = require('node:assert/strict')
const net = require('node:net')
const dgram = require('node:dgram')
const crypto = require('node:crypto')
const path = require('node:path')
const { once } = require('node:events')
const { blake2b } = require('blakejs')
process.chdir(path.resolve(__dirname, '..'))
const Config = require('../Utils/Config')
const { Server } = require('../main')
const NaCl19 = require('../Core/NaCl19')
const { Nonce, DEFAULT_CLIENT_PRIVATE_KEY } = require('../Core/Crypto')
const { Reader, envelope, encodeInput, readEnvelope } = require('../Logic/Battle/Network/V13BattleCodec')

const int = value => { const b = Buffer.alloc(4); b.writeInt32BE(value); return b }
const string = value => { const b = Buffer.from(value); return Buffer.concat([int(b.length), b]) }
const frame = (type, payload, version = 0) => {
  const h = Buffer.alloc(7); h.writeUInt16BE(type); h.writeUIntBE(payload.length, 2, 3); h.writeUInt16BE(version, 5)
  return Buffer.concat([h, payload])
}

async function main () {
  // Leave the caller's config and database paths untouched. Existing account
  // tests must run from an isolated copy (see BATTLES.md).
  const settings = Config.GetValue()
  assert.equal(settings.Store.Enabled, false, 'Run in an isolated test copy with Store.Enabled=false')
  const sk = Buffer.from(DEFAULT_CLIENT_PRIVATE_KEY, 'hex')
  const pk = NaCl19.scalarmultBase(sk)
  const serverPk = Buffer.from(settings.Crypto.ServerPublicKey, 'hex')
  const shared = NaCl19.boxBeforenm(serverPk, sk)
  const sendNonce = new Nonce(crypto.randomBytes(24))
  const fingerprint = require('../Utils/Fingerprint').loadFinger('GameAssets/fingerprint.json')
  const server = new Server('127.0.0.1', 0)
  let socket
  const udp = dgram.createSocket('udp4')
  try {
    await server.start()
    await new Promise(resolve => udp.bind(0, '127.0.0.1', resolve))
    const announcement = new Promise((resolve, reject) => {
      socket = net.connect(server.port, '127.0.0.1')
      socket.on('error', reject)
      let rx = Buffer.alloc(0); let recvNonce; let sessionKey; let sentInfo = false
      socket.on('connect', () => socket.write(frame(10100, Buffer.concat([
        int(1), int(1), int(settings.ClientMajor), int(settings.ClientMinor), int(settings.ClientBuild), string(fingerprint), int(0), int(0)
      ]))))
      socket.on('data', chunk => {
        try {
          rx = Buffer.concat([rx, chunk])
          while (rx.length >= 7) {
            const type = rx.readUInt16BE(); const length = rx.readUIntBE(2, 3)
            if (rx.length < length + 7) break
            const payload = rx.subarray(7, length + 7); rx = rx.subarray(length + 7)
            if (type === 20100) {
              const helloNonce = Buffer.from(blake2b(Buffer.concat([pk, serverPk]), null, 24))
              const login = Buffer.concat([
                int(0), int(0), string(''), int(settings.ClientMajor), int(settings.ClientMinor), int(settings.ClientBuild),
                string(fingerprint), string(''), string('udp-test'), string('udp-test'), string('test')
              ])
              socket.write(frame(10101, Buffer.concat([pk, NaCl19.secretbox(Buffer.concat([payload.subarray(4, 28), sendNonce.toBuffer(), login]), helloNonce, shared)]), 1))
            } else if (type === 20104) {
              const raw = NaCl19.secretboxOpen(payload, new Nonce(sendNonce.toBuffer(), pk, serverPk).toBuffer(), shared)
              assert(raw)
              recvNonce = new Nonce(raw.subarray(0, 24)); sessionKey = raw.subarray(24, 56)
            } else if (type === 20103) reject(new Error('TCP login rejected'))
            else {
              assert(recvNonce && sessionKey)
              recvNonce.increment()
              const raw = NaCl19.secretboxOpen(payload, recvNonce.toBuffer(), sessionKey)
              assert(raw, `Failed to decrypt ${type}`)
              if (type === 24101 && !sentInfo) {
                sentInfo = true; sendNonce.increment()
                socket.write(frame(10177, NaCl19.secretbox(string('wifi'), sendNonce.toBuffer(), sessionKey)))
              } else if (type === 24112) resolve(raw)
            }
          }
        } catch (error) { reject(error) }
      })
    })
    const raw = await announcement
    const reader = new Reader(raw)
    const port = reader.vint()
    const host = reader.take(reader.take(4).readInt32BE()).toString()
    const header = reader.take(reader.take(4).readInt32BE())
    assert.equal(reader.take(4).readInt32BE(), 0)
    reader.end()
    assert.equal(port, server.battleTransport.gateway.port)
    assert.equal(host, '127.0.0.1')
    assert.equal(header.length, 10)
    const inputEvent = once(server.battleTransport, 'input')
    const payload = encodeInput({ tick: 1, sequence: 1, inputs: [{ counter: 1, category: 1, code: 100, x: 1500, y: 1800 }] })
    udp.send(Buffer.concat([header, envelope(10555, payload)]), port, host)
    const [session, input] = await inputEvent
    assert(session.player.logged_in)
    assert.equal(session.player.udp_session, session)
    assert.equal(input.inputs[0].y, 1800)
    assert.equal(session.input.drain().length, 1)
    const reply = once(udp, 'message')
    server.battleTransport.send(session, 10555, payload)
    assert.deepEqual(readEnvelope((await reply)[0].subarray(10)).payload, payload)
    const disconnected = once(server.battleTransport, 'release')
    socket.destroy()
    const [released, reason] = await disconnected
    assert.equal(released, session)
    assert.equal(reason, 'disconnect')
    assert.equal(server.battleTransport.gateway.sessions.size, 0)
    console.log('BATTLE CONNECTION E2E OK: encrypted TCP login -> 24112 -> UDP 10555 -> reply -> disconnect cleanup')
  } finally {
    if (socket) socket.destroy()
    udp.close()
    await server.close()
  }
}
const timer = setTimeout(() => { console.error('Battle connection e2e timed out'); process.exit(1) }, 10000)
main().then(() => clearTimeout(timer), error => { clearTimeout(timer); console.error(error); process.exitCode = 1 })
