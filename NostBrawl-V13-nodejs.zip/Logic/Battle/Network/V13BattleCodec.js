'use strict'

// Wire layouts recovered from the supplied ARM64 v13 libg.so:
// UDPConnectionInfo.encode 0x4fb394; input.encode 0x287328;
// input entry.encode 0x2fd2a8; UDP envelope.encode 0x1f8888.
const { ValueError } = require('../../../Utils/Errors')

class Reader {
  constructor (bytes) { this.bytes = bytes; this.offset = 0; this.bit = 0; this.booleanByte = 0 }
  take (length) {
    this.bit = 0
    if (!Number.isSafeInteger(length) || length < 0 || length > this.bytes.length - this.offset) throw new ValueError('Truncated v13 battle packet')
    const out = this.bytes.subarray(this.offset, this.offset + length)
    this.offset += length
    return out
  }
  vint () {
    const first = this.take(1)[0]
    const negative = (first & 64) !== 0
    let value = first & 63
    if (!(first & 128)) return negative ? value | -64 : value
    for (let group = 1; group <= 4; group++) {
      const byte = this.take(1)[0]
      if (group === 4 && (byte & 0xf0)) throw new ValueError('Invalid v13 VInt')
      value |= (byte & 127) << (6 + (group - 1) * 7)
      if (!(byte & 128)) {
        if (negative) value |= group === 4 ? 0x80000000 : -1 << (6 + group * 7)
        return value | 0
      }
    }
    throw new ValueError('Invalid v13 VInt')
  }
  boolean () {
    if (!this.bit) this.booleanByte = this.take(1)[0]
    const out = Boolean(this.booleanByte & (1 << this.bit))
    this.bit = (this.bit + 1) & 7
    return out
  }
  end () { if (this.offset !== this.bytes.length) throw new ValueError('Trailing v13 battle data') }
}

function vint (value) {
  if (!Number.isInteger(value) || value < -2147483648 || value > 2147483647) throw new ValueError('v13 VInt outside int32')
  let size = 1
  while (size < 5 && (value < -(2 ** (6 + (size - 1) * 7) - 1) || value > 2 ** (6 + (size - 1) * 7) - 1)) size++
  const unsigned = value >>> 0
  const out = Buffer.allocUnsafe(size)
  out[0] = (unsigned & 63) | (value < 0 ? 64 : 0) | (size > 1 ? 128 : 0)
  for (let i = 1; i < size; i++) out[i] = ((unsigned >>> (6 + (i - 1) * 7)) & (i === 4 ? 15 : 127)) | (i < size - 1 ? 128 : 0)
  return out
}

function envelope (type, payload) {
  if (!Number.isInteger(type) || type < 1 || type > 32767 || !Buffer.isBuffer(payload)) throw new ValueError('Invalid UDP message')
  return Buffer.concat([vint(type), vint(payload.length), payload])
}

function readEnvelope (bytes) {
  const reader = new Reader(bytes)
  const type = reader.vint()
  const length = reader.vint()
  if (type < 1 || type > 32767) throw new ValueError('Invalid UDP message type')
  const payload = reader.take(length)
  reader.end()
  return { type, payload }
}

function decodeInput (payload) {
  const reader = new Reader(payload)
  const tick = reader.vint()
  const latency = reader.vint()
  const sequence = reader.vint()
  const count = reader.vint()
  if (count < 0 || count > 30) throw new ValueError('Invalid v13 input count')
  const inputs = []
  for (let i = 0; i < count; i++) {
    inputs.push({
      counter: reader.vint(), category: reader.vint(), code: reader.vint(),
      x: reader.vint(), y: reader.vint(), targetId: reader.vint(),
      flag: reader.boolean()
    })
  }
  reader.end()
  return { tick, latency, sequence, inputs }
}

function encodeInput ({ tick = 0, latency = 0, sequence = 0, inputs = [] }) {
  if (inputs.length > 30) throw new ValueError('Too many v13 inputs')
  const parts = [vint(tick), vint(latency), vint(sequence), vint(inputs.length)]
  for (const input of inputs) parts.push(vint(input.counter), vint(input.category), vint(input.code), vint(input.x), vint(input.y), vint(input.targetId || 0), Buffer.from([input.flag ? 1 : 0]))
  return Buffer.concat(parts)
}

module.exports = { Reader, vint, envelope, readEnvelope, decodeInput, encodeInput }
