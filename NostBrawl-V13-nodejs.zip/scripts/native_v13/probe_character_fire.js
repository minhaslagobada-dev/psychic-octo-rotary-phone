'use strict'
// Port of probe_character_fire.py.
// Execute original Skill::tick and Character fire; controlled owner fixture.
// Full native Skill::tick for Attack setup without attached spawns.
// Controlled character memory; no character CSV/constructor claim and no hooks.
// This measures attack scheduling, not projectile damage or complete hero combat.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { disassembler, read } = require('./native')
const { NativeOpenMap } = require('./native_open_map')
const R = require('./lib/research')
const { C } = R
const int0x = text => { text = text.trim(); const negative = text.startsWith('-'); const v = Number(BigInt(negative ? text.slice(1) : text)); return negative ? -v : v }
R.main(async () => {
  const md = await disassembler()
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/skills.csv')); t.initialize_schema(0x13da8c)
  const proj = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); proj.initialize_schema(0x449b0c)
  const terrain = new NativeOpenMap(n, root); const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v)
  const getters = {}
  for (const address of [0x287418, 0xc0178, 0x2a545c, 0x1f1e5c, 0x428410, 0x4cb730, 0x161534, 0x2820dc, 0x350abc, 0x2ea740, 0x4f0ed0, 0x28f610]) {
    let page = null
    for (const ins of md.disasm(Array.from(read(address, 48)), address)) {
      if (ins.mnemonic === 'adrp' && ins.op_str.startsWith('x8, ')) page = int0x(ins.op_str.split('#')[1])
      if (page !== null && ins.mnemonic === 'ldr' && ins.op_str.startsWith('w1, [x8, #')) {
        const offset = int0x(ins.op_str.split('#')[1].split(']')[0])
        const index = m.i32(page + offset)
        getters[R.hex(address)] = t.names.at(index); break
      }
    }
  }
  const projectileTable = t.alloc(0x40); w(projectileTable + 0x28, 6)
  const projectiles = {}
  proj.records.forEach((row, i) => {
    const d = R.zipDict(proj.names, row); const meta = t.alloc(0x200); p(meta + 8, proj.rows[i]); p(meta + 0x10, projectileTable); w(meta + 0x94, R.int0(d.Speed)); w(meta + 0x98, R.int0(d.Radius)); w(meta + 0xa0, R.int0(d.Gravity))
    n.uc.mem_write(meta + 0x90, Buffer.from([d.Indirect === 'true' ? 1 : 0, d.ConstantFlyTime === 'true' ? 1 : 0]))
    projectiles[d.Name] = meta
  })
  let manager = t.alloc(0x100); const battle = t.alloc(0x400); p(manager + 0x50, battle); p(battle, manager); p(battle + 0x70, terrain.pointer); w(battle + 0x18, 100)
  const records = []
  const get = m.i32
  // Only this existing character column is bound for the controlled muzzle fixture.
  // This is not initialization or validation of the incomplete character schema.
  const chars = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/characters.csv'), ['HookDude', 'ClusterBombDude', 'Ninja'])
  const columnIndex = chars.names.indexOf('TwoWeaponAttackEffectOffset')
  if (columnIndex < 0) throw new Error("ValueError: 'TwoWeaponAttackEffectOffset' is not in list")
  w(0x9aabfc, columnIndex)
  const charRows = new Set(chars.rows)
  const observe = (uc, address, size, data) => {
    if (address === 0x469228 && charRows.has(Number(uc.reg_read(C.UC_ARM64_REG_X0)))) {
      R.assert(Number(uc.reg_read(C.UC_ARM64_REG_X1)) === columnIndex, 'Unexpected character column: incomplete schema cannot be assumed')
    }
  }
  n.uc.hook_add(C.UC_HOOK_CODE, observe, null, 0x469228, 0x469228)
  for (const row of t.records) {
    const d = R.zipDict(t.names, row)
    if (d.BehaviorType !== 'Attack' || !d.Projectile || ['SummonedCharacter', 'AreaEffectObject', 'AreaEffectObject2', 'SpawnedItem'].some(k => d[k])) continue
    manager = t.alloc(0x100); p(manager + 0x50, battle); p(battle, manager)
    const meta = t.alloc(0x200); p(meta + 8, t.find(d.Name)); p(meta + 0x68, projectiles[d.Projectile])
    const owner = t.alloc(0x400); const charmeta = t.alloc(0x200); p(charmeta + 8, chars.rows[0]); p(owner, 0x72dc10); p(owner + 0x10, charmeta); p(owner + 0x18, manager); p(charmeta + 0x198, meta)
    w(owner + 0x30, 3000); w(owner + 0x34, 4500); w(owner + 0x3c, -1); w(owner + 0x2fc, -1)
    const state = t.alloc(0x30); n.call(0x248d70, state, meta); w(state + 0x14, 3000); w(state + 0xc, Math.max(1, R.int0(d.ActiveTime))); w(state + 0x18, 3500); w(state + 0x1c, 5000); w(state + 0x28, 1); n.uc.mem_write(state + 0x20, Buffer.from([1, 1]))
    const skills = t.alloc(8); p(skills, state); p(owner + 0x130, skills); w(owner + 0x13c, 1)
    n.call(0xec2a8, state, owner, 50)
    const firstInterval = R.u32(n.call(0x14ad30, owner))
    const frames = []; const allShots = []
    for (const tick of [100, 101, 100 + Math.max(2, firstInterval)]) {
      w(battle + 0x18, tick)
      const interval = R.u32(n.call(0x14ad30, owner)); const before = get(manager + 0xc); const last = get(owner + 0x7c); const counter = get(owner + 0xc4)
      n.uc.mem_write(0x201ff000, R.pack('Q', 0, 1, 0))
      n.call(0x1e048c, owner, 0, get(owner + 0x180), get(owner + 0x184), R.int0(d.Damage), R.int0(d.Damage), projectiles[d.Projectile], get(owner + 0xe0))
      const array = m.u64(manager); const shots = []
      for (let index = before; index < get(manager + 0xc); index++) {
        const obj = m.u64(array + index * 8)
        shots.push({ start: [get(obj + 0x60), get(obj + 0x64)], end: [get(obj + 0x68), get(obj + 0x6c)], launch: get(obj + 0x20), finish: get(obj + 0x24), damage: get(obj + 0x74), earlyTicks: get(obj + 0x10c) })
      }
      frames.push({ tick, lastShot: last, interval, beforeCounter: counter, afterCounter: get(owner + 0xc4), attackingTicks: get(owner + 0x12c), shots })
      allShots.push(...shots)
    }
    records.push({ skill: d.Name, definition: d, shots: allShots, frames })
    w(battle + 0x18, 100)
  }
  R.writeJson('character-fire-vectors.json', records)
  R.print('Original Skill tick + Character fire:', records.length, 'attack definitions;', records.reduce((s, r) => s + r.shots.length, 0), 'projectiles; controlled muzzle metadata, no gameplay substitutions')
})
