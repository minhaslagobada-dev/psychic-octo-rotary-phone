'use strict'

const DataBase = require('../../../Database/DatabaseManager')

class LogicSetPlayerThumbnailCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
    reader.player.profile_icon = reader.read_Vint()
  }

  static process (reader) {
    DataBase.replaceValue(reader, 'profileIcon', reader.player.profile_icon)
  }
}

module.exports = LogicSetPlayerThumbnailCommand
