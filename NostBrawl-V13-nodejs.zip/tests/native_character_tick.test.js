'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'character-tick-vectors.json')))
const assets = new BattleAssets()
for (const v of vectors) {
  assert.equal(v.hp, Number(assets.named('characters', v.name).Hitpoints), v.name)
  assert.equal(v.state, 0, v.name)
  assert.equal(v.x, 3000, v.name)
  assert.equal(v.y, 4500, v.name)
  assert.equal(v.attackingTicks, 63, v.name)
}
assert.equal(new Set(vectors.map(v => v.name)).size, 22)
console.log('Actual client character tick:', vectors.length, 'idle frames across 22 heroes; controlled world/player input, native gameplay and CSV readers')
