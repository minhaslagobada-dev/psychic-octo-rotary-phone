'use strict'
// Port of the Python project's tests/test_battle_return_regression.py.
// Validates the full cycle the V13 client does: room create -> ready ->
// battle result upload (14110) -> BattleResult (23456) -> GoHome (14109) ->
// OwnHomeData (24101) -> keepalive (10108 -> 20108) with the connection
// staying open, and persisted state surviving a reload.
const path = require('path')
process.chdir(path.resolve(__dirname, '..'))

const fs = require('fs')
const net = require('net')

const Characters = require('../Files/CsvLogic/Characters')
const Skins = require('../Files/CsvLogic/Skins')
const DataBase = require('../Database/DatabaseManager')
const Device = require('../Logic/Device')
const { Players } = require('../Logic/Player')
const { BattleParticipants } = require('../Logic/Battle/BattleParticipants')
const { GameRoomService } = require('../Logic/GameRoomService')
const { ClientThread } = require('../main')
const TeamCreateMessage = require('../Packets/Messages/Client/Gameroom/TeamCreateMessage')
const TeamSetMemberReadyMessage = require('../Packets/Messages/Client/Gameroom/TeamSetMemberReadyMessage')
const AskForBattleEndMessage = require('../Packets/Messages/Client/Battle/AskForBattleEndMessage')
const GoHomeFromOfflinePractiseMessage = require('../Packets/Messages/Client/Home/GoHomeFromOfflinePractiseMessage')
const StartLoadingMessage = require('../Packets/Messages/Server/Battle/StartLoadingMessage')
const Writer = require('../Utils/Writer')
const { AccountLocks } = require('../Utils/AsyncLock')
const { Crypto } = require('../Core/Crypto')

for (const suffix of ['', '-wal', '-shm']) {
  fs.rmSync(`Database/players.sqlite${suffix}`, { force: true })
}

let passed = 0
function check (label, condition) {
  if (!condition) {
    console.error(`FAIL ${label}`)
    console.error(new Error('trace').stack)
    process.exit(1)
  }
  passed += 1
  console.log(`ok ${label}`)
}

// --------------------------------------------------------------------------
// Native V13 wire reader (mirrors tests' NativeResponseReader semantics)
// --------------------------------------------------------------------------
class NativeReader {
  constructor (payload) {
    this.payload = payload
    this.offset = 0
    this.bit_index = 0
    this.bit_buffer = 0
  }

  byte () {
    if (this.offset >= this.payload.length) throw new Error('Unexpected end of payload')
    return this.payload[this.offset++]
  }

  align () { this.bit_index = 0 }

  vint () {
    this.align()
    const first = this.byte()
    const negative = Boolean(first & 0x40)
    let result = first & 0x3f
    if (!(first & 0x80)) {
      if (negative) result |= (-1 << 6)
      return result | 0
    }
    for (let group = 1; group < 4; group++) {
      const b = this.byte()
      result |= (b & 0x7f) << (6 + (group - 1) * 7)
      if (!(b & 0x80)) {
        if (negative) result |= (-1 << (6 + group * 7))
        return result | 0
      }
    }
    result |= this.byte() << 27
    if (negative) result = (result | 0x80000000) >>> 0
    result = result >>> 0
    return result & 0x80000000 ? result - 0x100000000 : result
  }

  boolean () {
    if (this.bit_index === 0) this.bit_buffer = this.byte()
    const value = Boolean(this.bit_buffer & (1 << this.bit_index))
    this.bit_index = (this.bit_index + 1) & 7
    return value
  }

  int32 () {
    this.align()
    return this.take(4).readInt32BE(0)
  }

  string () {
    this.align()
    const length = this.int32()
    if (length === -1) return ''
    return this.take(length).toString('utf-8')
  }

  dataref () {
    const classId = this.vint()
    return [classId, classId ? this.vint() : 0]
  }

  long () {
    this.align()
    const raw = this.take(8)
    return [raw.readInt32BE(0), raw.readInt32BE(4)]
  }

  array () { const out = []; const n = this.vint(); for (let i = 0; i < n; i++) out.push(this.vint()); return out }

  references () { const out = []; const n = this.vint(); for (let i = 0; i < n; i++) out.push([this.vint(), this.vint()]); return out }

  brawler_values () { const out = []; const n = this.vint(); for (let i = 0; i < n; i++) out.push([this.vint(), this.vint(), this.vint()]); return out }

  take (length) {
    const end = this.offset + length
    if (end > this.payload.length) throw new Error('Unexpected end of payload')
    const value = this.payload.subarray(this.offset, end)
    this.offset = end
    return value
  }

  ensure_end () {
    if (this.offset !== this.payload.length) {
      throw new Error(`trailing bytes: ${this.payload.length - this.offset}`)
    }
  }

  // OwnHomeData aliases used by the Python regression test
  v () { this.align(); return this.vint() }
  b () { return this.boolean() }
  i () { this.align(); return this.int32() }
  s () { this.align(); return this.string() }
  read () { return this.payload.subarray(this.offset) }
}

function readHomeCommodities (payload) {
  const r = new NativeReader(payload)
  r.dailyTimestamp = r.v()
  r.v()
  for (let i = 0; i < 5; i++) r.v()
  for (let i = 0; i < 3; i++) r.v()
  r.references()
  r.references()
  r.b()
  for (let i = 0; i < 6; i++) r.v()
  r.tokenLimit = r.b()
  r.v()
  r.b()
  for (let i = 0; i < 2; i++) r.v()
  for (let i = 0; i < 4; i++) r.b()
  for (let i = 0; i < 3; i++) r.v()
  r.b()
  for (let i = 0, n = r.v(); i < n; i++) {
    for (let j = 0, m = r.v(); j < m; j++) {
      r.v(); r.v()
      const targetClass = r.v()
      if (targetClass) r.v()
      r.v()
    }
    for (let j = 0; j < 5; j++) r.v()
    r.b(); r.v(); r.b(); r.v(); r.s()
  }
  r.dailyHomeFields = [r.v(), r.v(), r.v(), r.v(), r.v(), r.v()]
  r.selectedBrawler = [r.v(), r.v()]
  r.shopTimestamp = r.v()
  for (let i = 0; i < 11; i++) r.v()
  r.array()
  r.array()
  r.events = []
  for (let i = 0, n = r.v(); i < n; i++) {
    r.events.push([r.v(), r.v(), r.v(), r.v(), r.v(), r.v(), r.v(), r.v()])
    r.s(); r.v(); r.array(); r.v()
  }
  r.v()
  for (let i = 0; i < 6; i++) r.array()
  r.v()
  r.dailyFields = [r.v(), r.v(), r.v(), r.v(), r.v()]
  for (let i = 0; i < 3; i++) r.b()
  for (let i = 0; i < 2; i++) r.v()
  r.b(); r.v(); r.long()
  for (let i = 0, n = r.v(); i < n; i++) { r.v(); r.v() }
  r.v(); r.b(); r.v()
  for (let i = 0; i < 3; i++) { r.v(); r.v() }
  r.s(); r.b(); r.s(); r.v()
  const commodities = []
  for (let i = 0, n = r.v(); i < n; i++) commodities.push([r.v(), r.v(), r.v()])
  return [r, commodities]
}

function assertCompleteHome (label, payload, brawlerId) {
  const [reader] = readHomeCommodities(payload)
  check(`${label}: home selected brawler is ${brawlerId}`, reader.selectedBrawler[0] === 16 && reader.selectedBrawler[1] === brawlerId)
  reader.brawler_values()
  reader.brawler_values()
  reader.v()
  reader.brawler_values()
  reader.brawler_values()
  for (let i = 0; i < 2; i++) reader.v()
  for (let i = 0; i < 3; i++) reader.v()
  for (let i = 0; i < 7; i++) reader.v()
  for (let i = 0; i < 2; i++) reader.v()
  check(`${label}: home payload fully consumed`, reader.read().length === 0)
}

// --------------------------------------------------------------------------
// Payload builders & BattleResult parser
// --------------------------------------------------------------------------
function nativeWriter () {
  return new Writer(null).enable_native_v13()
}

function statusPayload (status) {
  const w = nativeWriter()
  w.writeVint(status)
  return w.buffer
}

function createPayload (mapId) {
  const w = nativeWriter()
  w.writeVint(mapId); w.writeVint(0); w.writeVint(0)
  w.writeBoolean(false)
  return w.buffer
}

function readyPayload () {
  const w = nativeWriter()
  w.writeBoolean(true)
  w.writeVint(0)
  return w.buffer
}

function battlePayload (entries, ownIndex, mapId, result, rank) {
  const w = nativeWriter()
  for (const value of [result, entries[ownIndex].team, rank, mapId, 0, entries.length]) w.writeVint(value)
  entries.forEach((entry, index) => {
    w.writeScId(16, entry.brawler_id)
    w.writeScId(29, entry.skin_id)
    w.writeVint(entry.team)
    w.writeBoolean(index === ownIndex)
    w.writeString(entry.name)
  })
  return w.buffer
}

function readNativeResult (payload) {
  const r = new NativeReader(payload)
  const result = {
    header: [r.vint(), r.vint(), r.vint(), r.vint(), r.vint(), r.vint(), r.vint()],
    flags: [r.boolean(), r.boolean(), r.boolean(), r.boolean(), r.boolean(), r.boolean()]
  }
  result.participants = []
  for (let i = 0, n = r.vint(); i < n; i++) {
    const participant = {
      name: r.string(),
      flags: [r.boolean(), r.boolean(), r.boolean()],
      brawler: r.dataref(),
      skin: r.dataref(),
      trophies: r.vint(),
      powerLevel: r.vint(),
      isPlayer: r.boolean()
    }
    if (participant.isPlayer) participant.ids = [r.int32(), r.int32()]
    result.participants.push(participant)
  }
  return result
}

function parseStartLoading (payload) {
  const r = new NativeReader(payload)
  const result = { count: r.i(), own_index: r.i(), own_team: r.i() }
  check('start loading: repeated count matches', r.i() === result.count)
  result.members = []
  for (let i = 0; i < result.count; i++) {
    const member = { high_id: r.i(), low_id: r.i(), name: r.s() }
    member.index = r.v(); member.team = r.v(); member.unknown = r.v()
    member.object = r.i()
    member.brawler = r.dataref(); member.skin = r.dataref()
    member.optional = r.b()
    result.members.push(member)
  }
  result.arrays = [r.i(), r.i()]
  result.timestamp = r.i()
  result.variation = r.v()
  result.controls = [r.v(), r.v()]
  result.flag = r.b()
  result.tail = [r.v(), r.v()]
  result.map = r.dataref()
  r.ensure_end()
  return result
}

// --------------------------------------------------------------------------
// Account helpers (mirrors BattleAccountTestCase)
// --------------------------------------------------------------------------
let accountSeq = 0
function makeAccount (lowId = 0, token = null) {
  accountSeq += 1
  const device = new Device({ write: () => {}, destroyed: false })
  const player = new Players(device)
  player.low_id = lowId || (900000 + accountSeq)
  player.high_id = 0
  player.token = token || `battle-return-${player.low_id}-${Date.now()}`
  player.name = 'Local'
  player.tutorial = 2
  player.player_experience = 0
  player.battle_tokens = 200
  player.tokensdoubler = 0
  player.brawl_boxes = 0
  player.big_boxes = 0
  player.trophies = 0
  player.highest_trophies = 0
  player.brawlers_trophies = { 0: 0 }
  player.brawlers_trophies_in_rank = { 0: 0 }
  const owner = { player }
  DataBase.createAccount(owner)
  DataBase.replaceValues(owner, {
    playerExp: 0,
    battleTokens: 200,
    tokensdoubler: 0,
    brawlBoxes: 0,
    bigBoxes: 0,
    trophies: 0,
    highest_trophies: 0,
    brawlersTrophies: { 0: 0 },
    brawlersTrophiesForRank: { 0: 0 }
  })
  return player
}

function reload (player) {
  const loaded = new Players(new Device({ write: () => {} }))
  loaded.token = player.token
  check('reload: account found', DataBase.loadAccount({ player: loaded }) !== false)
  return loaded
}

function configureBrawler (player, brawlerId, trophies = 0) {
  const skinId = Skins.get_default_skin(brawlerId)
  player.brawler_id = brawlerId
  player.skin_id = skinId
  player.BrawlersUnlockedState = Object.assign({}, player.BrawlersUnlockedState, { [String(brawlerId)]: 1 })
  player.brawlers_skins = Object.assign({}, player.brawlers_skins, { [String(brawlerId)]: skinId })
  player.brawlers_trophies = Object.assign({}, player.brawlers_trophies, { [String(brawlerId)]: trophies })
  player.brawlers_trophies_in_rank = Object.assign({}, player.brawlers_trophies_in_rank, { [String(brawlerId)]: trophies })
  player.Brawler_level = Object.assign({}, player.Brawler_level, { [String(brawlerId)]: 4 })
  player.trophies = trophies
  player.highest_trophies = trophies
  DataBase.replaceValues({ player }, {
    brawlerID: brawlerId,
    skinID: skinId,
    brawlersSkins: player.brawlers_skins,
    brawlersTrophies: player.brawlers_trophies,
    brawlersTrophiesForRank: player.brawlers_trophies_in_rank,
    brawlerPowerLevel: player.Brawler_level,
    UnlockedBrawlers: player.BrawlersUnlockedState,
    trophies,
    highest_trophies: trophies
  })
  return skinId
}

class CaptureClient {
  constructor () { this.packets = [] }
  write (data) { this.packets.push(Buffer.from(data)) }
  setNoDelay () {}
  payload (index = -1) {
    const packet = this.packets.at(index)
    this.message_id = packet.readUInt16BE(0)
    const length = packet.readUIntBE(2, 3)
    if (length !== packet.length - 7) throw new Error('invalid captured packet length')
    return packet.subarray(7)
  }
}

function createRoom (player, mapId) {
  const client = new CaptureClient()
  const message = new TeamCreateMessage(client, player, createPayload(mapId))
  message.decode()
  const room = message.process()
  const entries = BattleParticipants.build(room)
  const ownIndex = BattleParticipants.own_index(entries, player)
  return [room, entries, ownIndex]
}

function processBattle (player, payload) {
  const client = new CaptureClient()
  const message = new AskForBattleEndMessage(client, player, payload)
  message.decode()
  const result = message.process()
  return [result, readNativeResult(client.payload())]
}

function processHome (player) {
  const client = new CaptureClient()
  const message = new GoHomeFromOfflinePractiseMessage(client, player, Buffer.from([0]))
  message.decode()
  message.process()
  const payload = client.payload()
  check('GoHome: response is OwnHomeData (24101)', client.message_id === 24101)
  return payload
}

// --------------------------------------------------------------------------
// Part A — every brawler survives room loading, result, reload and home
// --------------------------------------------------------------------------
function partA () {
  let count = 0
  for (const brawlerId of Characters.get_brawlers_id()) {
    GameRoomService.init()
    const player = makeAccount()
    const skinId = configureBrawler(player, brawlerId)
    const [, entries, ownIndex] = createRoom(player, 7)
    if (entries[ownIndex].brawler_id !== brawlerId) throw new Error(`entries mismatch for brawler ${brawlerId}`)
    if (entries[ownIndex].skin_id !== skinId) throw new Error(`skin mismatch for brawler ${brawlerId}`)

    const loadingMsg = new StartLoadingMessage(null, player, GameRoomService.for_player(player), entries)
    loadingMsg.buffer = Buffer.alloc(0)
    loadingMsg.encode()
    const decoded = parseStartLoading(loadingMsg.buffer)
    if (decoded.members[ownIndex].brawler[1] !== brawlerId) throw new Error('start loading brawler mismatch')
    if (decoded.members[ownIndex].skin[1] !== skinId) throw new Error('start loading skin mismatch')

    const [, response] = processBattle(player, battlePayload(entries, ownIndex, 7, 0, 0))
    if (response.header[3] !== 6) throw new Error(`expected trophy gain 6 for brawler ${brawlerId}, got ${response.header[3]}`)
    if (response.flags[4] !== true) throw new Error('is_in_real_game flag missing')
    for (let i = 0; i < entries.length; i++) {
      if (response.participants[i].brawler[1] !== entries[i].brawler_id) throw new Error('participant brawler mismatch')
      if (response.participants[i].skin[1] !== entries[i].skin_id) throw new Error('participant skin mismatch')
    }

    const loaded = reload(player)
    if (loaded.brawler_id !== brawlerId) throw new Error('reload brawler mismatch')
    if (loaded.skin_id !== skinId) throw new Error('reload skin mismatch')
    if (loaded.brawlers_trophies[String(brawlerId)] !== 6) throw new Error('reload trophies mismatch')
    const homePayload = processHome(loaded)
    assertCompleteHome(`brawler ${brawlerId}`, homePayload, brawlerId)
    count++
  }
  console.log(`ok part A: ${count} brawlers survive loading/result/reload/home`)
}

// --------------------------------------------------------------------------
// Part B — real socket loop for the documented status/flow cases
// --------------------------------------------------------------------------
async function partB () {
  const cases = [
    ['3v3-victory', 7, 23, 0, 0, 0, 6],
    ['3v3-defeat', 7, 1, 1, 0, 100, -2],
    ['solo-victory', 13, 23, 1, 1, 0, 8],
    ['solo-eighth-low', 13, 20, 8, 8, 0, 2],
    ['solo-defeat', 13, 7, 10, 10, 100, -4]
  ]

  for (let caseIndex = 0; caseIndex < cases.length; caseIndex++) {
    const [label, mapId, brawlerId, result, rank, oldTrophies, expectedGain] = cases[caseIndex]
    GameRoomService.init()
    const player = makeAccount()
    configureBrawler(player, brawlerId, oldTrophies)
    player.crypto = new Crypto({ Enabled: false })

    const locks = new AccountLocks()
    const loopServer = {
      crypto_settings: { Enabled: false },
      max_packet_size: 1024 * 1024,
      Clients: { ClientCounts: 0, Clients: {} },
      _account_locks: locks,
      account_lock: (id) => locks.acquire(id),
      unregister_client: () => {}
    }

    // ephemeral TCP listener hopping the accepted socket into a raw ClientThread
    const accepted = await new Promise((resolve, reject) => {
      const listener = net.createServer()
      listener.once('error', reject)
      listener.listen(0, '127.0.0.1', () => {
        const port = listener.address().port
        const clientSocket = net.connect(port, '127.0.0.1')
        listener.once('connection', (serverSide) => {
          listener.close()
          resolve({ serverSide, clientSocket })
        })
      })
    })
    const { serverSide, clientSocket } = accepted
    serverSide.setNoDelay(true)

    const thread = new ClientThread(serverSide, ['127.0.0.1', 0], loopServer)
    thread.player = player
    thread.player.ClientDict = loopServer.Clients
    loopServer.Clients.Clients[String(player.low_id)] = {
      SocketInfo: serverSide,
      Crypto: player.crypto,
      Lock: thread._queue,
      Status: 1
    }
    loopServer.Clients.ClientCounts = 1
    thread.start()

    const rxBuffer = { buf: Buffer.alloc(0) }
    const inbox = []
    clientSocket.on('data', (chunk) => {
      rxBuffer.buf = Buffer.concat([rxBuffer.buf, chunk])
      while (rxBuffer.buf.length >= 7) {
        const length = rxBuffer.buf.readUIntBE(2, 3)
        if (rxBuffer.buf.length < 7 + length) break
        inbox.push({ id: rxBuffer.buf.readUInt16BE(0), payload: rxBuffer.buf.subarray(7, 7 + length) })
        rxBuffer.buf = rxBuffer.buf.subarray(7 + length)
      }
    })
    const send = (id, payload = Buffer.alloc(0)) => {
      const header = Buffer.alloc(7)
      header.writeUInt16BE(id, 0)
      header.writeUIntBE(payload.length, 2, 3)
      header.writeUInt16BE(0, 5)
      clientSocket.write(Buffer.concat([header, payload]))
    }
    const receive = (timeoutMs = 4000) => new Promise((resolve, reject) => {
      const deadline = Date.now() + timeoutMs
      const poll = () => {
        if (inbox.length) return resolve(inbox.shift())
        if (Date.now() > deadline) return reject(new Error(`${label}: timeout waiting for packet`))
        setTimeout(poll, 5)
      }
      poll()
    })

    try {
      send(14366, statusPayload(4))
      send(14350, createPayload(mapId))
      const created = await receive()
      check(`${label}: TeamCreate -> TeamGameroomData (24124)`, created.id === 24124)
      const stream = await receive()
      check(`${label}: TeamCreate -> TeamStream (24131)`, stream.id === 24131)

      const room = GameRoomService.for_player(player)
      check(`${label}: room exists`, room !== null && room !== undefined)
      const entries = BattleParticipants.build(room)
      const ownIndex = BattleParticipants.own_index(entries, player)
      check(`${label}: entry brawler/skin match`, entries[ownIndex].brawler_id === brawlerId && entries[ownIndex].skin_id === Skins.get_default_skin(brawlerId))

      send(14355, readyPayload())
      const roomData = await receive()
      check(`${label}: ready -> TeamGameroomData (24124)`, roomData.id === 24124)
      const cancelled = await receive()
      check(`${label}: ready -> MatchMakingCancelled (20406) empty`, cancelled.id === 20406 && cancelled.payload.length === 0)

      send(14366, statusPayload(10))
      send(14110, battlePayload(entries, ownIndex, mapId, result, rank))
      const battleResult = await receive()
      check(`${label}: battle end -> BattleResult (23456)`, battleResult.id === 23456)
      const response = readNativeResult(battleResult.payload)
      check(`${label}: trophy delta ${expectedGain}`, response.header[3] === expectedGain)
      check(`${label}: is_in_real_game flag`, response.flags[4] === true)
      check(`${label}: own brawler in result`, response.participants[ownIndex].brawler[1] === brawlerId)
      check(`${label}: own skin in result`, response.participants[ownIndex].skin[1] === Skins.get_default_skin(brawlerId))

      send(14366, statusPayload(8))
      send(14109, Buffer.from([0]))
      const home = await receive()
      check(`${label}: go home -> OwnHomeData (24101)`, home.id === 24101)
      assertCompleteHome(label, home.payload, brawlerId)

      send(14366, statusPayload(-1))
      send(10108)
      const keepalive = await receive()
      check(`${label}: keepalive -> 20108 empty`, keepalive.id === 20108 && keepalive.payload.length === 0)
      check(`${label}: connection still alive`, !clientSocket.destroyed && !serverSide.destroyed)

      // ------------------------------------------------------------------
      // SECOND BATTLE on the same session — must work "however many times".
      // The V13 client expects the leave-then-recreate pair: server emits
      // TeamLeft (24125) for the abandoned room before the fresh room data.
      // This mirrors the Python behaviour (tests/test_battle_return_regression.py).
      // ------------------------------------------------------------------
      send(14366, statusPayload(4))
      send(14350, createPayload(mapId))
      const r2left = await receive()
      check(`${label}: second battle leaves old room (24125)`, r2left.id === 24125)
      const r2data = await receive()
      check(`${label}: second battle room data (24124)`, r2data.id === 24124)
      const r2stream = await receive()
      check(`${label}: second battle room stream (24131)`, r2stream.id === 24131)

      send(14355, readyPayload())
      const r2ready = await receive()
      check(`${label}: second battle ready data (24124)`, r2ready.id === 24124)
      const r2mm = await receive()
      check(`${label}: second battle 20406`, r2mm.id === 20406)

      send(14366, statusPayload(10))
      send(14110, battlePayload(BattleParticipants.build(GameRoomService.for_player(player)), BattleParticipants.own_index(BattleParticipants.build(GameRoomService.for_player(player)), player), mapId, result, rank))
      const r2br = await receive()
      check(`${label}: second battle result (23456)`, r2br.id === 23456)

      send(14366, statusPayload(8))
      send(14109, Buffer.from([0]))
      const r2home = await receive()
      check(`${label}: second battle home (24101)`, r2home.id === 24101)
      assertCompleteHome(`${label} round 2`, r2home.payload, brawlerId)

      const loaded = reload(player)
      const expectedTrophies = oldTrophies + expectedGain * 2
      check(`${label}: trophies persisted ${expectedTrophies}`, loaded.trophies === expectedTrophies && loaded.brawlers_trophies[String(brawlerId)] === expectedTrophies)
      check(`${label}: brawler/skin persisted`, loaded.brawler_id === brawlerId && loaded.skin_id === Skins.get_default_skin(brawlerId))
    } finally {
      clientSocket.destroy()
      await new Promise((resolve) => serverSide.once('close', resolve))
    }
  }
  console.log('ok part B: all five flows return home, stay connected and can requeue')
}

async function main () {
  partA()
  await partB()
  console.log(`${passed} checks passed`)
  console.log('BATTLE RETURN E2E OK')
  process.exit(0)
}

main().catch((error) => {
  console.error('BATTLE RETURN E2E FAILED', error)
  process.exit(1)
})
