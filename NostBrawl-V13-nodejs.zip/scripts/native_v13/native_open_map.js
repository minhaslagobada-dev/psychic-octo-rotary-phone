'use strict'
// Port of native_open_map.py.
// A controlled open terrain fixture, read by original v13 tile/collision code.
//
// Not a game mode or replacement pathfinder: this constructs a known
// obstacle-free input map so target clipping can be measured inside the
// native implementation.
const path = require('node:path')
const { NativeCsv } = require('./native_csv')
const { ValueError } = require('./lib/pycompat')

class NativeOpenMap {
  constructor (native, root, width = 21, height = 33) {
    const t = new NativeCsv(native, path.join(String(root), 'GameAssets/csv_logic/tiles.csv'))
    t.initialize_schema(0x4478e4)
    this.csv = t
    this.width = width
    this.height = height
    this.tiles = new Map()
    this.metadata = new Map()
    this.pointer = t.alloc(0x100)
    t.word(this.pointer + 0x40, width); t.word(this.pointer + 0x44, height)
    t.word(this.pointer + 0x48, width * 300); t.word(this.pointer + 0x4c, height * 300)
    // Original TileMap constructor f1f88 uses three fine cells per tile.
    t.word(this.pointer + 0x50, width * 3); t.word(this.pointer + 0x54, height * 3)
    const cells = t.alloc(width * height * 8); t.ptr(this.pointer, cells)
    const meta = t.alloc(0x100); t.ptr(meta + 8, t.find('Open'))
    this.metadata.set('Open', meta)
    for (let y = 0; y < height; y++) {
      for (let x = 0; x < width; x++) {
        const tile = t.alloc(0x40)
        native.call(0x39f9bc, tile, meta, x, y)
        t.ptr(cells + (y * width + x) * 8, tile)
        this.tiles.set(`${x},${y}`, tile)
      }
    }
  }

  // Change controlled terrain input; all collision readers stay native.
  set_tile (x, y, name) {
    if (!this.tiles.has(`${x},${y}`)) throw new ValueError('Tile outside controlled map')
    const t = this.csv
    if (!this.metadata.has(name)) {
      const meta = t.alloc(0x100); t.ptr(meta + 8, t.find(name))
      this.metadata.set(name, meta)
    }
    const tile = this.tiles.get(`${x},${y}`)
    t.native.call(0x39f9bc, tile, this.metadata.get(name), x, y)
    return tile
  }

  tile (x, y) { return this.tiles.get(`${x},${y}`) }
}

module.exports = { NativeOpenMap }
