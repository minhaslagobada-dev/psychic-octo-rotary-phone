'use strict'

const DataBase = require('../Database/DatabaseManager')
const { ClubService } = require('./ClubService')

class LeaderboardService {
  static players (brawlerId = null) {
    const selectedBrawler = brawlerId === null || brawlerId === undefined ? null : Math.trunc(brawlerId)
    return DataBase._connection((connection) => {
      const rows = connection.prepare(
        'SELECT lowID, name, trophies, profileIcon, namecolor, clubID, playerExp, online FROM players'
      ).all()
      const brawlerTrophies = new Map()
      if (selectedBrawler !== null) {
        for (const row of rows) {
          brawlerTrophies.set(row.lowID, DataBase._read_state(connection, row.lowID, 'brawlersTrophies'))
        }
      }
      const clubNames = new Map()
      for (const row of connection.prepare('SELECT id, name FROM clubs').all()) {
        clubNames.set(Math.trunc(row.id), row.name)
      }

      const entries = []
      for (const row of rows) {
        let trophies
        if (selectedBrawler === null) {
          trophies = DataBase._number(row.trophies)
        } else {
          let brawlers = brawlerTrophies.get(row.lowID) || {}
          if (typeof brawlers !== 'object' || brawlers === null) {
            brawlers = {}
          }
          trophies = DataBase._number(brawlers[String(selectedBrawler)] || 0)
          if (trophies <= 0) {
            continue
          }
        }
        const clubId = DataBase._number(row.clubID)
        entries.push({
          low_id: DataBase._number(row.lowID),
          name: row.name || 'Guest',
          trophies,
          profile_icon: DataBase._number(row.profileIcon),
          name_color: DataBase._number(row.namecolor),
          club_id: clubId,
          club_name: clubId ? (clubNames.get(clubId) || '') : '',
          player_experience: DataBase._number(row.playerExp),
          online: DataBase._number(row.online)
        })
      }
      entries.sort((a, b) => (b.trophies - a.trophies) || (a.low_id - b.low_id))
      return entries
    })
  }

  static clubs () {
    return ClubService.list_clubs(1, ClubService.MAX_MEMBERS, 3, null)
  }
}

module.exports = { LeaderboardService }
