'use strict'
const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')
const { spawnSync } = require('node:child_process')
if (!process.env.LIBG_V13) throw new Error('Set LIBG_V13 to the supplied v13 ARM64 libg.so')
const destination = process.env.V13_RESEARCH_DIR || fs.mkdtempSync(path.join(os.tmpdir(), 'v13-native-engine-'))
const env = { ...process.env, V13_RESEARCH_DIR: destination }
const root = path.resolve(__dirname, '..')
for (const file of ['validate_function_ranges.js', 'inspect_native_schema.js', 'validate_native_csv.js', 'probe_server_character.js', 'probe_skill_idle.js', 'probe_skill_activation.js', 'probe_projectile_position.js', 'probe_projectile_launch.js', 'probe_random.js', 'probe_projectile_shoot.js', 'probe_projectile_tick.js', 'probe_collision_geometry.js', 'probe_tile_state.js', 'probe_projectile_terrain.js', 'probe_angle.js', 'probe_aim.js', 'probe_attack_configuration.js', 'probe_skill_range.js', 'probe_skill_attack_setup.js', 'probe_damage_nonlethal.js', 'probe_character_fire.js', 'probe_attack_timing.js', 'probe_projectile_scale.js', 'probe_projectile_hit.js', 'probe_data_registry.js', 'probe_character_tick.js', 'probe_tile_map.js', 'probe_character_movement.js', 'probe_battle_constructor.js']) {
  const r = spawnSync(process.execPath, [path.join(__dirname, 'native_v13', file)], { cwd: root, env, stdio: 'inherit', timeout: ['probe_data_registry.js', 'probe_character_tick.js', 'probe_tile_map.js', 'probe_character_movement.js'].includes(file) ? 420000 : 120000 })
  if (r.error) throw r.error
  if (r.status !== 0) throw new Error('Native reconstruction audit failed: ' + file)
}
// A second input scenario verifies native pathfinding around actual Tutorial walls.
{
  const r = spawnSync(process.execPath, [path.join(__dirname, 'native_v13', 'probe_character_movement.js')], { cwd: root, env: { ...env, V13_MOVEMENT_SCENARIO: 'obstacle' }, stdio: 'inherit', timeout: 420000 })
  if (r.error) throw r.error
  if (r.status !== 0) throw new Error('Native obstacle movement audit failed')
}
for (const scenario of [
  { V13_ADVANCE_OBJECTS: '1' },
  { V13_ADVANCE_OBJECTS: '1', V13_ENEMY: 'LootBox' },
  { V13_ADVANCE_OBJECTS: '1', V13_ENEMY: 'LootBox', V13_ENEMY_HP: '500' }
]) {
  const r = spawnSync(process.execPath, [path.join(__dirname, 'native_v13', 'probe_hero_skills.js')], { cwd: root, env: { ...env, ...scenario }, stdio: 'inherit', timeout: 420000 })
  if (r.error) throw r.error
  if (r.status !== 0) throw new Error('Original hero/object-manager scenario failed: ' + JSON.stringify(scenario))
}
for (const file of ['tests/native_skill_idle.test.js', 'tests/native_projectile_position.test.js', 'tests/native_projectile_timing.test.js', 'tests/native_random.test.js', 'tests/native_projectile_integration.test.js', 'tests/native_projectile_tick.test.js', 'tests/native_collision_geometry.test.js', 'tests/native_tile_state.test.js', 'tests/native_projectile_terrain.test.js', 'tests/native_angle.test.js', 'tests/native_aim.test.js', 'tests/native_attack_configuration.test.js', 'tests/native_skill_range.test.js', 'tests/native_attack_skill_setup.test.js', 'tests/native_attack_timing.test.js', 'tests/native_character_fire.test.js', 'tests/native_projectile_scale.test.js', 'tests/native_data_registry.test.js', 'tests/native_character_tick.test.js', 'tests/native_tile_map.test.js', 'tests/native_character_movement.test.js', 'tests/native_character_obstacle.test.js', 'tests/native_hero_world.test.js', 'tests/native_hero_enemy.test.js', 'tests/native_hero_death.test.js', 'tests/native_battle_constructor.test.js']) {
  const r = spawnSync(process.execPath, [file], { cwd: root, env, stdio: 'inherit' })
  if (r.error) throw r.error
  if (r.status !== 0) throw new Error('Transcription differs from native library: ' + file)
}
const schema = JSON.parse(fs.readFileSync(path.join(destination, 'required-csv-schema.json')))
const blocked = Object.entries(schema).filter(([, s]) => s.missing.length || s.invalidIntegers.length).map(([name]) => name)
console.log('Evidence saved to:', destination)
console.log('Asset families blocked:', blocked.join(', ') || 'none')
console.log('This audit does not certify a complete native battle runtime or APK gameplay.')
