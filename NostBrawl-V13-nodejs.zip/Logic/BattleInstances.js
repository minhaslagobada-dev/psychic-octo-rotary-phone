'use strict'

const crypto = require('crypto')

const DataBase = require('../Database/DatabaseManager')
const { ValueError } = require('../Utils/Errors')

class BattleInstanceError extends ValueError {
  constructor (message) {
    super(message)
    this.name = 'BattleInstanceError'
  }
}

class BattleInstanceService {
  static _player_id (player) {
    let lowId = 0
    try {
      lowId = Math.trunc(Number(player.low_id ?? 0)) || 0
    } catch (error) {
      throw new BattleInstanceError('Conta inválida para identificar a partida')
    }
    if (lowId <= 0 || !(player.token || '')) {
      throw new BattleInstanceError('Conta não autenticada para identificar a partida')
    }
    return lowId
  }

  static _current (connection, lowId) {
    return connection.prepare(
      'SELECT battle_id, payload_hash, game_mode, rewards_json ' +
      'FROM battle_reward_ledger WHERE player_id = ? AND is_current = 1'
    ).get(lowId)
  }

  static _completed (connection, lowId, payloadHash, gameMode) {
    return connection.prepare(
      'SELECT battle_id FROM battle_reward_ledger ' +
      'WHERE player_id = ? AND payload_hash = ? AND game_mode = ? ' +
      'AND rewards_json IS NOT NULL ' +
      'ORDER BY completed_at DESC, created_at DESC LIMIT 1'
    ).get(lowId, payloadHash, gameMode)
  }

  static _insert (connection, lowId, payloadHash = '', gameMode = -1) {
    const battleId = crypto.randomBytes(16).toString('hex')
    const now = Math.floor(Date.now() / 1000)
    connection.prepare(
      'UPDATE battle_reward_ledger SET is_current = 0, updated_at = ? ' +
      'WHERE player_id = ? AND is_current = 1'
    ).run(now, lowId)
    connection.prepare(
      'INSERT INTO battle_reward_ledger (' +
      'player_id, battle_id, payload_hash, game_mode, is_current, ' +
      'created_at, updated_at' +
      ') VALUES (?, ?, ?, ?, 1, ?, ?)'
    ).run(lowId, battleId, payloadHash, Math.trunc(gameMode), now, now)
    return battleId
  }

  static begin (player) {
    if (!(player.token || '')) {
      return null
    }
    const lowId = BattleInstanceService._player_id(player)
    const battleId = DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const current = BattleInstanceService._current(connection, lowId)
      if (current !== undefined && current.rewards_json === null) {
        return current.battle_id
      }
      return BattleInstanceService._insert(connection, lowId)
    }, true)
    player.battle_instance_id = battleId
    return battleId
  }

  static resolve_result (player, payloadHash, gameMode) {
    const lowId = BattleInstanceService._player_id(player)
    if (typeof payloadHash !== 'string' || payloadHash.length !== 64) {
      throw new BattleInstanceError('Identidade de conteúdo BattleEnd inválida')
    }
    try {
      gameMode = Math.trunc(Number(gameMode))
    } catch (error) {
      throw new BattleInstanceError('Modo BattleEnd inválido')
    }
    if (Number.isNaN(gameMode)) {
      throw new BattleInstanceError('Modo BattleEnd inválido')
    }

    const battleId = DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const current = BattleInstanceService._current(connection, lowId)
      if (current === undefined) {
        const completed = BattleInstanceService._completed(connection, lowId, payloadHash, gameMode)
        return completed !== undefined
          ? completed.battle_id
          : BattleInstanceService._insert(connection, lowId, payloadHash, gameMode)
      }
      if (current.rewards_json !== null) {
        if (String(current.payload_hash) === payloadHash && Math.trunc(current.game_mode) === gameMode) {
          return current.battle_id
        }
        const completed = BattleInstanceService._completed(connection, lowId, payloadHash, gameMode)
        return completed !== undefined
          ? completed.battle_id
          : BattleInstanceService._insert(connection, lowId, payloadHash, gameMode)
      }
      if (!current.payload_hash) {
        const battleId = current.battle_id
        const now = Math.floor(Date.now() / 1000)
        connection.prepare(
          'UPDATE battle_reward_ledger SET payload_hash = ?, ' +
          'game_mode = ?, updated_at = ? WHERE player_id = ? AND battle_id = ?'
        ).run(payloadHash, gameMode, now, lowId, battleId)
        return battleId
      }
      if (String(current.payload_hash) === payloadHash && Math.trunc(current.game_mode) === gameMode) {
        return current.battle_id
      }
      const completed = BattleInstanceService._completed(connection, lowId, payloadHash, gameMode)
      if (completed === undefined) {
        throw new BattleInstanceError(
          'Resultado divergente para a instância de partida aberta'
        )
      }
      return completed.battle_id
    }, true)
    player.battle_instance_id = battleId
    return battleId
  }

  static mark_home (player) {
    if (!(player.token || '')) {
      return
    }
    const lowId = BattleInstanceService._player_id(player)
    DataBase._connection((connection) => {
      connection.prepare(
        'UPDATE battle_reward_ledger SET home_seen = 1, updated_at = ? ' +
        'WHERE player_id = ? AND is_current = 1'
      ).run(Math.floor(Date.now() / 1000), lowId)
    }, true)
  }
}

module.exports = { BattleInstanceService, BattleInstanceError }
module.exports.default = BattleInstanceService
