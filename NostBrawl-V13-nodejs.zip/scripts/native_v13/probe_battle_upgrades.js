'use strict'
// Port of probe_battle_upgrades.py.
// Original upgraded character registration and skin-specific primary firing.
const fs = require('node:fs')
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x4000000 }); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const record = {}
  try {
    const battle = new NativeBattle(data, 'Gemgrab1')
    battle.add_player('ShotgunGirl', 0, { power_level: 9, star_card: 'ShotgunGirl_unique', skin: 'BanditGirlPrereg' })
    battle.setup(); record.initial = battle.describe(); record.frames = []
    // A valid v13 direct-shot entry: tick=0, latency=0, sequence=1, count=1;
    // counter=1, category=1, skill=0, relative X=0, relative Y=-1000,
    // target=0, auto-aim=false. Packet bytes are supplied by the JS encoder.
    if (process.env.V13_INPUT_SCHEDULE === undefined) throw new Error("KeyError: 'V13_INPUT_SCHEDULE'")
    const schedule = JSON.parse(fs.readFileSync(process.env.V13_INPUT_SCHEDULE, 'utf8'))
    for (let tick = 0; tick < 20; tick++) {
      if (tick === 2) battle.input_packet(0, Buffer.from(schedule[0].packet, 'hex'))
      const vision = battle.frame(); const frame = battle.describe(); frame.vision = vision; record.frames.push(frame)
    }
    R.print('Native upgraded registration + skin firing completed:', record.frames.length, 'frames')
  } catch (e) {
    record.error = { message: R.errorMessage(e), pc: m.pc(), lr: m.lr() }
    R.print('blocked', record.error)
  }
  R.writeJson('battle-upgrades-vectors.json', record)
  if ('error' in record) throw new R.SystemExit(1)
})
