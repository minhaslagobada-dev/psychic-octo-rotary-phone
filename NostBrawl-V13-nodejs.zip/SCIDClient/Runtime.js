'use strict'

let _service = null

function get_service () {
  return _service
}

function set_service (service) {
  _service = service
}

module.exports = { get_service, set_service }
