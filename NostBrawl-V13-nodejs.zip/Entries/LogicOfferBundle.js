'use strict'

const LogicOfferItem = require('./LogicOfferItem')

class LogicOfferBundle {
  static encode (writer, offer, now) {
    const items = offer.items || []
    if (!(items.length >= 1 && items.length <= 3)) {
      throw new Error('An offer requires between one and three items')
    }
    writer.v(items.length)
    for (const item of items) {
      LogicOfferItem.encode(writer, item)
    }
    const price = Math.trunc(offer.price)
    const originalPrice = Math.trunc(offer.originalPrice !== undefined ? offer.originalPrice : price)
    writer.v(Math.trunc(offer.currency))
    writer.v(price)
    writer.v(Math.max(0, Math.trunc(offer.expiresAt) - Math.trunc(now)))
    writer.v(offer.seen ? 1 : 0)
    writer.v(100)
    writer.boolean(Boolean(offer.purchased))
    writer.v(0)
    writer.boolean(Boolean(offer.daily))
    writer.v(originalPrice > price ? originalPrice : 0)
    writer.s(String(offer.title || ''))
  }
}

module.exports = LogicOfferBundle
