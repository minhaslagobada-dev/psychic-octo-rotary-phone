'use strict'

const Writer = require('../../../../Utils/Writer')

class AvatarNameChangeFailedMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 20205
    this.player = player
  }

  encode () {
    this.writeVint(0)
  }
}

module.exports = AvatarNameChangeFailedMessage
