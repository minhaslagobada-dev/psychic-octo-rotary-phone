'use strict'
const { enabled } = require('../World/BattleAssets')
// Native entry: sequence, category, action/skill ID, X, Y, target, bool.
// Handler 0xcd610 reads action at +8, coordinates at +12/+16. These are
// neither the v36 action numbers nor its absolute direct-shot coordinates.
function absoluteAim (skill, assets) {
  const projectile = skill.Projectile && assets.named('projectiles', skill.Projectile)
  return Boolean(projectile && enabled(projectile.Indirect) && (projectile.SpawnAreaEffectObject || skill.SpawnedItem || skill.SummonedCharacter || enabled(projectile.AttractsPet))) ||
    (skill.BehaviorType === 'Charge' && [2, 3, 6].includes(Number(skill.ChargeType)))
}
function worldCommand (world, entry, input) {
  if (input.category !== 1) return null
  const char = world.characters.get(entry.player.low_id)
  if (!char) return null
  if (input.code === 100) return { type: 2, x: input.x, y: input.y }
  if (input.code === 107 || input.code === 108) { char.superSelected = input.code === 107; return null }
  const slot = char.skills.findIndex(state => state.definition.id === input.code)
  if (slot < 0 || input.code >= 100) return null
  const skill = char.skills[slot].definition
  let x = input.x; let y = input.y
  if (input.flag) {
    const target = world.objects.get(input.targetId - 1000000)
    const selected = target && target.dataClass === 16 && target.hp > 0 ? target : world.nearestEnemy(char)
    if (selected) { x = selected.x; y = selected.y }
  } else if (!absoluteAim(skill, world.assets)) { x += char.x; y += char.y }
  if (x === char.x && y === char.y) x += 100
  return { type: slot, x, y, flag: false }
}
module.exports = { absoluteAim, worldCommand }
