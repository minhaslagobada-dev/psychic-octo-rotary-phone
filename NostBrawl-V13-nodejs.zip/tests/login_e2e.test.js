'use strict'
const path = require('path')
process.chdir(path.resolve(__dirname, '..'))

const DataBase = require('../Database/DatabaseManager')
const Device = require('../Logic/Device')
const { Players } = require('../Logic/Player')
const Config = require('../Utils/Config')
const Fingerprint = require('../Utils/Fingerprint')
const Runtime = require('../SCIDClient/Runtime')
const LoginMessage = require('../Packets/Messages/Client/Login/LoginMessage')

let passed = 0
function check (label, condition) {
  if (!condition) {
    console.error(`FAIL ${label}`)
    process.exit(1)
  }
  passed += 1
  console.log(`ok ${label}`)
}

function parseHeader (packet) {
  return {
    id: packet.readUInt16BE(0),
    length: packet.readUIntBE(2, 3),
    version: packet.readUInt16BE(5)
  }
}

function buildLoginPayload (highId, lowId, token) {
  const settings = Config.GetValue()
  const parts = []
  const int32 = (value) => {
    const b = Buffer.alloc(4)
    b.writeInt32BE(value, 0)
    return b
  }
  const string = (value) => {
    const raw = Buffer.from(value, 'utf-8')
    return Buffer.concat([int32(raw.length), raw])
  }
  parts.push(int32(highId))
  parts.push(int32(lowId))
  parts.push(string(token))
  parts.push(int32(settings.ClientMajor))
  parts.push(int32(settings.ClientMinor))
  parts.push(int32(settings.ClientBuild))
  parts.push(string(Fingerprint.loadFinger('GameAssets/fingerprint.json')))
  parts.push(string(''))
  parts.push(string('device-open-udid'))
  parts.push(string('device-android-id'))
  parts.push(string('device-os-version'))
  return Buffer.concat(parts)
}

async function runLogin (lowId, token) {
  const sent = []
  const fakeSocket = { write: (data) => sent.push(Buffer.from(data)) }
  const device = new Device(fakeSocket)
  const player = new Players(device)
  const message = new LoginMessage(fakeSocket, player, buildLoginPayload(0, lowId, token))
  message.decode()
  await message.process()
  return { player, sent }
}

async function main () {
  const lowId = 700000 + Math.floor(Math.random() * 100000)
  const token = `login_e2e_${lowId}`

  const playerDraft = { token, low_id: lowId, high_id: 0, name: 'LoginProbe' }
  DataBase.createAccount({ player: playerDraft })

  Runtime.set_service({
    authenticate: () => null,
    link_game: () => false,
    token_for_game: () => [null, null],
    store: { by_id: () => null, by_game: () => null, game_account: () => null, game_by_token: () => null },
    tokens: { issue: () => null }
  })
  try {
    const { player, sent } = await runLogin(lowId, token)
    check('login accepted', player.logged_in === true)
    check('login has account loaded', player.name === 'LoginProbe')

    check('at least two packets sent', sent.length >= 2)
    const first = parseHeader(sent[0])
    check('first packet is LoginOk (20104)', first.id === 20104)
    const second = parseHeader(sent[1])
    check('second packet is OwnHomeData (24101)', second.id === 24101)
    check('own home data payload non-trivial', second.length > 64)
    check('sent frames match header lengths', sent.every((packet) => parseHeader(packet).length + 7 === packet.length))

    const wrong = await runLogin(lowId, 'bogus_token_' + lowId)
    check('wrong token rejected', wrong.player.logged_in !== true)
    const failed = parseHeader(wrong.sent[0])
    check('rejected packet is LoginFailed (20103)', failed.id === 20103)

    // brand-new account path (low_id=0): server must assign a random id+token
    const fresh = await runLogin(0, '')
    check('new account login accepted', fresh.player.logged_in === true)
    check('new account got generated low_id', fresh.player.low_id > 0)
    check('new account got generated 40-char token', typeof fresh.player.token === 'string' && fresh.player.token.length === 40)
    check('new account LoginOk sent', parseHeader(fresh.sent[0]).id === 20104)

    // and the generated credentials must work on a second login
    const relogin = await runLogin(fresh.player.low_id, fresh.player.token)
    check('generated credentials survive relogin', relogin.player.logged_in === true)
    check('relogin LoginOk sent', parseHeader(relogin.sent[0]).id === 20104)
  } finally {
    Runtime.set_service(null)
  }

  console.log(`${passed} checks passed`)
  console.log('LOGIN E2E OK')
}

main().catch((error) => {
  console.error('LOGIN E2E FAILED', error)
  process.exit(1)
})
