'use strict'

const fs = require('fs')
const path = require('path')

const { openDatabase: sqlite3 } = require('../Database/SqliteDriver')

const DataBase = require('../Database/DatabaseManager')
const PresenceService = require('./PresenceService')
const { ValueError } = require('../Utils/Errors')

class ClubError extends ValueError {
  constructor (message, code = 42) {
    super(message)
    this.name = 'ClubError'
    this.code = code
  }
}

function toInteger (value, defaultValue = 0) {
  if (typeof value === 'bigint') {
    return Number(value)
  }
  const parsed = Number(value)
  if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
    return defaultValue
  }
  return Math.trunc(parsed)
}

class ClubService {
  static get MAX_MEMBERS () { return 100 }

  static _now () {
    return Math.floor(Date.now() / 1000)
  }

  static _text (value, maximum, required = false) {
    const text = String(value !== undefined && value !== null ? value : '')
    const size = Buffer.byteLength(text, 'utf-8')
    if (required && !text.trim()) {
      throw new ClubError('Nome do clube obrigatório')
    }
    if (size > maximum) {
      throw new ClubError('Texto do clube muito longo')
    }
    return text
  }

  static _membership (connection, playerId) {
    const row = connection.prepare(
      'SELECT clubID, clubRole FROM players WHERE lowID = ?'
    ).get(playerId)
    if (row === undefined) {
      throw new ClubError('Conta não encontrada')
    }
    return [Math.trunc(row.clubID), Math.trunc(row.clubRole)]
  }

  static _set_membership (connection, playerId, clubId, role, seen = false) {
    let progression = null
    let info
    if (seen) {
      const row = connection.prepare('SELECT 1 FROM players WHERE lowID = ?').get(playerId)
      if (row === undefined) {
        throw new ClubError('Conta não encontrada')
      }
      progression = DataBase._read_state(connection, playerId, 'progression')
      progression.clubLastSeenMessageID = 0
      info = connection.prepare(
        'UPDATE players SET clubID = ?, clubRole = ? WHERE lowID = ?'
      ).run(clubId, role, playerId)
      DataBase._write_state(connection, playerId, 'progression', progression)
    } else {
      info = connection.prepare(
        'UPDATE players SET clubID = ?, clubRole = ? WHERE lowID = ?'
      ).run(clubId, role, playerId)
    }
    if (info.changes !== 1) {
      throw new ClubError('Conta não encontrada')
    }
    return progression
  }

  static _sync_player (player, clubId, role, progression = null) {
    player.club_low_id = clubId
    player.club_role = role
    if (progression !== null && progression !== undefined && 'clubLastSeenMessageID' in progression) {
      let current = player.progression
      if (typeof current !== 'object' || current === null || Array.isArray(current)) {
        current = {}
        player.progression = current
      }
      current.clubLastSeenMessageID = progression.clubLastSeenMessageID
    }
  }

  static _sync_actor (player) {
    return DataBase._connection((connection) => {
      const [clubId, role] = ClubService._membership(connection, Math.trunc(player.low_id))
      const progression = DataBase._read_state(connection, Math.trunc(player.low_id), 'progression')
      ClubService._sync_player(player, clubId, role, progression)
    })
  }

  static refresh_online_player (actor, playerId) {
    const registry = actor.ClientDict !== undefined ? actor.ClientDict : null
    if (!registry) {
      return null
    }
    const entry = (registry.Clients || {})[String(Math.trunc(playerId))]
    const livePlayer = entry === undefined || entry === null ? null : entry.Player
    if (livePlayer === null || livePlayer === undefined) {
      return null
    }
    return DataBase._connection((connection) => {
      const [clubId, role] = ClubService._membership(connection, Math.trunc(playerId))
      const progression = DataBase._read_state(connection, Math.trunc(playerId), 'progression')
      ClubService._sync_player(livePlayer, clubId, role, progression)
      return livePlayer
    })
  }

  static _add_message (connection, clubId, event, tick, player, message, role = null) {
    const now = ClubService._now()
    const messageRole = role === null || role === undefined
      ? Math.trunc(player.club_role || 0)
      : Math.trunc(role)
    const countRow = connection.prepare(
      'SELECT COUNT(*) + 1 AS position FROM club_messages WHERE club_id = ?'
    ).get(clubId)
    const info = connection.prepare(
      'INSERT INTO club_messages ' +
      '(club_id, event, tick, player_id, player_name, player_role, message, created_at) ' +
      'VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
    ).run(
      clubId, event, tick, Math.trunc(player.low_id || 0),
      String(player.name || ''),
      messageRole, String(message), now
    )
    return {
      id: Number(info.lastInsertRowid),
      position: Math.trunc(countRow.position),
      event,
      tick,
      player_id: Math.trunc(player.low_id || 0),
      player_name: String(player.name || ''),
      player_role: messageRole,
      message: String(message),
      created_at: now
    }
  }

  static _club (connection, clubId, currentPlayer = null) {
    const row = connection.prepare(
      'SELECT id, name, description, region, badge_id, type, ' +
      'required_trophies, family_friendly, created_at FROM clubs WHERE id = ?'
    ).get(clubId)
    if (row === undefined) {
      return null
    }
    const memberRows = connection.prepare(
      'SELECT p.lowID, p.name, p.trophies, m.role, p.online, ' +
      'p.profileIcon, p.namecolor, p.playerExp, m.joined_at, sp.last_activity_at ' +
      'FROM club_members m JOIN players p ON p.lowID = m.player_id ' +
      'LEFT JOIN social_presence sp ON sp.player_id = p.lowID ' +
      'WHERE m.club_id = ? ORDER BY m.joined_at ASC, p.lowID ASC'
    ).all(clubId)
    const members = []
    for (const member of memberRows) {
      const ranks = DataBase._read_state(
        connection, member.lowID, 'brawlersTrophiesForRank'
      )
      const rankValues = (typeof ranks === 'object' && ranks !== null && !Array.isArray(ranks))
        ? Object.values(ranks).map((value) => Math.trunc(Number(value || 0)))
        : []
      let status = PresenceService.status(member.lowID, member.online)
      if (
        currentPlayer !== null && currentPlayer !== undefined &&
        Math.trunc(currentPlayer.low_id || 0) === Math.trunc(member.lowID)
      ) {
        status = Math.trunc(currentPlayer.online || 0)
      }
      const elapsed = PresenceService.elapsed(
        status, member.last_activity_at !== undefined ? member.last_activity_at : null
      )
      if (status === 0 && elapsed === -1) {
        status = -1
      }
      members.push({
        low_id: Math.trunc(member.lowID),
        name: member.name,
        trophies: Math.trunc(member.trophies),
        role: Math.trunc(member.role),
        status,
        last_seen_seconds: elapsed,
        rank: rankValues.length ? Math.max(...rankValues) : 0,
        profile_icon: Math.trunc(member.profileIcon),
        name_color: Math.trunc(member.namecolor),
        experience: Math.trunc(member.playerExp),
        joined_at: Math.trunc(member.joined_at)
      })
    }
    return {
      id: Math.trunc(row.id),
      name: row.name,
      description: row.description,
      region: row.region,
      badge_id: Math.trunc(row.badge_id),
      type: Math.trunc(row.type),
      required_trophies: Math.trunc(row.required_trophies),
      family_friendly: Math.trunc(row.family_friendly),
      created_at: Math.trunc(row.created_at),
      members,
      member_ids: members.map((member) => member.low_id),
      member_count: members.length,
      online_count: members.filter(
        (member) => member.status > 0 && member.status !== 6
      ).length,
      trophies: members.reduce((total, member) => total + member.trophies, 0)
    }
  }

  static get_club (clubId, currentPlayer = null) {
    return DataBase._connection((connection) =>
      ClubService._club(connection, Math.trunc(clubId), currentPlayer)
    )
  }

  static is_member (playerId, clubId) {
    return DataBase._connection((connection) =>
      connection.prepare(
        'SELECT 1 FROM club_members WHERE player_id = ? AND club_id = ?'
      ).get(Math.trunc(playerId), Math.trunc(clubId)) !== undefined
    )
  }

  static get_own_club (player) {
    let role
    let club
    DataBase._connection((connection) => {
      ;[club, role] = ClubService._membership(connection, Math.trunc(player.low_id))
      const clubId = club
      club = clubId ? ClubService._club(connection, clubId, player) : null
    })
    return [club, role !== undefined ? role : 0]
  }

  static push_presence (player) {
    const clubId = Math.trunc(player.club_low_id || 0)
    if (!clubId) {
      return 0
    }
    const recipients = DataBase._connection((connection) =>
      connection.prepare(
        'SELECT player_id FROM club_members WHERE club_id = ?'
      ).all(clubId).map((row) => Math.trunc(row.player_id))
    )
    const AllianceMemberEntryMessage = require('../Packets/Messages/Server/Alliance/AllianceMemberEntryMessage')
    let delivered = 0
    const ownId = Math.trunc(player.low_id || 0)
    for (const recipient of recipients) {
      if (recipient === ownId) {
        continue
      }
      if (new AllianceMemberEntryMessage(null, player).sendWithLowID(recipient)) {
        delivered += 1
      }
    }
    return delivered
  }

  static get_messages (clubId) {
    const rows = DataBase._connection((connection) =>
      connection.prepare(
        'SELECT id, event, tick, player_id, player_name, player_role, message, created_at ' +
        'FROM club_messages WHERE club_id = ? ORDER BY id ASC'
      ).all(Math.trunc(clubId))
    )
    const messages = rows.map((row) => ({
      id: Math.trunc(row.id),
      event: Math.trunc(row.event),
      tick: Math.trunc(row.tick),
      player_id: Math.trunc(row.player_id),
      player_name: row.player_name,
      player_role: Math.trunc(row.player_role),
      message: row.message,
      created_at: Math.trunc(row.created_at)
    }))
    let position = 0
    for (const entry of messages) {
      position += 1
      entry.position = position
    }
    return messages
  }

  static get_notifications (clubId, limit = 5) {
    const rows = DataBase._connection((connection) =>
      connection.prepare(
        'SELECT id, text, sender_id, created_at FROM club_notifications ' +
        'WHERE club_id = ? ORDER BY id DESC LIMIT ?'
      ).all(Math.trunc(clubId), Math.trunc(limit))
    )
    return rows.reverse().map((row) => ({
      id: Math.trunc(row.id),
      text: row.text,
      by: Math.trunc(row.sender_id),
      timer: Math.trunc(row.created_at)
    }))
  }

  static list_clubs (minMembers = 1, maxMembers = 100, clubType = 2, maxListLength = 30, name = null) {
    const minimum = Math.max(0, Math.trunc(minMembers))
    const maximum = Math.min(ClubService.MAX_MEMBERS, Math.max(minimum, Math.trunc(maxMembers)))
    const typeLimit = Math.trunc(clubType)
    const limit = maxListLength === null || maxListLength === undefined
      ? null
      : Math.max(0, Math.min(200, Math.trunc(maxListLength)))
    const needle = String(name !== null && name !== undefined ? name : '').toLowerCase()
    const clubs = DataBase._connection((connection) => {
      const ids = connection.prepare('SELECT id FROM clubs').all().map((row) => Math.trunc(row.id))
      return ids.map((clubId) => ClubService._club(connection, clubId))
    })
    const filtered = clubs.filter(
      (club) =>
        club.member_count >= minimum && club.member_count <= maximum &&
        club.type <= typeLimit &&
        (!needle || club.name.toLowerCase().includes(needle) || needle === String(club.id))
    )
    filtered.sort((a, b) => (b.trophies - a.trophies) || (a.id - b.id))
    return limit === null ? filtered : filtered.slice(0, limit)
  }

  static create (player, clubId, name, description, badgeId, clubType, requiredTrophies, familyFriendly) {
    clubId = Math.trunc(clubId)
    name = ClubService._text(name, 96, true)
    description = ClubService._text(description, 1024)
    badgeId = Math.trunc(badgeId)
    clubType = Math.trunc(clubType)
    requiredTrophies = Math.trunc(requiredTrophies)
    familyFriendly = Math.trunc(familyFriendly)
    if (clubId <= 0 || badgeId < 0 || ![1, 2, 3].includes(clubType)) {
      throw new ClubError('Configuração de clube inválida')
    }
    if (!(requiredTrophies >= 0 && requiredTrophies <= 1000000) || ![0, 1].includes(familyFriendly)) {
      throw new ClubError('Configuração de clube inválida')
    }
    const now = ClubService._now()
    const club = DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const [currentClub] = ClubService._membership(connection, player.low_id)
      if (currentClub) {
        throw new ClubError('O jogador já pertence a um clube')
      }
      if (connection.prepare('SELECT 1 FROM clubs WHERE id = ?').get(clubId)) {
        throw new ClubError('ID de clube já utilizado')
      }
      connection.prepare(
        'INSERT INTO clubs ' +
        '(id, name, description, region, badge_id, type, required_trophies, family_friendly, created_at) ' +
        'VALUES (?, ?, ?, \'RU\', ?, ?, ?, ?, ?)'
      ).run(clubId, name, description, badgeId, clubType, requiredTrophies, familyFriendly, now)
      connection.prepare(
        'INSERT INTO club_members (club_id, player_id, role, joined_at) VALUES (?, ?, 2, ?)'
      ).run(clubId, player.low_id, now)
      ClubService._set_membership(connection, player.low_id, clubId, 2, true)
      return ClubService._club(connection, clubId)
    }, true)
    ClubService._sync_actor(player)
    return [club, null]
  }

  static join (player, clubId) {
    clubId = Math.trunc(clubId)
    const now = ClubService._now()
    const [club, entry] = DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const [currentClub] = ClubService._membership(connection, player.low_id)
      if (currentClub) {
        throw new ClubError('O jogador já pertence a um clube')
      }
      const found = ClubService._club(connection, clubId)
      if (found === null) {
        throw new ClubError('Clube não encontrado')
      }
      if (found.member_count >= ClubService.MAX_MEMBERS) {
        throw new ClubError('O clube está cheio', 42)
      }
      connection.prepare(
        'INSERT INTO club_members (club_id, player_id, role, joined_at) VALUES (?, ?, 1, ?)'
      ).run(clubId, player.low_id, now)
      ClubService._set_membership(connection, player.low_id, clubId, 1, true)
      const entry = ClubService._add_message(connection, clubId, 4, 0, player, '3', 1)
      return [ClubService._club(connection, clubId), entry]
    }, true)
    ClubService._sync_actor(player)
    return [club, entry]
  }

  static leave (player) {
    let successorId = null
    let clubId
    let entry
    let remaining
    let remainingIds
    let deleted
    DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const membership = ClubService._membership(connection, player.low_id)
      clubId = membership[0]
      const role = membership[1]
      if (!clubId) {
        throw new ClubError('O jogador não pertence a um clube')
      }
      const club = ClubService._club(connection, clubId)
      if (club === null) {
        throw new ClubError('Clube não encontrado')
      }
      entry = ClubService._add_message(connection, clubId, 4, 0, player, '4', role)
      connection.prepare(
        'DELETE FROM club_members WHERE club_id = ? AND player_id = ?'
      ).run(clubId, player.low_id)
      ClubService._set_membership(connection, player.low_id, 0, 0, true)
      remaining = ClubService._club(connection, clubId)
      if (remaining.member_count === 0) {
        connection.prepare('DELETE FROM clubs WHERE id = ?').run(clubId)
        remainingIds = []
        deleted = true
      } else {
        remainingIds = remaining.member_ids
        deleted = false
        if (role === 2 && !remaining.members.some((member) => member.role === 2)) {
          const successor = remaining.members[0]
          successorId = successor.low_id
          connection.prepare(
            'UPDATE club_members SET role = 2 WHERE club_id = ? AND player_id = ?'
          ).run(clubId, successor.low_id)
          connection.prepare(
            'UPDATE players SET clubRole = 2 WHERE lowID = ?'
          ).run(successor.low_id)
          remaining = ClubService._club(connection, clubId)
        }
      }
    }, true)
    ClubService._sync_actor(player)
    if (successorId !== null) {
      ClubService.refresh_online_player(player, successorId)
    }
    return {
      successorID: successorId,
      clubID: clubId,
      club: remaining,
      entry,
      memberIDs: remainingIds,
      deleted
    }
  }

  static edit (player, description, badgeId, clubType, requiredTrophies, familyFriendly = null) {
    description = ClubService._text(description, 1024)
    badgeId = Math.trunc(badgeId)
    clubType = Math.trunc(clubType)
    requiredTrophies = Math.trunc(requiredTrophies)
    if (badgeId < 0 || ![1, 2, 3].includes(clubType) || !(requiredTrophies >= 0 && requiredTrophies <= 1000000)) {
      throw new ClubError('Configuração de clube inválida')
    }
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const [clubId, role] = ClubService._membership(connection, player.low_id)
      if (!clubId || ![2, 3].includes(role)) {
        throw new ClubError('Sem permissão para editar o clube')
      }
      const club = ClubService._club(connection, clubId)
      if (club === null) {
        throw new ClubError('Clube não encontrado')
      }
      if (familyFriendly === null || familyFriendly === undefined) {
        familyFriendly = club.family_friendly
      }
      familyFriendly = Math.trunc(familyFriendly)
      if (![0, 1].includes(familyFriendly)) {
        throw new ClubError('Configuração family friendly inválida')
      }
      connection.prepare(
        'UPDATE clubs SET description = ?, badge_id = ?, type = ?, ' +
        'required_trophies = ?, family_friendly = ? WHERE id = ?'
      ).run(description, badgeId, clubType, requiredTrophies, familyFriendly, clubId)
      return ClubService._club(connection, clubId)
    }, true)
  }

  static promote (player, targetId, targetedRole) {
    targetId = Math.trunc(targetId)
    targetedRole = Math.trunc(targetedRole)
    if (![1, 2, 3, 4].includes(targetedRole) || targetId === player.low_id) {
      throw new ClubError('Promoção inválida')
    }
    let actorNewRole
    const club = DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const [clubId, actorRole] = ClubService._membership(connection, player.low_id)
      const [targetClub, targetRole] = ClubService._membership(connection, targetId)
      if (!clubId || targetClub !== clubId) {
        throw new ClubError('O membro não pertence ao mesmo clube')
      }
      let allowed
      if (actorRole === 2) {
        allowed = true
      } else if (actorRole === 3 && [1, 4].includes(targetedRole)) {
        allowed = true
      } else {
        allowed = false
      }
      if (!allowed || targetRole === 2) {
        throw new ClubError('Sem permissão para alterar esse papel')
      }
      connection.prepare(
        'UPDATE club_members SET role = ? WHERE club_id = ? AND player_id = ?'
      ).run(targetedRole, clubId, targetId)
      connection.prepare(
        'UPDATE players SET clubRole = ? WHERE lowID = ?'
      ).run(targetedRole, targetId)
      actorNewRole = actorRole
      if (targetedRole === 2) {
        actorNewRole = 4
        connection.prepare(
          'UPDATE club_members SET role = 4 WHERE club_id = ? AND player_id = ?'
        ).run(clubId, player.low_id)
        connection.prepare(
          'UPDATE players SET clubRole = 4 WHERE lowID = ?'
        ).run(player.low_id)
      }
      return ClubService._club(connection, clubId)
    }, true)
    ClubService._sync_actor(player)
    ClubService.refresh_online_player(player, targetId)
    return [club, actorNewRole]
  }

  static kick (player, targetId) {
    targetId = Math.trunc(targetId)
    if (targetId === player.low_id) {
      throw new ClubError('Use a saída de clube para sair')
    }
    const [club, entry] = DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const [clubId, actorRole] = ClubService._membership(connection, player.low_id)
      const [targetClub, targetRole] = ClubService._membership(connection, targetId)
      if (!clubId || targetClub !== clubId || ![2, 3, 4].includes(actorRole)) {
        throw new ClubError('Sem permissão para expulsar esse membro')
      }
      if (targetRole === 2 || (actorRole !== 2 && targetRole !== 1)) {
        throw new ClubError('Sem permissão para expulsar esse membro')
      }
      const entry = ClubService._add_message(connection, clubId, 4, 1, player, '1', actorRole)
      connection.prepare(
        'DELETE FROM club_members WHERE club_id = ? AND player_id = ?'
      ).run(clubId, targetId)
      ClubService._set_membership(connection, targetId, 0, 0, true)
      return [ClubService._club(connection, clubId), entry]
    }, true)
    ClubService.refresh_online_player(player, targetId)
    return [club, entry, targetId]
  }

  static chat (player, text) {
    text = ClubService._text(text, 1024, true)
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const [clubId, role] = ClubService._membership(connection, player.low_id)
      if (!clubId || role <= 0) {
        throw new ClubError('O jogador não pertence a um clube')
      }
      if (ClubService._club(connection, clubId) === null) {
        throw new ClubError('Clube não encontrado')
      }
      const entry = ClubService._add_message(connection, clubId, 2, 0, player, text, role)
      return [clubId, entry]
    }, true)
  }

  static mail (player, text) {
    text = ClubService._text(text, 1024, true)
    const now = ClubService._now()
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const [clubId, role] = ClubService._membership(connection, player.low_id)
      if (!clubId || role <= 0) {
        throw new ClubError('O jogador não pertence a um clube')
      }
      const club = ClubService._club(connection, clubId)
      if (club === null) {
        throw new ClubError('Clube não encontrado')
      }
      const info = connection.prepare(
        'INSERT INTO club_notifications (club_id, text, sender_id, created_at) VALUES (?, ?, ?, ?)'
      ).run(clubId, text, player.low_id, now)
      return [club, {
        id: Number(info.lastInsertRowid),
        text,
        by: player.low_id,
        timer: now
      }]
    }, true)
  }

  static migrate_legacy (clubsPath = 'Database/clubs.db', chatsDirectory = 'Database/Chats') {
    const emptyResult = { clubs: 0, members: 0, messages: 0, notifications: 0 }
    const resolvedClubs = path.resolve(clubsPath)
    if (!fs.existsSync(resolvedClubs) || fs.statSync(resolvedClubs).size === 0) {
      return emptyResult
    }
    let rows
    try {
      const legacy = new sqlite3(resolvedClubs, { readonly: true })
      try {
        rows = legacy.prepare('SELECT * FROM clubs').raw().all()
      } finally {
        legacy.close()
      }
    } catch (error) {
      return emptyResult
    }
    const counts = { clubs: 0, members: 0, messages: 0, notifications: 0 }
    const now = ClubService._now()
    DataBase._connection((connection) => {
      for (const row of rows) {
        if (row.length < 10) {
          continue
        }
        const clubId = Math.trunc(row[0])
        let info = connection.prepare(
          'INSERT OR IGNORE INTO clubs ' +
          '(id, name, description, region, badge_id, type, required_trophies, family_friendly, created_at) ' +
          'VALUES (?, ?, ?, ?, ?, ?, ?, 0, ?)'
        ).run(clubId, String(row[1]), String(row[2]), String(row[3]), Math.trunc(row[4]), Math.trunc(row[5]), Math.trunc(row[6]), now)
        counts.clubs += info.changes
        let members
        try {
          members = JSON.parse(row[8] || '{}')
          if (typeof members !== 'object' || members === null) {
            members = {}
          }
        } catch (error) {
          members = {}
        }
        for (const playerKey of Object.keys(members)) {
          if (playerKey === 'totalmembers') {
            continue
          }
          const playerId = Math.trunc(Number(playerKey))
          if (Number.isNaN(playerId)) {
            continue
          }
          const account = connection.prepare(
            'SELECT clubID, clubRole FROM players WHERE lowID = ?'
          ).get(playerId)
          const data = members[playerKey]
          if (account === undefined || Math.trunc(account.clubID) !== clubId) {
            continue
          }
          const role = (typeof data === 'object' && data !== null && data.role !== undefined)
            ? Math.trunc(data.role)
            : Math.trunc(account.clubRole)
          info = connection.prepare(
            'INSERT OR IGNORE INTO club_members (club_id, player_id, role, joined_at) VALUES (?, ?, ?, ?)'
          ).run(clubId, playerId, role || 1, now)
          counts.members += info.changes
        }
        const chatPath = path.join(path.resolve(chatsDirectory), `${clubId}.db`)
        if (fs.existsSync(chatPath) && fs.statSync(chatPath).size) {
          const hasMessages = connection.prepare(
            'SELECT 1 FROM club_messages WHERE club_id = ? LIMIT 1'
          ).get(clubId)
          if (!hasMessages) {
            let messages
            try {
              const chat = new sqlite3(chatPath, { readonly: true })
              try {
                messages = chat.prepare('SELECT * FROM chats').raw().all()
              } finally {
                chat.close()
              }
            } catch (error) {
              messages = []
            }
            for (const message of messages) {
              if (message.length < 6) {
                continue
              }
              connection.prepare(
                'INSERT INTO club_messages ' +
                '(club_id, event, tick, player_id, player_name, player_role, message, created_at) ' +
                'VALUES (?, ?, ?, ?, ?, ?, ?, ?)'
              ).run(
                clubId, Math.trunc(message[0]), Math.trunc(message[1]),
                Math.trunc(message[2]), String(message[3]), Math.trunc(message[4]),
                String(message[5]), now
              )
              counts.messages += 1
            }
          }
        }
        let notifications
        try {
          notifications = JSON.parse(row[9] || '{}')
          if (typeof notifications !== 'object' || notifications === null) {
            notifications = {}
          }
        } catch (error) {
          notifications = {}
        }
        const hasNotifications = connection.prepare(
          'SELECT 1 FROM club_notifications WHERE club_id = ? LIMIT 1'
        ).get(clubId)
        if (!hasNotifications) {
          for (const notification of Object.values(notifications)) {
            if (typeof notification !== 'object' || notification === null) {
              continue
            }
            connection.prepare(
              'INSERT INTO club_notifications (club_id, text, sender_id, created_at) VALUES (?, ?, ?, ?)'
            ).run(
              clubId, String(notification.text !== undefined ? notification.text : ''),
              Math.trunc(notification.by !== undefined ? notification.by : 0),
              Math.trunc(notification.timer !== undefined ? notification.timer : now)
            )
            counts.notifications += 1
          }
        }
      }
    }, true)
    return counts
  }
}

module.exports = { ClubService, ClubError }
module.exports.default = ClubService
