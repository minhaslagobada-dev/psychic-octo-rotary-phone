'use strict'
// Port of probe_random.py.
// Original v13 random integer generator used by projectile spread.
const { NativeV13 } = require('./emulate_v13')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); const state = n.alloc(4); const records = []; const m = R.memory(n)
  for (const seed of [0, 1, -1, 17, 2147483647, -2147483648, 123456789]) {
    for (const bound of [-1, 0, 1, 2, 3, 7, 100, 300, 2147483647]) {
      n.uc.mem_write(state, R.pack('i', seed))
      for (let index = 0; index < 64; index++) {
        const before = m.i32(state)
        const value = R.signed32(n.call(0x2880b8, state, R.u32(bound)))
        const after = m.i32(state)
        records.push({ state: before, bound, value, nextState: after })
      }
    }
  }
  R.writeJson('random-vectors.json', records)
  R.print('Original v13 spread RNG:', records.length, 'state transitions')
})
