'use strict'

const { LeaderboardService } = require('../../../../Logic/LeaderboardService')
const LeaderboardMessage = require('./LeaderboardMessage')

class GetLeaderboardClubLocalOkMessage extends LeaderboardMessage {
  constructor (client, player, type = 2) {
    super(client, player, 2, true, LeaderboardService.clubs())
  }
}

module.exports = GetLeaderboardClubLocalOkMessage
