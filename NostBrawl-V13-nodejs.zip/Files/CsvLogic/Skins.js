'use strict'
const { readRows } = require('./CsvRows')

class Skins {
  static _rows (path) {
    return readRows(path)
  }

  static _skin (skinId) {
    let parsed
    try {
      parsed = Number.parseInt(skinId, 10)
      if (Number.isNaN(parsed)) throw new Error('nan')
    } catch (error) {
      throw new Error('Invalid skin id')
    }
    const rows = Skins._rows('GameAssets/csv_logic/skins.csv')
    if (parsed < 0 || parsed >= rows.length || !rows[parsed][2]) {
      throw new Error('Invalid skin id')
    }
    return rows[parsed]
  }

  static get_skins_id () {
    const rows = Skins._rows('GameAssets/csv_logic/skins.csv')
    const ids = []
    for (let skinId = 0; skinId < rows.length; skinId++) {
      if (rows[skinId].length > 2 && rows[skinId][2]) {
        ids.push(skinId)
      }
    }
    return ids
  }

  static getBrawler (skinId) {
    const target = Skins._skin(skinId)[2]
    const rows = Skins._rows('GameAssets/csv_logic/characters.csv')
    for (let brawlerId = 0; brawlerId < rows.length; brawlerId++) {
      if (rows[brawlerId].length && rows[brawlerId][0] === target) {
        return brawlerId
      }
    }
    throw new Error('Skin has no character')
  }

  static get_default_skin (brawlerId) {
    let parsed
    try {
      parsed = Number.parseInt(brawlerId, 10)
      if (Number.isNaN(parsed)) throw new Error('nan')
    } catch (error) {
      throw new Error('Invalid brawler id')
    }
    const characters = Skins._rows('GameAssets/csv_logic/characters.csv')
    if (
      parsed < 0 || parsed >= characters.length ||
      characters[parsed].length <= 22 ||
      characters[parsed][20] !== 'Hero'
    ) {
      throw new Error('Invalid brawler id')
    }
    const character = characters[parsed]
    const rows = Skins._rows('GameAssets/csv_logic/skins.csv')
    for (let skinId = 0; skinId < rows.length; skinId++) {
      const row = rows[skinId]
      if (row.length > 2 && row[0] === character[22] && row[2] === character[0]) {
        return skinId
      }
    }
    throw new Error('Brawler has no default skin')
  }

  static resolve_skin (brawlerId, skinId) {
    try {
      const parsedBrawler = Number.parseInt(brawlerId, 10)
      const parsedSkin = Number.parseInt(skinId || 0, 10)
      if (Skins.getBrawler(parsedSkin) === parsedBrawler) {
        return parsedSkin
      }
    } catch (error) {
    }
    return Skins.get_default_skin(brawlerId)
  }

  static getNonDefaultSkins () {
    const defaultSkins = new Set(
      Skins._rows('GameAssets/csv_logic/characters.csv')
        .filter((row) => row.length > 22)
        .map((row) => row[22])
    )
    const ids = []
    const rows = Skins._rows('GameAssets/csv_logic/skins.csv')
    for (let skinId = 0; skinId < rows.length; skinId++) {
      const row = rows[skinId]
      if (row.length > 2 && row[2] && !defaultSkins.has(row[0])) {
        ids.push(skinId)
      }
    }
    return ids
  }

  static getSkinPrice (skinId) {
    const row = Skins._skin(skinId)
    try {
      return Math.max(0, Number.parseInt(row[4] || '0', 10) || 0)
    } catch (error) {
      return 0
    }
  }

  static getIsDefaultSkin (skinId) {
    const name = Skins._skin(skinId)[0]
    return Skins._rows('GameAssets/csv_logic/characters.csv')
      .some((row) => row.length > 22 && row[22] === name)
  }
}

module.exports = Skins
