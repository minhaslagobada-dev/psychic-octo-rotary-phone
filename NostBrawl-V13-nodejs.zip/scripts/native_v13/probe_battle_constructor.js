'use strict'
// Port of probe_battle_constructor.py.
// Original battle/container constructor; not full match initialization.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/globals.csv'))
  const word = m.i32; const pointer = m.u64
  const records = []
  for (let kind = 0; kind < 12; kind++) {
    const battle = t.alloc(0x400); n.call(0x4328f8, battle, kind, { count: 3000000 })
    const manager = pointer(battle); const terrain = pointer(battle + 0x70)
    n.call(0x201398, manager, battle)
    const players = word(battle + 0x84)
    let empty = true
    for (let i = 0; i < players; i++) if (pointer(pointer(battle + 0x78) + i * 8) !== 0) { empty = false; break }
    const record = { kind, storedKind: word(battle + 0xa4), playerSlots: players, expectedSlots: n.call(0xda014, kind), tick: word(battle + 0x18), managerObjects: word(manager + 0xc), managerFlags: [...n.uc.mem_read(manager + 0x60, 5)], managerBattleMatches: pointer(manager + 0x50) === battle, emptyPlayerSlots: empty, mapPointerPresent: terrain !== 0 }
    R.assert(record.storedKind === kind && BigInt(record.playerSlots) === record.expectedSlots)
    R.assert(record.managerBattleMatches && record.emptyPlayerSlots && record.mapPointerPresent)
    records.push(record)
  }
  R.writeJson('battle-constructor-vectors.json', records)
  R.print('Original battle/container constructors:', records.length, 'kind inputs; player slots, manager flags/binding and map container; no players/maps/modes initialized')
})
