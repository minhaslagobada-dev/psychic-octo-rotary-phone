'use strict'

const ClubService = require('../../../../Logic/ClubService').ClubService
const Writer = require('../../../../Utils/Writer')

class AllianceStreamMessage extends Writer {
  constructor (client, player, clubLowID, type) {
    super(client)
    this.id = 24311
    this.version = 11
    this.player = player
    this.eventType = type
    this.clubLowID = clubLowID
  }

  encode () {
    if (!this.clubLowID || !ClubService.is_member(this.player.low_id, this.clubLowID)) {
      this.writeVint(0)
      return
    }
    const entries = ClubService.get_messages(this.clubLowID)
    this.writeVint(entries.length)
    for (const entry of entries) {
      this.writeVint(entry.event)
      this.writeVint(0)
      this.writeVint(entry.tick)
      this.writeVint(0)
      this.writeVint(entry.player_id)
      this.writeString(entry.player_name)
      this.writeVint(entry.player_role)
      this.writeVint(0)
      this.writeVint(0)
      if (entry.event === 4) {
        this.writeVint(Math.trunc(Number(entry.message)))
        this.writeVint(1)
        this.writeVint(0)
        this.writeVint(entry.player_id)
        this.writeString(entry.player_name)
      } else {
        this.writeString(entry.message)
      }
    }
  }
}

module.exports = AllianceStreamMessage
