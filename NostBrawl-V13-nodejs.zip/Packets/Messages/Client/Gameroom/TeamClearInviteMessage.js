'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamClearInviteMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.high_id = 0
    this.low_id = 0
  }

  decode () {
    this.high_id = this.read_int()
    this.low_id = this.read_int()
    this.ensure_end()
  }

  process () {
    const [room, invite] = GameRoomService.cancel_invite(
      this.player, this.high_id, this.low_id
    )
    if (room === null) {
      return null
    }
    GameRoomGateway.broadcast_data(this.player, room, this.client)
    return { room, invite }
  }
}

module.exports = TeamClearInviteMessage
