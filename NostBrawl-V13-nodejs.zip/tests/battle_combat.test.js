'use strict'
const assert = require('node:assert/strict')
const { battleAssets } = require('../Logic/Battle/World/BattleAssets')
const { BattleWorld } = require('../Logic/Battle/Game/BattleWorld')
const { TileMap } = require('../Logic/Battle/World/TileMap')
const assets = battleAssets()
function arena (hero = 0) {
  const roster = Array.from({ length: 6 }, (_, i) => ({ index: i, team: i < 3 ? 0 : 1, player: { low_id: i + 1, brawler_id: hero, Brawler_level: {} } }))
  const w = new BattleWorld('combat', assets, 7, roster)
  w.map = new TileMap(Array(33).fill('.'.repeat(21)), assets)
  for (const entry of roster) w.input(entry, { type: 4 })
  w.step()
  for (const c of w.characters.values()) Object.assign(c, { x: 5000, y: 8000 })
  const own = w.characters.get(1); const enemy = w.characters.get(4)
  Object.assign(own, { x: 1500, y: 1500 }); Object.assign(enemy, { x: 1500, y: 1900 })
  return { w, own, enemy }
}
// Every enabled hero's primary must reach a real enemy, rather than merely
// instantiate an object or consume ammunition.
for (const hero of assets.heroes) {
  const { w, own, enemy } = arena(hero.id); const hp = enemy.hp
  assert(w.activate(own, 0, enemy.x, enemy.y))
  for (let i = 0; i < 45; i++) w.step()
  assert(enemy.hp < hp, hero.Name + ': primary never damaged the target')
}
for (const hero of assets.heroes.filter(h => ![13, 14, 16, 23].includes(h.id))) {
  const { w, own, enemy } = arena(hero.id); const hp = enemy.hp
  own.superCharge = 4000; assert(w.activate(own, 1, enemy.x, enemy.y))
  let damaged = false
  for (let i = 0; i < 90; i++) { w.step(); if (enemy.hp < hp) damaged = true }
  assert(damaged, hero.Name + ': super never damaged the target')
}
{
  const { w, own, enemy } = arena(0)
  enemy.x = 5000
  w.activate(own, 0, 1500, 3500); assert.equal(own.skills[0].ammo, 2000, 'One trigger consumes one cartridge'); w.step()
  assert.equal(Array.from(w.objects.values()).filter(o => o.dataClass === 6).length, 5, 'Shelly must fire five pellets')
  for (let i = 0; i < 6; i++) w.step()
  assert.equal(own.skills[0].ammo, 2000, 'Reload must wait until active time plus cooldown')
  w.step()
  assert(own.skills[0].ammo > 2000 && own.skills[0].ammo < 3000, 'Ammo must reload gradually')
}
{
  const { w, own, enemy } = arena(20); const hp = enemy.hp
  w.activate(own, 0, enemy.x, enemy.y)
  for (let i = 0; i < 11; i++) w.step()
  assert.equal(enemy.hp, hp, 'Frank must not deal damage before his windup')
  for (let i = 0; i < 10; i++) w.step()
  assert(enemy.hp < hp)
}
{
  const { w, own, enemy } = arena(12)
  w.activate(own, 0, enemy.x, enemy.y)
  for (let i = 0; i < 10; i++) w.step()
  const hp = enemy.hp; assert(enemy.statuses.some(s => s.kind === 'poison'))
  for (let i = 0; i < 20; i++) w.step()
  assert(enemy.hp < hp, 'Crow poison must continue dealing damage')
}
for (const hero of [7, 8, 19]) {
  const { w, own, enemy } = arena(hero); const hp = enemy.hp
  own.superCharge = 4000; w.activate(own, 1, enemy.x, enemy.y)
  for (let i = 0; i < 80; i++) w.step()
  assert(Array.from(w.objects.values()).some(o => o.dataClass === 16 && o.owner === own), 'Summon must remain in world')
  assert(enemy.hp < hp, 'Summoned turret/pet must attack')
}
{
  const { w, own } = arena(16)
  own.hp = 500; own.superCharge = 4000; w.activate(own, 1, own.x, own.y)
  for (let i = 0; i < 70; i++) { own.lastDamage = w.tick; w.step() }
  assert(own.hp > 500, 'Pam station must heal independently of natural regeneration')
}
{
  const { w, own, enemy } = arena(13)
  const ally = w.characters.get(2)
  Object.assign(ally, { x: 1500, y: 1800 }); own.hp = 1000; ally.hp = 1000
  const enemyHp = enemy.hp
  own.superCharge = 4000; w.activate(own, 1, 1500, 3000)
  for (let i = 0; i < 8; i++) w.step()
  assert.equal(own.hp, 2840, 'Poco super heals himself once')
  assert.equal(ally.hp, 2840, 'Poco wave cannot multiply healing across its three projectiles')
  assert.equal(enemy.hp, enemyHp, 'Poco healing super must not damage opponents')
}
{
  const { w, own, enemy } = arena(20)
  const hp = enemy.hp; w.activate(own, 0, enemy.x, enemy.y)
  for (let i = 0; i < 22; i++) w.step()
  assert.equal(hp - enemy.hp, 1200, 'Frank wave applies its damage once, despite overlapping projectiles')
}
{
  const { w, own } = arena(0)
  w.damage(own, 1000, null)
  for (let i = 0; i < 59; i++) w.step()
  assert.equal(own.hp, own.maxHp - 1000)
  w.step(); assert.equal(own.hp, own.maxHp - 1000 + Math.trunc(own.maxHp * 13 / 100))
}
{
  const { w, own } = arena(23)
  own.superCharge = 4000; assert(w.activate(own, 1, 1500, 2000)); assert(own.invisible)
  assert(w.activate(own, 0, 1500, 2000)); assert.equal(own.invisible, false, 'Leon attack must break invisibility')
}
{
  const { w, own, enemy } = arena(14)
  own.superCharge = 4000; w.activate(own, 1, enemy.x, enemy.y)
  for (let i = 0; i < 40; i++) w.step()
  const mines = Array.from(w.objects.values()).filter(o => o.dataClass === 18 && assets.tables.items[o.dataId].Name === 'Mine')
  assert.equal(mines.length, 3)
  const hp = enemy.hp; Object.assign(enemy, { x: mines[0].x, y: mines[0].y })
  for (let i = 0; i < 30; i++) w.step()
  assert(enemy.hp < hp, 'Bo mines must arm and explode after a victim enters their trigger radius')
}
{
  const { w, own, enemy } = arena(15)
  own.superCharge = 4000; const hp = enemy.hp
  w.activate(own, 1, 1500, 1950)
  // Remove the bombs to isolate Piper's jump itself: no landing damage.
  for (const object of w.objects.values()) if (object.dataClass === 18) w.objects.delete(object.id)
  for (let i = 0; i < 35; i++) w.step()
  assert.equal(enemy.hp, hp, 'Piper jump must not inherit El Primo landing damage')
  assert.equal(own.charging, false)
}
{
  const { w, own, enemy } = arena(10)
  own.superCharge = 4000; w.activate(own, 1, 1500, 3500)
  const hp = own.hp
  const s = assets.named('skills', 'GunslingerWeapon')
  w.projectile(s.Projectile, enemy, -Math.PI / 2, 1000, { slot: 0, definition: s, target: { x: own.x, y: own.y } })
  for (let i = 0; i < 3; i++) w.step()
  assert.equal(own.hp, hp, 'Ground projectiles cannot hit an airborne hero')
}
{
  const { w, own } = arena(15)
  const box = w.spawnItem('BoxOfBombs', 3000, 3000, own, 800)
  for (let i = 0; i < 25; i++) w.step()
  assert(!w.objects.has(box.id))
  assert(!Array.from(w.objects.values()).some(o => o.dataClass === 18 && assets.tables.items[o.dataId].Name === 'Bomb'), 'Piper bombs must detonate even with nobody nearby')
}
{
  const { w, own } = arena(18)
  const grid = Array(33).fill('.'.repeat(21)).map(s => s.split(''))
  const code = Array.from(assets.tileCodes).find(([, d]) => d.BlocksMovement === 'true' && d.BlocksProjectiles === 'true')[0]
  for (let y = 0; y < 33; y++) grid[y][8] = code
  w.map = new TileMap(grid.map(row => row.join('')), assets)
  own.superCharge = 4000; w.activate(own, 1, 3500, 1500)
  let reflected = false
  for (let i = 0; i < 15; i++) { w.step(); if (own.chargeTarget.x < own.x) reflected = true }
  assert(reflected, 'Darryl must reflect his roll from a wall')
  assert(own.x < 2200, 'Darryl must travel away from the wall after reflecting')
}
console.log('COMBAT OK: 22 primaries/supers; summons, healing, poison, invisibility, air immunity, Piper bombs and Darryl roll')
