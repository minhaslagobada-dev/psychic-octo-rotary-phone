'use strict'

const BillingService = require('../../../../Logic/BillingService')
const RewardDelivery = require('../../../../Logic/RewardDelivery')
const { RewardError } = require('../../../../Logic/Rewards')
const BillingRequestFailedMessage = require('../../Server/Billing/BillingRequestFailedMessage')
const BuyBundleBillingPackResponseMessage = require('../../Server/Billing/BuyBundleBillingPackResponseMessage')
const GoogleBillingProcessedByServerMessage = require('../../Server/Billing/GoogleBillingProcessedByServerMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')
const { ValueError } = require('../../../../Utils/Errors')

class GoogleBillingRequestMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.client = client
    this.player = player
    this.values = []
  }

  decode () {
    this.values = Array.from({ length: 6 }, () => this.read_string())
  }

  process () {
    let result
    try {
      result = BillingService.purchase(this.player, this.values)
    } catch (error) {
      if (error instanceof RewardError || error instanceof TypeError || error instanceof ValueError) {
        new BillingRequestFailedMessage(this.client, this.player, String(error.message)).send()
        return { accepted: false, error: String(error.message) }
      }
      throw error
    }
    const billingPackage = result.package
    if (result.isBundle) {
      new BuyBundleBillingPackResponseMessage(
        this.client, this.player,
        billingPackage.type, billingPackage.starterPackNumber
      ).send()
    } else {
      new GoogleBillingProcessedByServerMessage(
        this.client, this.player,
        billingPackage.name, result.transactionId, 0
      ).send()
    }
    RewardDelivery.send_many(this.client, this.player, result.responses)
    return { accepted: true, product: billingPackage.name }
  }
}

module.exports = GoogleBillingRequestMessage
