'use strict'
// Smoke test da Lakey Store: vínculo, gift card de uso único, débito atômico,
// idempotência de pedidos, estorno em falha de entrega, reconciliação,
// isolamento do fulfillment Google e API HTTP (health/offers/purchase).
const path = require('path')
const fs = require('fs')
const http = require('http')
process.chdir(path.resolve(__dirname, '..'))

function check (label, condition) {
  if (!condition) {
    console.error(`FAIL ${label}`)
    process.exit(1)
  }
  console.log(`ok ${label}`)
}

// --- config da suíte: bancos de teste isolados ---
const TEST_DB = 'Database/store_test.sqlite'
const TEST_CATALOG = 'JSON/store_catalog_test.json'
for (const suffix of ['', '-wal', '-shm']) {
  try { fs.unlinkSync(path.resolve(TEST_DB + suffix)) } catch (e) { /* ok */ }
}
try { fs.unlinkSync(path.resolve(TEST_CATALOG)) } catch (e) { /* ok */ }

const StoreConfig = require('../Store/StoreConfig')
StoreConfig._cache = {
  Enabled: true,
  PublicUrl: 'http://127.0.0.1',
  Port: 0,
  BotToken: '',
  AdminIds: [8719469905],
  StarCents: 40,
  DatabasePath: TEST_DB,
  CatalogPath: TEST_CATALOG,
  SessionDays: 30,
  TicketMinutes: 5,
  Mode: 'embedded',
  InternalPort: 0,
  InternalKey: 'smoke-internal-key-0123456789abcdef',
  SiteInternalUrl: ''
}

const DataBase = require('../Database/DatabaseManager')
const StoreCatalog = require('../Store/StoreCatalog')
const { StoreService, StoreError } = require('../Store/StoreService')
const TelegramBot = require('../Store/TelegramBot')
const WebServer = require('../Store/WebServer')
const InternalApi = require('../Store/InternalApi')
const Hmac = require('../Store/Hmac')
const Delivery = require('../Store/Delivery')
const BillingService = require('../Logic/BillingService')
const ShopCatalog = require('../Logic/ShopCatalog')
const ShopServicePkg = require('../Logic/ShopService')
const BoxInventory = require('../Logic/BoxInventory')
const { RewardError } = require('../Logic/Rewards')

// --- conta de jogo para entrega offline ---
const lowId = 977001
const token = 'store_smoke_' + lowId
const player = {
  token,
  low_id: lowId,
  high_id: 0,
  name: 'StoreTester',
  gems: 0,
  gold: 0,
  tickets: 0,
  tokensdoubler: 0,
  battle_tokens: 0,
  brawl_boxes: 0,
  big_boxes: 0,
  trophies: 0,
  highest_trophies: 0,
  player_experience: 99999,
  trophy_road: 1,
  tutorial: 2,
  profile_icon: 0,
  brawler_id: 0,
  skin_id: 0,
  starpower: 0,
  name_color: 0,
  star_points: 0,
  progression: {}
}
try {
  DataBase.createAccount({ player })
} catch (error) {
  /* conta já existe de execução anterior */
}
require('../Logic/Player')

const fakeServer = { Clients: { ClientCounts: 0, Clients: {} } }
const store = new StoreService().attach(fakeServer)
check('store sobe com DB isolado', fs.existsSync(path.resolve(TEST_DB)))

function freshPlayer () {
  const re = { token, low_id: lowId }
  DataBase.loadAccount({ player: re })
  return re
}

// Baselines: a conta pode existir de execuções anteriores (teste idempotente).
const baseGems = freshPlayer().gems || 0
const baseBoxes = BoxInventory.count(freshPlayer(), 11) || 0

// ---------- identidade: intent -> ticket ----------
const intent = store.createIntent({ u: String(lowId), t: token, sku: '' }, '10.0.0.1')
check('ticket emitido (48 hex)', /^[0-9a-f]{48}$/.test(intent.ticket))
const session = store.consumeTicket(intent.ticket)
check('sessão emitida por ticket', session.session.length === 64 && session.lowId === lowId)
let duplo = null
try { store.consumeTicket(intent.ticket) } catch (error) { duplo = error }
check('ticket é de uso único', duplo instanceof StoreError)
let bogus = null
try { store.consumeTicket('f'.repeat(48)) } catch (error) { bogus = error }
check('ticket inexistente falha', bogus instanceof StoreError)
check('getSession válida', store.getSession(session.session).lowId === lowId)
check('getSession inválida', store.getSession('x'.repeat(64)) === null)

// identidade fraca é rejeitada (conta offline + IP desconhecido + token errado)
let weak = null
try { store.createIntent({ u: String(lowId), t: 'token-errado', sku: '' }, '9.9.9.9') } catch (error) { weak = error }
check('intent sem prova rejeitado', weak instanceof StoreError)
let ghostIntent = null
try { store.createIntent({ u: '424242', t: 'x', sku: '' }, '10.0.0.1') } catch (error) { ghostIntent = error }
check('intent de conta inexistente rejeitado', ghostIntent instanceof StoreError)

// identidade por IP: mesma origem da conexão ativa do protocolo
fakeServer.Clients.Clients[String(lowId)] = {
  SocketInfo: { remoteAddress: '10.0.0.77' },
  Crypto: null,
  Player: null
}
const intentIp = store.createIntent({ u: `conta:${lowId}`, t: '', sku: '' }, '10.0.0.77')
check('intent forte por IP online', /^[0-9a-f]{48}$/.test(intentIp.ticket))
check('parse low_id em formato "conta:X"', intentIp.lowId === lowId)
let ipWrong = null
try { store.createIntent({ u: String(lowId), t: '', sku: '' }, '10.0.0.78') } catch (error) { ipWrong = error }
check('IP divergente rejeitado', ipWrong instanceof StoreError)

// campos A/B podem vir invertidos (u=token, t=id) — servidor resolve sozinho
const swapped = store.createIntent({ u: token, t: String(lowId), sku: '' }, '10.0.0.77')
check('intent com A/B trocados aceito', /^[0-9a-f]{48}$/.test(swapped.ticket) && swapped.lowId === lowId)

// ---------- gift cards ----------
const card = store.createGiftCard(8719469905, 25)
check('25 estrelas -> $10.00', card.cents === 1000)
const cardAdmin = store.createGiftCardCents(8719469905, 500)
check('admin gera $5.00 sem estrelas', cardAdmin.cents === 500)
const redeem = store.redeemGiftCard(lowId, card.code)
check('resgate credita 1000¢', redeem.creditedCents === 1000 && redeem.balanceCents === 1000)
store.redeemGiftCard(lowId, cardAdmin.code)
check('saldo acumula 1500¢', store.getBalanceCents(lowId) === 1500)
let second = null
try { store.redeemGiftCard(lowId, card.code) } catch (error) { second = error }
check('gift card resgatável uma única vez', second instanceof StoreError && store.getBalanceCents(lowId) === 1500)
let ghost = null
try { store.redeemGiftCard(lowId, 'XXXX-XXXX-XXXX') } catch (error) { ghost = error }
check('código inexistente falha sem creditar', ghost instanceof StoreError && store.getBalanceCents(lowId) === 1500)

// ---------- catálogo Type 4 ----------
const offer = StoreCatalog.create_offer(8719469905, {
  kind: 'gems', amount: 10, priceCents: 400, title: 'Teste Gemas 10'
})
check('sku namespace lakeystore', offer.sku.startsWith('lakeystore.teste_gemas_10'))
check('oferta no catálogo', StoreCatalog.find(offer.sku).priceCents === 400)
const csvContent = fs.readFileSync(path.resolve('GameAssets/csv_client/billing_packages.csv'), 'utf-8')
check('linha Type 4 registrada no CSV', csvContent.includes(`"${offer.sku}","","4"`))
check('fulfillment Google ignora Type 4', !(offer.sku in ShopCatalog.billing_packages()))

const boxOffer = StoreCatalog.create_offer(8719469905, {
  kind: 'big_box', amount: 1, priceCents: 499, title: 'Teste BIGBOX'
})

// ---------- compra atômica + idempotente ----------
const buy = store.purchase(lowId, offer.sku, 'order-test-1')
check('compra debita 400¢', buy.balanceCents === 1100 && store.getBalanceCents(lowId) === 1100)
let after = freshPlayer()
check('gemas entregues na conta', after.gems === baseGems + 10)
const replay = store.purchase(lowId, offer.sku, 'order-test-1')
check('replay idempotente não duplica', replay.replay === true && store.getBalanceCents(lowId) === 1100)
after = freshPlayer()
check('sem entrega dupla', after.gems === baseGems + 10)

// ---------- saldo insuficiente ----------
const expensive = StoreCatalog.create_offer(8719469905, {
  kind: 'gems', amount: 500, priceCents: 99999, title: 'Teste Caro 500'
})
let broke = null
try { store.purchase(lowId, expensive.sku, 'order-test-2') } catch (error) { broke = error }
check('saldo insuficiente bloqueia', broke instanceof StoreError)
check('sem cobrança parcial', store.getBalanceCents(lowId) === 1100)
after = freshPlayer()
check('sem entrega sem saldo', after.gems === baseGems + 10)

// ---------- compra de caixa (inventário) ----------
const buyBox = store.purchase(lowId, boxOffer.sku, 'order-test-3')
check('compra caixa debita 499¢', buyBox.balanceCents === 601)
after = freshPlayer()
check('BIGBOX no inventário', BoxInventory.count(after, 11) === baseBoxes + 1)

// ---------- oferta 1x por conta ----------
const once = StoreCatalog.create_offer(8719469905, {
  kind: 'gems', amount: 1, priceCents: 100, title: 'Teste Unico', oneTime: true
})
store.purchase(lowId, once.sku, 'order-test-4')
let again = null
try { store.purchase(lowId, once.sku, 'order-test-5') } catch (error) { again = error }
check('oferta 1x não recompra', again instanceof StoreError && store.getBalanceCents(lowId) === 501)

// ---------- estorno em falha de entrega ----------
const realDeliver = Delivery.deliver
Delivery.deliver = () => { throw new RewardError('falha simulada') }
let failed = null
try { store.purchase(lowId, offer.sku, 'order-test-6') } catch (error) { failed = error }
Delivery.deliver = realDeliver
check('entrega com erro falha a compra', failed instanceof StoreError)
check('valor estornado', store.getBalanceCents(lowId) === 501)
const failedOrder = store.store.db.prepare("SELECT status FROM orders WHERE order_key = 'order-test-6'").get()
check('pedido marcado como failed', failedOrder && failedOrder.status === 'failed')

// ---------- reconciliação de pendências ----------
const balanceBefore = store.getBalanceCents(lowId)
store.store.db.prepare(
  "INSERT INTO orders (order_key, low_id, sku, cents, items_json, status, created_at) VALUES (?, ?, ?, ?, ?, 'pending', ?)"
).run('order-pending-1', lowId, offer.sku, offer.priceCents, JSON.stringify(offer.items), store.store.now())
store.store.db.prepare(
  'UPDATE wallets SET balance_cents = balance_cents - ? WHERE low_id = ?'
).run(offer.priceCents, lowId)
const recovered = store.reconcile()
check('reconciliação reentrega pendente', recovered === 1)
after = freshPlayer()
check('entrega reconciliada na conta', after.gems === baseGems + 21)

// ---------- isolamento do Google billing ----------
let cross = null
try {
  const pl = freshPlayer()
  BillingService.purchase(pl, ['x', 'y', offer.sku, 'z', 'w', 'v'])
} catch (error) { cross = error }
check('SKU lakeystore não é fulfillable via Google', cross instanceof RewardError)

// ---------- admin money parse ----------
const bot = new TelegramBot(store)
check('parse 9.99 -> 999¢', bot._parseMoney('9.99') === 999)
check('parse 12,50 -> 1250¢', bot._parseMoney('12,50') === 1250)
check('parse inválido', bot._parseMoney('abc') === null && bot._parseMoney('-5') === null)
check('admin id reconhecido', bot.isAdmin(8719469905) && !bot.isAdmin(1))

// ---------- API HTTP ----------
async function apiTests () {
  const web = new WebServer(store)
  await web.start()
  const port = web.server.address().port
  const base = `http://127.0.0.1:${port}`
  const get = (p, headers = {}) => new Promise((resolve, reject) => {
    http.get(base + p, { headers }, (res) => {
      let data = ''
      res.on('data', (c) => { data += c })
      res.on('end', () => resolve({ status: res.statusCode, body: data }))
    }).on('error', reject)
  })
  const post = (p, payload, headers = {}) => new Promise((resolve, reject) => {
    const req = http.request(base + p, {
      method: 'POST',
      headers: Object.assign({ 'Content-Type': 'application/json' }, headers)
    }, (res) => {
      let data = ''
      res.on('data', (c) => { data += c })
      res.on('end', () => resolve({ status: res.statusCode, body: data }))
    })
    req.on('error', reject)
    req.end(JSON.stringify(payload))
  })

  const health = await get('/health')
  check('/health ok', health.status === 200 && JSON.parse(health.body).ok === true)

  const offers = await get('/api/offers')
  const list = JSON.parse(offers.body).offers
  check('/api/offers lista catálogo', Array.isArray(list) && list.some((o) => o.sku === offer.sku))
  check('oferta expõe preço formatado', list.find((o) => o.sku === offer.sku).price === '$4.00')

  const prices = await get('/api/prices')
  check('/api/prices tem micros USD', JSON.parse(prices.body)[offer.sku].micros === 4000000)

  const noAuth = await post('/api/purchase', { sku: offer.sku, orderKey: 'x-noauth' })
  check('purchase sem sessão -> 401', noAuth.status === 401)

  const auth = { 'X-Store-Session': session.session }
  const topup = store.createGiftCardCents(8719469905, 1000)
  await post('/api/redeem', { code: topup.code }, auth)
  const buyApi = await post('/api/purchase', { sku: offer.sku, orderKey: 'order-api-1' }, auth)
  check('purchase via API entrega', buyApi.status === 200 && JSON.parse(buyApi.body).delivered === true)
  after = freshPlayer()
  check('API entregou gemas', after.gems === baseGems + 31)
  check('saldo após API', JSON.parse(buyApi.body).balanceCents === 701)

  const badCode = await post('/api/redeem', { code: 'NOPE-1234-5678' }, auth)
  check('redeem inválido -> 400', badCode.status === 400)

  const webTicket = store.createIntent({ u: String(lowId), t: token, sku: offer.sku }, '10.0.0.1')
  const ticketApi = await post('/api/ticket', { ticket: webTicket.ticket })
  check('/api/ticket via HTTP', ticketApi.status === 200 && JSON.parse(ticketApi.body).session.length === 64)
  check('ticket carrega o sku clicado', JSON.parse(ticketApi.body).sku === offer.sku)

  const index = await get('/')
  check('página principal serve HTML', index.status === 200 && index.body.includes('Lakey Store'))

  const img = await get('/assets/img/gems.png')
  check('imagem de gemas servida', img.status === 200)

  // ---------- API interna jogo<->site (HMAC estilo SCID) ----------
  const internal = new InternalApi(store)
  await internal.start()
  const ibase = `http://127.0.0.1:${internal.server.address().port}`
  const KEY = StoreConfig._cache.InternalKey
  const hpost = (path, payload, key = KEY) => new Promise((resolve, reject) => {
    const body = Buffer.from(JSON.stringify(payload), 'utf-8')
    const headers = Object.assign(Hmac.headers(key, 'POST', path, body), { 'Content-Length': body.length })
    const req = http.request(ibase + path, { method: 'POST', headers }, (res) => {
      let data = ''
      res.on('data', (c) => { data += c })
      res.on('end', () => resolve({ status: res.statusCode, body: data }))
    })
    req.on('error', reject)
    req.end(body)
  })
  const rawpost = (path, payload) => new Promise((resolve, reject) => {
    const req = http.request(ibase + path, {
      method: 'POST', headers: { 'Content-Type': 'application/json' }
    }, (res) => {
      let data = ''
      res.on('data', (c) => { data += c })
      res.on('end', () => resolve({ status: res.statusCode, body: data }))
    })
    req.on('error', reject)
    req.end(JSON.stringify(payload))
  })

  const ihealth = await new Promise((resolve, reject) => {
    http.get(ibase + '/internal/store/v1/health', (res) => {
      let data = ''
      res.on('data', (c) => { data += c })
      res.on('end', () => resolve({ status: res.statusCode, body: data }))
    }).on('error', reject)
  })
  check('internal health ok', ihealth.status === 200 && JSON.parse(ihealth.body).ok === true)

  const httpIntent = await rawpost('/internal/store/v1/intent', { u: String(lowId), t: token, sku: offer.sku })
  check('intent via HTTP emite ticket+url', httpIntent.status === 200 &&
    /^[0-9a-f]{48}$/.test(JSON.parse(httpIntent.body).ticket) &&
    JSON.parse(httpIntent.body).url.includes('?t='))

  const deliverNoAuth = await rawpost('/internal/store/v1/deliver', { order_key: 'r-0', low_id: lowId, items: [{ offerId: 16, amount: 1, value: 0, target: null }] })
  check('deliver sem assinatura -> 401', deliverNoAuth.status === 401)
  const deliverBad = await hpost('/internal/store/v1/deliver', { order_key: 'r-0', low_id: lowId, items: [{ offerId: 16, amount: 1, value: 0, target: null }] }, 'chave-errada')
  check('deliver assinatura errada -> 401', deliverBad.status === 401)

  const deliver = await hpost('/internal/store/v1/deliver', { order_key: 'r-1', low_id: lowId, items: [{ offerId: 16, amount: 5, value: 0, target: null }] })
  check('deliver remoto entrega', deliver.status === 200 && JSON.parse(deliver.body).ok === true)
  after = freshPlayer()
  check('entrega remota aplicada', after.gems === baseGems + 36)
  const deliverReplay = await hpost('/internal/store/v1/deliver', { order_key: 'r-1', low_id: lowId, items: [{ offerId: 16, amount: 5, value: 0, target: null }] })
  check('deliver remoto idempotente', JSON.parse(deliverReplay.body).replay === true)
  after = freshPlayer()
  check('replay remoto não duplica', after.gems === baseGems + 36)

  internal.stop()
  web.stop()
}

apiTests().then(() => {
  // limpeza do CSV de registro Type 4 (não poluir o repo real)
  try {
    const csvPath = path.resolve('GameAssets/csv_client/billing_packages.csv')
    const lines = fs.readFileSync(csvPath, 'utf-8').split('\n')
      .filter((line) => !line.includes('lakeystore.teste_'))
    fs.writeFileSync(csvPath, lines.join('\n'))
  } catch (error) { /* melhor esforço */ }
  try { fs.unlinkSync(path.resolve(TEST_CATALOG)) } catch (e) { /* ok */ }
  store.store.close()
  console.log('smoke_store: TODOS OS TESTES PASSARAM')
  process.exit(0)
}).catch((error) => {
  console.error('FAIL api', error)
  process.exit(1)
})
