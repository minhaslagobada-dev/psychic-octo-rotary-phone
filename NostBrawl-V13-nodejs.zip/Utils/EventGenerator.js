'use strict'
const fs = require('fs')

class EventGenerator {
  loadEvents () {
    const data = JSON.parse(fs.readFileSync('JSON/events.json', 'utf-8'))
    return data
  }

  generateEvents () {
    const result = this.loadEvents()

    const appendEvent = (ids) => {
      const l = String(Object.keys(result).length)
      result[l] = {}
      result[l].ID = ids[Math.floor(Math.random() * ids.length)]
      result[l].Modifier = 0
      result[l].Tokens = 10
      result[l].Collected = []
    }

    appendEvent([7, 8, 9, 10, 11, 12, 40, 48, 70, 72, 82, 83, 112, 114, 115, 116, 117, 122, 137, 138, 139])
    appendEvent([13, 14, 15, 16, 32, 43, 93, 95, 101, 103, 105, 109, 123, 125])
    appendEvent([0, 4, 22, 80, 81])
    appendEvent([24, 25, 26, 50, 51, 118, 132])
    appendEvent([34, 35, 36, 37, 38, 28, 94, 96, 102, 104, 106, 110, 124, 126])
    this.newEvents(result)
  }

  newEvents (result) {
    fs.writeFileSync('JSON/events.json', JSON.stringify(result))
  }

  deleteEvents () {
    fs.writeFileSync('JSON/events.json', JSON.stringify({}))
  }
}

module.exports = EventGenerator
