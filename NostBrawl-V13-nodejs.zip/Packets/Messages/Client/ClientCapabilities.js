'use strict'

const { BSMessageReader } = require('../../../Utils/Reader')

class ClientCapabilities extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
  }

  decode () {
    this.Latency = this.read_Vint()
  }

  process () {
  }
}

module.exports = ClientCapabilities
