'use strict'
const { FriendService, FriendError } = require('../../../../Logic/FriendService')
const PresenceService = require('../../../../Logic/PresenceService')
const FriendListUpdateMessage = require('../../Server/Friend/FriendListUpdateMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AcceptFriendMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
    this.high_id = 0
    this.low_id = 0
  }

  decode () {
    this.high_id = this.read_int()
    this.low_id = this.read_int()
    this.ensure_end()
  }

  process () {
    let result
    try {
      if (this.high_id !== 0) {
        throw new FriendError('Conta de amizade inexistente')
      }
      result = FriendService.accept(this.player, this.low_id)
    } catch (error) {
      if (error instanceof FriendError || error instanceof TypeError || error instanceof ValueError) {
        return { accepted: false, error: String(error.message !== undefined ? error.message : error) }
      }
      throw error
    }
    new FriendListUpdateMessage(
      this.client, this.player, result.entry, false, true
    ).send()
    new FriendListUpdateMessage(
      this.client, this.player, result.reverse_entry, false, true
    ).sendWithLowID(result.friend_id)
    PresenceService.sync_pair(this.player, result.friend_id)
    return result
  }
}

module.exports = AcceptFriendMessage
