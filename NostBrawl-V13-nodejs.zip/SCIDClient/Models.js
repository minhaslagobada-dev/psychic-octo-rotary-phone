'use strict'

const path = require('path')

const { openDatabase: sqlite3 } = require('../Database/SqliteDriver')

class SCIDError extends Error {
  constructor (code) {
    super(code)
    this.name = 'SCIDError'
    this.code = code
  }
}

class SCIDAccount {
  constructor ({
    id,
    identity,
    scid,
    bind_token,
    game_low_id,
    email_marketing_permission,
    marketing_consents,
    avatar_image,
    profile_name,
    block_incoming_friend_requests
  }) {
    this.id = id
    this.identity = identity
    this.scid = scid
    this.bind_token = bind_token
    this.game_low_id = game_low_id
    this.email_marketing_permission = email_marketing_permission
    this.marketing_consents = marketing_consents
    this.avatar_image = avatar_image
    this.profile_name = profile_name
    this.block_incoming_friend_requests = block_incoming_friend_requests
  }
}

class LocalGameAccounts {
  constructor (databasePath) {
    this.database_path = String(databasePath)
  }

  _connect () {
    const resolved = path.resolve(this.database_path)
    return sqlite3(resolved, { readonly: true })
  }

  game_account (lowId) {
    const connection = this._connect()
    try {
      return LocalGameAccounts._game_row(connection, Math.trunc(lowId), null)
    } finally {
      connection.close()
    }
  }

  game_by_token (token, lowId = null) {
    const connection = this._connect()
    try {
      return LocalGameAccounts._game_row(connection, lowId, token)
    } finally {
      connection.close()
    }
  }

  static _game_row (connection, lowId = null, token = null) {
    let row
    if (lowId !== null && lowId !== undefined && token !== null && token !== undefined) {
      row = connection.prepare(
        'SELECT lowID, token, name FROM players WHERE lowID = ? AND token = ?'
      ).get(Math.trunc(lowId), String(token))
    } else if (lowId !== null && lowId !== undefined) {
      row = connection.prepare(
        'SELECT lowID, token, name FROM players WHERE lowID = ?'
      ).get(Math.trunc(lowId))
    } else if (token !== null && token !== undefined) {
      row = connection.prepare(
        'SELECT lowID, token, name FROM players WHERE token = ?'
      ).get(String(token))
    } else {
      return null
    }
    if (row === undefined) {
      return null
    }
    return {
      low_id: Math.trunc(row.lowID),
      token: row.token,
      name: row.name
    }
  }
}

module.exports = { SCIDError, SCIDAccount, LocalGameAccounts }
