'use strict'
// Port of probe_native_placements.py.
// Natural Solo/Duo placement observations; original offline rank readers.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const { NativePlacements } = require('./native_battle_results')
const { StopIteration } = require('./lib/pycompat')
const R = require('./lib/research')
const sameMap = (a, b) => a.size === b.size && [...a].every(([k, v]) => b.has(k) && b.get(k) === v)
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x8000000, reclaim_memory: true, instruction_counting: false, timeout_us: 2000000 })
  n.decrypt(); const root = R.ROOT
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const results = []
  const table = data.csv.get(15)
  for (const [mode, kind] of [['BattleRoyale', 0], ['BattleRoyaleTeam', 6]]) {
    const row = table.records.find(row => R.zipDict(table.names, row).GameMode === mode)
    if (!row) throw new StopIteration()
    const location = row[0]
    const battle = new NativeBattle(data, location, kind); battle.add_player('ShotgunGirl', 0); battle.setup(); const placements = new NativePlacements(battle)
    const events = []; let previous = new Map(); let state
    for (let i = 0; i < 6500; i++) {
      battle.frame(); state = battle.describe(); placements.observe(state)
      if (!sameMap(placements.ranks, previous)) {
        events.push({ tick: state.tick, ranks: new Map(placements.ranks) }); previous = new Map(placements.ranks)
      }
      if (state.ended) break
    }
    const record = { mode, finished: state.ended, ticks: state.tick, ranks: placements.ranks, players: state.players, events }
    R.print('Original placements', record); results.push(record)
    placements.close(); battle.close()
  }
  R.writeJson('native-placements.json', results)
  R.assert(results.every(record => record.finished && record.ranks.size === 10))
})
