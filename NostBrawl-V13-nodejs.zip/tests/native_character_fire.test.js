'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { dueAtTick } = require('../Native/V13/AttackTiming')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'character-fire-vectors.json')))
let frames = 0; let shots = 0
for (const v of vectors) for (const frame of v.frames) {
  const gate = dueAtTick(frame.lastShot, frame.interval, frame.tick)
  assert.equal(gate.attackingTicks, frame.attackingTicks, v.skill)
  if (!gate.due) {
    assert.equal(frame.shots.length, 0, v.skill)
    assert.equal(frame.afterCounter, frame.beforeCounter, v.skill)
  } else {
    const pattern = Number(v.definition.AttackPattern) || 0
    const count = pattern >= 1 && pattern <= 3 ? 1 : Math.max(1, Number(v.definition.NumBulletsInOneAttack) || 0)
    assert.equal(frame.shots.length, count, v.skill)
    assert.equal(frame.afterCounter, frame.beforeCounter + 1, v.skill)
  }
  frames++; shots += frame.shots.length
}
assert(shots > 0)
console.log('Original character fire:', vectors.length, 'definitions;', frames, 'gates;', shots, 'projectiles; controlled muzzle fixture, not complete hero/frame simulation')
