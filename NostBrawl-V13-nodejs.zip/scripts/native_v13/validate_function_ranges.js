'use strict'
// Port of validate_function_ranges.py.
// Fail if a documented routine starts inside another native function.
const fs = require('node:fs')
const path = require('node:path')
const { elf } = require('./native')
const R = require('./lib/research')
R.main(async () => {
  const manifest = JSON.parse(fs.readFileSync(path.join(R.ROOT, 'Native/V13/manifest.json'), 'utf8'))
  const ranges = new Map()
  for (const e of elf.ehFrameRanges()) ranges.set(e.initial_location, e.initial_location + e.address_range)
  for (const f of manifest.functions) {
    const start = parseInt(f.start, 16); const end = parseInt(f.end, 16)
    R.assert(ranges.get(start) === end, [f.name, R.hex(start), R.hex(ranges.get(start) || 0), R.hex(end)])
    R.assert(end - start === f.size, f.name)
  }
  R.print('Native function boundaries verified against ELF unwind metadata:', manifest.functions.length)
})
