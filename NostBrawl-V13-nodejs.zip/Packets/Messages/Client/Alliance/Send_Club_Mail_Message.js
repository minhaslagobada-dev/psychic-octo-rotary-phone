'use strict'
const { ClubService, ClubError } = require('../../../../Logic/ClubService')
const AllianceMailWindow = require('../../Server/Alliance/Events/Mail')
const LogicAddNotificationCommand = require('../../Server/NotifAdd')
const { BSMessageReader } = require('../../../../Utils/Reader')

class SendClubMail extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.clubHighID = this.read_int()
    this.clubLowID = this.read_int()
    this.msg = this.read_string()
  }

  process () {
    let club
    let notification
    try {
      ;[club, notification] = ClubService.mail(this.player, this.msg)
    } catch (error) {
      if (error instanceof ClubError) {
        if (!this.msg) {
          new AllianceMailWindow(this.client, this.player, 114).send()
        }
        return String(error.message)
      }
      throw error
    }
    new AllianceMailWindow(this.client, this.player, 113).send()
    for (const memberId of club.member_ids) {
      new LogicAddNotificationCommand(
        this.client, this.player, this.msg, notification
      ).sendWithLowID(memberId)
    }
    return notification
  }
}

module.exports = SendClubMail
