'use strict'
const assert = require('node:assert/strict')
const { battleAssets } = require('../Logic/Battle/World/BattleAssets')
const { Matchmaker } = require('../Logic/Battle/Matchmaker')
const { VARIATIONS, rules } = require('../Logic/Battle/World/GameModes')
const assets = battleAssets()
let id = 0
const member = () => ({ player: { low_id: ++id, logged_in: true, brawler_id: 0 }, client: { destroyed: false } })
assert.equal(VARIATIONS.AttackDefend, 2)
assert.equal(VARIATIONS.LaserBall, 5)
assert.equal(VARIATIONS.BossFight, 7)
assert.equal(VARIATIONS.Survival, 8)
assert.equal(VARIATIONS.Raid, 10)
assert.equal(rules('Survival').capacity, 3)
const matchmaker = new Matchmaker(assets)
const parties = [Array.from({ length: 3 }, member), Array.from({ length: 2 }, member), [member()]]
const tickets = parties.map(m => matchmaker.enqueue(m, 7))
assert.equal(matchmaker.enqueue(parties[0], 7), tickets[0])
assert.throws(() => matchmaker.enqueue([parties[0][0]], 0))
const selected = matchmaker.select(matchmaker.buckets.get(7))
assert.equal(selected.length, 3)
assert.equal(selected.find(s => s.ticket === tickets[1]).team, selected.find(s => s.ticket === tickets[2]).team)
assert.notEqual(selected[0].team, selected[1].team)
matchmaker.poll(() => ({ id: 1 }))
assert.equal(matchmaker.players.size, 0)
assert(tickets.every(t => t.state === 'matched'))
const a = member(); const b = member()
matchmaker.enqueue([a, b], 34)
assert.equal(matchmaker.cancel(a.player, b.client), false)
assert.equal(matchmaker.cancel(a.player, a.client), true)
assert.equal(matchmaker.players.size, 0)
const solo = new Matchmaker(assets)
for (let i = 0; i < 200; i++) solo.enqueue([member()], 13)
let count = 0
solo.poll(selection => { assert.equal(selection.length, 10); return { id: ++count } })
assert.equal(count, 20)
assert.equal(solo.players.size, 0)
const fragmented = new Matchmaker(assets)
for (let i = 0; i < 100; i++) fragmented.enqueue([member(), member()], 7)
assert.equal(fragmented.select(fragmented.buckets.get(7)), null, 'parties cannot be split to fabricate a full team')
fragmented.close()
assert.equal(fragmented.players.size, 0)
assert.throws(() => fragmented.enqueue([member()], 7))
console.log('BATTLE MATCHMAKING OK: native modes, parties, fair selection, 200 queued players, cancel ownership and shutdown')

// A monotonic test clock checks the exact deadline without a flaky real wait.
let now = 1000
const timed = new Matchmaker(assets, 200, { now: () => now })
const statuses = []
timed.on('status', (ticket, found, seconds) => statuses.push({ found, seconds }))
const first = member(); const firstTicket = timed.enqueue([first], 7)
assert.equal(statuses.at(-1).seconds, 15)
now += 1000; timed.notify(7); assert.equal(statuses.at(-1).seconds, 14)
const lateParty = [member(), member()]
now += 13000; timed.enqueue(lateParty, 7)
assert.equal(statuses.at(-1).seconds, 1, 'Late arrivals share the current countdown')
assert.equal(timed.enqueue([first], 7), firstTicket, 'Repeated Play cannot reset the deadline')
let timeoutMatches = 0
now = firstTicket.joinedAt + 14999
timed.poll(() => { timeoutMatches++; return true })
assert.equal(timeoutMatches, 0)
now++
timed.poll(selection => {
  timeoutMatches++
  assert.equal(selection.reduce((sum, s) => sum + s.ticket.members.length, 0), 3)
  assert(selection.some(s => s.ticket.members.length === 2), 'The party must remain together')
  return true
})
assert.equal(timeoutMatches, 1)
assert.equal(timed.players.size, 0)
const cancelled = member(); timed.enqueue([cancelled], 13)
timed.cancel(cancelled.player, cancelled.client)
now += 20000; timed.poll(() => { throw new Error('A cancelled queue must not create a bot-only match') })
const asymmetric = new Matchmaker(assets, 200, { now: () => now })
const bigParty = Array.from({ length: 5 }, member)
asymmetric.enqueue(bigParty, 21); now += 15000
asymmetric.poll(selection => { assert.equal(selection[0].team, 0); assert.equal(selection[0].ticket.members.length, 5); return true })
assert.equal(asymmetric.players.size, 0)
console.log('MATCHMAKING TIMEOUT OK: 15 -> 0, exact deadline, shared countdown, parties, Big Game and cancellation')
