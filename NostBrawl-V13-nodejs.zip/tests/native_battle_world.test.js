'use strict'
const assert = require('node:assert/strict')
const { NativeBattleBridge } = require('../Logic/Battle/NativeBattleBridge')
const { NativeBattleWorld } = require('../Logic/Battle/Game/NativeBattleWorld')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
const { InputBuffer } = require('../Logic/Battle/Network/InputBuffer')
const { Reader } = require('../Logic/Battle/Network/V13BattleCodec')
const assets = new BattleAssets()
const runtime = new NativeBattleBridge()
try {
  const mapId = assets.named('locations', 'Gemgrab1').id
  const human = { index: 0, team: 0, brawlerId: 0, skinId: 0, powerLevel: 0,
    player: { low_id: 1, name: 'Native adapter', Brawler_starPower: {} }, session: { input: new InputBuffer() } }
  const world = new NativeBattleWorld('adapter', assets, mapId, [human], 17, runtime)
  assert.equal(world.players.length, 6)
  assert.equal(world.players.filter(player => player.bot).length, 5)
  assert.equal(world.phase, 'loading')
  const tick = world.tick
  for (let i = 0; i < 10; i++) world.step()
  assert.equal(world.tick, tick, 'Native clock must pause while clients load')
  world.players[0].ready = true
  human.session.input.push([{ counter: 1, category: 1, code: 100, x: 3150, y: 6150, targetId: 0, flag: false }])
  for (let i = 0; i < 150; i++) world.step()
  assert.equal(world.phase, 'running')
  const actor = world.state.objects.find(object => object.id === world.state.players[0].characterId)
  assert.equal(actor.x, 3150); assert.equal(actor.y, 6150)
  const reader = new Reader(world.nativeVisionPayload(world.players[0]))
  assert.equal(reader.vint(), world.tick - 1); assert.equal(reader.vint(), 1)
  let finishes = 0; world.on('finished', result => { finishes++; assert.equal(result.reason, 'abandoned') })
  world.disconnectPlayer(world.players[0]); world.disconnectPlayer(world.players[0])
  assert.equal(finishes, 1); assert.equal(world.nativeActive, false)
  const again = new NativeBattleWorld('again', assets, mapId, [{ ...human, session: { input: new InputBuffer() } }], 18, runtime)
  again.finish(null, 'shutdown')
  console.log('Synchronous native session adapter: original roster, paused loading clock, buffered input, movement, vision ACK, one-shot abandonment and reuse')
} finally { runtime.close() }
