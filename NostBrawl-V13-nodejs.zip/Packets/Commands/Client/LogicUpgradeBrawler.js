'use strict'

const Characters = require('../../../Files/CsvLogic/Characters')
const { RewardError, RewardTransaction } = require('../../../Logic/Rewards')
const { ValueError } = require('../../../Utils/Errors')

const UPGRADE_GOLD_COSTS = [20, 35, 75, 140, 290, 480, 800, 1250]
const MAX_POWER_LEVEL = UPGRADE_GOLD_COSTS.length

class Upgrade_Brawler {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    const reference = reader.readScId()
    if (reference[0] !== 16 || !Characters.get_brawlers_id().includes(reference[1])) {
      throw new ValueError(`Invalid brawler DataReference: ${reference}`)
    }
    reader.BrawlerID = reference[1]
  }

  static process (reader) {
    try {
      const brawler = Math.trunc(reader.BrawlerID)
      if (!Characters.get_brawlers_id().includes(brawler)) {
        throw new RewardError('Brawler inválido')
      }
      const states = reader.player.BrawlersUnlockedState || {}
      const state = states[String(brawler)] !== undefined ? states[String(brawler)] : states[brawler]
      if ((state || 0) !== 1) {
        throw new RewardError('O brawler precisa estar desbloqueado')
      }
      const levels = structuredClone(reader.player.Brawler_level || {})
      const key = String(brawler)
      const current = Math.trunc(Number(
        (levels[key] !== undefined ? levels[key] : levels[brawler]) || 0
      )) || 0
      if (current < 0 || current >= MAX_POWER_LEVEL) {
        throw new RewardError('Nível de poder inválido ou máximo')
      }
      const transaction = new RewardTransaction(reader.player)
      transaction.charge('gold', UPGRADE_GOLD_COSTS[current])
      levels[key] = current + 1
      transaction.set_value('Brawler_level', 'brawlerPowerLevel', levels)
      transaction.commit()
      return { brawler, level: current + 1 }
    } catch (error) {
      if (error instanceof RewardError || error instanceof TypeError || error instanceof ValueError) {
        return String(error.message)
      }
      throw error
    }
  }
}

module.exports = Upgrade_Brawler
module.exports.UPGRADE_GOLD_COSTS = UPGRADE_GOLD_COSTS
module.exports.MAX_POWER_LEVEL = MAX_POWER_LEVEL
