'use strict'

const Writer = require('../../../../Utils/Writer')
const Fingerprint = require('../../../../Utils/Fingerprint')

class LoginFailedMessage extends Writer {
  constructor (client, player, msg) {
    super(client)
    this.id = 20103
    this.player = player
    this.msg = msg
    this.fingerprint = Fingerprint.loadFinger_full('GameAssets/fingerprint.json')
  }

  encode () {
    this.writeInt(this.player.err_code)

    this.writeString(this.fingerprint)

    this.writeString()

    this.writeString(this.player.patch_url)
    this.writeString(this.player.update_url)
    this.writeString(this.msg)

    this.writeInt(this.player.maintenance_time)
    this.writeBoolean(false)

    this.writeString()
    this.writeString()

    this.writeInt(0)
    this.writeInt(3)

    this.writeString()
    this.writeString()

    this.writeInt(0)
    this.writeInt(0)

    this.writeBoolean(false)
    this.writeBoolean(false)
  }
}

module.exports = LoginFailedMessage
