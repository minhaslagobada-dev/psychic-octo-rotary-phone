'use strict'

const Writer = require('../../../../Utils/Writer')

class BuyBundleBillingPackResponseMessage extends Writer {
  constructor (client, player, packageType, starterPackNumber) {
    super(client)
    this.id = 28363
    this.player = player
    this.package_type = packageType
    this.starter_pack_number = starterPackNumber
  }

  encode () {
    this.writeVint(this.package_type)
    this.writeVint(this.starter_pack_number)
  }
}

module.exports = BuyBundleBillingPackResponseMessage
