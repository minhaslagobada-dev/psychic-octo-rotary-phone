'use strict'
const { parentPort, workerData } = require('node:worker_threads')
const { NativeBattleRuntime } = require('./NativeBattleRuntime')
const runtime = new NativeBattleRuntime(workerData.options)
function reply (control, buffer, result, error) {
  const signal = new Int32Array(control)
  let bytes = Buffer.from(JSON.stringify(error ? { error: error.message, fatal: runtime.closed } : { result }))
  if (bytes.length > buffer.byteLength) { error = new Error('Native response exceeded shared buffer'); bytes = Buffer.from(JSON.stringify({ error: error.message })) }
  new Uint8Array(buffer).set(bytes); Atomics.store(signal, 1, bytes.length)
  Atomics.store(signal, 0, error ? -1 : 1); Atomics.notify(signal, 0)
}
runtime.on('engineFailure', error => parentPort.postMessage({ engineFailure: error.message }))
runtime.start().then(() => reply(workerData.control, workerData.buffer, true), error => reply(workerData.control, workerData.buffer, null, error))
parentPort.on('message', async ({ command, fields, control, buffer }) => {
  try {
    const result = command === 'shutdown' ? await runtime.close() : await runtime.request(command, fields)
    reply(control, buffer, result === undefined ? true : result)
    if (command === 'shutdown') parentPort.close()
  } catch (error) { reply(control, buffer, null, error) }
})
