'use strict'
const TeamLeftMessage = require('./TeamLeftMessage')

class TeamLeaveOkMessage extends TeamLeftMessage {
  constructor (client, player) {
    super(client, player, 0)
  }
}

module.exports = TeamLeaveOkMessage
