'use strict'
const assert = require('node:assert/strict')
const { spawnSync } = require('node:child_process')
const Config = require('../Utils/Config')
assert.equal(Config.GetValue().Store.Enabled, false, 'Use scripts/test_battles.js: disposable database required')
const DataBase = require('../Database/DatabaseManager')
const Device = require('../Logic/Device')
const { Players } = require('../Logic/Player')
const { BattleInstanceService } = require('../Logic/BattleInstances')
const { BattleEndData, BattleParticipant } = require('../Logic/BattleEnd')
const { ResultOutbox } = require('../Logic/Battle/ResultOutbox')
const { BattleCoordinator } = require('../Logic/Battle/BattleCoordinator')
const { EventEmitter } = require('node:events')
function reload (token) {
  const player = new Players(new Device({ write () {} }))
  player.token = token; assert.notEqual(DataBase.loadAccount({ player }), false)
  return player
}
if (process.argv[2] === '--recover') {
  const player = reload(process.argv[3])
  assert(ResultOutbox.restore(player), 'Recovery must load the result journal in a new process')
  assert.equal(player.trophies, 6, 'Interrupted settlement must complete after restart')
  assert.equal(player.pendingBattleResultSent, undefined)
  console.log('RECOVERED'); process.exit(0)
}
const token = 'outbox-regression-' + Date.now()
const player = new Players(new Device({ write () {} }))
Object.assign(player, { low_id: 950001, token, name: 'Outbox', tutorial: 2, trophies: 0, highest_trophies: 0,
  brawlers_trophies: { 0: 0 }, brawlers_trophies_in_rank: { 0: 0 }, player_experience: 0,
  battle_tokens: 200, tokensdoubler: 0, brawl_boxes: 0, big_boxes: 0 })
DataBase.createAccount({ player })
DataBase.replaceValues({ player }, { trophies: 0, highest_trophies: 0, brawlersTrophies: { 0: 0 }, brawlersTrophiesForRank: { 0: 0 }, playerExp: 0, battleTokens: 200, tokensdoubler: 0, brawlBoxes: 0, bigBoxes: 0 })
BattleInstanceService.begin(player)
const hash = require('node:crypto').createHash('sha256').update(token).digest('hex')
const id = BattleInstanceService.resolve_result(player, hash, 0)
const participants = Array.from({ length: 6 }, (_, i) => new BattleParticipant({ brawlerId: 0, skinId: 0, team: i < 3 ? 0 : 1, isPlayer: i === 0, name: 'P' + i, lowId: i === 0 ? player.low_id : 0, highId: 0, powerLevel: 1 }))
const data = new BattleEndData({ battleResult: 0, submittedResult: 0, rank: 1, mapSlot: 0, mapId: 7, gameMode: 0, locationGameMode: 'CoinRush', participants, battleId: hash, localIndex: 0 })
ResultOutbox.save(player, data, id)
// Simulate a process dying after the durable outcome, before any rewards/send.
const child = spawnSync(process.execPath, [__filename, '--recover', token], { encoding: 'utf8' })
assert.equal(child.status, 0, child.stdout + child.stderr)
const fresh = reload(token); ResultOutbox.restore(fresh)
const progression = [fresh.trophies, fresh.player_experience, fresh.brawl_boxes]
assert.throws(() => ResultOutbox.send(fresh, { write () { throw new Error('socket write failed') } }), /socket write failed/)
assert.equal(ResultOutbox.acknowledge(fresh), false, 'Failed delivery cannot clear the durable result')
assert.deepEqual([fresh.trophies, fresh.player_experience, fresh.brawl_boxes], progression, 'Failed send cannot duplicate rewards')
const writes = []
assert(ResultOutbox.send(fresh, { write (buffer) { writes.push(buffer); return true } }))
assert.equal(writes[0].readUInt16BE(), 23456)
ResultOutbox.send(fresh, { write () { return true } })
assert.deepEqual([fresh.trophies, fresh.player_experience, fresh.brawl_boxes], progression)
const transport = new EventEmitter(); const coordinator = new BattleCoordinator(transport); clearInterval(coordinator.timer)
try {
  const queued = coordinator.enqueue([{ player: fresh, client: { write () { return true } } }], 7)
  assert.equal(queued, null, 'Pending result is replayed before another battle can replace its ledger')
  assert.equal(coordinator.matchmaker.players.size, 0)
} finally { coordinator.close() }
assert(ResultOutbox.acknowledge(fresh))
assert.equal(ResultOutbox.restore(reload(token)), null, 'Acknowledged results must not reappear on next login')
console.log('RESULT OUTBOX OK: process restart, interrupted settlement, failed send, idempotent replay, queue protection and home acknowledgment')
