'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const records = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'hero-world-vectors.json')))
const assets = new BattleAssets()
assert.equal(records.length, assets.heroes.length * 2)
const seen = new Set()
let frames = 0
for (const record of records) {
  assert.equal(record.error, undefined, JSON.stringify(record.error))
  const hero = assets.named('characters', record.hero)
  assert(assets.heroes.includes(hero))
  assert(record.slot === 0 || record.slot === 1)
  const key = `${record.hero}:${record.slot}`
  assert(!seen.has(key)); seen.add(key)
  assert.equal(record.skill, hero[record.slot ? 'UltimateSkill' : 'WeaponSkill'])
  const skill = assets.named('skills', record.skill)
  assert.equal(record.frames.length, 40)
  for (const [i, frame] of record.frames.entries()) {
    assert.equal(frame.tick, 150 + i)
    assert.equal(frame.hp, Number(hero.Hitpoints), key)
    assert(frame.objects >= 1, key)
    assert(frame.ammo >= 0 && frame.ammo <= 3000, key)
    frames++
  }
  if (skill.BehaviorType === 'Attack') assert(record.frames.some(frame => frame.objects > 1), `${key}: no attack object created`)
  if (skill.BehaviorType === 'Charge') assert(record.frames.some(frame => frame.x !== 2550 || frame.y !== 3450), `${key}: no charge movement`)
  if (skill.BehaviorType === 'Invisibility') assert(record.frames.at(-1).activeMs > 0, `${key}: expected active invisibility timer`)
  if (!record.slot) assert(record.frames.some(frame => frame.ammo < 3000), `${key}: ammo was not consumed`)
}
console.log(`Original hero + object-manager updates: ${records.length} skills, ${frames} frames; attack creation, charge motion, invisibility timer and primary ammo verified in controlled world`)
