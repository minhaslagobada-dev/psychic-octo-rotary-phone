'use strict'

const { RewardError } = require('../../../Logic/Rewards')
const ShopService = require('../../../Logic/ShopService')
const { ValueError } = require('../../../Utils/Errors')

class LogicClearShopTickersCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    reader.read_Vint()
    reader.read_Vint()
    reader.read_Vint()
  }

  static process (reader) {
    try {
      return ShopService.clear_tickers(reader.player)
    } catch (error) {
      if (error instanceof RewardError || error instanceof TypeError || error instanceof ValueError) {
        return String(error.message)
      }
      throw error
    }
  }
}

module.exports = LogicClearShopTickersCommand
