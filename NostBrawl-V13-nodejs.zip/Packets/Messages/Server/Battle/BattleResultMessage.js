'use strict'
const { apply_battle_result_rewards } = require('../../../../Logic/BattleResultAdapter')
const { encode_battle_result } = require('../../../../Logic/BattleResultPayload')
const Writer = require('../../../../Utils/Writer')

class BattleResultMessage extends Writer {
  static get GAME_MODE () { return 0 }

  constructor (client, player) {
    super(client)
    this.id = 23456
    this.version = 27
    this.player = player
    this.enable_native_v13()
  }

  _get_rewards (battleId) {
    if (battleId === null || battleId === undefined) {
      return apply_battle_result_rewards(this.player, this.constructor.GAME_MODE)
    }
    return apply_battle_result_rewards(this.player, this.constructor.GAME_MODE, battleId)
  }

  _encode_with_rewards (rewards) {
    this.rewards = rewards
    encode_battle_result(this, rewards, this.constructor.GAME_MODE)
  }

  encode () {
    const battleId = this.player.battle_end_id !== undefined ? this.player.battle_end_id : null
    const rewards = this._get_rewards(battleId)
    this._encode_with_rewards(rewards)
  }
}

module.exports = BattleResultMessage
