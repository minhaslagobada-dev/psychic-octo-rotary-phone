'use strict'

const crypto = require('crypto')

const LogicOfferBundle = require('../Entries/LogicOfferBundle')
const Cards = require('../Files/CsvLogic/Cards')
const Characters = require('../Files/CsvLogic/Characters')
const Skins = require('../Files/CsvLogic/Skins')
const Config = require('../Utils/Config')
const Random = require('../Utils/Random')
const BoxInventory = require('./BoxInventory')
const { apply_box_opening } = require('./BoxService')
const RewardDelivery = require('./RewardDelivery')
const { MAX_POWER_POINTS, RewardError, RewardTransaction } = require('./Rewards')
const ShopCatalog = require('./ShopCatalog')

function toInteger (value, defaultValue = 0) {
  try {
    const parsed = Number(value)
    if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
      return defaultValue
    }
    return Math.trunc(parsed)
  } catch (error) {
    return defaultValue
  }
}

function isoDay (date) {
  const year = date.getUTCFullYear()
  const month = String(date.getUTCMonth() + 1).padStart(2, '0')
  const day = String(date.getUTCDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

function localIsoDay (date) {
  const year = date.getFullYear()
  const month = String(date.getMonth() + 1).padStart(2, '0')
  const day = String(date.getDate()).padStart(2, '0')
  return `${year}-${month}-${day}`
}

class ShopService {
  static get STATE_KEY () { return 'shop' }
  static get STATE_VERSION () { return 7 }
  static get COMBINED_BOX_OFFERS () { return new Set(['gems_big_mega']) }
  static get MAX_DAILY_POWER_OFFERS () { return 5 }
  static get STAR_POWER_DAILY_CHANCE () { return 5 }
  static get STAR_POWER_PRICE () { return 2000 }
  static get WEEKEND_TICKET_AMOUNT () { return 2 }
  static get WEEKEND_TICKET_STATE_KEY () { return 'weekendTickets' }
  static get WEEKEND_TICKET_HISTORY () { return 16 }
  static get RETIRED_OFFER_KEYS () {
    return new Set([
      'coins', 'token_doubler', 'mega_box', 'resource_bundle',
      'box_bundle', 'daily_bundle'
    ])
  }

  static _timestamp (now = null) {
    return Math.trunc(now === null || now === undefined ? Date.now() / 1000 : now)
  }

  static _day (now) {
    return isoDay(new Date(now * 1000))
  }

  static _next_day (now) {
    const current = new Date(now * 1000)
    const following = Date.UTC(
      current.getUTCFullYear(), current.getUTCMonth(), current.getUTCDate() + 1
    )
    return Math.trunc(following / 1000)
  }

  static _weekend_key (now) {
    const current = new Date(now * 1000)
    const weekday = (current.getDay() + 6) % 7
    if (weekday < 5) {
      return null
    }
    const saturday = new Date(current.getTime())
    saturday.setDate(saturday.getDate() - (weekday - 5))
    return localIsoDay(saturday)
  }

  static sync_weekend_tickets (player, now = null) {
    now = ShopService._timestamp(now)
    const weekend = ShopService._weekend_key(now)
    if (weekend === null) {
      return false
    }
    let persistent
    try {
      persistent = toInteger(player.low_id, 0) > 0
    } catch (error) {
      persistent = false
    }
    const token = player.token
    if (
      !persistent ||
      typeof token !== 'string' ||
      !token ||
      token === 'None'
    ) {
      return false
    }
    const progression = player.progression || {}
    let stored = (
      typeof progression === 'object' && progression !== null && !Array.isArray(progression)
    )
      ? progression[ShopService.WEEKEND_TICKET_STATE_KEY] || {}
      : {}
    let claims = (typeof stored === 'object' && stored !== null && !Array.isArray(stored))
      ? stored.claims || {}
      : {}
    if (typeof claims !== 'object' || claims === null || Array.isArray(claims)) {
      claims = {}
    }
    claims = Object.fromEntries(
      Object.entries(claims)
        .filter(([, value]) => value === true)
        .map(([key]) => [String(key), true])
    )
    if (claims[weekend] === true) {
      return false
    }
    const retained = Object.keys(claims).sort().slice(-(ShopService.WEEKEND_TICKET_HISTORY - 1))
    claims = Object.fromEntries(retained.map((key) => [key, true]))
    claims[weekend] = true
    const transaction = new RewardTransaction(player)
    transaction.add_reward('tickets', ShopService.WEEKEND_TICKET_AMOUNT)
    transaction.set_progression_value(ShopService.WEEKEND_TICKET_STATE_KEY, {
      version: 1,
      claims
    })
    transaction.commit()
    return true
  }

  static _is_state (value) {
    return (
      typeof value === 'object' && value !== null && !Array.isArray(value) &&
      'version' in value &&
      'day' in value &&
      Array.isArray(value.offers) &&
      typeof value.billing === 'object' && value.billing !== null
    )
  }

  static _stored_state (player) {
    const progression = player.progression || {}
    if (typeof progression !== 'object' || progression === null || Array.isArray(progression)) {
      return {}
    }
    const state = progression[ShopService.STATE_KEY] || {}
    if (typeof state === 'object' && state !== null && !Array.isArray(state) && Object.keys(state).length) {
      return structuredClone(state)
    }
    const previous = Object.entries(progression)
      .filter(([key, value]) => key !== ShopService.STATE_KEY && ShopService._is_state(value))
      .map(([, value]) => value)
    if (previous.length === 1) {
      return structuredClone(previous[0])
    }
    return (typeof state === 'object' && state !== null && !Array.isArray(state))
      ? structuredClone(state)
      : {}
  }

  static _billing_state (state) {
    let billing = state.billing || {}
    if (typeof billing !== 'object' || billing === null || Array.isArray(billing)) {
      billing = {}
    }
    const transactions = billing.transactions || {}
    const bundles = billing.bundles || {}
    return {
      transactions: (typeof transactions === 'object' && transactions !== null && !Array.isArray(transactions))
        ? structuredClone(transactions)
        : {},
      bundles: (typeof bundles === 'object' && bundles !== null && !Array.isArray(bundles))
        ? structuredClone(bundles)
        : {}
    }
  }

  static _power_target (player, now, amount = 1) {
    const states = player.BrawlersUnlockedState || {}
    const points = player.brawlers_upgradium || {}
    const unlocked = Characters.get_brawlers_id().filter(
      (brawler) => ShopService._mapping_value(states, brawler) === 1
    )
    const eligible = unlocked.filter(
      (brawler) => ShopService._mapping_value(points, brawler) + amount <= MAX_POWER_POINTS
    )
    const candidates = eligible.length ? eligible : (unlocked.length ? unlocked : [0])
    const seed = `${toInteger(player.low_id, 0) || 0}:${ShopService._day(now)}:power`
    return candidates[crypto.createHash('sha256').update(seed).digest()[0] % candidates.length]
  }

  static _daily_offer (definition, expires, items, key = null) {
    return {
      key: key || definition.key,
      items: structuredClone(items),
      currency: definition.currency,
      price: definition.price,
      originalPrice: definition.originalPrice,
      display: definition.display,
      expiresAt: expires,
      seen: false,
      purchased: false,
      title: String(definition.title || ''),
      daily: !definition.display
    }
  }

  static _unlocked_brawlers (player) {
    const states = player.BrawlersUnlockedState || {}
    return Characters.get_brawlers_id().filter(
      (brawler) => ShopService._mapping_value(states, brawler) === 1
    )
  }

  static _daily_brawlers (player, now) {
    const unlocked = ShopService._unlocked_brawlers(player)
    const identity = `${player.low_id}:${ShopService._day(now)}:power`
    const ranked = unlocked.slice().sort((a, b) => {
      const digestA = crypto.createHash('sha256').update(`${identity}:${a}`).digest()
      const digestB = crypto.createHash('sha256').update(`${identity}:${b}`).digest()
      return Buffer.compare(digestA, digestB)
    })
    return ranked.slice(0, ShopService.MAX_DAILY_POWER_OFFERS)
  }

  static _eligible_star_power (player, now, brawler) {
    if (Cards.get_brawler_star_power(brawler) <= 0) {
      return false
    }
    const levels = player.Brawler_level || {}
    const powers = player.Brawler_starPower || {}
    if (ShopService._mapping_value(levels, brawler) !== 8) {
      return false
    }
    if (ShopService._mapping_value(powers, brawler) !== 0) {
      return false
    }
    const identity = `${player.low_id}:${ShopService._day(now)}:star-power:${brawler}`
    const digest = crypto.createHash('sha256').update(identity).digest()
    const roll = BigInt('0x' + digest.subarray(0, 8).toString('hex'))
    const threshold = ((1n << 64n) * BigInt(ShopService.STAR_POWER_DAILY_CHANCE)) / 100n
    return roll < threshold
  }

  static _offer_identity (offer) {
    const key = String(offer.key || '')
    let kind
    if (key === 'power_points') {
      kind = key
    } else if (key.startsWith('star_power')) {
      kind = 'star_power'
    } else {
      return [key, null]
    }
    const items = offer.items
    let target = null
    if (Array.isArray(items) && items.length === 1 && typeof items[0] === 'object' && items[0] !== null) {
      const rawTarget = items[0].target
      if (Array.isArray(rawTarget) && rawTarget.length === 2) {
        target = rawTarget[1]
      }
    }
    return [kind, target]
  }

  static _inherit_daily_flags (offers, previous, now) {
    if (previous.day !== ShopService._day(now)) {
      return
    }
    const previousOffers = previous.offers
    if (!Array.isArray(previousOffers)) {
      return
    }
    const identities = new Map()
    for (const offer of previousOffers) {
      if (typeof offer === 'object' && offer !== null) {
        const identity = JSON.stringify(ShopService._offer_identity(offer))
        if (!identities.has(identity)) {
          identities.set(identity, offer)
        }
      }
    }
    for (const offer of offers) {
      const old = identities.get(JSON.stringify(ShopService._offer_identity(offer)))
      if (old !== undefined && old !== null) {
        offer.purchased = old.purchased === true
        offer.seen = old.seen === true
      }
    }
  }

  static _claimed_state (state) {
    const claimed = state.claimed || {}
    const result = (typeof claimed === 'object' && claimed !== null && !Array.isArray(claimed))
      ? Object.fromEntries(
          Object.entries(claimed)
            .filter(([, value]) => value === true)
            .map(([key]) => [String(key), true])
        )
      : {}
    const offers = state.offers || []
    if (Array.isArray(offers)) {
      for (const offer of offers) {
        if (
          typeof offer === 'object' && offer !== null &&
          offer.oneTime === true &&
          offer.purchased === true
        ) {
          result[String(offer.key || '')] = true
        }
      }
    }
    return result
  }

  static _generate (player, now, previous = null) {
    const config = ShopCatalog.daily_definitions()
    const templates = Object.fromEntries(config.daily.map((definition) => [definition.key, definition]))
    const expires = ShopService._next_day(now)
    const free = templates.free_box
    const power = templates.power_points
    const offers = [ShopService._daily_offer(free, expires, free.items)]
    const starPowers = []
    for (const brawler of ShopService._daily_brawlers(player, now)) {
      const powerItems = structuredClone(power.items)
      powerItems[0].target = [16, brawler]
      offers.push(ShopService._daily_offer(power, expires, powerItems))
    }
    for (const brawler of ShopService._unlocked_brawlers(player)) {
      if (!ShopService._eligible_star_power(player, now, brawler)) {
        continue
      }
      const definition = {
        currency: 1,
        price: ShopService.STAR_POWER_PRICE,
        originalPrice: ShopService.STAR_POWER_PRICE,
        display: 0,
        title: ''
      }
      const starItems = [{
        offerId: 5,
        amount: 1,
        value: 0,
        target: [16, brawler]
      }]
      starPowers.push(ShopService._daily_offer(
        definition,
        expires,
        starItems,
        `star_power_${brawler}`
      ))
    }
    offers.push(...starPowers)
    const claimed = ShopService._claimed_state(previous || {})
    for (const definition of config.once || []) {
      if (claimed[definition.key]) {
        continue
      }
      const offer = ShopService._daily_offer(definition, expires, definition.items)
      offer.oneTime = true
      offers.push(offer)
    }
    if (typeof previous === 'object' && previous !== null) {
      ShopService._inherit_daily_flags(offers, previous, now)
    }
    return {
      version: ShopService.STATE_VERSION,
      day: ShopService._day(now),
      offers,
      claimed,
      billing: ShopService._billing_state(previous || {})
    }
  }

  static _migrate_state (player, state, now) {
    let offers = state.offers || []
    if (!Array.isArray(offers)) {
      return false
    }
    const retained = offers.filter(
      (offer) => typeof offer !== 'object' || offer === null ||
        !ShopService.RETIRED_OFFER_KEYS.has(offer.key)
    )
    let changed = retained.length !== offers.length
    offers = retained
    state.offers = offers
    for (const offer of offers) {
      if (typeof offer !== 'object' || offer === null) {
        continue
      }
      const items = offer.items || []
      if (!Array.isArray(items)) {
        continue
      }
      for (const item of items) {
        if (typeof item !== 'object' || item === null) {
          continue
        }
        try {
          if (toInteger(item.offerId, -1) === 0 && toInteger(item.value, 0) === 0) {
            item.value = 1
            changed = true
          }
        } catch (error) {
          continue
        }
      }
      if (offer.key === 'power_points') {
        let needsMigration
        try {
          const item = items[0]
          const target = item.target
          needsMigration = (
            items.length !== 1 ||
            toInteger(item.offerId, -1) !== 8 ||
            toInteger(item.value, -1) !== 0 ||
            !Array.isArray(target) ||
            target.length !== 2 ||
            toInteger(target[0]) !== 16
          )
        } catch (error) {
          needsMigration = true
        }
        if (needsMigration) {
          const definition = ShopCatalog.daily_definitions().daily.find(
            (candidate) => candidate.key === 'power_points'
          )
          for (const field of ['items', 'currency', 'price', 'originalPrice', 'display']) {
            offer[field] = structuredClone(definition[field])
          }
          offer.items[0].target = [16, ShopService._power_target(
            player, now, toInteger(offer.items[0].amount)
          )]
          changed = true
        }
      }
      const display = offer.display
      if (display === 0 || display === 1) {
        const daily = !display
        if (offer.daily !== daily) {
          offer.daily = daily
          changed = true
        }
      }
      for (const field of ['reroll', 'claim']) {
        if (field in offer) {
          delete offer[field]
          changed = true
        }
      }
    }
    return changed
  }

  static _valid_offer (offer) {
    if (typeof offer !== 'object' || offer === null) {
      return false
    }
    try {
      ShopCatalog.validate_definition(offer)
      if (toInteger(offer.expiresAt, 0) < 0) {
        return false
      }
    } catch (error) {
      return false
    }
    return true
  }

  static _append_stored_offers (player, state, now) {
    const offers = state.offers
    const storedTypes = [
      [11, 10, 'stored_mega_box'],
      [12, 14, 'stored_big_box']
    ]
    for (const [boxType, offerId, key] of storedTypes) {
      if (offers.some((offer) => offer.storedBox === boxType)) {
        continue
      }
      if (BoxInventory.count(player, boxType) < 1) {
        continue
      }
      offers.push({
        key,
        items: [{
          offerId,
          amount: 1,
          value: 0,
          target: null
        }],
        currency: 0,
        price: 0,
        originalPrice: 0,
        display: 0,
        expiresAt: ShopService._next_day(now),
        seen: false,
        purchased: false,
        title: '',
        daily: false,
        storedBox: boxType
      })
    }
  }

  static get_state (player, now = null) {
    now = ShopService._timestamp(now)
    ShopService.sync_weekend_tickets(player, now)
    const progression = player.progression || {}
    const canonical = (typeof progression === 'object' && progression !== null && !Array.isArray(progression))
      ? progression[ShopService.STATE_KEY]
      : null
    const hasPrevious = (
      typeof progression === 'object' && progression !== null && !Array.isArray(progression) &&
      Object.entries(progression).some(
        ([key, value]) => key !== ShopService.STATE_KEY && ShopService._is_state(value)
      )
    )
    const needsRelocation = (
      typeof canonical !== 'object' || canonical === null ||
      Array.isArray(canonical) || !Object.keys(canonical).length || hasPrevious
    )
    let state = ShopService._stored_state(player)
    const previous = structuredClone(state)
    const migrated = ShopService._migrate_state(player, state, now)
    let offers = state.offers || []
    const valid = (
      state.version === ShopService.STATE_VERSION &&
      state.day === ShopService._day(now) &&
      Array.isArray(offers) &&
      Boolean(offers.length) &&
      offers.every((offer) => ShopService._valid_offer(offer))
    )
    if (!valid) {
      state = ShopService._generate(player, now, previous)
      ShopService._save_state(player, state)
    } else {
      const active = offers.filter((offer) => toInteger(offer.expiresAt) > now)
      if (active.length !== offers.length) {
        state.offers = active
        if (!active.length) {
          state = ShopService._generate(player, now, state)
        }
        ShopService._save_state(player, state)
      } else if (migrated || needsRelocation) {
        ShopService._save_state(player, state)
      }
    }
    state.billing = ShopService._billing_state(state)
    ShopService._append_stored_offers(player, state, now)
    return state
  }

  static _save_state (player, state, transaction = null) {
    const ownsTransaction = transaction === null
    transaction = transaction || new RewardTransaction(player)
    for (const key of Object.keys(transaction.progression)) {
      if (key !== ShopService.STATE_KEY && ShopService._is_state(transaction.progression[key])) {
        delete transaction.progression[key]
      }
    }
    const persistentState = structuredClone(state)
    persistentState.offers = (persistentState.offers || []).filter(
      (offer) => !offer.storedBox
    )
    transaction.set_progression_value(ShopService.STATE_KEY, persistentState)
    if (ownsTransaction) {
      transaction.commit()
    }
    return state
  }

  static _diagnostic_offer (index, offer, now) {
    const price = toInteger(offer.price)
    const originalPrice = toInteger(offer.originalPrice !== undefined ? offer.originalPrice : price)
    return {
      index,
      key: offer.key || '',
      items: offer.items || [],
      currency: toInteger(offer.currency),
      cost: price,
      expiresAt: toInteger(offer.expiresAt),
      timer: Math.max(0, toInteger(offer.expiresAt) - toInteger(now)),
      newTag: offer.seen ? 1 : 0,
      percentage: 100,
      purchased: Boolean(offer.purchased),
      auxiliary: 0,
      daily: Boolean(offer.daily),
      originalCost: originalPrice > price ? originalPrice : 0,
      title: String(offer.title || '')
    }
  }

  static _log_home_offers (player, state, now) {
    if (!Config.GetValue().ShowPacketsInLog) {
      return
    }
    const offers = state.offers
    const account = toInteger(player.low_id, 0) || 0
    console.log(
      `Server | ShopState account=${account} day=${state.day || ''} ` +
      `now=${now} count=${offers.length}`
    )
    for (let index = 0; index < offers.length; index++) {
      const payload = ShopService._diagnostic_offer(index, offers[index], now)
      console.log(
        'Server | ShopOffer ' +
        JSON.stringify(payload)
      )
    }
  }

  static encode_home (writer, player, now = null) {
    now = ShopService._timestamp(now)
    const state = ShopService.get_state(player, now)
    const offers = state.offers
    ShopService._log_home_offers(player, state, now)
    writer.v(offers.length)
    for (const offer of offers) {
      LogicOfferBundle.encode(writer, offer, now)
    }
  }

  static clear_tickers (player, now = null) {
    const state = ShopService.get_state(player, now)
    let changed = false
    for (const offer of state.offers) {
      if (!offer.seen) {
        offer.seen = true
        changed = true
      }
    }
    if (changed) {
      ShopService._save_state(player, state)
    }
    return { cleared: changed, count: state.offers.length }
  }

  static _mapping_value (mapping, key, defaultValue = 0) {
    if (typeof mapping !== 'object' || mapping === null) {
      return defaultValue
    }
    try {
      const raw = mapping[String(key)] !== undefined ? mapping[String(key)] : mapping[key]
      return toInteger(raw, defaultValue) || 0
    } catch (error) {
      return defaultValue
    }
  }

  static _locked_by_rarity (player, rarity) {
    const states = player.BrawlersUnlockedState || {}
    const result = []
    for (const brawler of Characters.get_brawlers_id()) {
      if (ShopService._mapping_value(states, brawler) === 1) {
        continue
      }
      const card = Cards.get_brawler_unlock_by_character(brawler)
      if (Cards.get_brawler_rarity(card) === rarity) {
        result.push(brawler)
      }
    }
    return result
  }

  static _selected_brawler (item, selectedBrawler) {
    if (selectedBrawler) {
      return Math.trunc(selectedBrawler)
    }
    const target = item.target
    if (target && Math.trunc(target[0]) === 16) {
      return Math.trunc(target[1])
    }
    throw new RewardError('Selecione um brawler para essa oferta')
  }

  static _opened_box_result (details, boxType, boxCount, rewardUnits = null, initial = null) {
    const result = {
      boxID: boxType,
      boxType,
      boxCount,
      rewards: details.map((detail) => detail.amount),
      rewardNames: details.map((detail) => detail.name),
      rewardsTargetBrawler: details.map((detail) => detail.target !== undefined ? detail.target : 0),
      rewardDetails: structuredClone(details),
      trophyRoad: 0
    }
    if (rewardUnits !== null) {
      result.rewardUnits = rewardUnits
      result.unitCount = rewardUnits.length
    }
    if (initial !== null) {
      result.initial = Math.trunc(initial)
    }
    return result
  }

  static _combined_box_results (openedBoxes, extraDetails = null) {
    const details = []
    let rewardUnits = []
    let expectedUnits = 0
    for (const result of openedBoxes) {
      expectedUnits += Math.trunc(result.boxCount)
      details.push(...structuredClone(result.rewardDetails))
      let units = result.rewardUnits
      if (units === null || units === undefined) {
        if (Math.trunc(result.boxCount) !== 1) {
          throw new RewardError('Unidades da caixa ausentes')
        }
        units = [ShopService._opened_box_result(
          result.rewardDetails, result.boxType, 1
        )]
      }
      rewardUnits.push(...structuredClone(units))
    }
    extraDetails = structuredClone(extraDetails || [])
    if (extraDetails.length) {
      if (!rewardUnits.length) {
        throw new RewardError('Recompensa sem caixa para apresentação')
      }
      const first = rewardUnits[0]
      const firstDetails = extraDetails.concat(first.rewardDetails)
      rewardUnits[0] = ShopService._opened_box_result(
        firstDetails, first.boxType, 1
      )
      details.unshift(...extraDetails)
    }
    const detailCount = rewardUnits.reduce(
      (total, unit) => total + unit.rewardDetails.length, 0
    )
    if (
      rewardUnits.length !== expectedUnits ||
      detailCount !== details.length ||
      rewardUnits.some((unit) => Math.trunc(unit.boxCount) !== 1)
    ) {
      throw new RewardError('Unidades ou drops das caixas divergentes')
    }
    return ShopService._opened_box_result(
      details,
      openedBoxes[0].boxType,
      rewardUnits.length,
      rewardUnits,
      rewardUnits.length
    )
  }

  static _deliver_item (
    transaction, item, selectedBrawler, rng, openBox = false,
    allowUnlocked = false
  ) {
    item = ShopCatalog.validate_item(item)
    const offerId = item.offerId
    const amount = item.amount
    const value = item.value
    const target = item.target || [0, 0]
    const player = transaction.player
    const boxTypes = ShopCatalog.BOX_TYPES
    if (offerId === 0 || ((offerId in boxTypes) && openBox)) {
      const boxType = boxTypes[offerId]
      const start = transaction.reward_details.length
      const rewardUnits = []
      for (let index = 0; index < amount; index++) {
        const unitStart = transaction.reward_details.length
        apply_box_opening(transaction, boxType, rng, 1)
        const unitDetails = transaction.reward_details.slice(unitStart)
        rewardUnits.push(ShopService._opened_box_result(
          unitDetails, boxType, 1
        ))
      }
      const details = transaction.reward_details.slice(start)
      return {
        openedBox: ShopService._opened_box_result(
          details,
          boxType,
          amount,
          amount > 1 ? rewardUnits : null,
          amount > 1 ? amount : null
        )
      }
    }
    if (offerId in boxTypes) {
      const boxType = boxTypes[offerId]
      BoxInventory.add(transaction, boxType, item.amount)
      return { boxType, amount: item.amount }
    }
    let name
    let rewardAmount
    let rewardTarget
    if (offerId === 1) {
      ;[name, rewardAmount, rewardTarget] = ['Coins', amount, 0]
    } else if (offerId === 16) {
      ;[name, rewardAmount, rewardTarget] = ['gems', amount, 0]
    } else if (offerId === 7) {
      if (value !== 0) {
        throw new RewardError('Essa variante de ticket não pertence à loja')
      }
      ;[name, rewardAmount, rewardTarget] = ['tickets', amount, 0]
    } else if (offerId === 9) {
      ;[name, rewardAmount, rewardTarget] = ['tokens_doubler', amount, 0]
    } else if (offerId === 8) {
      if (Math.trunc(target[0]) !== 16) {
        throw new RewardError('Brawler dos power points inválido')
      }
      rewardTarget = Math.trunc(target[1])
      rewardAmount = amount
      name = 'UpgradePoints'
    } else if (offerId === 12) {
      rewardTarget = ShopService._selected_brawler(item, selectedBrawler)
      rewardAmount = amount
      name = 'UpgradePoints'
    } else if (offerId === 5) {
      if (Math.trunc(target[0]) !== 16) {
        throw new RewardError('Brawler da star power inválido')
      }
      rewardTarget = Math.trunc(target[1])
      const powers = player.Brawler_starPower || {}
      if (ShopService._mapping_value(powers, rewardTarget)) {
        throw new RewardError('Star power já desbloqueada')
      }
      rewardAmount = Cards.get_brawler_star_power(rewardTarget)
      name = 'StarPower'
    } else if (offerId === 3) {
      if (Math.trunc(target[0]) !== 16) {
        throw new RewardError('Brawler da oferta inválido')
      }
      rewardTarget = Math.trunc(target[1])
      const states = player.BrawlersUnlockedState || {}
      if (
        !allowUnlocked &&
        ShopService._mapping_value(states, rewardTarget) === 1
      ) {
        throw new RewardError('Brawler já desbloqueado')
      }
      name = 'Brawler'
      rewardAmount = rewardTarget
    } else if (offerId === 2) {
      const choices = ShopService._locked_by_rarity(player, value)
      if (!choices.length) {
        throw new RewardError('Nenhum brawler disponível nessa raridade')
      }
      name = 'Brawler'
      rewardAmount = rng.choice(choices)
      rewardTarget = 0
    } else if (offerId === 4) {
      const skin = Math.trunc(target[1] || value)
      if (![0, 29].includes(Math.trunc(target[0])) || !Skins.get_skins_id().includes(skin)) {
        throw new RewardError('Skin inválida')
      }
      const brawler = Skins.getBrawler(skin)
      const states = player.BrawlersUnlockedState || {}
      const unlocked = ShopService._mapping_value(states, brawler) === 1
      if (Skins.getIsDefaultSkin(skin)) {
        if (unlocked) {
          throw new RewardError('Brawler já desbloqueado')
        }
        name = 'Brawler'
        rewardAmount = brawler
        rewardTarget = 0
      } else {
        if (!unlocked) {
          throw new RewardError('A skin exige um brawler desbloqueado')
        }
        name = 'Skin'
        rewardAmount = skin
        rewardTarget = brawler
      }
    } else {
      throw new RewardError(`Oferta ${offerId} não suportada`)
    }
    const start = transaction.reward_details.length
    transaction.add_reward(name, rewardAmount, rewardTarget, true)
    const details = transaction.reward_details.slice(start)
    if (details.length !== 1 || details[0].amount !== rewardAmount) {
      throw new RewardError('Quantidade de recompensa divergente')
    }
    const display = RewardDelivery.display(details[0])
    if (offerId === 12) {
      display.type = 9
      display.brawler = rewardTarget
    }
    return {
      display,
      rewardDetail: structuredClone(details[0])
    }
  }

  static purchase (player, offerIndex, selectedBrawler = 0, now = null, rng = Random) {
    now = ShopService._timestamp(now)
    try {
      offerIndex = Math.trunc(offerIndex)
      selectedBrawler = Math.trunc(selectedBrawler || 0)
      if (Number.isNaN(offerIndex) || Number.isNaN(selectedBrawler)) {
        throw new TypeError()
      }
    } catch (error) {
      throw new RewardError('Oferta inválida')
    }
    const state = ShopService.get_state(player, now)
    if (!(offerIndex >= 0 && offerIndex < state.offers.length)) {
      throw new RewardError('Oferta inválida')
    }
    const offer = state.offers[offerIndex]
    if (toInteger(offer.expiresAt) <= now) {
      throw new RewardError('Oferta expirada')
    }
    if (offer.purchased) {
      throw new RewardError('Oferta já comprada')
    }
    if (offer.storedBox) {
      const storedBox = Math.trunc(offer.storedBox)
      if (![11, 12].includes(storedBox)) {
        throw new RewardError('Caixa armazenada inválida')
      }
      const transaction = new RewardTransaction(player)
      BoxInventory.consume(transaction, storedBox, 1)
      apply_box_opening(transaction, storedBox, rng)
      transaction.commit()
      const result = transaction.result(storedBox, storedBox)
      Object.assign(result, {
        offerIndex,
        offerKey: offer.key,
        boxCount: 1,
        price: 0,
        currency: null,
        storedBoxes: BoxInventory.count(player, storedBox),
        openingSource: 'storedOffer'
      })
      result.responses = [{ kind: 'box', result: Object.assign({}, result) }]
      return result
    }
    const transaction = new RewardTransaction(player)
    const currency = ShopCatalog.CURRENCIES[toInteger(offer.currency)]
    if (currency === undefined) {
      throw new RewardError('Moeda da oferta inválida')
    }
    const price = toInteger(offer.price)
    if (price) {
      transaction.charge(currency, price)
    }
    const rewards = []
    const offeredDetails = []
    const storedBoxes = []
    const openedBoxes = []
    const mixedBoxBundle = (
      offer.oneTime === true &&
      ShopService.COMBINED_BOX_OFFERS.has(offer.key)
    )
    for (const item of offer.items) {
      const deferBox = (
        offer.oneTime === true &&
        !mixedBoxBundle &&
        Boolean(openedBoxes.length) &&
        (item.offerId in ShopCatalog.BOX_TYPES)
      )
      const delivered = ShopService._deliver_item(
        transaction,
        item,
        selectedBrawler,
        rng,
        offer.oneTime === true && !deferBox,
        offer.key === 'the_big_three'
      )
      if ('openedBox' in delivered) {
        openedBoxes.push(delivered.openedBox)
      } else if ('boxType' in delivered) {
        storedBoxes.push(delivered)
      } else {
        rewards.push(delivered.display)
        if (mixedBoxBundle) {
          offeredDetails.push(delivered.rewardDetail)
        }
      }
    }
    let combinedBox = null
    if (mixedBoxBundle && openedBoxes.length) {
      combinedBox = ShopService._combined_box_results(
        openedBoxes, offeredDetails
      )
      if (!deepEqual(combinedBox.rewardDetails, transaction.reward_details)) {
        throw new RewardError('Recompensas da oferta divergentes')
      }
    }
    offer.purchased = true
    if (offer.oneTime === true) {
      const claimed = ShopService._claimed_state(state)
      claimed[String(offer.key)] = true
      state.claimed = claimed
    }
    ShopService._save_state(player, state, transaction)
    transaction.commit()
    const inventoryEmbedded = (
      offer.oneTime === true &&
      openedBoxes.length === 1 &&
      storedBoxes.length === 1
    )
    const responses = RewardDelivery.responses(
      combinedBox !== null ? [] : rewards,
      inventoryEmbedded ? [] : storedBoxes
    )
    if (combinedBox !== null) {
      responses.push({ kind: 'box', result: combinedBox })
    } else {
      for (const result of openedBoxes) {
        responses.push({ kind: 'box', result })
      }
    }
    return {
      offerIndex,
      offerKey: offer.key,
      price,
      currency,
      rewards,
      storedBoxes,
      openedBoxes,
      responses
    }
  }
}

function deepEqual (a, b) {
  if (a === b) {
    return true
  }
  if (typeof a !== 'object' || typeof b !== 'object' || a === null || b === null) {
    return false
  }
  if (Array.isArray(a) !== Array.isArray(b)) {
    return false
  }
  const keysA = Object.keys(a)
  const keysB = Object.keys(b)
  if (keysA.length !== keysB.length) {
    return false
  }
  return keysA.every((key) => key in b && deepEqual(a[key], b[key]))
}

module.exports = ShopService
