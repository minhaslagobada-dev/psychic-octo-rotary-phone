'use strict'

const { ClubService } = require('../../../../Logic/ClubService')
const Writer = require('../../../../Utils/Writer')

class AllianceSearchResultMessage extends Writer {
  constructor (client, player, requestedName, count, clubs = null) {
    super(client)
    this.id = 24310
    this.version = 11
    this.player = player
    this.requestedName = String(requestedName)
    this.count = count
    this.clubs = clubs
  }

  encode () {
    let clubs = this.clubs
    if (clubs === null || clubs === undefined) {
      clubs = ClubService.list_clubs(1, 100, 2, this.count, this.requestedName)
    }
    this.writeString(this.requestedName)
    this.writeVint(clubs.length)
    for (const club of clubs) {
      this.writeInt(0)
      this.writeInt(club.id)
      this.writeString(club.name)
      this.writeVint(8)
      this.writeVint(club.badge_id)
      this.writeVint(club.type)
      this.writeVint(club.member_count)
      this.writeVint(club.trophies)
      this.writeVint(club.required_trophies)
      this.writeVint(0)
      this.writeVint(club.online_count)
    }
  }
}

module.exports = AllianceSearchResultMessage
