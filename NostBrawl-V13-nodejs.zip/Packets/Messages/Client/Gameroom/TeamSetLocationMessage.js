'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamSetLocationMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.location = [0, -1]
    this.slot = 0
  }

  decode () {
    this.location = this.readScId()
    this.ensure_end()
  }

  process () {
    const [, mapId] = this.location
    const room = GameRoomService.set_location(this.player, mapId)
    if (room !== null) {
      GameRoomGateway.broadcast_data(this.player, room, this.client)
    }
    return room
  }
}

module.exports = TeamSetLocationMessage
