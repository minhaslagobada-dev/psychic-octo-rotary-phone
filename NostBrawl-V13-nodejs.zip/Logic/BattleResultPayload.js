'use strict'

const Skins = require('../Files/CsvLogic/Skins')
const { BattleParticipant } = require('./BattleEnd')
const { ValueError } = require('../Utils/Errors')

function _participants (player) {
  const battle = player.battle_end !== undefined ? player.battle_end : null
  if (battle !== null && battle.participants !== undefined && battle.participants !== null && battle.participants.length) {
    return [Array.from(battle.participants), battle.local_index]
  }
  const count = Math.trunc(player.players !== undefined ? player.players : 6) || 6
  if (!(count >= 1 && count <= 10)) {
    throw new ValueError('Invalid battle participant count')
  }
  const participants = [new BattleParticipant({
    brawlerId: Math.trunc(player.brawler_id || 0),
    skinId: Math.trunc(player.skin_id || 0),
    team: Math.trunc(player.team || 0),
    isPlayer: true,
    name: String(player.name !== undefined && player.name !== null ? player.name : '')
  })]
  for (let index = 1; index < count; index++) {
    participants.push(new BattleParticipant({
      brawlerId: Math.trunc(player[`bot${index}`] || 0),
      skinId: 0,
      team: Math.trunc(player[`bot${index}_team`] || 0),
      isPlayer: false,
      name: String(player[`bot${index}_n`] || '')
    }))
  }
  return [participants, 0]
}

function _data_reference (message, csvId, itemId) {
  if (!csvId) {
    message.writeVint(0)
  } else {
    message.writeScId(csvId, itemId)
  }
}

function encode_battle_result (message, rewards, gameMode) {
  const player = message.player
  const [participants, localIndex] = _participants(player)
  const local = participants[localIndex]
  const rewardData = rewards.rewards
  const tutorialState = Math.trunc(player.tutorial !== undefined ? player.tutorial : 2) || 0
  const tutorial = tutorialState === 1
  const isInRealGame = tutorialState === 2 && !(player.authoritativeBattleResult && player.authoritativeBattleResult.practice)
  const oldBattleTokens = Math.trunc(rewardData.old_battle_tokens || 0)
  const remainingBattleTokens = Math.trunc(rewardData.battle_tokens || 0)

  message.writeVint(gameMode)
  if ([2, 5].includes(gameMode)) {
    message.writeVint(Math.trunc(player.rank !== undefined ? player.rank : 1) || 0)
  } else {
    message.writeVint(Math.trunc(player.battle_result || 0))
  }
  message.writeVint(rewards.token)
  message.writeVint(rewards.gainedtrophies)
  message.writeVint(rewards.doubledtokens)
  message.writeVint(rewards.remainingtokens)
  message.writeVint(0)
  message.writeBoolean(Boolean(rewardData.hasStarKey))
  message.writeBoolean(oldBattleTokens <= 0)
  message.writeBoolean(remainingBattleTokens <= 0)
  message.writeBoolean(tutorial)
  message.writeBoolean(isInRealGame)
  message.writeBoolean(tutorial)
  message.writeVint(participants.length)

  const oldExperience = Math.trunc(
    rewardData.old_experience !== undefined
      ? rewardData.old_experience
      : Math.trunc(player.player_experience || 0) - rewards.experience - rewards.mvpexperience
  )
  for (let index = 0; index < participants.length; index++) {
    const participant = participants[index]
    const isLocal = index === localIndex
    const isPlayer = Boolean(participant.is_player)
    message.writeString(
      isLocal ? String(player.name !== undefined && player.name !== null ? player.name : '') : participant.name
    )
    // PlayerEntry +8 is the local-player marker, not "human account".
    // The account-presence flag below identifies other humans separately.
    message.writeBoolean(isLocal)
    message.writeBoolean(participant.team !== local.team)
    const nativeMvp = player.authoritativeBattleResult && player.authoritativeBattleResult.mvp_index
    message.writeBoolean(Number.isInteger(nativeMvp) ? index === nativeMvp : isLocal && Boolean(rewards.starplayer))
    _data_reference(message, 16, participant.brawler_id)
    const skinId = Skins.resolve_skin(participant.brawler_id, participant.skin_id)
    _data_reference(message, 29, skinId)
    message.writeVint(isLocal ? rewards.brawler_trophies : 0)
    let powerLevel
    if (isLocal) {
      const levels = player.Brawler_level || {}
      const stored = levels[String(participant.brawler_id)] !== undefined
        ? levels[String(participant.brawler_id)]
        : levels[participant.brawler_id]
      powerLevel = Math.trunc(stored || 0) + 1
    } else {
      powerLevel = participant.power_level === undefined ? 10 : participant.power_level
    }
    message.writeVint(powerLevel)
    message.writeBoolean(isPlayer)
    if (isPlayer) {
      message.writeInt(isLocal ? Math.trunc(player.high_id || 0) : Math.trunc(participant.high_id || 0))
      message.writeInt(isLocal ? Math.trunc(player.low_id || 0) : Math.trunc(participant.low_id || 0))
    }
  }

  const experience = rewardData.exp_rewards_array !== undefined
    ? rewardData.exp_rewards_array
    : { 0: rewards.experience, 8: rewards.mvpexperience }
  const entries = Object.entries(experience).sort(
    (a, b) => Math.trunc(a[0]) - Math.trunc(b[0])
  )
  message.writeVint(entries.length)
  for (const [rewardType, amount] of entries) {
    message.writeVint(Math.trunc(rewardType))
    message.writeVint(Math.trunc(amount))
  }
  message.writeVint(0)
  message.writeVint(2)
  message.writeVint(1)
  message.writeVint(rewards.brawler_trophies)
  message.writeVint(rewards.brawler_trophies_for_rank)
  message.writeVint(5)
  message.writeVint(oldExperience)
  message.writeVint(oldExperience)
  _data_reference(message, 28, Math.trunc(player.profile_icon || 0))
  message.writeBoolean(false)
}

module.exports = { encode_battle_result }
