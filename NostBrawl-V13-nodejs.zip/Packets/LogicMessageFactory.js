'use strict'

function lazy (path) {
  let cached = null
  let failed = false
  return function load () {
    if (failed) return undefined
    if (cached === null) {
      try {
        cached = require(path)
      } catch (error) {
        if (error && error.code === 'MODULE_NOT_FOUND' && String(error.message).includes(path)) {
          failed = true
          console.log(`Packets | Message not implemented yet: ${path}`)
          return undefined
        }
        throw error
      }
    }
    return cached
  }
}

const MESSAGE_LOADERS = {
  10100: lazy('./Messages/Client/Login/ClientHelloMessage'),
  10101: lazy('./Messages/Client/Login/LoginMessage'),
  10107: lazy('./Messages/Client/ClientCapabilities'),
  10108: lazy('./Messages/Client/KeepAliveMessage'),
  10110: lazy('./Messages/Client/AnalyticsEventMessage'),
  10113: lazy('./Messages/Client/SetDeviceToken'),
  10151: lazy('./Messages/Client/Billing/GoogleBillingRequestMessage'),
  10160: lazy('./Messages/Client/Billing/BuyBillingPackageMessage'),
  10177: lazy('./Messages/Client/Battle/ClientInfoMessage'),
  10212: lazy('./Messages/Client/SetNameMessage'),
  10501: lazy('./Messages/Client/Friend/AcceptFriendMessage'),
  10502: lazy('./Messages/Client/Friend/AddFriend'),
  10503: lazy('./Messages/Client/Friend/AskForAddableFriendsMessage'),
  10504: lazy('./Messages/Client/Friend/AskForFriendListMessage'),
  10506: lazy('./Messages/Client/Friend/RemoveFriendMessage'),
  10555: lazy('./Messages/Client/Battle/ClientInputMessage'),
  10599: lazy('./Messages/Client/Friend/AskForFriendSuggestionsMessage'),
  10636: lazy('./Messages/Client/SCID/SCIDBindAccountMessage'),
  14102: lazy('./LogicCommandManager'),
  14103: lazy('./Messages/Client/Battle/OnPlay'),
  14106: lazy('./Messages/Client/Battle/Cancel_Matchmaking'),
  14109: lazy('./Messages/Client/Home/GoHomeFromOfflinePractiseMessage'),
  14110: lazy('./Messages/Client/Battle/AskForBattleEndMessage'),
  14113: lazy('./Messages/Client/Home/AskProfileMessage'),
  14201: lazy('./Messages/Client/Friend/FacebookConnect'),
  14211: lazy('./Messages/Client/Friend/UnlinkFacebookAcount'),
  14301: lazy('./Messages/Client/Alliance/Create_Message'),
  14302: lazy('./Messages/Client/Alliance/Ask_For_Alliance_Data_Message'),
  14303: lazy('./Messages/Client/Alliance/Ask_Joinable_Alliances_Message'),
  14305: lazy('./Messages/Client/Alliance/Join_Message'),
  14306: lazy('./Messages/Client/Alliance/Promote_Alliance_Member_Message'),
  14307: lazy('./Messages/Client/Alliance/Kick_Member_Message'),
  14308: lazy('./Messages/Client/Alliance/Leave_Message'),
  14315: lazy('./Messages/Client/Alliance/Alliance_Chat_Message'),
  14316: lazy('./Messages/Client/Alliance/Edit_Settings_Message'),
  14324: lazy('./Messages/Client/Alliance/Search_Message'),
  14330: lazy('./Messages/Client/Alliance/Send_Club_Mail_Message'),
  14350: lazy('./Messages/Client/Gameroom/TeamCreateMessage'),
  14351: lazy('./Messages/Client/Gameroom/TeamJoinMessage'),
  14352: lazy('./Messages/Client/Gameroom/TeamKickMessage'),
  14353: lazy('./Messages/Client/Gameroom/TeamLeaveMessage'),
  14354: lazy('./Messages/Client/Gameroom/TeamChangeMemberSettingsMessage'),
  14355: lazy('./Messages/Client/Gameroom/TeamSetMemberReadyMessage'),
  14356: lazy('./Messages/Client/Gameroom/TeamTogglePractiseMessage'),
  14357: lazy('./Messages/Client/Gameroom/TeamToggleMemberSideMessage'),
  14358: lazy('./Messages/Client/Gameroom/TeamSpectateMessage'),
  14359: lazy('./Messages/Client/Gameroom/TeamChatMessage'),
  14360: lazy('./Messages/Client/Gameroom/TeamPostAdMessage'),
  14361: lazy('./Messages/Client/Gameroom/TeamMemberStatusMessage'),
  14362: lazy('./Messages/Client/Gameroom/TeamSetRankedLocationMessage'),
  14363: lazy('./Messages/Client/Gameroom/TeamSetLocationMessage'),
  14365: lazy('./Messages/Client/Gameroom/TeamInviteMessage'),
  14366: lazy('./Messages/Client/Home/PlayerStatusMessage'),
  14367: lazy('./Messages/Client/Gameroom/TeamClearInviteMessage'),
  14368: lazy('./Messages/Client/Gameroom/TeamInviteResponseMessage'),
  14370: lazy('./Messages/Client/Gameroom/TeamInviteMessage'),
  14371: lazy('./Messages/Client/Gameroom/TeamJoinOrCreateRoomMessage'),
  14403: lazy('./Messages/Client/Home/GetLeaderboardMessage'),
  14479: lazy('./Messages/Client/Gameroom/TeamInvitationResponseMessage'),
  14600: lazy('./Messages/Client/Home/AvatarNameCheckRequestMessage'),
  14777: lazy('./Messages/Client/Gameroom/SetInvitesBlockedMessage'),
  14880: lazy('./Messages/Client/Gameroom/TeamJoinRequestCancelMessage'),
  14881: lazy('./Messages/Client/Gameroom/TeamRequestJoinMessage'),
  14882: lazy('./Messages/Client/Gameroom/TeamJoinRequestResponseMessage')
}

const packets = {
  get (packetId) {
    const loader = MESSAGE_LOADERS[packetId]
    return loader ? loader() : undefined
  }
}

module.exports = packets
