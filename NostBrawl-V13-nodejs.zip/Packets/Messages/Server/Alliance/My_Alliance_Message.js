'use strict'

const ClubService = require('../../../../Logic/ClubService').ClubService
const Writer = require('../../../../Utils/Writer')

class MyAllianceMessage extends Writer {
  constructor (client, player, LowID) {
    super(client)
    this.id = 24399
    this.version = 11
    this.player = player
    this.clubid = LowID
  }

  encode () {
    const [club, role] = ClubService.get_own_club(this.player)
    if (club === null || club === undefined) {
      this.writeVint(0)
      this.writeVint(0)
      return
    }
    this.writeVint(club.online_count)
    this.writeVint(1)
    this.writeVint(25)
    this.writeVint(role)
    this.writeInt(0)
    this.writeInt(club.id)
    this.writeString(club.name)
    this.writeVint(8)
    this.writeVint(club.badge_id)
    this.writeVint(club.type)
    this.writeVint(club.member_count)
    this.writeVint(club.trophies)
    this.writeVint(club.required_trophies)
    this.writeVint(0)
    this.writeVint(club.online_count)
  }
}

module.exports = MyAllianceMessage
