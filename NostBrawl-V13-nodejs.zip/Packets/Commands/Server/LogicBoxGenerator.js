'use strict'

const Cards = require('../../../Files/CsvLogic/Cards')
const Characters = require('../../../Files/CsvLogic/Characters')
const Skins = require('../../../Files/CsvLogic/Skins')
const Config = require('../../../Utils/Config')
const Random = require('../../../Utils/Random')

function toInteger (value) {
  if (typeof value === 'bigint') {
    return Number(value)
  }
  const parsed = Number(value)
  if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
    return null
  }
  return Math.trunc(parsed)
}

function mappingValue (mapping, key, defaultValue = 0) {
  if (typeof mapping !== 'object' || mapping === null) {
    return defaultValue
  }
  const raw = mapping[String(key)] !== undefined ? mapping[String(key)] : mapping[key]
  try {
    const value = toInteger(raw || 0)
    return value === null ? defaultValue : value
  } catch (error) {
    return defaultValue
  }
}

class LogicBoxGenerator {
  static get BRAWLER_POOLS () {
    return {
      common: [0, 1, 2, 3, 7, 8, 9, 14],
      rare: [6, 10, 13, 24],
      super_rare: [4, 18, 19, 25],
      epic: [15, 16, 20, 26],
      mega_epic: [11, 17, 21],
      legendary: [5, 12, 23]
    }
  }

  static get BRAWLER_CHANCES () {
    return [
      [10, 'legendary'],
      [25, 'mega_epic'],
      [70, 'epic'],
      [200, 'super_rare'],
      [400, 'rare']
    ]
  }

  static get SKIN_POOLS () {
    return {
      rare: [15, 27, 29, 94, 117],
      super_rare: [5, 11, 20, 25, 28, 45, 47, 56, 58, 61, 70, 88, 92, 93],
      epic: [26, 30, 44, 50, 57, 60, 64, 68, 69, 71, 72, 75, 79, 90, 91],
      legendary: [49],
      silver: [95, 97, 99, 101, 103, 105, 107, 109, 111, 113, 115],
      gold: [96, 98, 100, 102, 104, 106, 108, 110, 112, 114, 116]
    }
  }

  static get POINT_TARGETS () { return { 1: 2, 3: 3, 10: 5 } }

  static get REWARD_ORDER () {
    return [
      'Coins', 'UpgradePoints', 'Brawler', 'StarPower', 'Skin',
      'gems', 'tokens_doubler', 'tickets'
    ]
  }

  static get AGGREGATED () { return new Set(['Coins', 'gems', 'tokens_doubler', 'tickets']) }

  static _number (mapping, key, defaultValue = 0) {
    try {
      return mappingValue(mapping, key, defaultValue)
    } catch (error) {
      return defaultValue
    }
  }

  static _owned_skins (player) {
    let owned = player.UnlockedSkins
    if (typeof owned === 'object' && owned !== null && !Array.isArray(owned)) {
      owned = owned.Skins || []
    }
    if (!Array.isArray(owned) && !(owned instanceof Set)) {
      return new Set()
    }
    const result = new Set()
    for (const skin of owned) {
      try {
        const value = toInteger(skin)
        if (value !== null) {
          result.add(value)
        }
      } catch (error) {
        continue
      }
    }
    return result
  }

  static _brawler_pools (player, playable) {
    const states = player.BrawlersUnlockedState || {}
    playable = new Set(playable)
    const pools = {}
    for (const [rarity, pool] of Object.entries(LogicBoxGenerator.BRAWLER_POOLS)) {
      pools[rarity] = pool.filter(
        (brawler) => playable.has(brawler) && LogicBoxGenerator._number(states, brawler) !== 1
      )
    }
    return pools
  }

  static _point_targets (player, playable) {
    const states = player.BrawlersUnlockedState || {}
    const levels = player.Brawler_level || {}
    const points = player.brawlers_upgradium || {}
    return playable.filter(
      (brawler) =>
        LogicBoxGenerator._number(states, brawler) === 1 &&
        ![8, 9].includes(LogicBoxGenerator._number(levels, brawler, 0)) &&
        Math.max(0, LogicBoxGenerator._number(points, brawler)) <= 1500
    )
  }

  static _star_power_targets (player, playable) {
    const states = player.BrawlersUnlockedState || {}
    const levels = player.Brawler_level || {}
    const powers = player.Brawler_starPower || {}
    return playable.filter(
      (brawler) =>
        LogicBoxGenerator._number(states, brawler) === 1 &&
        LogicBoxGenerator._number(levels, brawler, 0) === 8 &&
        LogicBoxGenerator._number(powers, brawler) === 0 &&
        Cards.get_brawler_star_power(brawler) !== 0
    )
  }

  static _skin_pools (player, settings, playable) {
    const owned = LogicBoxGenerator._owned_skins(player)
    const states = player.BrawlersUnlockedState || {}
    const available = new Set(Skins.get_skins_id())
    const unique = settings.UniqueSkinsBox !== undefined ? settings.UniqueSkinsBox : true
    const pools = {}
    for (const [rarity, pool] of Object.entries(LogicBoxGenerator.SKIN_POOLS)) {
      if ((rarity === 'silver' || rarity === 'gold') && !unique) {
        pools[rarity] = []
        continue
      }
      const candidates = []
      for (const skin of pool) {
        if (!available.has(skin) || owned.has(skin)) {
          continue
        }
        const brawler = Skins.getBrawler(skin)
        if (!playable.includes(brawler) || LogicBoxGenerator._number(states, brawler) !== 1) {
          continue
        }
        if (rarity === 'gold' && !owned.has(skin - 1)) {
          continue
        }
        candidates.push(skin)
      }
      pools[rarity] = candidates
    }
    return pools
  }

  static _skin_rarity (roll) {
    if (roll <= 59) {
      return 'rare'
    }
    if (roll <= 84) {
      return 'super_rare'
    }
    if (roll <= 94) {
      return 'epic'
    }
    if (roll <= 97) {
      return 'legendary'
    }
    if (roll <= 99) {
      return 'silver'
    }
    return 'gold'
  }

  static _context (player, settings) {
    const playable = Characters.get_brawlers_id().slice()
    return {
      brawlers: LogicBoxGenerator._brawler_pools(player, playable),
      points: LogicBoxGenerator._point_targets(player, playable),
      starPowers: LogicBoxGenerator._star_power_targets(player, playable),
      skins: LogicBoxGenerator._skin_pools(player, settings, playable)
    }
  }

  static _generate_single (boxType, rng, settings, context) {
    const brawlerPools = context.brawlers
    const pointTargets = context.points
    const starPowerTargets = context.starPowers
    const skinPools = context.skins
    let gold = 0
    let cardPoints = 0
    const brawlers = []
    const starPowers = []
    const skins = []

    for (let index = 0; index < boxType; index++) {
      const brawlerRoll = rng.randint(1, 10000)
      const starPowerRoll = rng.randint(1, 1000)
      const skinRoll = rng.randint(1, 1000)
      const iterationGold = rng.randint(30, 60)
      const iterationCards = rng.randint(12, 26)
      gold += iterationGold
      cardPoints += iterationCards

      const replaceBaseReward = () => {
        gold = Math.max(0, gold - iterationGold)
        cardPoints = Math.max(0, cardPoints - iterationCards)
      }

      const brawlersBox = settings.BrawlersBox !== undefined ? settings.BrawlersBox : true
      if (brawlersBox) {
        for (const [threshold, rarity] of LogicBoxGenerator.BRAWLER_CHANCES) {
          if (brawlerRoll > threshold) {
            continue
          }
          const pool = brawlerPools[rarity]
          if (pool.length) {
            const brawler = rng.choice(pool)
            pool.splice(pool.indexOf(brawler), 1)
            brawlers.push(brawler)
            replaceBaseReward()
          }
          break
        }
      }

      if (starPowerRoll < 10 && starPowerTargets.length) {
        const target = rng.choice(starPowerTargets)
        starPowerTargets.splice(starPowerTargets.indexOf(target), 1)
        starPowers.push(target)
        replaceBaseReward()
      }

      const skinsBox = settings.SkinsBox !== undefined ? settings.SkinsBox : false
      if (skinsBox && skinRoll <= 20) {
        const rarity = LogicBoxGenerator._skin_rarity(rng.randint(1, 100))
        const pool = skinPools[rarity]
        if (pool.length) {
          const skin = rng.choice(pool)
          pool.splice(pool.indexOf(skin), 1)
          skins.push(skin)
          replaceBaseReward()
        }
      }
    }

    const rewards = []
    if (gold > 0) {
      rewards.push({ name: 'Coins', amount: gold, target: 0 })
    }

    const pointAmounts = []
    if (cardPoints > 0) {
      for (let index = 0; index < LogicBoxGenerator.POINT_TARGETS[boxType]; index++) {
        let amount
        if (index === 4) {
          amount = cardPoints
        } else if (cardPoints <= 20) {
          amount = rng.randint(5, 15)
        } else {
          amount = rng.randint(10, Math.floor(cardPoints / 2))
          cardPoints -= amount
        }
        if (amount > 0) {
          pointAmounts.push(amount)
        }
      }
    }
    pointAmounts.sort((a, b) => a - b)

    const targetCount = Math.min(
      pointTargets.length, LogicBoxGenerator.POINT_TARGETS[boxType], pointAmounts.length
    )
    const awardedPoints = []
    for (let index = 0; index < targetCount; index++) {
      const target = rng.choice(pointTargets)
      pointTargets.splice(pointTargets.indexOf(target), 1)
      awardedPoints.push([target, pointAmounts.shift()])
    }
    if (awardedPoints.length && targetCount < 5) {
      const extra = Math.floor(20 / awardedPoints.length)
      for (const pointReward of awardedPoints) {
        pointReward[1] += extra
      }
    }
    for (const [target, amount] of awardedPoints) {
      rewards.push({ name: 'UpgradePoints', amount, target })
    }

    for (const brawler of brawlers) {
      rewards.push({ name: 'Brawler', amount: brawler, target: 0 })
    }
    for (const target of starPowers) {
      rewards.push({
        name: 'StarPower',
        amount: Cards.get_brawler_star_power(target),
        target
      })
    }
    for (const skin of skins) {
      rewards.push({
        name: 'Skin',
        amount: skin,
        target: Skins.getBrawler(skin)
      })
    }

    const bonuses = { gems: 0, tokens_doubler: 0, tickets: 0 }
    for (let index = 0; index < boxType; index++) {
      if (rng.randint(1, 5) !== 1) {
        continue
      }
      const bonusRoll = rng.randint(1, 11)
      if (bonusRoll === 10) {
        bonuses.gems = rng.randint(3, 10)
      } else if (bonusRoll === 7) {
        bonuses.tokens_doubler = 200
      } else {
        bonuses.tickets = rng.choice([3, 5, 7, 10])
      }
    }
    for (const name of ['gems', 'tokens_doubler', 'tickets']) {
      if (bonuses[name] > 0) {
        rewards.push({ name, amount: bonuses[name], target: 0 })
      }
    }
    return rewards
  }

  static generate_rewards (player, boxType, boxCount = 1, rng = Random) {
    boxType = toInteger(boxType)
    boxCount = toInteger(boxCount)
    if (
      boxType === null || boxCount === null ||
      !(boxType in LogicBoxGenerator.POINT_TARGETS) || boxCount < 1
    ) {
      throw new Error('Tipo ou quantidade de caixa inválido')
    }

    const settings = Config.GetValue()
    const context = LogicBoxGenerator._context(player, settings)
    const grouped = {}
    for (const name of LogicBoxGenerator.REWARD_ORDER) {
      grouped[name] = []
    }
    for (let index = 0; index < boxCount; index++) {
      for (const reward of LogicBoxGenerator._generate_single(boxType, rng, settings, context)) {
        grouped[reward.name].push(reward)
      }
    }

    const rewards = []
    for (const name of LogicBoxGenerator.REWARD_ORDER) {
      const entries = grouped[name]
      if (!entries.length) {
        continue
      }
      if (LogicBoxGenerator.AGGREGATED.has(name)) {
        rewards.push({
          name,
          amount: entries.reduce((total, entry) => total + Math.trunc(entry.amount), 0),
          target: 0
        })
      } else {
        rewards.push(...entries)
      }
    }
    return rewards
  }
}

module.exports = LogicBoxGenerator
