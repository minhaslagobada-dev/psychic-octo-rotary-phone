'use strict'

const { ClubService } = require('../../../../Logic/ClubService')
const Writer = require('../../../../Utils/Writer')

class PlayerProfileMessage extends Writer {
  constructor (client, player, highId, lowId, players) {
    super(client)
    this.id = 24113
    this.version = 9
    this.player = player
    this.high_id = highId
    this.low_id = lowId
    this.players = players
  }

  encode () {
    for (const player of this.players) {
      if (this.low_id === player[4]) {
        const unlockedBrawlersList = []
        const unlockedBrawlers = player[33]
        for (const brawlerId of Object.keys(unlockedBrawlers)) {
          if (unlockedBrawlers[brawlerId] === 1) {
            unlockedBrawlersList.push(Math.trunc(Number(brawlerId)))
          }
        }
        this.UnlockedBrawlersList = unlockedBrawlersList

        this.writeVint(this.high_id)
        this.writeVint(this.low_id)
        this.writeString(player[2])
        this.writeVint(0)

        this.writeVint(unlockedBrawlersList.length)

        for (const brawlerId of unlockedBrawlersList) {
          const brawlerTrophies = player[28]
          const brawlerTrophiesForRank = player[29]
          const brawlerPowerLevel = player[31]
          const brawlerStarPower = player[32]
          this.writeScId(16, Math.trunc(brawlerId))
          this.writeVint(0)
          this.writeVint(brawlerTrophies[String(brawlerId)])
          this.writeVint(brawlerTrophiesForRank[String(brawlerId)])
          if (brawlerStarPower[String(brawlerId)] >= 1) {
            this.writeVint(2 + brawlerPowerLevel[String(brawlerId)])
          } else {
            this.writeVint(1 + brawlerPowerLevel[String(brawlerId)])
          }
        }

        this.writeVint(10)

        this.writeVint(1)
        this.writeVint(player[11])

        this.writeVint(2)
        this.writeVint(player[8])

        this.writeVint(3)
        this.writeVint(player[19])

        this.writeVint(4)
        this.writeVint(player[20])

        this.writeVint(5)
        this.writeVint(unlockedBrawlersList.length)

        this.writeVint(7)
        this.writeVint(28000000 + player[21])

        this.writeVint(8)
        this.writeVint(player[9])

        this.writeVint(9)
        this.writeVint(0)

        this.writeVint(10)
        this.writeVint(0)

        this.writeVint(11)
        this.writeVint(player[10])

        const club = player[6] ? ClubService.get_club(player[6]) : null
        if (club !== null) {
          this.writeBoolean(true)
          this.writeInt(0)
          this.writeInt(club.id)
          this.writeString(club.name)
          this.writeVint(8)
          this.writeVint(club.badge_id)
          this.writeVint(club.type)
          this.writeVint(club.member_count)
          this.writeVint(club.trophies)
          this.writeVint(club.required_trophies)
          this.writeVint(0)
          this.writeVint(club.online_count)
          this.writeVint(25)
          this.writeVint(player[7])
        } else {
          this.writeVint(0)
          this.writeVint(0)
        }
      }
    }
  }
}

module.exports = PlayerProfileMessage
