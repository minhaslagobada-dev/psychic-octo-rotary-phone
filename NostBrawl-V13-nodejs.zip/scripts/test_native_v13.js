'use strict'
const fs = require('node:fs')
const path = require('node:path')
const os = require('node:os')
const { spawnSync } = require('node:child_process')
if (!process.env.LIBG_V13) throw new Error('Set LIBG_V13 to the supplied ARM64 v13 libg.so; run npm install (and optionally npm run setup:native) first')
const directory = fs.mkdtempSync(path.join(os.tmpdir(), 'v13-native-proof-'))
const env = { ...process.env, V13_VECTOR_DIR: directory }
try {
  for (const name of ['char', 'object', 'header', 'loading', 'command', 'world']) {
    const generated = spawnSync(process.execPath, [path.join(__dirname, 'native_v13', `make_${name}_vectors.js`)], { env, stdio: 'inherit' })
    if (generated.status !== 0) throw new Error('Failed to generate ' + name)
    const test = name === 'char' ? 'validate_char_native.js' : name === 'object' ? 'validate_objects_native.js' : name === 'header' ? 'validate_header_native.js' : name === 'loading' ? 'validate_loading_native.js' : name === 'command' ? 'validate_command_native.js' : 'validate_world_native.js'
    const result = spawnSync(process.execPath, [path.join(__dirname, 'native_v13', test)], { env, stdio: 'inherit', timeout: name === 'world' ? 300000 : 120000 })
    if (result.error) throw result.error
    if (result.status !== 0) throw new Error('Native v13 validation failed: ' + name)
  }
} finally { fs.rmSync(directory, { recursive: true, force: true }) }
