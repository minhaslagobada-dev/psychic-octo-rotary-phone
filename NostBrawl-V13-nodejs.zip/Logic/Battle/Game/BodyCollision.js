'use strict'
const blocks = new Set(['LootBox', 'Pvp_Base'])
module.exports = {
  moveBody (char, targetX, targetY) {
    let { x, y } = char; let dx = targetX - x; let dy = targetY - y
    if (!this.map.canOccupy(x, y, char.radius)) return { x, y }
    for (let pass = 0; pass < 4 && dx * dx + dy * dy > 1e-8; pass++) {
      let hit = this.map.trace(x, y, x + dx, y + dy, char.radius)
      for (const body of this.objects.values()) {
        if (body === char || body.dataClass !== 16 || body.hp <= 0 || !blocks.has(this.assets.tables.characters[body.dataId].Type)) continue
        const radius = char.radius + body.radius; const ox = x - body.x; const oy = y - body.y
        const a = dx * dx + dy * dy; const b = ox * dx + oy * dy
        const disc = b * b - a * (ox * ox + oy * oy - radius * radius)
        if (disc < 0 || b >= 0) continue
        const t = Math.max(0, (-b - Math.sqrt(disc)) / a)
        if (t > 1 || (hit && t >= hit.t)) continue
        const distance = Math.hypot(ox + dx * t, oy + dy * t) || 1
        hit = { t, nx: (ox + dx * t) / distance, ny: (oy + dy * t) / distance }
      }
      if (!hit) { x += dx; y += dy; break }
      const t = Math.max(0, hit.t - 0.001 / Math.max(1, Math.hypot(dx, dy)))
      x += dx * t; y += dy * t; dx *= 1 - t; dy *= 1 - t
      const normal = dx * hit.nx + dy * hit.ny
      if (normal < 0) { dx -= normal * hit.nx; dy -= normal * hit.ny }
    }
    return { x, y }
  }
}
