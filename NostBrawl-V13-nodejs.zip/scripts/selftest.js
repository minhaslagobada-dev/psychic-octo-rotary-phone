'use strict'
const net = require('net')
const crypto = require('crypto')
const path = require('path')

process.chdir(path.join(__dirname, '..'))

const { Server } = require('../main')

const SUFFIX = '00446f6e277420747279203a29'

function frame (id, payload) {
  const header = Buffer.alloc(7)
  header.writeUInt16BE(id, 0)
  header.writeUIntBE(payload.length, 2, 3)
  header.writeUInt16BE(0, 5)
  return Buffer.concat([header, payload])
}

async function main () {
  const server = new Server('127.0.0.1', 0)
  await server.start()
  const port = server.port
  console.log(`selftest: server listening on ${port}`)

  const helloPayload = Buffer.concat([
    Buffer.from([0, 0, 0, 1, 0, 0, 0, 1]),
    Buffer.from([0, 0, 0, 13]),
    Buffer.from([0, 0, 1, 27]),
    Buffer.from([0, 0, 0, 1]),
    Buffer.from([0, 0, 0, 3]), Buffer.from('sha'),
    Buffer.from([0, 0, 0, 0, 0, 0, 0, 0])
  ])

  const steps = new Promise((resolve, reject) => {
    const socket = net.connect(port, '127.0.0.1')
    let rx = Buffer.alloc(0)
    const timeout = setTimeout(() => reject(new Error('timeout waiting for server')), 10000)

    socket.on('connect', () => {
      socket.write(frame(10100, helloPayload))
    })

    socket.on('data', (chunk) => {
      rx = Buffer.concat([rx, chunk])
      while (rx.length >= 7) {
        const id = rx.readUInt16BE(0)
        const length = rx.readUIntBE(2, 3)
        if (rx.length < 7 + length) return
        const payload = rx.subarray(7, 7 + length)
        rx = rx.subarray(7 + length)

        if (id !== 20100) return reject(new Error(`unexpected packet ${id}`))
        if (payload.length !== 28) return reject(new Error(`expected 28-byte ServerHello, got ${payload.length}`))
        if (payload.readUInt32BE(0) !== 24) return reject(new Error('ServerHello length prefix mismatch'))
        if (payload.subarray(4 + 11, 4 + 24).toString('hex') !== SUFFIX) {
          return reject(new Error('ServerHello suffix mismatch'))
        }
        console.log('selftest: ServerHello (20100) ok; 11-byte random value + suffix')

        socket.write(frame(10101, crypto.randomBytes(100)))
      }
    })

    socket.on('close', (hadError) => {
      clearTimeout(timeout)
      resolve(hadError)
    })
    socket.on('error', () => {})
  })

  await steps
  console.log('selftest: invalid LoginMessage rejected and connection closed (crypto error path)')

  server.close()
  console.log('selftest: done')
  process.exit(0)
}

main().catch((error) => {
  console.error('selftest: FAILED', error)
  process.exit(1)
})
