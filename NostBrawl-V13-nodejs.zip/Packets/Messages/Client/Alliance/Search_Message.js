'use strict'
const { ClubService } = require('../../../../Logic/ClubService')
const AllianceSearchResultMessage = require('../../Server/Alliance/AllianceSearchResultMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class Search_Message extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.RequestedName = this.read_string()
    this.minMembers = this.read_int()
    this.maxMembers = this.read_int()
    this.clubType = this.read_int()
    this.maxListLength = this.read_int()
    this.onlyOnline = this.read_boolean()
    this.regionID = this.read_int()
    this.sortOrder = this.read_int()
  }

  process () {
    const clubs = ClubService.list_clubs(
      this.minMembers,
      this.maxMembers,
      this.clubType,
      this.maxListLength,
      this.RequestedName
    )
    new AllianceSearchResultMessage(
      this.client, this.player, this.RequestedName, clubs.length, clubs
    ).send()
    return clubs
  }
}

module.exports = Search_Message
