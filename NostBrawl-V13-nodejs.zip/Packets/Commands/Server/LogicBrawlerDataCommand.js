'use strict'

const LogicBuyItem = require('./LogicBuyItem')

class LogicBrawlerDataCommand extends LogicBuyItem {
  constructor (client, player, ID, state) {
    const trophyRoad = state === 1 ? player.trophy_road : 0
    super(
      client,
      player,
      [{ type: 6, amount: 1, brawler: Math.trunc(ID) }],
      trophyRoad
    )
  }
}

module.exports = LogicBrawlerDataCommand
