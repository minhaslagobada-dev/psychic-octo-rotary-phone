'use strict'
// Port of probe_aim.py.
// Original turning and active-skill selection, with real native skill readers.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/skills.csv')); t.initialize_schema(0x13da8c)
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const records = []
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row); const meta = t.alloc(0x200); p(meta + 8, t.rows[i])
    for (const [active, executing] of [[0, 0], [50, 0], [0, 1], [50, 1]]) {
      for (const target of [[3500, 5000], [3000, 4500], [1000, 4500], [5317, 8429]]) {
        const actor = t.alloc(0x400); w(actor + 0x30, 3000); w(actor + 0x34, 4500); w(actor + 0x48, 90); w(actor + 0x4c, 90)
        const skill = t.alloc(0x30); p(skill, meta); w(skill + 0xc, active); n.uc.mem_write(skill + 0x20, Buffer.from([executing]))
        const skills = t.alloc(8); p(skills, skill); p(actor + 0x130, skills); w(actor + 0x13c, 1)
        n.call(0x200010, actor, ...target)
        records.push({ definition: d, activeMs: active, executing, target, attackAngle: get(actor + 0x4c), moveAngle: get(actor + 0x48) })
      }
    }
  })
  R.writeJson('aim-vectors.json', records)
  R.print('Original aim and active-skill selection:', records.length, 'cases; no gameplay hooks')
})
