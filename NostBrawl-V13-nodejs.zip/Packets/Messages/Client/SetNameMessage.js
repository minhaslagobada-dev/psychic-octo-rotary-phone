'use strict'

const LogicChangeAvatarNameCommand = require('../../Commands/Server/LogicChangeAvatarNameCommand')
const AvatarNameChangeFailedMessage = require('../Server/Home/AvatarNameChangeFailedMessage')
const { BSMessageReader } = require('../../../Utils/Reader')

class SetNameMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.username = this.read_string()
    this.state = this.read_Vint()
  }

  process () {
    if (this.username !== '') {
      if (this.username.length >= 2 && this.username.length <= 20) {
        this.player.name = this.username
        new LogicChangeAvatarNameCommand(this.client, this.player, this.state).send()
      } else {
        new AvatarNameChangeFailedMessage(this.client, this.player).send()
      }
    } else {
      new AvatarNameChangeFailedMessage(this.client, this.player).send()
    }
  }
}

module.exports = SetNameMessage
