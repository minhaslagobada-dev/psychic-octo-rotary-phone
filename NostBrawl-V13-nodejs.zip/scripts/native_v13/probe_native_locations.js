'use strict'
// Port of probe_native_locations.py.
// Populate every non-tutorial location with the original engine, then tick it.
//
// Disabled rotation entries are included as data coverage, not enabled publicly.
// The actual constructed map grid is captured, including generated Robo maps.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeBattle } = require('./native_battle')
const { NativeTileMap } = require('./native_tile_map')
const { kindOf } = require('./lib/battle_probe')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create({ heap_bytes: 0x8000000, reclaim_memory: true, instruction_counting: false, timeout_us: 2000000 })
  n.decrypt(); const root = R.ROOT
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const records = []; R.outDir()
  const table = data.csv.get(15)
  for (const row of table.records) {
    const location = R.zipDict(table.names, row); const mode = location.GameMode
    if (!location.AllowedMaps || mode === 'Tutorial') continue
    const kind = kindOf(mode)
    const record = { location: location.Name, gameMode: mode, disabled: location.Disabled === 'true', map: location.AllowedMaps }; let battle = null
    try {
      battle = new NativeBattle(data, location.Name, kind); battle.add_player('ShotgunGirl', 0); battle.setup()
      const terrain = Object.create(NativeTileMap.prototype); terrain.data = data; terrain.pointer = data.ptr(battle.pointer + 0x70)
      record.terrain = terrain.describe(); record.initial = battle.describe()
      let vision
      for (let i = 0; i < 40; i++) vision = battle.frame()
      const state = battle.describe(); state.vision = vision; record.final = state
      R.assert(record.initial.objects.filter(obj => obj.dataId >= 16000000 && obj.dataId < 17000000).every(obj => obj.x >= 0 && obj.x < record.terrain.logicWidth && obj.y >= 0 && obj.y < record.terrain.logicHeight), 'Unplaced native character')
    } catch (error) { record.error = R.errorMessage(error) } finally {
      if (battle) {
        try { battle.close() } catch (error) { record.cleanupError = R.errorMessage(error) }
      }
    }
    records.push(record); R.writeJson('native-locations.json', records)
    R.print('Original location', location.Name, 'map', record.map, 'error', record.error ?? null)
  }
  R.assert(records.length && !records.some(record => 'error' in record || 'cleanupError' in record))
  R.print('Original populated locations:', records.length, 'with 40 complete frames each')
})
