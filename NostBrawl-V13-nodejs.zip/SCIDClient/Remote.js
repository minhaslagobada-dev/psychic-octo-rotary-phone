'use strict'

const { execFileSync } = require('child_process')

const { GAME_SESSIONS } = require('./GameSessions')
const {
  API_PREFIX,
  account_from_data,
  key_bytes,
  new_nonce,
  request_signature,
  response_signature,
  signatures_match
} = require('./Integration')
const { LocalGameAccounts, SCIDError } = require('./Models')

const LOGGER = {
  warning: (...args) => console.warn(...args)
}
const MAX_RESPONSE_SIZE = 1024 * 1024

function httpPostWithHeaders (url, body, headers, timeoutSeconds) {
  const args = [
    '-sS', '-i', '-X', 'POST', url,
    '--max-time', String(timeoutSeconds),
    '--data-binary', '@-'
  ]
  for (const [name, value] of Object.entries(headers)) {
    args.push('-H', `${name}: ${value}`)
  }
  let output
  try {
    output = execFileSync('curl', args, {
      input: body,
      maxBuffer: MAX_RESPONSE_SIZE + 64 * 1024 + 4096
    })
  } catch (error) {
    const unavailable = new SCIDError('scid_unavailable')
    unavailable.cause = error
    throw unavailable
  }
  const separator = output.indexOf('\r\n\r\n')
  if (separator < 0) {
    throw new SCIDError('scid_unavailable')
  }
  const head = output.subarray(0, separator).toString('latin1')
  const responseBody = output.subarray(separator + 4)
  const lines = head.split('\r\n')
  const statusMatch = /^HTTP\/\d(?:\.\d)?\s+(\d{3})/.exec(lines[0] || '')
  const status = statusMatch ? parseInt(statusMatch[1], 10) : 0
  const responseHeaders = {}
  for (const line of lines.slice(1)) {
    const colon = line.indexOf(':')
    if (colon > 0) {
      responseHeaders[line.slice(0, colon).trim().toLowerCase()] = line.slice(colon + 1).trim()
    }
  }
  return { status, headers: responseHeaders, body: responseBody }
}

class RemoteStore {
  constructor (service, settings) {
    this.service = service
    const databasePath = ((settings.Database || {}).Path !== undefined
      ? settings.Database.Path
      : 'Database/players.sqlite')
    this.local_games = new LocalGameAccounts(databasePath)
  }

  static _account (result) {
    try {
      return account_from_data(result ? result.account : undefined)
    } catch (error) {
      if (error instanceof SCIDError) {
        throw error
      }
      const wrapped = new SCIDError('scid_invalid_response')
      wrapped.cause = error
      throw wrapped
    }
  }

  by_id (accountId) {
    const result = this.service._request(
      'account-by-id', { account_id: Math.trunc(accountId) }
    )
    return RemoteStore._account(result)
  }

  by_game (lowId) {
    const result = this.service._request(
      'account-by-game', { low_id: Math.trunc(lowId) }
    )
    return RemoteStore._account(result)
  }

  game_account (lowId) {
    return this.local_games.game_account(lowId)
  }

  game_by_token (token, lowId = null) {
    return this.local_games.game_by_token(token, lowId)
  }
}

class RemoteTokenManager {
  constructor (service) {
    this.service = service
  }

  issue (account) {
    const result = this.service._request('issue', { account_id: Math.trunc(account.id) })
    const token = result.token
    if (typeof token !== 'string' || !token) {
      throw new SCIDError('scid_invalid_response')
    }
    return token
  }
}

class RemoteSCIDClient {
  constructor (settings, gameSessions = GAME_SESSIONS, clock = () => Date.now() / 1000) {
    this.is_remote = true
    this.settings = settings
    this.scid_settings = settings.SCID || {}
    this.clock = clock
    this.game_sessions = gameSessions
    this.base_url = RemoteSCIDClient._base_url(this.scid_settings.RemoteUrl)
    this.api_key = String(this.scid_settings.RemoteApiKey !== undefined ? this.scid_settings.RemoteApiKey : '')
    key_bytes(this.api_key)
    this.timeout = Number(this.scid_settings.RemoteTimeoutSeconds !== undefined ? this.scid_settings.RemoteTimeoutSeconds : 10)
    if (!(this.timeout >= 1 && this.timeout <= 60)) {
      throw new Error('SCID.RemoteTimeoutSeconds deve estar entre 1 e 60')
    }
    this.store = new RemoteStore(this, settings)
    this.tokens = new RemoteTokenManager(this)
  }

  static _base_url (value) {
    const base = String(value || '').trim().replace(/\/+$/, '')
    let parsed
    try {
      parsed = new URL(base)
    } catch (error) {
      throw new Error('SCID.RemoteUrl deve ser uma URL HTTP ou HTTPS válida')
    }
    if (
      !['http:', 'https:'].includes(parsed.protocol) ||
      !parsed.hostname ||
      parsed.username || parsed.password ||
      (parsed.search && parsed.search !== '') || (parsed.hash && parsed.hash !== '')
    ) {
      throw new Error('SCID.RemoteUrl deve ser uma URL HTTP ou HTTPS válida')
    }
    return base
  }

  _request (action, payload) {
    const path = `${API_PREFIX}/${action}`
    const body = Buffer.from(JSON.stringify(payload), 'utf-8')
    const timestamp = Math.trunc(this.clock())
    const nonce = new_nonce()
    const signature = request_signature(
      this.api_key, 'POST', path, timestamp, nonce, body
    )
    let response
    try {
      response = httpPostWithHeaders(
        this.base_url + path,
        body,
        {
          'Content-Type': 'application/json',
          'X-SCID-Timestamp': String(timestamp),
          'X-SCID-Nonce': nonce,
          'X-SCID-Signature': signature,
          'User-Agent': 'NostBrawl-R120-SCID-Integration'
        },
        this.timeout
      )
    } catch (error) {
      if (error instanceof SCIDError) {
        LOGGER.warning(`Remote SCID request ${action} failed: ${error.code}`)
        throw error
      }
      LOGGER.warning(`Remote SCID request ${action} failed: ${error.name}`)
      const wrapped = new SCIDError('scid_unavailable')
      wrapped.cause = error
      throw wrapped
    }
    if (response.status >= 400) {
      LOGGER.warning(
        `Remote SCID request ${action} rejected with HTTP ${response.status}`
      )
      throw new SCIDError('scid_integration_rejected')
    }
    const raw = response.body
    const responseNonce = response.headers['x-scid-nonce'] || ''
    const responseSignature = response.headers['x-scid-signature'] || ''

    if (raw.length > MAX_RESPONSE_SIZE) {
      throw new SCIDError('scid_invalid_response')
    }
    const expectedResponse = response_signature(this.api_key, nonce, raw)
    if (
      !signatures_match(nonce, responseNonce) ||
      !signatures_match(expectedResponse, responseSignature)
    ) {
      LOGGER.warning(`Remote SCID response ${action} has invalid authentication`)
      throw new SCIDError('scid_integration_rejected')
    }
    let result
    try {
      result = JSON.parse(raw.toString('utf-8'))
    } catch (error) {
      const wrapped = new SCIDError('scid_invalid_response')
      wrapped.cause = error
      throw wrapped
    }
    if (typeof result !== 'object' || result === null || typeof result.ok !== 'boolean') {
      throw new SCIDError('scid_invalid_response')
    }
    if (!result.ok) {
      const errorCode = result.error
      if (typeof errorCode !== 'string' || !errorCode) {
        throw new SCIDError('scid_invalid_response')
      }
      throw new SCIDError(errorCode)
    }
    return result
  }

  authenticate (token) {
    try {
      const result = this._request('authenticate', { token: token || '' })
      return RemoteStore._account(result)
    } catch (error) {
      if (error instanceof SCIDError && error.code === 'invalid_token') {
        return null
      }
      throw error
    }
  }

  link_game (account, lowId) {
    const result = this._request(
      'link', { account_id: Math.trunc(account.id), low_id: Math.trunc(lowId) }
    )
    const changed = result.changed
    if (typeof changed !== 'boolean') {
      throw new SCIDError('scid_invalid_response')
    }
    RemoteStore._account(result)
    if (changed) {
      this.game_sessions.notify_registration(lowId)
    }
    return changed
  }

  token_for_game (lowId) {
    const result = this._request('token-for-game', { low_id: Math.trunc(lowId) })
    const account = RemoteStore._account(result)
    const token = result.token
    if (account === null || account === undefined) {
      if (token !== null && token !== undefined) {
        throw new SCIDError('scid_invalid_response')
      }
      return [null, null]
    }
    if (typeof token !== 'string' || !token) {
      throw new SCIDError('scid_invalid_response')
    }
    return [account, token]
  }
}

module.exports = { RemoteSCIDClient, RemoteStore, RemoteTokenManager }
