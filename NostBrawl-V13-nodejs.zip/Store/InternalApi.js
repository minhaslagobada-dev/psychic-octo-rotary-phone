'use strict'

const http = require('http')

const Hmac = require('./Hmac')
const StoreCatalog = require('./StoreCatalog')
const { StoreError } = require('./StoreService')

// API interna do servidor de jogo — o "SCID da Lakey Store".
//
//   POST /internal/store/v1/intent    (app APK, sem HMAC — identidade provada
//                                      por token de billing OU IP da conexão)
//     -> { u, t, sku } => { ticket, url }
//   POST /internal/store/v1/deliver   (site remoto, HMAC X-Store-*)
//     -> { order_key, low_id, items } => entrega idempotente
//   GET  /internal/store/v1/health    (healthcheck)
//
// O ticket é empurrado ao site remoto (Site.PushUrl/Site.Key); no modo
// embedded o ticket fica no próprio banco e o site local consome.

class InternalApi {
  constructor (store) {
    this.store = store
    this.config = store.config
    this.server = http.createServer((req, res) => this._handle(req, res))
  }

  start () {
    const port = this.config.InternalPort
    return new Promise((resolve, reject) => {
      this.server.once('error', reject)
      this.server.listen(port, '0.0.0.0', () => resolve(port))
    })
  }

  stop () {
    try { this.server.close() } catch (error) { /* noop */ }
  }

  _json (res, status, payload) {
    const body = Buffer.from(JSON.stringify(payload), 'utf-8')
    res.writeHead(status, {
      'Content-Type': 'application/json; charset=utf-8',
      'Content-Length': body.length,
      'Cache-Control': 'no-store'
    })
    res.end(body)
  }

  _body (req) {
    return new Promise((resolve, reject) => {
      const chunks = []
      let size = 0
      req.on('data', (chunk) => {
        size += chunk.length
        if (size > 64 * 1024) {
          req.destroy()
          reject(new StoreError('payload grande demais'))
          return
        }
        chunks.push(chunk)
      })
      req.on('end', () => resolve(Buffer.concat(chunks)))
      req.on('error', reject)
    })
  }

  _authorized (req, pathname, raw) {
    const reason = Hmac.verify(
      this.config.InternalKey, req.method, pathname, req.headers, raw
    )
    return reason === null
  }

  async _route (req, res, pathname) {
    if (req.method === 'GET' && pathname === '/internal/store/v1/health') {
      this._json(res, 200, { ok: true, service: 'lakeystore-internal', ts: this.store.store.now() })
      return
    }
    if (req.method !== 'POST') {
      this._json(res, 404, { error: 'not found' })
      return
    }
    const raw = await this._body(req)

    if (pathname === '/internal/store/v1/intent') {
      const body = this._parse(raw)
      const result = this.store.createIntent(body, req.socket.remoteAddress || '')
      this._json(res, 200, result)
      return
    }

    if (!this.config.InternalKey) {
      this._json(res, 503, { error: 'internal_key_unset' })
      return
    }
    if (!this._authorized(req, pathname, raw)) {
      this._json(res, 401, { error: 'unauthorized' })
      return
    }

    if (pathname === '/internal/store/v1/deliver') {
      const body = this._parse(raw)
      const result = this.store.deliverRemote(body)
      this._json(res, 200, result)
      return
    }
    if (pathname === '/internal/store/v1/prices') {
      this._json(res, 200, {
        prices: StoreCatalog.list().map((offer) => ({
          sku: offer.sku,
          price: `$${(offer.priceCents / 100).toFixed(2)}`,
          micros: offer.priceCents * 10000,
          currency: 'USD'
        }))
      })
      return
    }
    this._json(res, 404, { error: 'not found' })
  }

  _parse (raw) {
    try {
      const parsed = JSON.parse(raw.toString('utf-8') || '{}')
      if (typeof parsed !== 'object' || parsed === null) {
        throw new Error('not object')
      }
      return parsed
    } catch (error) {
      throw new StoreError('JSON inválido')
    }
  }

  _handle (req, res) {
    let pathname
    try {
      pathname = new URL(req.url, 'http://internal.local').pathname
    } catch (error) {
      this._json(res, 400, { error: 'URL inválida' })
      return
    }
    this._route(req, res, pathname).catch((error) => {
      if (error instanceof StoreError) {
        this._json(res, 400, { error: error.message })
        return
      }
      console.error('Store | Erro na API interna:', error)
      this._json(res, 500, { error: 'internal_error' })
    })
  }
}

module.exports = InternalApi
