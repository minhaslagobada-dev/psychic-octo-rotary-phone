'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamJoinRequestCancelMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
  }

  decode () {
    this.ensure_end()
  }

  process () {
    const affected = GameRoomService.cancel_join_requests(this.player)
    for (const [room, requests] of affected) {
      const recipients = new Set(requests.map((request) => Math.trunc(request.recipient_id)))
      for (const recipientId of recipients) {
        GameRoomGateway.send_data_to(
          recipientId, this.player, room
        )
      }
    }
    return { cancelled: affected }
  }
}

module.exports = TeamJoinRequestCancelMessage
