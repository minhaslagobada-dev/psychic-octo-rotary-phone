'use strict'

const Random = require('../Utils/Random')
const Boxes = require('./Boxes')
const BoxInventory = require('./BoxInventory')
const { RewardError, RewardTransaction } = require('./Rewards')
const LogicBoxGenerator = require('../Packets/Commands/Server/LogicBoxGenerator')

const DIRECT_COSTS = {
  5: ['brawlBoxes', 100],
  4: ['bigBoxes', 10],
  3: ['gems', 80],
  1: ['gems', 30]
}

function generate_rewards (player, boxType, rng = Random, boxCount = 1) {
  boxType = Boxes.get_box_type(boxType)
  const generationType = Boxes.get_generation_type(boxType)
  return LogicBoxGenerator.generate_rewards(
    player, generationType, boxCount, rng
  )
}

function apply_box_opening (transaction, boxId, rng = Random, boxCount = 1) {
  const boxType = Boxes.get_box_type(boxId)
  const rewards = generate_rewards(
    transaction.generation_player(), boxType, rng, boxCount
  )
  transaction.add_rewards(rewards)
  return boxType
}

function open_boxes (player, boxId, count = 1, rng = Random) {
  try {
    boxId = Number.isInteger(boxId) ? boxId : Math.trunc(Number(boxId))
    count = Number.isInteger(count) ? count : Math.trunc(Number(count))
    if (Number.isNaN(boxId) || Number.isNaN(count)) {
      throw new TypeError()
    }
  } catch (error) {
    throw new RewardError('Caixa ou quantidade inválida')
  }
  if (!(boxId in DIRECT_COSTS) || count < 1) {
    throw new RewardError('Essa caixa não pode ser aberta diretamente')
  }

  const boxType = Boxes.get_box_type(boxId)
  const transaction = new RewardTransaction(player)
  const stored = [3, 4, 5].includes(boxId) ? BoxInventory.count(player, boxType) : 0
  const consumed = Math.min(stored, count)
  if (consumed) {
    BoxInventory.consume(transaction, boxType, consumed)
  }
  const remaining = count - consumed
  const [currency, price] = DIRECT_COSTS[boxId]
  if (remaining) {
    transaction.charge(currency, price * remaining)
  }
  let source
  if (consumed === count) {
    source = 'inventory'
  } else if (consumed) {
    source = 'mixed'
  } else {
    source = 'currency'
  }

  apply_box_opening(transaction, boxType, rng, count)
  transaction.commit()
  const result = transaction.result(boxType, boxType)
  result.boxCount = count
  result.openingSource = source
  result.storedBoxes = BoxInventory.count(player, boxType)
  return result
}

module.exports = { DIRECT_COSTS, generate_rewards, apply_box_opening, open_boxes }
