'use strict'

const { LogicCharacter } = require('./LogicCharacter')

class LogicGameObjectManager {
  encode (stream, participants = null) {
    stream.writePositiveInt(1000000 + 0, 21)
    stream.writePositiveVInt(0, 4)
    stream.writePositiveInt(20, 1)
    stream.writeInt(-1, 4)

    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(1, 1)
    stream.writePositiveInt(1, 1)
    stream.writePositiveInt(1, 1)

    stream.writePositiveInt(0, 5)
    stream.writePositiveInt(0, 6)
    stream.writePositiveInt(0, 5)
    stream.writePositiveInt(0, 6)

    stream.writePositiveInt(1, 1)
    stream.writePositiveInt(1, 1)
    stream.writePositiveInt(0, 1)
    stream.writeBoolean(true)

    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 12)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(0, 1)
    stream.writePositiveInt(1, 1)

    for (let index = 0; index < 6; index++) {
      stream.writePositiveInt(0, 1)
      stream.writePositiveInt(0, 1)
    }

    stream.writePositiveInt(0, 4)
    new LogicCharacter().encode.call(this, stream, participants)
  }
}

module.exports = { LogicGameObjectManager }
module.exports.default = LogicGameObjectManager
