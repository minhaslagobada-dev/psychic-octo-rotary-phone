'use strict'

const LogicBuySkinCommand = require('./LogicBuySkinCommand')

class LogicUnlockSkinCommand extends LogicBuySkinCommand {
}

module.exports = LogicUnlockSkinCommand
