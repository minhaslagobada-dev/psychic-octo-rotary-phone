'use strict'
const assert = require('node:assert/strict')
const { NativeBattleRuntime } = require('../Logic/Battle/NativeBattleRuntime')
const { encodeInput } = require('../Logic/Battle/Network/V13BattleCodec')
async function main () {
  const runtime = new NativeBattleRuntime()
  const failures = []; runtime.on('engineFailure', error => failures.push(error))
  const players = [{ hero: 'ShotgunGirl', team: 0, accountId: 1, name: 'Native IPC test', powerLevel: 1 }]
  try {
    await runtime.start()
    await assert.rejects(runtime.create('bad', 'Gemgrab1', 17, Array(4).fill(players[0])), /capacity/)
    const initial = await runtime.create('match', 'Gemgrab1', 17, players)
    assert.equal(initial.kind, 1)
    assert.equal(initial.state.players.length, 6)
    assert.equal(initial.state.players.filter(player => !player.bot).length, 1)
    const actor = initial.state.objects.find(object => object.id === initial.state.players[0].characterId)
    const x = actor.x; const y = actor.y
    assert.throws(() => runtime.input('match', 0, Buffer.from([128])), /Truncated/)
    await runtime.input('match', 0, encodeInput({ tick: 0, sequence: 1, inputs: [{ counter: 1, category: 1, code: 100, x: 3150, y: 6150 }] }))
    let latest
    for (let tick = 0; tick < 150; tick++) {
      latest = await runtime.frame('match')
      assert.equal(latest.state.tick, tick + 1)
      assert.equal(latest.vision[0].tick, tick)
      assert.equal(latest.vision[0].hex.length / 2, Math.ceil(latest.vision[0].bits / 8))
    }
    const moved = latest.state.objects.find(object => object.id === latest.state.players[0].characterId)
    assert(moved.x !== x || moved.y !== y)
    assert.equal(moved.x, 3150); assert.equal(moved.y, 6150)
    await runtime.destroy('match')
    await assert.rejects(runtime.frame('match'), /Unknown native match/)
    await runtime.create('reused', 'Gemgrab1', 18, players)
    await runtime.destroy('reused')
    assert.deepEqual(failures, [])
    console.log('Node IPC executes original constructors, bot fill, input decoding, movement, 150 vision frames, cleanup and match reuse')
  } finally { await runtime.close() }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
