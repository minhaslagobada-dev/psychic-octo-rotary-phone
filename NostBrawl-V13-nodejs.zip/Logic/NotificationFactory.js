'use strict'

const Skins = require('../Files/CsvLogic/Skins')
const Config = require('../Utils/Config')
const { ValueError } = require('../Utils/Errors')

function toInteger (value, defaultValue = 0) {
  try {
    const parsed = Number(value)
    if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
      return defaultValue
    }
    return Math.trunc(parsed)
  } catch (error) {
    return defaultValue
  }
}

class NotificationFactory {
  static get SKIN_REWARD_TYPE () { return 94 }
  static get SEASON_END_TYPE () { return 99 }
  static get SKIN_GLOBAL_ID () { return 29000000 }
  static get STAR_SHELLY_SKIN_ID () { return 52 }
  static get STAR_SHELLY_TEXT () {
    return 'You have unlocked a new skin! Thank you for playing Brawl Stars in 2018'
  }

  static get WIZARD_BARLEY_SKIN_ID () { return 59 }
  static get WIZARD_BARLEY_TEXT () {
    return 'You have unlocked a new skin! Thank you for registering your Supercell ID'
  }

  static get SEASON_UNKNOWN_BEFORE () { return [0, 9000] }
  static get SEASON_UNKNOWN_AFTER () { return [9000, 0] }
  static get SEASON_BOX_TYPES () { return [10, 11, 12] }

  static _integer (value, defaultValue = 0) {
    return toInteger(value, defaultValue)
  }

  static _nonnegative (value, defaultValue = 0) {
    return Math.max(0, toInteger(value, defaultValue))
  }

  static _type (notification) {
    return toInteger(
      notification.Type !== undefined
        ? notification.Type
        : (notification.ID !== undefined ? notification.ID : (notification.type !== undefined ? notification.type : 0))
    )
  }

  static _read (notification) {
    return Boolean(
      notification.Read !== undefined ? notification.Read : (notification.nrd !== undefined ? notification.nrd : false)
    )
  }

  static _ordered (notifications) {
    let values
    if (typeof notifications === 'object' && notifications !== null && !Array.isArray(notifications)) {
      const order = (key) => {
        const numeric = Number(key)
        if (!Number.isNaN(numeric) && Number.isFinite(numeric)) {
          return [0, Math.trunc(numeric), String(key)]
        }
        return [1, 0, String(key)]
      }
      const keys = Object.keys(notifications).sort((a, b) => {
        const ka = order(a)
        const kb = order(b)
        if (ka[0] !== kb[0]) return ka[0] - kb[0]
        if (ka[1] !== kb[1]) return ka[1] - kb[1]
        return ka[2] < kb[2] ? -1 : (ka[2] > kb[2] ? 1 : 0)
      })
      values = keys.map((key) => notifications[key])
    } else if (Array.isArray(notifications)) {
      values = notifications.slice()
    } else {
      return []
    }
    return values.filter(
      (value) => typeof value === 'object' && value !== null && !Array.isArray(value)
    )
  }

  static _skin_id (notification) {
    if ('SkinID' in notification) {
      return toInteger(notification.SkinID, -1)
    }
    let skinId = toInteger(notification.sd, -1)
    if (skinId >= NotificationFactory.SKIN_GLOBAL_ID) {
      skinId -= NotificationFactory.SKIN_GLOBAL_ID
    }
    return skinId
  }

  static _entries (notifications) {
    const entries = []
    for (const value of NotificationFactory._ordered(notifications)) {
      if (NotificationFactory._type(value) !== NotificationFactory.SKIN_REWARD_TYPE) {
        continue
      }
      const skinId = NotificationFactory._skin_id(value)
      if (skinId < 0) {
        continue
      }
      entries.push([value, skinId])
    }
    return entries
  }

  static has_scid_connection (player) {
    const account = player.scid_account !== undefined ? player.scid_account : null
    const lowId = toInteger(player.low_id !== undefined ? player.low_id : 0)
    return Boolean(
      account !== null &&
      lowId > 0 &&
      toInteger(account.game_low_id !== undefined ? account.game_low_id : 0) === lowId
    )
  }

  static _is_wizard_barley (notification) {
    return (
      NotificationFactory._type(notification) === NotificationFactory.SKIN_REWARD_TYPE &&
      NotificationFactory._skin_id(notification) === NotificationFactory.WIZARD_BARLEY_SKIN_ID
    )
  }

  static home_notifications (player) {
    const notifications = player.Notifications !== undefined ? player.Notifications : {}
    if (NotificationFactory.has_scid_connection(player)) {
      return notifications
    }
    if (typeof notifications === 'object' && notifications !== null && !Array.isArray(notifications)) {
      return Object.fromEntries(
        Object.entries(notifications).filter(
          ([, value]) =>
            !(typeof value === 'object' && value !== null && !Array.isArray(value)) ||
            !NotificationFactory._is_wizard_barley(value)
        )
      )
    }
    if (Array.isArray(notifications)) {
      return notifications.filter(
        (value) =>
          !(typeof value === 'object' && value !== null && !Array.isArray(value)) ||
          !NotificationFactory._is_wizard_barley(value)
      )
    }
    return notifications
  }

  static _season_block (notification, nestedName) {
    let nested = notification[nestedName] || {}
    if (typeof nested !== 'object' || nested === null || Array.isArray(nested)) {
      nested = {}
    }
    const legacyTrophies = {
      Best: ['bestBrawlerTrophies', 'BestBrawlerTrophies'],
      Total: ['totalTrophies', 'TotalTrophies']
    }[nestedName]
    const legacyPrefix = nestedName === 'Best' ? 'bestBrawler' : 'totalTrophies'
    const trophiesFallback = notification[legacyTrophies[0]] !== undefined
      ? notification[legacyTrophies[0]]
      : (notification[legacyTrophies[1]] !== undefined ? notification[legacyTrophies[1]] : 0)
    return {
      Trophies: NotificationFactory._nonnegative(
        nested.Trophies !== undefined ? nested.Trophies : trophiesFallback
      ),
      Points: NotificationFactory._nonnegative(
        nested.Points !== undefined ? nested.Points : (notification[legacyPrefix + 'Points'] !== undefined ? notification[legacyPrefix + 'Points'] : 0)
      ),
      Coins: NotificationFactory._nonnegative(
        nested.Coins !== undefined ? nested.Coins : (notification[legacyPrefix + 'Coins'] !== undefined ? notification[legacyPrefix + 'Coins'] : 0)
      ),
      Bonus: NotificationFactory._nonnegative(
        nested.Bonus !== undefined ? nested.Bonus : (notification[legacyPrefix + 'Bonus'] !== undefined ? notification[legacyPrefix + 'Bonus'] : 0)
      )
    }
  }

  static _season_details (notification) {
    return {
      Best: NotificationFactory._season_block(notification, 'Best'),
      Total: NotificationFactory._season_block(notification, 'Total'),
      BestBrawler: NotificationFactory._nonnegative(
        notification.BestBrawler !== undefined ? notification.BestBrawler : (notification.bestBrawler !== undefined ? notification.bestBrawler : 0)
      )
    }
  }

  static _season_boxes (notification) {
    let raw = notification.Boxes !== undefined ? notification.Boxes : (notification.boxes !== undefined ? notification.boxes : [])
    const entries = []
    if (typeof raw === 'object' && raw !== null && !Array.isArray(raw)) {
      raw = Object.entries(raw).map(([key, value]) => ({ Type: key, Count: value }))
    }
    if (!Array.isArray(raw)) {
      throw new ValueError('Caixas da notificação de temporada inválidas')
    }
    for (const entry of raw) {
      let boxType
      let count
      if (typeof entry === 'object' && entry !== null && !Array.isArray(entry)) {
        boxType = entry.Type !== undefined ? entry.Type : entry.boxType
        count = entry.Count !== undefined ? entry.Count : (entry.amount !== undefined ? entry.amount : 0)
      } else if (Array.isArray(entry) && entry.length === 2) {
        ;[boxType, count] = entry
      } else {
        throw new ValueError('Caixa da notificação de temporada inválida')
      }
      boxType = toInteger(boxType, -1)
      count = toInteger(count, -1)
      if (!NotificationFactory.SEASON_BOX_TYPES.includes(boxType) || count <= 0) {
        throw new ValueError('Caixa da notificação de temporada inválida')
      }
      entries.push({ Type: boxType, Count: count })
    }
    return entries
  }

  static encode_season (writer, notification) {
    const details = NotificationFactory._season_details(notification)
    let write = writer.v
    if (write === undefined || write === null) {
      write = writer.writeVint.bind(writer)
    } else {
      write = write.bind(writer)
    }
    for (const blockName of ['Best', 'Total']) {
      const block = details[blockName]
      for (const field of ['Trophies', 'Points', 'Coins', 'Bonus']) {
        write(block[field])
      }
    }
    for (const value of NotificationFactory.SEASON_UNKNOWN_BEFORE) {
      write(value)
    }
    write(16)
    write(details.BestBrawler)
    for (const value of NotificationFactory.SEASON_UNKNOWN_AFTER) {
      write(value)
    }
  }

  static encode (writer, notifications, now = null) {
    const settings = Config.GetValue()
    const hiddenSkins = new Set()
    if (settings.StarShelly !== undefined ? settings.StarShelly : false) {
      hiddenSkins.add(NotificationFactory.STAR_SHELLY_SKIN_ID)
    }
    if (settings.WizardBarley !== undefined ? settings.WizardBarley : false) {
      hiddenSkins.add(NotificationFactory.WIZARD_BARLEY_SKIN_ID)
    }

    const entries = []
    for (const notification of NotificationFactory._ordered(notifications)) {
      if (NotificationFactory._read(notification)) {
        continue
      }
      const notificationType = NotificationFactory._type(notification)
      if (notificationType === NotificationFactory.SKIN_REWARD_TYPE) {
        const skinId = NotificationFactory._skin_id(notification)
        if (skinId < 0 || hiddenSkins.has(skinId)) {
          continue
        }
        entries.push([notificationType, notification])
      } else if (notificationType === NotificationFactory.SEASON_END_TYPE) {
        entries.push([notificationType, notification])
      }
    }

    writer.v(entries.length)
    for (const [notificationType, notification] of entries) {
      writer.v(notificationType)
      if (notificationType === NotificationFactory.SKIN_REWARD_TYPE) {
        writer.v(NotificationFactory.SKIN_GLOBAL_ID + NotificationFactory._skin_id(notification))
      } else {
        NotificationFactory.encode_season(writer, notification)
      }
    }
  }

  static _prepare_notification (player, notificationType) {
    let current = player.Notifications !== undefined ? player.Notifications : {}
    if (typeof current !== 'object' || current === null || Array.isArray(current)) {
      current = {}
    }
    const notifications = structuredClone(current)
    const numericKeys = Object.keys(notifications).map((key) => toInteger(key, -1))
    const nextKey = String(Math.max(...numericKeys, -1) + 1)
    const indices = Object.values(notifications)
      .filter((value) => typeof value === 'object' && value !== null && !Array.isArray(value))
      .map((value) => toInteger(value.Index !== undefined ? value.Index : 0))
    const notification = {
      Type: notificationType,
      Index: Math.max(...indices, 0) + 1,
      Read: false,
      Time: Date.now() / 1000
    }
    notifications[nextKey] = notification
    return [notifications, notification]
  }

  static _prepare_skin (player, skinId, text) {
    skinId = toInteger(skinId, -1)
    Skins.getSkinPrice(skinId)
    const [notifications, notification] = NotificationFactory._prepare_notification(
      player, NotificationFactory.SKIN_REWARD_TYPE
    )
    notification.Text = String(text)
    notification.SkinID = skinId
    return [notifications, notification]
  }

  static _prepare_season (player, details, now = null) {
    const [notifications, notification] = NotificationFactory._prepare_notification(
      player, NotificationFactory.SEASON_END_TYPE
    )
    if (now !== null && now !== undefined) {
      notification.Time = Math.trunc(now)
    }
    notification.Seen = false
    Object.assign(notification, structuredClone(details))
    return [notifications, notification]
  }

  static add_skin (player, skinId, text = 'Voucher gift') {
    const [notifications, notification] = NotificationFactory._prepare_skin(player, skinId, text)
    const DataBase = require('../Database/DatabaseManager')
    const lowId = toInteger(player.low_id !== undefined ? player.low_id : 0)
    if (lowId <= 0 || !DataBase._update_value(
      'lowID', lowId, 'Notifications', notifications
    )) {
      throw new Error('Não foi possível persistir a notificação')
    }
    player.Notifications = notifications
    return structuredClone(notification)
  }

  static ensure_skin (player, skinId, text) {
    skinId = toInteger(skinId, -1)
    for (const [, existingSkin] of NotificationFactory._entries(
      player.Notifications !== undefined ? player.Notifications : {}
    )) {
      if (existingSkin === skinId) {
        return false
      }
    }
    NotificationFactory.add_skin(player, skinId, text)
    return true
  }

  static ensure_star_shelly (player) {
    return NotificationFactory.ensure_skin(player, NotificationFactory.STAR_SHELLY_SKIN_ID, NotificationFactory.STAR_SHELLY_TEXT)
  }

  static ensure_wizard_barley (player) {
    const { RewardTransaction } = require('./Rewards')
    const brawlerId = Skins.getBrawler(NotificationFactory.WIZARD_BARLEY_SKIN_ID)
    const states = player.BrawlersUnlockedState !== undefined ? player.BrawlersUnlockedState : {}
    const statesValue = states[String(brawlerId)] !== undefined ? states[String(brawlerId)] : states[brawlerId]
    const unlocked = (
      typeof states === 'object' && states !== null && !Array.isArray(states) &&
      (statesValue || 0) === 1
    )
    const hasNotification = NotificationFactory._entries(
      player.Notifications !== undefined ? player.Notifications : {}
    ).some(
      ([, skinId]) => skinId === NotificationFactory.WIZARD_BARLEY_SKIN_ID
    )
    if (unlocked && hasNotification) {
      return false
    }
    const transaction = new RewardTransaction(player)
    if (!unlocked) {
      transaction.add_reward('Brawler', brawlerId)
    }
    if (!hasNotification) {
      const [notifications] = NotificationFactory._prepare_skin(
        player, NotificationFactory.WIZARD_BARLEY_SKIN_ID, NotificationFactory.WIZARD_BARLEY_TEXT
      )
      transaction.set_value('Notifications', 'Notifications', notifications)
    }
    transaction.commit()
    return true
  }

  static next_pending_type (player) {
    for (const notification of NotificationFactory._ordered(NotificationFactory.home_notifications(player))) {
      if (NotificationFactory._read(notification)) {
        continue
      }
      const notificationType = NotificationFactory._type(notification)
      if ([NotificationFactory.SKIN_REWARD_TYPE, NotificationFactory.SEASON_END_TYPE].includes(notificationType)) {
        return notificationType
      }
    }
    return null
  }

  static claim_next_skin (player) {
    const current = NotificationFactory.home_notifications(player)
    if (typeof current !== 'object' || current === null || Array.isArray(current)) {
      throw new ValueError('Notificação não encontrada')
    }
    const pending = NotificationFactory._entries(current).filter(
      ([notification]) => !NotificationFactory._read(notification)
    )
    if (!pending.length) {
      throw new ValueError('Notificação não encontrada')
    }
    const notificationIndex = toInteger(pending[0][0].Index, -1)
    if (notificationIndex <= 0) {
      throw new ValueError('Notificação sem índice válido')
    }
    return NotificationFactory.claim_skin(player, notificationIndex)
  }

  static claim_next_season (player) {
    for (const notification of NotificationFactory._ordered(
      player.Notifications !== undefined ? player.Notifications : {}
    )) {
      if (NotificationFactory._type(notification) === NotificationFactory.SEASON_END_TYPE && !NotificationFactory._read(notification)) {
        const notificationIndex = toInteger(notification.Index, -1)
        if (notificationIndex <= 0) {
          throw new ValueError('Notificação sem índice válido')
        }
        return NotificationFactory.claim_season(player, notificationIndex)
      }
    }
    throw new ValueError('Notificação de temporada não encontrada')
  }

  static notification_type_at_index (player, notificationIndex) {
    notificationIndex = toInteger(notificationIndex, -1)
    for (const notification of NotificationFactory._ordered(
      player.Notifications !== undefined ? player.Notifications : {}
    )) {
      if (toInteger(notification.Index, -1) === notificationIndex) {
        if (NotificationFactory._is_wizard_barley(notification) && !NotificationFactory.has_scid_connection(player)) {
          throw new ValueError('Notificação não encontrada')
        }
        return NotificationFactory._type(notification)
      }
    }
    throw new ValueError('Notificação não encontrada')
  }

  static mark_season_seen (player, notificationIndex) {
    const { RewardTransaction } = require('./Rewards')
    notificationIndex = toInteger(notificationIndex, -1)
    const current = player.Notifications !== undefined ? player.Notifications : {}
    if (typeof current !== 'object' || current === null || Array.isArray(current)) {
      throw new ValueError('Notificação não encontrada')
    }
    const notifications = structuredClone(current)
    for (const notification of Object.values(notifications)) {
      if (typeof notification !== 'object' || notification === null || Array.isArray(notification)) {
        continue
      }
      if (toInteger(notification.Index, -1) !== notificationIndex) {
        continue
      }
      if (NotificationFactory._type(notification) !== NotificationFactory.SEASON_END_TYPE) {
        throw new ValueError('A notificação não pertence à temporada')
      }
      if (NotificationFactory._read(notification)) {
        throw new ValueError('Notificação já resgatada')
      }
      notification.Seen = true
      const transaction = new RewardTransaction(player)
      transaction.set_value('Notifications', 'Notifications', notifications)
      transaction.commit()
      return {
        type: NotificationFactory.SEASON_END_TYPE,
        index: notificationIndex,
        seen: true,
        claimed: false
      }
    }
    throw new ValueError('Notificação não encontrada')
  }

  static claim_season (player, notificationIndex) {
    const BoxInventory = require('./BoxInventory')
    const { RewardTransaction } = require('./Rewards')
    notificationIndex = toInteger(notificationIndex, -1)
    const current = player.Notifications !== undefined ? player.Notifications : {}
    if (typeof current !== 'object' || current === null || Array.isArray(current)) {
      throw new ValueError('Notificação não encontrada')
    }
    const notifications = structuredClone(current)
    for (const notification of Object.values(notifications)) {
      if (typeof notification !== 'object' || notification === null || Array.isArray(notification)) {
        continue
      }
      if (toInteger(notification.Index, -1) !== notificationIndex) {
        continue
      }
      if (NotificationFactory._type(notification) !== NotificationFactory.SEASON_END_TYPE) {
        throw new ValueError('A notificação não pertence à temporada')
      }
      if (NotificationFactory._read(notification)) {
        throw new ValueError('Notificação já resgatada')
      }

      const details = NotificationFactory._season_details(notification)
      const boxes = NotificationFactory._season_boxes(notification)
      let tokenAmount = 0
      for (const block of ['Best', 'Total']) {
        for (const field of ['Coins', 'Bonus']) {
          tokenAmount += details[block][field]
        }
      }
      const transaction = new RewardTransaction(player)
      if (tokenAmount) {
        const balance = Math.trunc(Number(transaction._value('brawl_boxes', 0) || 0)) || 0
        transaction.set_value(
          'brawl_boxes', 'brawlBoxes', balance + tokenAmount
        )
      }
      const resources = { 5000001: tokenAmount, 5000009: 0 }
      for (const box of boxes) {
        BoxInventory.add(transaction, box.Type, box.Count)
        if (box.Type === 10) {
          resources[5000001] += box.Count * 100
        } else if (box.Type === 12) {
          resources[5000009] += box.Count * 10
        }
      }

      notification.Seen = true
      notification.Read = true
      notification.ClaimedAt = Date.now() / 1000
      transaction.set_value('Notifications', 'Notifications', notifications)
      transaction.commit()
      return {
        type: NotificationFactory.SEASON_END_TYPE,
        index: notificationIndex,
        tokens: tokenAmount,
        boxes,
        resources,
        bestBrawler: details.BestBrawler,
        claimed: true
      }
    }
    throw new ValueError('Notificação não encontrada')
  }

  static claim_skin (player, notificationIndex) {
    const { RewardTransaction } = require('./Rewards')
    notificationIndex = toInteger(notificationIndex, -1)
    const current = player.Notifications !== undefined ? player.Notifications : {}
    if (typeof current !== 'object' || current === null || Array.isArray(current)) {
      throw new ValueError('Notificação não encontrada')
    }
    const notifications = structuredClone(current)
    for (const notification of Object.values(notifications)) {
      if (typeof notification !== 'object' || notification === null || Array.isArray(notification)) {
        continue
      }
      if (toInteger(notification.Index, -1) !== notificationIndex) {
        continue
      }
      const entries = NotificationFactory._entries([notification])
      if (!entries.length) {
        throw new ValueError('A notificação não é uma recompensa de skin')
      }
      const skinId = entries[0][1]
      if (skinId === NotificationFactory.WIZARD_BARLEY_SKIN_ID && !NotificationFactory.has_scid_connection(player)) {
        throw new ValueError('Notificação não encontrada')
      }
      if (NotificationFactory._read(notification)) {
        throw new ValueError('Notificação já resgatada')
      }
      const brawlerId = Skins.getBrawler(skinId)
      const owned = ((player.UnlockedSkins !== undefined ? player.UnlockedSkins : {}) || {}).Skins || []
      const alreadyOwned = owned.includes(skinId)
      const isWizardBarley = skinId === NotificationFactory.WIZARD_BARLEY_SKIN_ID
      const states = player.BrawlersUnlockedState !== undefined ? player.BrawlersUnlockedState : {}
      const statesValue = states[String(brawlerId)] !== undefined ? states[String(brawlerId)] : states[brawlerId]
      const brawlerUnlocked = (statesValue || 0) === 1
      const transaction = new RewardTransaction(player)
      if (isWizardBarley && !brawlerUnlocked) {
        transaction.add_reward('Brawler', brawlerId)
      }
      if (!alreadyOwned) {
        if (isWizardBarley) {
          transaction.add_reward('Skin', skinId)
        } else {
          const unlockedSkins = structuredClone(
            player.UnlockedSkins !== undefined ? player.UnlockedSkins : { Skins: [] }
          )
          if (!Array.isArray(unlockedSkins.Skins)) {
            unlockedSkins.Skins = []
          }
          unlockedSkins.Skins.push(skinId)
          transaction.set_value('UnlockedSkins', 'UnlockedSkins', unlockedSkins)
        }
      }
      notification.Read = true
      transaction.set_value('Notifications', 'Notifications', notifications)
      transaction.commit()
      return {
        skin: skinId,
        brawler: brawlerId,
        brawlerReward: isWizardBarley ? brawlerId : null,
        index: notificationIndex,
        alreadyOwned
      }
    }
    throw new ValueError('Notificação não encontrada')
  }
}

module.exports = NotificationFactory
