process.chdir(require('path').resolve(__dirname, '../..'))
const fs=require('fs'),{battleAssets}=require('../../Logic/Battle/World/BattleAssets'),{TileMap}=require('../../Logic/Battle/World/TileMap'),{V13BitStream}=require('../../Logic/Battle/Game/V13BitStream'),{encodeHeader}=require('../../Logic/Battle/Game/V13WorldCodec'),{rules}=require('../../Logic/Battle/World/GameModes')
const a=battleAssets(),out=[]
for(const l of a.tables.locations){if(!l.AllowedMaps||l.Disabled==='true')continue;const map=new TileMap(a.map(l.AllowedMaps),a),mode=rules(l.GameMode),players=Array.from({length:mode.capacity},(_,i)=>({player:{low_id:i+1},rank:0,score:3,kills:[]})),characters=new Map(players.map((p,i)=>[i+1,{id:i,hp:3600,superCharge:2000}]))
 const world={mode,map,players,characters,tick:20,alivePlayers:mode.capacity,aliveTeams:mode.capacity/mode.teamSize,baseHpPercent:[100,100],bossHpPercent:100},stream=new V13BitStream();encodeHeader(stream,world,players[0]);stream.uint(0,7)
 out.push({mapId:l.id,name:l.Name,mode:mode.variation,capacity:mode.capacity,grid:a.map(l.AllowedMaps),tiles:a.tables.tiles,hex:stream.bytes().toString('hex'),bits:stream.position})
}
fs.writeFileSync(require('path').join(process.env.V13_VECTOR_DIR, 'header-vectors.json'),JSON.stringify(out))
