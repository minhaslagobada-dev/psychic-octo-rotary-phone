'use strict'
// Port of probe_character_tick.py.
// Original full character tick with real client metadata.
// Battle/player memory is controlled input, not a complete battle-mode runtime.
// No character CSV reader or gameplay routine is replaced.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeDataRegistry } = require('./native_data')
const { NativeOpenMap } = require('./native_open_map')
const { RuntimeError, pyRepr, tuple } = require('./lib/pycompat')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT
  const data = new NativeDataRegistry(n, path.join(root, 'GameAssets'), (...parts) => R.print(...parts))
  const terrain = new NativeOpenMap(n, root); const t = terrain.csv; const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const records = []
  const characters = data.csv.get(16)
  for (const row of characters.records) {
    const d = R.zipDict(characters.names, row)
    if (d.Type !== 'Hero' || d.Disabled === 'true' || d.LockedForChronos === 'true') continue
    const manager = t.alloc(0x100); const battle = t.alloc(0x400); p(manager + 0x50, battle); p(battle, manager); p(battle + 0x70, terrain.pointer)
    const players = t.alloc(6 * 8); p(battle + 0x78, players)
    for (let i = 0; i < 6; i++) p(players + i * 8, t.alloc(0x200))
    const obj = t.alloc(0x400); n.call(0x14de30, obj, data.named(16, d.Name)); w(obj + 0x3c, 0); w(obj + 0x40, 0); n.call(0x253b18, manager, obj); n.call(0x465f38, obj, 3000, 4500, 0)
    for (let tick = 150; tick < 155; tick++) {
      w(battle + 0x18, tick)
      try { n.call(0x18ff68, obj, { count: 3000000 }) } catch (e) {
        const error = new RuntimeError(pyRepr(tuple(d.Name, tick, R.errorMessage(e)))); error.cause = e; throw error
      }
      records.push({ name: d.Name, tick, hp: data.word(obj + 0xb0), state: data.word(obj + 0x78), x: data.word(obj + 0x30), y: data.word(obj + 0x34), attackingTicks: data.word(obj + 0x12c) })
    }
  }
  R.writeJson('character-tick-vectors.json', records)
  R.print('Original full character idle tick:', records.length, 'frames;', new Set(records.map(r => r.name)).size, 'real client heroes; controlled battle/player structures')
})
