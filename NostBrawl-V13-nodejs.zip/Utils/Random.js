'use strict'

class Random {
  static random () {
    return Math.random()
  }

  static randint (min, max) {
    return min + Math.floor(Math.random() * (max - min + 1))
  }

  static choice (sequence) {
    return sequence[Random.randint(0, sequence.length - 1)]
  }
}

module.exports = Random
