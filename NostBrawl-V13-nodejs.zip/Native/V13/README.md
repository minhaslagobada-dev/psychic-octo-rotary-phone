# Reconstrução da lógica original v13

Este diretório contém transcrições de funções identificadas no ELF v13 cujo SHA-256 consta em `manifest.json`. Os testes executam as funções ARM64 originais com Unicorn e comparam seus resultados com JavaScript. A v36 auxilia na identificação; seus algoritmos não são usados como prova da v13.

## Estado real

- `Math.js`: raiz inteira com tabela e ramos originais, 532 vetores.
- `ProjectilePosition.js`: posição e altura, incluindo trajetória com salto, 8.400 vetores de 75 definições.
- `ProjectileTiming.js`: duração e incremento de progresso da inicialização, 1.800 vetores. As posições de lançamento e alvo são entradas já resolvidas. Não implementa criação, dispersão ou colisões.
- `ProjectileSpread.js`: dispersão determinística e seis padrões aleatórios, com renormalização do alcance e limites de terreno. Comparação de 14.400 disparos com a rotina original completa, incluindo estado aleatório e 43.200 pontos de trajetória.
- `Random.js`: gerador original usado pela dispersão, 4.032 transições.
- `SkillIdle.js`: ramo inativo da atualização de habilidades, 3.456 vetores. Rejeita execução ativa, que ainda precisa ser reconstruída.
- `CollisionGeometry.js` e `TileState.js`: interseções originais de segmentos, retângulos e círculos (12.017 casos), construção, destruição e reaparecimento de tiles (910 casos). A destruição direta não substitui as permissões verificadas pelo chamador.
- `Aim.js`, `AttackSetup.js` e `AttackTiming.js`: ângulo e orientação, configuração dos ataques e seleção dos intervalos, comparados com rotinas originais. `SkillRange.js` verifica a carga de alcance de mira. `AttackSkillSetup.js` cobre o ramo Attack sem invocações, áreas ou itens associados; rejeita explicitamente os outros tipos e casos ainda ausentes.
- `ProjectileScale.js`: tamanho e dano ao longo do voo, 825 casos de escala e 4.125 casos de dano.
- Sondas adicionais executam construtor/eventos de personagens e ativação/resolução de alvo de habilidades. Esses resultados não comprovam ataque completo nem Super completo. A sonda de disparo também verifica registro de objetos, dano, equipe, duração e posição ao longo do voo; os testes de integração usam origem controlada sem metadados de herói.

**O servidor principal usa o motor ARM64 original da v13.** `main.js` inicia `NativeBattleBridge`, e o coordenador cria `NativeBattleWorld`: um adaptador de sessão que executa a biblioteca por Unicorn. A movimentação, os ataques, Supers, bots, colisões, objetivos, mapas e bitstreams desse caminho não passam pelo motor aproximado `BattleWorld.js`. Esse arquivo permanece para testes antigos; não é um fallback automático. A verificação visual no Android ainda não foi concluída, e não há certificação para 200 jogadores simultâneos.

## Motor original completo em execução

`scripts/native_v13/native_battle.js` chama os construtores originais de modo, jogadores, personagens e mapas. A própria biblioteca preenche as vagas com bots, atualiza todos os objetos e objetivos, decodifica comandos e gera os bitstreams de visão. Não usa `BattleWorld.js` para esses cálculos.

Verificações executadas com a biblioteca do APK:

- Os nove modos habilitados iniciaram com as capacidades, equipes, objetos e escalas de HP nativos. Cada um também terminou naturalmente, com um humano parado e os bots originais: Bounty 3.120 ticks, Gem Grab 1.839, Solo 2.508, Heist 705, Big Game 4.415, Brawl Ball 3.120, Robo Rumble 1.357, Duo 2.767 e Raid 1.920. Nenhum HP, placar, relógio ou indicador de término foi forçado. Isso verifica esses cenários, não todas as condições de vitória.
- Os 22 heróis habilitados ganharam a carga completa por dano e acionaram seus Supers por comandos originais. Uma observação da entrada original de ativação (`0x4a3f3c`) confirmou o personagem humano e a habilidade correta. Cada caso continuou por mais 40 frames, sem novos comandos do humano, para executar os efeitos. HP, carga, relógio e estado de término não foram forçados nesses cenários.
- O leitor completo original do cliente aceitou 228 visões de fases avançadas, términos e do Super. A montagem das entradas de leitura controla alocações e chamadas gráficas; não executa a renderização Android.
- Nível 9 e a skin BanditGirlPrereg alteraram HP e projétil pelos caminhos nativos. As referências das 125 cartas e 67 skins foram resolvidas, incluindo o serviço NoOpTune original.
- Cinco partidas foram criadas, executadas e destruídas sem retenção de alocações no heap convidado. Foi necessário chamar `BitStream::destruct` (`0x16806c`) antes do destrutor virtual, exatamente como os chamadores nativos.
- Quarenta frames produziram estados e bytes idênticos com contagem de instruções e com limite de tempo por chamada. Na medição local, foram 45,22 s e 0,30 s, respectivamente. Isso não mede a capacidade de jogadores em produção.

`Logic/Battle/NativeBattleRuntime.js` comunica o Node com um processo persistente que executa a biblioteca ARM64. O teste `native_battle_runtime.test.js` verificou entrada, movimentação, 150 visões, destruição e reutilização do processo. `NativeVision.js` apenas envolve o bitstream original no cabeçalho de transporte v13.

Os testes integrados do servidor principal passaram com seis logins criptografados por UDP e com um humano mais cinco bots, tanto por UDP quanto por TCP. Verificaram contagem de 15 segundos, início, movimentação, ACK, entrega única de resultados e limpeza. A entrega de recompensas nesses testes usa um término explícito de teste; o encerramento natural dos nove modos é verificado separadamente.

As classificações Solo e Duo são lidas pelas rotinas originais `0x2558e4` e `0x3b0078`. Seus acessos à cena Android recebem um contexto de visualização controlado, incluindo metadados das áreas; nenhum estado de jogo é alterado. O adaptador projeta placares/objetivos nativos para os resultados e recompensas do servidor. O campo do jogador em `+0xd8` é o índice do último eliminador, confirmado nas escritas de `0x1dfd0c` e `0x1dfdd0`; não é classificação.

Também passaram 59 combinações de humanos/bots/equipes e 40 frames em cada uma das 68 localizações fora do Tutorial, incluindo entradas desabilitadas na rotação, que continuam desabilitadas publicamente. O leitor original aceitou as 68 visões. Os 55 grupos de mapas, incluindo o Tutorial e o mapa Robo gerado por blocos, já tiveram seus construtores nativos verificados. Isso não equivale a testar todas as interações e condições de vitória em todos os mapas.

Carregamento sem resposta termina após 30 segundos; desconexões e falha do processo nativo liberam as sessões. Uma falha de preparação desfaz o mundo sem cancelar indevidamente os tickets. O timeout UDP no lobby não cancela a fila; em batalha com TCP ativo, preserva ACK/deduplicação e permite recuperação por NAT ou envio de visões por TCP. A falha definitiva do motor fecha as filas, em vez de deixá-las presas. Os testes de falha são injeções controladas, não implementações de jogo simuladas.

## Dados efetivos do cliente

O APK `ogstars_signed.apk`, SHA-256 `fce09d5bdc4e3c3bfe91260f1a9ce10c7d0a86e1fd667e7a132072fbf733302c`, forneceu a tabela completa: 73 personagens e 98 colunas. `characters.csv`, `cards.csv` e `skins.csv` foram substituídos pelas cópias exatas do APK, após verificar os IDs. Os demais dados de batalha já coincidiam. `GameAssets/client_battle_assets.json` registra a origem e os hashes de 12 tabelas.

A inicialização nativa agora aceita todas as colunas de personagens. A biblioteca também construiu as tabelas, resolveu as referências de personagens, projéteis, áreas, itens, habilidades e tiles e executou os construtores dos 73 personagens sem substituir acessos a CSV ou funções de jogo. Os IDs dos heróis jogáveis permaneceram iguais; IDs de NPCs e objetos posteriores à inserção de `Animal` foram corrigidos para os valores do cliente.

A biblioteca extraída do APK tem SHA-256 `8d7a7f463f68edb6f4618c706670477ea18730eacfd788ebd17f9734b5f8c578`. Difere da referência em 56 bytes de código. As 42 funções comparadas na primeira etapa eram idênticas; o manifesto atual contém 64 funções verificadas por limites do ELF; as seções de dados e relocações também são idênticas. Ambas as identidades são aceitas explicitamente pelas ferramentas de análise; outras bibliotecas continuam sendo rejeitadas.

`probe_character_tick.js` executou 110 atualizações em repouso nos 22 heróis habilitados. `probe_character_movement.js` executou 660 atualizações de movimentação com o construtor de mapa, o cálculo de caminho, `moveTo` e a atualização de personagem originais. Todos os heróis atingiram o alvo no corredor livre do Tutorial, com a interpolação inteira observada. Com `V13_MOVEMENT_SCENARIO=obstacle`, mais 2.200 atualizações fizeram os mesmos heróis contornarem as paredes do Tutorial e atingirem o destino sem sobrepor seus raios de colisão às paredes. Os jogadores e o modo de batalha ainda são estruturas de entrada controladas; esses testes não comprovam comandos de rede, habilidades Super ou uma partida completa.

O registro de dados de teste usa o ID nativo 20 para habilidades e 37 para blocos de mapas. O segundo foi confirmado no carregador original (`0x3cd65c`) e no consumidor de blocos (`0xdd864`); o ID 25 usado anteriormente nesse registro estava incorreto. A grade fina original tem três células por tile em cada eixo, corrigidas também na entrada de terreno aberto dos testes.

`probe_tile_map.js` executou o construtor completo dos 55 grupos de mapas, incluindo `GeneratedRobo` e sua montagem original por blocos. O teste compara as 54 grades estáticas aos CSVs e verifica as dimensões, a quantidade de tiles e a alocação da grade fina de todos os grupos. Isso comprova a construção dos mapas na biblioteca, não a execução dos respectivos modos ou sua transmissão para o APK. O teste mantém as alocações dos mapas em um heap de pesquisa de 64 MiB; isso não constitui uma medida de consumo do servidor em produção.

`probe_hero_skills.js` executou as 44 habilidades dos 22 heróis com metadados reais: primeiro a atualização do próprio personagem e depois, com `V13_ADVANCE_OBJECTS=1`, a atualização original do gerenciador (`0x18572c`). Este segundo cenário verificou 1.760 atualizações, incluindo criação de ataques, consumo de munição, deslocamentos de Charge e temporizador de invisibilidade. A rotina original também processa a lista de objetos e a remoção pendente (`0x212770`); nenhuma dessas etapas foi substituída por um laço de simulação de objetos em JavaScript.

Com `V13_ENEMY=LootBox`, as 44 habilidades passaram pelo mesmo cenário contra um alvo inimigo, construído originalmente com 6.000 HP. Todos os 22 ataques principais causaram dano. Os IDs nativos dos personagens invocados e dos itens criados coincidiram com os CSVs do APK. O teste dura 40 ticks por habilidade: não comprova todos os efeitos tardios, todas as interações entre heróis, modos, morte de jogadores ou comunicação de rede. Os jogadores e a estrutura externa da batalha ainda são entradas controladas; o construtor completo do modo não foi executado nesse cenário.

## Instalação e reprodução

A biblioteca do cliente está incluída em `libg.so`. Somente Node 18+ é necessário (sem Python): execute `npm install`, `npm run setup:native` e `npm start` na raiz.

O emulador Unicorn 2.1.4 tem dois backends, escolhidos por `UNICORN_BACKEND` (`auto`, padrão; `native`; `wasm`):

* `native`: `libunicorn` 2.x carregada por `koffi`. A biblioteca é procurada em `UNICORN_LIB` e em `Native/unicorn/<plataforma>-<arquitetura>/` (já incluída para `linux-x64`). Em outras plataformas, `npm run setup:native` baixa o wheel oficial `unicorn==2.1.4` do PyPI (é apenas um zip; nenhum Python é executado), confere o SHA-256 e extrai só a `libunicorn`.
* `wasm`: `@alexaltea/unicorn-js`, puro WebAssembly, funciona em qualquer host Node; é cerca de 4× mais lento e é usado automaticamente quando o backend nativo não está disponível.

`LIBG_V13` permite indicar outra biblioteca (padrão `Native/V13/libg.so`), e `NODE_BINARY`, outro executável Node para o processo de batalha. Mantenha `config.json` e seus bancos ao atualizar.


Defina `LIBG_V13` para a biblioteca original e execute `npm run audit:native-engine` (somente Node; Capstone via `@alexaltea/capstone-js`). `V13_RESEARCH_DIR` permite escolher a pasta de evidências. O teste não altera contas, bancos ou `config.json`.

A rotina original completa de atualização de projéteis também foi executada em 300 casos, com posição comparada à transcrição em terreno aberto. Sondas separadas executaram colisões contra terreno em 1.000 casos e contra personagens controlados em 144 casos; esses cenários não comprovam todas as interações de combate.

Os cenários de teste têm entradas controladas. Por exemplo, a sonda de ativação usa terreno aberto e a inicialização isolada de projéteis usa uma origem que não é personagem. As sondas mais recentes de registro de dados, atualização e movimentação usam os metadados reais do APK, sem substituir leitores de CSV ou funções de jogo. Nenhum desses testes executa a interface Android ou comprova uma partida online completa.

## Verificações da entrega atual

O decoder original de resultados aceitou 47 pacotes dos sete formatos, verificando jogador local, IDs humanos, MVP, referências, leitura integral e liberação de memória. A marca de jogador local foi corrigida para não identificar todos os humanos como locais. O bônus de MVP das novas partidas usa o índice escolhido pelo motor original. Também foi corrigida a liberação dos buffers e entradas temporárias dos comandos: cinco partidas com comandos terminaram sem retenção de alocações.

A tentativa de executar o APK fornecido em Android x86 com tradução ARM64 falhou antes de conectar ao servidor: `SIGSEGV/SEGV_ACCERR` em `libndk_translation.so`, caminho `ndk_translation_HandleNoExec`. Portanto não se declara confirmação visual de entrada, renderização ou término no APK. O requisito de 200 jogadores simultâneos permanece para uma etapa futura.
