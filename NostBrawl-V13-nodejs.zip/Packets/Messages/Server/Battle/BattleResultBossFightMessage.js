'use strict'
const { apply_battle_result_rewards } = require('../../../../Logic/BattleResultAdapter')
const BattleResultMessage = require('./BattleResultMessage')

class BattleResultBossFightMessage extends BattleResultMessage {
  static get GAME_MODE () { return 6 }

  _get_rewards (battleId) {
    if (battleId === null || battleId === undefined) {
      return apply_battle_result_rewards(this.player, 6)
    }
    return apply_battle_result_rewards(this.player, 6, battleId)
  }
}

module.exports = BattleResultBossFightMessage
