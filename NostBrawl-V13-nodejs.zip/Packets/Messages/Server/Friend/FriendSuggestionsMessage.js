'use strict'

const { encode_friend_entry } = require('../../../../Logic/FriendPayload')
const Writer = require('../../../../Utils/Writer')

class FriendSuggestionsMessage extends Writer {
  constructor (client, player, entries) {
    super(client)
    this.id = 20199
    this.player = player
    this.entries = Array.from(entries)
  }

  encode () {
    this.writeInt(this.entries.length)
    for (const entry of this.entries) {
      this.writeInt(0)
      encode_friend_entry(this, entry)
    }
  }
}

module.exports = FriendSuggestionsMessage
