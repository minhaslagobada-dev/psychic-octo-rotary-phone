'use strict'
// Port of probe_projectile_position.py.
// Original v13 ProjectileServer::getPosAtTick, including original math.
// No gameplay function or CSV access is replaced. Input actor fields are fixtures.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); t.initialize_schema(0x449b0c)
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const records = []
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row); const meta = t.alloc(0x200); p(meta + 8, t.rows[i])
    n.uc.mem_write(meta + 0x90, Buffer.from([d.Indirect === 'true' ? 1 : 0, d.ConstantFlyTime === 'true' ? 1 : 0]))
    w(meta + 0x94, R.int0(d.Speed)); w(meta + 0xa0, R.int0(d.Gravity))
    for (const [start, end, duration] of [[[3000, 4500], [3500, 5000], 20], [[5200, 8000], [1200, 1200], 20], [[3500, 5000], [3000, 4500], 20],
      [[3101, 5157], [5317, 8429], 7], [[5317, 8429], [3101, 5157], 37], [[3001, 4503], [3001, 4503], 20], [[2, 2], [6298, 9898], 37]]) {
      for (const z of [0, 350]) {
        const obj = t.alloc(0x120); n.call(0x4d30d0, obj, meta)
        w(obj + 0x20, 100); w(obj + 0x24, 100 + duration); w(obj + 0x60, start[0]); w(obj + 0x64, start[1]); w(obj + 0x68, end[0]); w(obj + 0x6c, end[1]); w(obj + 0x70, z)
        const point = t.alloc(8)
        for (const tick of [99, 100, 101, 100 + Math.floor(duration / 4), 100 + Math.floor(duration / 2), 100 + duration - 1, 100 + duration, 101 + duration]) {
          const height = n.call(0x350c04, obj, tick, point)
          R.assert(height >= 0n && height <= 3000n)
          records.push({
            name: d.Name,
            data: { gravity: R.int0(d.Gravity), constantFlyTime: d.ConstantFlyTime === 'true', speed: R.int0(d.Speed), bounce: R.int0(d.BouncePercent) },
            input: { start, end, z, launch: 100, finish: 100 + duration, tick },
            output: { x: get(point), y: get(point + 4), z: height }
          })
        }
      }
    }
  })
  R.writeJson('projectile-position-vectors.json', records)
  // The decrypted original table is part of LogicMath, not generated with host sqrt.
  const table = Array.from({ length: 256 }, (_, i) => get(0x95b110 + i * 4))
  R.writeJson('math-tables.json', { sqrt: table })
  const values = [-1, -2147483648, 0, 1, 2, 255, 256, 257, 1023, 1024, 4095, 4096, 16383, 16384, 65535, 65536, 262143, 262144, 1048575, 1048576, 4194303, 4194304, 16777215, 16777216, 67108863, 67108864, 268435455, 268435456, 1073741823, 1073741824, 2147483646, 2147483647]
  let seed = 17
  for (let i = 0; i < 500; i++) { seed = (seed * 1664525 + 1013904223) % 4294967296; values.push(seed % 0x80000000) }
  const results = []
  for (const value of values) results.push({ input: value, output: R.signed32(n.call(0x28fc2c, R.u32(value))) })
  R.writeJson('sqrt-vectors.json', results)
  R.print('Original v13 projectile position oracle:', records.length, 'cases;', t.records.length, 'definitions; full bounce/height branches')
})
