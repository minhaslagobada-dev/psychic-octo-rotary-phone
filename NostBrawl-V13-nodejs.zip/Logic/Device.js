'use strict'

class Device {
  constructor (socket) {
    this.AndroidID = null
    this.DeviveModel = null
    this.OpenUDID = null
    this.OSVersion = null
    this.isAndroid = false
    this.Language = null
    this.socket = socket
  }

  SendData (data) {
    this.socket.write(data)
  }
}

module.exports = Device
