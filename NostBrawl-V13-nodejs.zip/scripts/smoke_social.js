'use strict'
const path = require('path')
process.chdir(path.resolve(__dirname, '..'))
const fs = require('fs')
fs.rmSync(path.resolve('Database/players.sqlite'), { force: true })

const DataBase = require('../Database/DatabaseManager')
const { Players } = require('../Logic/Player')
const { ClubService, ClubError } = require('../Logic/ClubService')
const { FriendService, FriendError } = require('../Logic/FriendService')
const PresenceService = require('../Logic/PresenceService')

let passed = 0
let failed = 0

function check (name, condition) {
  if (condition) {
    passed += 1
    console.log('ok', name)
  } else {
    failed += 1
    console.error('FAIL', name)
  }
}

function expectError (ErrorType, name, fn) {
  try {
    fn()
    failed += 1
    console.error('FAIL', name, '(expected ' + ErrorType.name + ')')
  } catch (error) {
    if (error instanceof ErrorType) {
      passed += 1
      console.log('ok', name)
    } else {
      failed += 1
      console.error('FAIL', name, '(wrong error: ' + String(error).split('\n')[0] + ')')
    }
  }
}

let nextLowId = 900100
function makeAccount (name) {
  nextLowId += 1
  const player = {
    token: 'social_smoke_' + nextLowId,
    low_id: nextLowId,
    high_id: 0,
    name,
    gems: 0,
    gold: 0,
    trophies: 50 + nextLowId % 100,
    highest_trophies: 50,
    profile_icon: 5,
    name_color: 12,
    player_experience: 100,
    online: 0
  }
  DataBase.createAccount({ player })
  return player
}

// --- create accounts ---------------------------------------------------------
const alice = makeAccount('Alice')
const bob = makeAccount('Bob')
const carol = makeAccount('Carol')
check('createAccount ids distinct', alice.low_id !== bob.low_id && bob.low_id !== carol.low_id)

// --- club create ----------------------------------------------------------
const [clubA] = ClubService.create(alice, 555001, 'Fumaça', 'Clube de testes', 42, 2, 100, 0)
check('create() owner becomes president', clubA.id === 555001 && clubA.member_count === 1 && clubA.members[0].role === 2)
check('actor synced after create', alice.club_low_id === 555001 && alice.club_role === 2)
check('create() fields persisted', clubA.description === 'Clube de testes' && clubA.badge_id === 42 && clubA.required_trophies === 100)
check('list_clubs includes new club', ClubService.list_clubs(1, 100, 2, 30).some((c) => c.id === 555001))

expectError(ClubError, 'create() while in club raises', () => ClubService.create(alice, 555002, 'Segundo', 'x', 1, 2, 0, 0))

// --- join -----------------------------------------------------------------
const [clubAfterJoin, joinEntry] = ClubService.join(bob, 555001)
check('join() adds member', clubAfterJoin.member_count === 2)
check('join() stream entry event 4 / msg 3', joinEntry.event === 4 && joinEntry.message === '3' && joinEntry.tick === 0)
check('actor synced after join', bob.club_low_id === 555001 && bob.club_role === 1)
check('is_member true after join', ClubService.is_member(bob.low_id, 555001))

expectError(ClubError, 'join() while already in club raises', () => ClubService.join(bob, 555001))
expectError(ClubError, 'join() unknown club raises', () => ClubService.join(carol, 998877))

// --- promote ---------------------------------------------------------------
const [clubPromoted, aliceRoleAfter] = ClubService.promote(alice, bob.low_id, 3)
check('alice keeps role when promoting to elder', aliceRoleAfter === 2)
check('promote() sets target role 3', clubPromoted.members.find((m) => m.low_id === bob.low_id).role === 3)

const [clubPromoteLeader, aliceDemoted] = ClubService.promote(alice, bob.low_id, 2)
check('promote to president demotes actor to vice', aliceDemoted === 4)
check('actor demoted in club', clubPromoteLeader.members.find((m) => m.low_id === alice.low_id).role === 4)
check('target becomes president', clubPromoteLeader.members.find((m) => m.low_id === bob.low_id).role === 2)
check('actor in-memory role updated', alice.club_role === 4)
DataBase.loadAccount({ player: bob })
check('target persisted role after reload', bob.club_role === 2)

expectError(ClubError, 'demoted actor cannot promote president', () => ClubService.promote(alice, bob.low_id, 3))

// --- chat ------------------------------------------------------------------
const [chatClubId, chatEntry] = ClubService.chat(alice, 'olá clube!')
check('chat() stores message entry', chatClubId === 555001 && chatEntry.event === 2 && chatEntry.message === 'olá clube!')
check('stream has join + chat entries', ClubService.get_messages(555001).length === 2)
check('stream positions sequential', ClubService.get_messages(555001)[1].position === 2)

// --- mail ------------------------------------------------------------------
const [mailClub, notification] = ClubService.mail(bob, 'combate amanhã')
check('mail() notification fields', notification.text === 'combate amanhã' && notification.by === bob.low_id)
check('notifications retrievable', ClubService.get_notifications(555001, 5).length === 1)

// --- kick ------------------------------------------------------------------
const [clubKick, kickEntry, kickedId] = ClubService.kick(bob, alice.low_id)
check('kick() returns target id', kickedId === alice.low_id)
check('kick stream entry', kickEntry.event === 4 && kickEntry.tick === 1 && kickEntry.message === '1')
DataBase.loadAccount({ player: alice })
check('kicked player membership cleared (persisted)', alice.club_low_id === 0 && alice.club_role === 0)
// actor fields still sync via _sync_actor on subsequent ops
check('kicker unchanged membership', bob.club_low_id === 555001)
check('club has one member after kick', clubKick.member_count === 1)

// --- leave with auto-successor ---------------------------------------------
ClubService.join(alice, 555001)
const leaveResult = ClubService.leave(bob) // bob is president; alice stays
check('leave() picks first member as successor', leaveResult.successorID === alice.low_id)
check('leave() returns club id', leaveResult.clubID === 555001)
check('remaining members list', leaveResult.memberIDs.length === 1 && leaveResult.memberIDs[0] === alice.low_id)
check('leave stream entry msg 4', leaveResult.entry.message === '4' && leaveResult.entry.tick === 0)
check('leaver membership cleared', bob.club_low_id === 0 && bob.club_role === 0)
check('successor role persisted', ClubService.get_club(555001).members[0].role === 2)

// --- leaving last member deletes club --------------------------------------
const lastLeave = ClubService.leave(alice)
check('club deleted when empty', lastLeave.deleted === true && ClubService.get_club(555001) === null)

// --- club edit --------------------------------------------------------------
const [editClub] = ClubService.create(carol, 777001, 'CarolClub', 'antes', 10, 2, 0, 0)
const edited = ClubService.edit(carol, 'descrição nova', 99, 3, 500)
check('edit() persists fields', edited.description === 'descrição nova' && edited.badge_id === 99 && edited.type === 3 && edited.required_trophies === 500)
check('edit() keeps family_friendly', edited.family_friendly === 0)
expectError(ClubError, 'edit() without club-role raises', () => ClubService.edit(alice, 'x', 1, 2, 0))

// --- search ------------------------------------------------------------------
const search = ClubService.list_clubs(1, 100, 3, 10, 'carol')
check('list_clubs finds by name', search.length === 1 && search[0].id === 777001)
check('list_clubs minMembers filter', ClubService.list_clubs(2, 100, 3, 10, 'carol').length === 0)
check('list_clubs type filter (invite-only)', ClubService.list_clubs(1, 100, 2, 10, 'carol').length === 0)
check('list_clubs finds by id string', ClubService.list_clubs(1, 100, 3, 10, '777001').length === 1)

// --- friend add / accept / remove -------------------------------------------
const addResult = FriendService.add(alice, bob.low_id, 1)
check('add() outgoing state', addResult.state === 2 && addResult.accepted === false)
check('add() entry state', addResult.entry.state === 2 && addResult.entry.low_id === bob.low_id)
check('add() reverse entry incoming', addResult.reverse_entry.state === 3 && addResult.reverse_entry.low_id === alice.low_id)
check('add() entry shape', addResult.entry.high_id === 0 && addResult.entry.origin === 1 && addResult.entry.facebook_id === '')

const acceptResult = FriendService.accept(bob, alice.low_id)
check('accept() sets friends', acceptResult.state === 4 && acceptResult.accepted === true)
check('friends() lists friendship', FriendService.friends(alice).some((f) => f.low_id === bob.low_id && f.state === 4))

const entry = FriendService.current_entry(alice.low_id, bob.low_id)
check('current_entry returns entry', entry !== null && entry.state === 4 && entry.profile_icon === 28000000 + bob.profile_icon)
check('current_entry has trophies/last_seen', entry.trophies === bob.trophies && typeof entry.last_seen_seconds === 'number')

const dupAdd = FriendService.add(alice, bob.low_id, 1)
check('add() existing friend no-op', dupAdd.state === 4 && dupAdd.accepted === true)

// --- set_facebook -------------------------------------------------------------
const prog = FriendService.set_facebook(carol, 'fb-123', 'tok-9', true)
check('set_facebook linked', prog.isFBLinked === true && prog.facebookID === 'fb-123' && prog.facebookToken === 'tok-9')
check('set_facebook syncs player', carol.IsFacebookLinked === 1 && carol.FacebookID === 'fb-123')
const prog2 = FriendService.set_facebook(carol, '', '', false)
check('set_facebook unlink', prog2.isFBLinked === false && prog2.facebookID === '')
expectError(FriendError, 'set_facebook without id raises', () => FriendService.set_facebook(carol, '', 'tok', true))

// --- addable ------------------------------------------------------------------
FriendService.set_facebook(carol, 'fb-999', 'tok-9', true)
const addable = FriendService.addable(alice, ['fb-999'], [])
check('addable finds by facebookID', addable.some((f) => f.low_id === carol.low_id))
check('addable empty when no match', !FriendService.addable(alice, ['nada'], []).length)
check('addable excludes existing friends', !FriendService.addable(alice, [], []).some((f) => f.low_id === bob.low_id))

// --- suggestions ---------------------------------------------------------------
const suggestions = FriendService.suggestions(alice, 10)
check('suggestions exclude friends', suggestions.every((f) => f.low_id !== bob.low_id))
check('suggestions include strangers', suggestions.some((f) => f.low_id === carol.low_id))
check('suggestions entry state 1', suggestions.every((f) => f.state === 1))
check('suggestions ordered trophies desc', suggestions.every((f, i, arr) => i === 0 || arr[i - 1].trophies >= f.trophies))

// --- remove ---------------------------------------------------------------------
const removeResult = FriendService.remove(alice, bob.low_id)
check('remove() returns removed true', removeResult.removed === true && removeResult.friend_id === bob.low_id)
check('remove() clears friendship', !FriendService.friends(alice).some((f) => f.low_id === bob.low_id))
check('remove() clears reverse', !FriendService.friends(bob).some((f) => f.low_id === alice.low_id))
check('current_entry null after remove', FriendService.current_entry(alice.low_id, bob.low_id) === null)
expectError(FriendError, 'remove() non-existing raises', () => FriendService.remove(alice, bob.low_id))

// --- legacy Friends migration ----------------------------------------------------
const dave = makeAccount('Dave')
const erin = makeAccount('Erin')
const frank = makeAccount('Frank')
dave.Friends = { legacy1: { lowID: erin.low_id }, legacy2: JSON.stringify({ lowID: frank.low_id }), raw: erin.low_id }
const friends = FriendService.friends(dave)
check('legacy Friends migrated to friend_relations', friends.some((f) => f.low_id === erin.low_id && f.state === 4))
check('legacy second entry migrated', friends.some((f) => f.low_id === frank.low_id && f.state === 4))
check('legacy Friends cleared in-memory', Object.keys(dave.Friends).length === 0)
check('reverse relation persisted', FriendService.friends(erin).some((f) => f.low_id === dave.low_id))

// --- presence service -----------------------------------------------------------
const registry = { Clients: {}, RegistryLock: null }
PresenceService.bind_clients(registry)
const now = Math.floor(Date.now() / 1000)
registry.Clients[String(frank.low_id)] = { SocketInfo: null, Status: 3, StatusSince: now - 42, LastActivity: now - 42 }
check('status() reads registry', PresenceService.status(frank.low_id, 0) === 3)
check('status() offline fallback', PresenceService.status(999999, 0) === 0)
check('elapsed() non-activity status returns 0', PresenceService.elapsed(3, now - 42) === 0)
check('elapsed() status 0 tracks time', PresenceService.elapsed(0, now - 10) >= 10)
check('elapsed() status 6 tracks time', PresenceService.elapsed(6, now - 5) >= 5)
check('elapsed() offline no activity returns -1', PresenceService.elapsed(6, null) === -1)
check('elapsed() clamps future activity', PresenceService.elapsed(0, now + 999) === 0)

// --- social_peers ------------------------------------------------------------------
const davePeers = PresenceService.social_peers(dave.low_id)
check('social_peers includes friends', davePeers.includes(erin.low_id) && davePeers.includes(frank.low_id))
check('social_peers no club mates alone', davePeers.length === 2)
// co-club peers
ClubService.join(dave, 777001)
const carolPeers = PresenceService.social_peers(carol.low_id)
check('social_peers includes co-club', carolPeers.includes(dave.low_id))
const davePeers2 = PresenceService.social_peers(dave.low_id)
check('social_peers union friends + club', davePeers2.includes(carol.low_id) && davePeers2.includes(erin.low_id))

// --- cleanup --------------------------------------------------------------------
console.log('')
console.log('SOCIAL SMOKE ' + (failed ? 'FAILED' : 'OK') + ': ' + passed + ' passed, ' + failed + ' failed')
if (failed) {
  process.exit(1)
}
