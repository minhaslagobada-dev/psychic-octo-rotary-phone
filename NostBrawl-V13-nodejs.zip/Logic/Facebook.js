'use strict'

class Facebook {
  static AppID = '103121310241222'
}

module.exports = Facebook
