'use strict'
const table = require('./MathTables.json').sqrt
// Original LogicMath::sqrt at0x28fc2c. Preserve its table/Newton branches,
// including the special INT_MAX return, rather than substituting host sqrt.
function sqrt (value) {
  const n = value | 0
  if (n < 0) return -1
  if (n < 256) return table[n] >> 4
  let estimate
  if (n < 65536) {
    if (n < 1024) estimate = table[n >>> 2] >> 3
    else if (n < 4096) estimate = table[n >>> 4] >> 2
    else if (n < 16384) estimate = table[n >>> 6] >> 1
    else estimate = table[n >>> 8]
    return estimate + (Math.imul(estimate + 1, estimate + 1) <= n ? 1 : 0)
  }
  let shift, scale, twice = false
  if (n < 16777216) {
    if (n < 262144) { shift = 10; scale = 1 }
    else if (n < 1048576) { shift = 12; scale = 2 }
    else if (n < 4194304) { shift = 14; scale = 3 }
    else { shift = 16; scale = 4 }
  } else {
    twice = true
    if (n < 67108864) { shift = 18; scale = 5 }
    else if (n < 268435456) { shift = 20; scale = 6 }
    else if (n < 1073741824) { shift = 22; scale = 7 }
    else {
      if (n === 2147483647) return 65535
      shift = 24; scale = 8
    }
  }
  estimate = table[n >> shift] << scale
  estimate = ((estimate | 1) + Math.trunc(n / estimate)) >> 1
  if (twice) estimate = (estimate + Math.trunc(n / estimate) + 1) >> 1
  return estimate - (Math.imul(estimate, estimate) > n ? 1 : 0)
}
function distance (a, b) {
  const dx = (b.x - a.x) | 0; const dy = (b.y - a.y) | 0
  return sqrt((Math.imul(dx, dx) + Math.imul(dy, dy)) | 0)
}
module.exports = { sqrt, distance }
