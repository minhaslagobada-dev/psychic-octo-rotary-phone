'use strict'
const assert = require('node:assert/strict')
const { battleAssets } = require('../Logic/Battle/World/BattleAssets')
const { BattleWorld } = require('../Logic/Battle/Game/BattleWorld')
const { TileMap } = require('../Logic/Battle/World/TileMap')
const { spreadFor, direction } = require('../Logic/Battle/Game/ProjectileGeometry')
const assets = battleAssets()
function arena (hero = 9, seed = 12345) {
  const players = Array.from({ length: 6 }, (_, i) => ({ index: i, team: i < 3 ? 0 : 1, player: { low_id: i + 1, brawler_id: hero } }))
  const w = new BattleWorld('trajectory', assets, 7, players, seed)
  w.map = new TileMap(Array(33).fill('.'.repeat(21)), assets)
  for (const p of players) p.ready = true
  w.step()
  const own = w.characters.get(1)
  for (const c of w.characters.values()) Object.assign(c, { x: 5000, y: 8000 })
  Object.assign(own, { x: 1500, y: 1500 })
  return { w, own }
}
function shot (world, own, skillName, x, y) {
  const s = assets.named('skills', skillName)
  return world.projectile(s.Projectile, own, Math.atan2(y - own.y, x - own.x), 1000,
    { slot: 0, definition: s, target: { x, y } })
}
// Fixed launch time, independent of distance: Brock's barrage.
for (const reach of [400, 2200]) {
  const { w, own } = arena(3)
  const p = shot(w, own, 'RocketGirlUlti', own.x, own.y + reach)
  assert.equal(p.flightTicks, 21)
  assert(p.z > 0 && p.age === 2, 'EarlyTicks advances the visible launch, including height')
  for (let i = 0; i < 18; i++) w.step()
  assert(w.objects.has(p.id), 'ConstantFlyTime must not explode early for a close target')
  w.step(); assert(!w.objects.has(p.id))
  assert.equal(p.x, p.target.x); assert.equal(p.y, p.target.y)
}
// Dynamike's fuse is absolute from launch; arrival must not start a second fuse.
for (const reach of [200, 2100]) {
  const { w, own } = arena()
  const p = shot(w, own, 'TntDudeWeapon', own.x, own.y + reach)
  assert.equal(p.fuseTick, 22)
  for (let i = 0; i < 21; i++) w.step()
  assert(w.objects.has(p.id))
  w.step(); assert(!w.objects.has(p.id), 'Dynamike explodes at tick22, regardless of target distance')
  assert(Array.from(w.objects.values()).some(o => o.dataClass === 17))
}
// Seeded scatter must be reproducible, vary between volleys, and remain in-map.
const a = arena(3, 7), b = arena(3, 7), endpoints = []
for (let i = 0; i < 10; i++) {
  const p = shot(a.w, a.own, 'RocketGirlUlti', 1500, 2000)
  const q = shot(b.w, b.own, 'RocketGirlUlti', 1500, 2000)
  assert.deepEqual(p.target, q.target)
  assert(p.target.x > 0 && p.target.x < a.w.map.logicWidth)
  endpoints.push(JSON.stringify(p.target))
}
assert(new Set(endpoints).size > 1)
assert.deepEqual(Array.from({ length: 3 }, (_, i) => spreadFor(30, 2, i, 3, 0, 1)), [-30, 0, 30])
assert.deepEqual(Array.from({ length: 5 }, (_, i) => spreadFor(60, 0, 0, 1, i, 5)), [-60, -30, 0, 30, 60])
assert(direction(0, 1000, -60) < Math.PI / 2)
assert(direction(0, 1000, 60) > Math.PI / 2)
// Rico collision reflects, announces actual tile index and extends range by500.
{
  const { w, own } = arena(4)
  const grid = Array(33).fill('.'.repeat(21)).map(s => s.split(''))
  const wallCode = Array.from(assets.tileCodes).find(([code, row]) => row.BlocksProjectiles === 'true' && row.BlocksMovement === 'true')[0]
  for (let y = 0; y < 33; y++) grid[y][8] = wallCode
  w.map = new TileMap(grid.map(row => row.join('')), assets)
  const p = shot(w, own, 'TrickshotDudeWeapon', 3500, 1500)
  const initialRange = p.totalRange
  for (let i = 0; i < 8 && !p.bounces; i++) w.step()
  assert.equal(p.bounces, 1)
  assert.equal(p.bounceTileIndex % 21, 8)
  assert([4, 5].includes(Math.floor(p.bounceTileIndex / 21)))
  assert.equal(p.totalRange, initialRange + 500)
  assert(Math.cos(p.rotation) < 0)
}
console.log('PROJECTILES OK: constant flight, launch fuse, early ticks, deterministic scatter, spread and Rico wall bounce')
