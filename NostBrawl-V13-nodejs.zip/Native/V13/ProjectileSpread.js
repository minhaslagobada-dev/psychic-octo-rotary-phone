'use strict'
const { sqrt } = require('./Math')
const { nextInt } = require('./Random')
const div = (a, b) => b === 0 ? 0 : Math.trunc(a / b) | 0
const length = (x, y) => sqrt((Math.imul(x, x) + Math.imul(y, y)) | 0)
// Original shootProjectile 0x4a02b4..0x4a05ac. The caller supplies the
// original object's position and the battle's current RNG state.
function spreadTarget ({ origin, target, spread, deterministic, pattern, data, rngState, width, height }) {
  const dx = (target[0] - origin[0]) | 0
  const dy = (target[1] - origin[1]) | 0
  const distance = length(dx, dy)
  const absolute = spread < 0 ? -spread | 0 : spread | 0
  const amplitude = data.constantFlyTime ? Math.imul(absolute, 3) : div(Math.imul(absolute, distance), 300)
  if (amplitude < 3) return { target: [...target], rngState }
  let x = 0; let y = 0
  function random (bound) {
    const result = nextInt(rngState, bound)
    rngState = result.nextState
    return result.value
  }
  if (deterministic) {
    x = -dy | 0; y = dx
    const normalizer = length(x, y)
    if (normalizer !== 0) { x = div(Math.imul(x, amplitude), normalizer); y = div(Math.imul(y, amplitude), normalizer) }
    if (spread < 0) { x = -x | 0; y = -y | 0 }
  } else if (pattern === 0 || pattern === 1) {
    const bound = pattern === 1 ? div(amplitude, 3) : amplitude
    x = (Math.imul(random(bound), 2) - (bound - 1)) | 0
    y = (Math.imul(random(bound), 2) - (bound - 1)) | 0
  } else if (pattern >= 2 && pattern <= 5) {
    const halfX = div(random(amplitude), 2)
    const halfY = div(random(amplitude), 2)
    x = pattern === 3 || pattern === 5 ? amplitude - 1 - halfX : halfX - (amplitude - 1)
    y = pattern >= 4 ? amplitude - 1 - halfY : halfY - (amplitude - 1)
  }
  x = (x + target[0]) | 0; y = (y + target[1]) | 0
  if (data.indirect) {
    x = Math.max(1, Math.min(width - 2, x)); y = Math.max(1, Math.min(height - 2, y))
  } else {
    let changedX = (x - origin[0]) | 0; let changedY = (y - origin[1]) | 0
    const normalizer = length(changedX, changedY)
    if (normalizer !== 0) { changedX = div(Math.imul(changedX, distance), normalizer); changedY = div(Math.imul(changedY, distance), normalizer) }
    x = (origin[0] + changedX) | 0; y = (origin[1] + changedY) | 0
  }
  return { target: [x, y], rngState }
}
module.exports = { spreadTarget }
