'use strict'
const { apply_battle_result_rewards } = require('../../../../Logic/BattleResultAdapter')
const BattleResultMessage = require('./BattleResultMessage')

class BattleResultShowdownMessage extends BattleResultMessage {
  static get GAME_MODE () { return 2 }

  _get_rewards (battleId) {
    if (battleId === null || battleId === undefined) {
      return apply_battle_result_rewards(this.player, 2)
    }
    return apply_battle_result_rewards(this.player, 2, battleId)
  }
}

module.exports = BattleResultShowdownMessage
