'use strict'
const Writer = require('../../../../Utils/Writer')

class TeamStreamMessage extends Writer {
  constructor (client, player, room = null, entries = null) {
    super(client)
    this.enable_native_v13()
    this.id = 24131
    this.player = player
    this.room = room
    this.entries = entries
  }

  _base (entry) {
    this.writeVint(0)
    this.writeVint(entry.id)
    this.writeVint(0)
    this.writeVint(entry.player_id)
    this.writeString(entry.player_name)
    this.writeVint(entry.player_role !== undefined ? entry.player_role : 0)
    const age = Math.max(0, Math.floor(Date.now() / 1000) - Math.trunc(entry.created_at))
    this.writeVint(age)
    this.writeBoolean(false)
  }

  encode () {
    let room = this.room
    if (room === null || room === undefined) {
      const { GameRoomService } = require('../../../../Logic/GameRoomService')
      room = GameRoomService.for_player(this.player)
    }
    const roomId = room !== null && room !== undefined ? Math.trunc(room.id) : 0
    let entries = this.entries
    if ((entries === null || entries === undefined) && room !== null && room !== undefined) {
      const { GameRoomService } = require('../../../../Logic/GameRoomService')
      entries = GameRoomService.stream(roomId)
    }
    entries = entries || []
    this.writeVint(0)
    this.writeVint(roomId)
    this.writeVint(entries.length)
    for (const entry of entries) {
      const kind = Math.trunc(entry.kind)
      this.writeVint(kind)
      this._base(entry)
      if (kind === 2) {
        this.writeString(entry.message)
      } else if (kind === 4) {
        this.writeVint(entry.event)
        this.writeBoolean(true)
        this.writeVint(0)
        this.writeVint(entry.target_id)
        this.writeString(entry.target_name)
      } else {
        throw new Error(`Unknown team stream entry: ${kind}`)
      }
    }
  }
}

module.exports = TeamStreamMessage
