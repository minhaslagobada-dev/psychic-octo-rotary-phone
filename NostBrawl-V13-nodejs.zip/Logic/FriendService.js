'use strict'

const DataBase = require('../Database/DatabaseManager')
const PresenceService = require('./PresenceService')
const { ValueError } = require('../Utils/Errors')

class FriendError extends ValueError {
  constructor (message) {
    super(message)
    this.name = 'FriendError'
  }
}

class FriendService {
  static get FRIEND () { return 4 }
  static get OUTGOING () { return 2 }
  static get INCOMING () { return 3 }
  static get SUGGESTION () { return 1 }

  static _now () {
    return Math.floor(Date.now() / 1000)
  }

  static _account_id (player) {
    const lowId = Math.trunc(Number(player.low_id ?? 0)) || 0
    if (lowId <= 0) {
      throw new FriendError('Conta inválida')
    }
    return lowId
  }

  static _migrate_legacy (connection, player) {
    const lowId = FriendService._account_id(player)
    const legacy = player.Friends !== undefined ? player.Friends : {}
    if (typeof legacy !== 'object' || legacy === null || Array.isArray(legacy) || !Object.keys(legacy).length) {
      return
    }
    const targets = new Set()
    for (let value of Object.values(legacy)) {
      if (typeof value === 'string') {
        try {
          value = JSON.parse(value)
        } catch (error) {
          continue
        }
      }
      if (typeof value === 'object' && value !== null) {
        value = value.lowID !== undefined ? value.lowID : value.low_id
      }
      const target = Math.trunc(Number(value))
      if (!Number.isNaN(target) && target > 0 && target !== lowId) {
        targets.add(target)
      }
    }
    const now = FriendService._now()
    for (const target of targets) {
      const exists = connection.prepare('SELECT 1 FROM players WHERE lowID = ?').get(target)
      if (exists === undefined) {
        continue
      }
      for (const [owner, friend] of [[lowId, target], [target, lowId]]) {
        connection.prepare(
          'INSERT OR IGNORE INTO friend_relations(owner_id, friend_id, state, created_at, updated_at) VALUES(?, ?, 4, ?, ?)'
        ).run(owner, friend, now, now)
      }
    }
    DataBase._write_state(connection, lowId, 'Friends', {})
    player.Friends = {}
  }

  static _relation (connection, owner, friend) {
    const row = connection.prepare(
      'SELECT state, origin FROM friend_relations WHERE owner_id = ? AND friend_id = ?'
    ).get(owner, friend)
    return row === undefined ? null : [Math.trunc(row.state), Math.trunc(row.origin)]
  }

  static _state (connection, owner, friend) {
    const relation = FriendService._relation(connection, owner, friend)
    return relation === null ? null : relation[0]
  }

  static _set_state (connection, owner, friend, state, now, origin = null) {
    if (origin === null || origin === undefined) {
      connection.prepare(
        'INSERT INTO friend_relations(owner_id, friend_id, state, created_at, updated_at) ' +
        'VALUES(?, ?, ?, ?, ?) ON CONFLICT(owner_id, friend_id) DO UPDATE SET ' +
        'state = excluded.state, updated_at = excluded.updated_at'
      ).run(owner, friend, state, now, now)
      return
    }
    connection.prepare(
      'INSERT INTO friend_relations(owner_id, friend_id, state, origin, created_at, updated_at) ' +
      'VALUES(?, ?, ?, ?, ?, ?) ON CONFLICT(owner_id, friend_id) DO UPDATE SET ' +
      'state = excluded.state, origin = excluded.origin, updated_at = excluded.updated_at'
    ).run(owner, friend, state, Math.trunc(origin), now, now)
  }

  static _entry (connection, owner, friend, state = null, origin = null) {
    const row = connection.prepare(
      'SELECT p.lowID, p.name, p.trophies, p.profileIcon, p.clubID, p.online, ' +
      'c.id AS clubId, c.name AS clubName, sp.last_activity_at FROM players p ' +
      'LEFT JOIN clubs c ON c.id = p.clubID ' +
      'LEFT JOIN social_presence sp ON sp.player_id = p.lowID ' +
      'WHERE p.lowID = ?'
    ).get(friend)
    if (row === undefined) {
      return null
    }
    const relation = FriendService._relation(connection, owner, friend)
    if (state === null || state === undefined) {
      state = relation === null ? 0 : relation[0]
    }
    if (origin === null || origin === undefined) {
      origin = relation === null ? 0 : relation[1]
    }
    const progression = DataBase._read_state(connection, friend, 'progression')
    let club = null
    if (row.clubId !== null && row.clubId !== undefined) {
      club = { id: Math.trunc(row.clubId), name: String(row.clubName || '') }
    }
    const status = PresenceService.status(friend, row.online)
    return {
      high_id: 0,
      low_id: Math.trunc(row.lowID),
      name: String(row.name || ''),
      facebook_id: progression.isFBLinked ? String(progression.facebookID || '') : '',
      game_center_id: String(progression.gameCenterID || '') || '',
      state: Math.trunc(state),
      origin: Math.trunc(origin),
      status,
      last_seen_seconds: PresenceService.elapsed(status, row.last_activity_at !== undefined ? row.last_activity_at : null),
      trophies: Math.trunc(row.trophies || 0),
      profile_icon: 28000000 + Math.trunc(row.profileIcon || 0),
      club
    }
  }

  static _friends (connection, owner) {
    const rows = connection.prepare(
      'SELECT friend_id, state FROM friend_relations WHERE owner_id = ? ORDER BY updated_at DESC, friend_id'
    ).all(owner)
    const entries = []
    for (const row of rows) {
      const entry = FriendService._entry(connection, owner, row.friend_id, row.state)
      if (entry !== null) {
        entries.push(entry)
      }
    }
    return entries
  }

  static add (player, friendId, source = 0) {
    const owner = FriendService._account_id(player)
    friendId = Math.trunc(friendId)
    source = Math.trunc(source)
    if (!(source >= 0 && source <= 4)) {
      throw new FriendError('Origem de amizade inválida')
    }
    if (owner === friendId) {
      throw new FriendError('Não é possível adicionar a própria conta')
    }
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      FriendService._migrate_legacy(connection, player)
      if (FriendService._entry(connection, owner, friendId) === null) {
        throw new FriendError('Conta de amizade inexistente')
      }
      const state = FriendService._state(connection, owner, friendId)
      const reverse = FriendService._state(connection, friendId, owner)
      const now = FriendService._now()
      let newState
      if (state === FriendService.FRIEND || reverse === FriendService.FRIEND) {
        FriendService._set_state(connection, owner, friendId, FriendService.FRIEND, now)
        FriendService._set_state(connection, friendId, owner, FriendService.FRIEND, now)
        newState = FriendService.FRIEND
      } else if (state === FriendService.INCOMING || reverse === FriendService.OUTGOING) {
        FriendService._set_state(connection, owner, friendId, FriendService.FRIEND, now)
        FriendService._set_state(connection, friendId, owner, FriendService.FRIEND, now)
        newState = FriendService.FRIEND
      } else if (state === FriendService.OUTGOING || reverse === FriendService.INCOMING) {
        FriendService._set_state(connection, owner, friendId, FriendService.OUTGOING, now)
        FriendService._set_state(connection, friendId, owner, FriendService.INCOMING, now)
        newState = FriendService.OUTGOING
      } else {
        FriendService._set_state(connection, owner, friendId, FriendService.OUTGOING, now, source)
        FriendService._set_state(connection, friendId, owner, FriendService.INCOMING, now, source)
        newState = FriendService.OUTGOING
      }
      const reverseState = FriendService._state(connection, friendId, owner)
      const entry = FriendService._entry(connection, owner, friendId, newState)
      const reverseEntry = FriendService._entry(connection, friendId, owner, reverseState)
      return {
        state: newState,
        accepted: newState === FriendService.FRIEND,
        entry,
        reverse_entry: reverseEntry,
        friend_id: friendId
      }
    }, true)
  }

  static accept (player, friendId) {
    const owner = FriendService._account_id(player)
    friendId = Math.trunc(friendId)
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      FriendService._migrate_legacy(connection, player)
      const state = FriendService._state(connection, owner, friendId)
      const now = FriendService._now()
      if (state === FriendService.FRIEND) {
        FriendService._set_state(connection, owner, friendId, FriendService.FRIEND, now)
        FriendService._set_state(connection, friendId, owner, FriendService.FRIEND, now)
      } else if (state === FriendService.INCOMING) {
        FriendService._set_state(connection, owner, friendId, FriendService.FRIEND, now)
        FriendService._set_state(connection, friendId, owner, FriendService.FRIEND, now)
      } else {
        throw new FriendError('Pedido de amizade recebido inexistente')
      }
      const entry = FriendService._entry(connection, owner, friendId, FriendService.FRIEND)
      const reverseEntry = FriendService._entry(connection, friendId, owner, FriendService.FRIEND)
      return { state: FriendService.FRIEND, accepted: true, entry, reverse_entry: reverseEntry, friend_id: friendId }
    }, true)
  }

  static remove (player, friendId) {
    const owner = FriendService._account_id(player)
    friendId = Math.trunc(friendId)
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      FriendService._migrate_legacy(connection, player)
      if (
        FriendService._state(connection, owner, friendId) === null &&
        FriendService._state(connection, friendId, owner) === null
      ) {
        throw new FriendError('Relação de amizade inexistente')
      }
      const entry = FriendService._entry(connection, owner, friendId)
      const reverseEntry = FriendService._entry(connection, friendId, owner)
      if (entry === null || reverseEntry === null) {
        throw new FriendError('Conta de amizade inexistente')
      }
      connection.prepare(
        'DELETE FROM friend_relations WHERE (owner_id = ? AND friend_id = ?) ' +
        'OR (owner_id = ? AND friend_id = ?)'
      ).run(owner, friendId, friendId, owner)
      const entries = FriendService._friends(connection, owner)
      const reverseEntries = FriendService._friends(connection, friendId)
      return {
        entry,
        reverse_entry: reverseEntry,
        entries,
        reverse_entries: reverseEntries,
        friend_id: friendId,
        removed: true
      }
    }, true)
  }

  static friends (player) {
    const owner = FriendService._account_id(player)
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      FriendService._migrate_legacy(connection, player)
      return FriendService._friends(connection, owner)
    }, true)
  }

  static friends_for_account (lowId) {
    return DataBase._connection((connection) => {
      return FriendService._friends(connection, Math.trunc(lowId))
    })
  }

  static current_entry (owner, friend) {
    return DataBase._connection((connection) => {
      if (FriendService._relation(connection, Math.trunc(owner), Math.trunc(friend)) === null) {
        return null
      }
      return FriendService._entry(connection, Math.trunc(owner), Math.trunc(friend))
    })
  }

  static push_presence (player) {
    return FriendService.push_account(player, FriendService._account_id(player))
  }

  static push_account (sender, playerId) {
    const owner = Math.trunc(playerId)
    if (owner <= 0) {
      throw new FriendError('Conta inválida')
    }
    const rows = DataBase._connection((connection) => {
      return connection.prepare('SELECT owner_id FROM friend_relations WHERE friend_id = ?').all(owner)
    })
    const FriendListMessage = require('../Packets/Messages/Server/Friend/FriendListMessage')
    let delivered = 0
    for (const row of rows) {
      const recipient = Math.trunc(row.owner_id)
      if (new FriendListMessage(null, sender, null, true).sendWithLowID(recipient)) {
        delivered += 1
      }
    }
    return delivered
  }

  static suggestions (player, limit = 20) {
    const owner = FriendService._account_id(player)
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      FriendService._migrate_legacy(connection, player)
      const rows = connection.prepare(
        'SELECT lowID FROM players p WHERE p.lowID <> ? AND NOT EXISTS(' +
        'SELECT 1 FROM friend_relations r WHERE ' +
        '(r.owner_id = ? AND r.friend_id = p.lowID) OR ' +
        '(r.owner_id = p.lowID AND r.friend_id = ?)' +
        ') ORDER BY p.online DESC, p.trophies DESC, p.lowID LIMIT ?'
      ).all(owner, owner, owner, Math.min(100, Math.max(1, Math.trunc(limit))))
      return rows.map((row) => FriendService._entry(connection, owner, row.lowID, FriendService.SUGGESTION))
    }, true)
  }

  static addable (player, facebookIds, gameCenterIds) {
    const owner = FriendService._account_id(player)
    facebookIds = new Set((facebookIds || []).map((value) => String(value)).filter((value) => value))
    gameCenterIds = new Set((gameCenterIds || []).map((value) => String(value)).filter((value) => value))
    return DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      FriendService._migrate_legacy(connection, player)
      const rows = connection.prepare('SELECT lowID FROM players WHERE lowID <> ?').all(owner)
      const result = []
      for (const row of rows) {
        const friendId = row.lowID
        if (
          FriendService._state(connection, owner, friendId) !== null ||
          FriendService._state(connection, friendId, owner) !== null
        ) {
          continue
        }
        const progression = DataBase._read_state(connection, friendId, 'progression')
        const facebook = String(progression.facebookID || '') || ''
        const gameCenter = String(progression.gameCenterID || '') || ''
        if (!facebookIds.has(facebook) && !gameCenterIds.has(gameCenter)) {
          continue
        }
        const entry = FriendService._entry(connection, owner, friendId, FriendService.SUGGESTION)
        if (entry !== null) {
          result.push(entry)
        }
      }
      return result
    }, true)
  }

  static set_facebook (player, facebookId = '', facebookToken = '', linked = true) {
    const lowId = FriendService._account_id(player)
    facebookId = String(facebookId || '')
    facebookToken = String(facebookToken || '')
    if (linked && (!facebookId || !facebookToken)) {
      throw new FriendError('Credenciais Facebook incompletas')
    }
    const progression = DataBase._connection((connection) => {
      connection.exec('BEGIN IMMEDIATE')
      const row = connection.prepare('SELECT 1 FROM players WHERE lowID = ?').get(lowId)
      if (row === undefined) {
        throw new FriendError('Conta não encontrada')
      }
      const current = DataBase._read_state(connection, lowId, 'progression')
      current.isFBLinked = Boolean(linked)
      current.facebookID = linked ? facebookId : ''
      current.facebookToken = linked ? facebookToken : ''
      DataBase._write_state(connection, lowId, 'progression', current)
      return current
    }, true)
    player.progression = progression
    player.IsFacebookLinked = Number(Boolean(linked))
    player.FacebookID = progression.facebookID
    player.FacebookToken = progression.facebookToken
    return progression
  }
}

module.exports = { FriendService, FriendError }
module.exports.default = FriendService
