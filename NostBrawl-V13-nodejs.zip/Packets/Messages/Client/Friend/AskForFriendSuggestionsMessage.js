'use strict'
const { FriendService } = require('../../../../Logic/FriendService')
const FriendSuggestionsMessage = require('../../Server/Friend/FriendSuggestionsMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AskForFriendSuggestionsMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.ensure_end()
  }

  process () {
    const entries = FriendService.suggestions(this.player)
    new FriendSuggestionsMessage(this.client, this.player, entries).send()
    return entries
  }
}

module.exports = AskForFriendSuggestionsMessage
