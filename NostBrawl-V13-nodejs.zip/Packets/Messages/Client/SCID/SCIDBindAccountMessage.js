'use strict'

const crypto = require('crypto')
const process = require('process')

const SCIDAccountBoundMessage = require('../../Server/SCID/SCIDAccountBoundMessage')
const { decode_compressed_string } = require('../../../../SCIDClient/Protocol')
const { get_service } = require('../../../../SCIDClient/Runtime')
const { SCIDError } = require('../../../../SCIDClient/Models')
const { BSMessageReader } = require('../../../../Utils/Reader')

function compare_digest (left, right) {
  const a = Buffer.from(String(left === null || left === undefined ? '' : left))
  const b = Buffer.from(String(right === null || right === undefined ? '' : right))
  if (a.length !== b.length) {
    return false
  }
  return crypto.timingSafeEqual(a, b)
}

class SCIDBindAccountMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.client = client
    this.player = player
    this.initial_bytes = initialBytes
    this.bind_token = ''
    this.scid_token = ''
  }

  decode () {
    this.enable_native_v13()
    const first = decode_compressed_string(this.initial_bytes, 0)
    this.bind_token = first[0]
    const second = decode_compressed_string(this.initial_bytes, first[1])
    this.scid_token = second[0]
    const end = second[1]
    if (end !== this.initial_bytes.length) {
      throw new Error('Dados residuais após SCIDBindAccountMessage')
    }
    this._offset = end
  }

  process () {
    const lowId = Math.trunc((this.player && this.player.low_id) || 0)
    let account
    let boundToken
    let changed
    try {
      if (lowId <= 0) {
        throw new SCIDError('invalid_game_credentials')
      }
      const service = get_service()
      if (service === null || service === undefined) {
        throw new SCIDError('scid_disabled')
      }
      account = service.authenticate(this.scid_token)
      if (account === null || account === undefined || !compare_digest(account.bind_token, this.bind_token)) {
        throw new SCIDError('invalid_token')
      }
      changed = service.link_game(account, lowId)
      account = service.store.by_id(account.id)
      if (account === null || account === undefined || account.game_low_id !== lowId) {
        throw new SCIDError('game_account_bound')
      }
      boundToken = service.tokens.issue(account)
    } catch (error) {
      if (!(error instanceof SCIDError)) {
        throw error
      }
      process.emitWarning(
        `SCID bind rejected for game ${lowId}: ${error.code || error.message}`
      )
      new SCIDAccountBoundMessage(this.client, this.player, 1, '').send()
      return { linked: false, error: error.code }
    }

    this.player.scid_account = account
    this.player.scid_token = boundToken
    new SCIDAccountBoundMessage(this.client, this.player, 0, boundToken).send()
    return { linked: true, changed }
  }
}

module.exports = SCIDBindAccountMessage
