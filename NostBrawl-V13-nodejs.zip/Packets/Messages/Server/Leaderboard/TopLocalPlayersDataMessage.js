'use strict'

const { LeaderboardService } = require('../../../../Logic/LeaderboardService')
const LeaderboardMessage = require('./LeaderboardMessage')

class GetLeaderboardLocalOkMessage extends LeaderboardMessage {
  constructor (client, player, players = null) {
    if (players === null) {
      players = LeaderboardService.players()
    }
    super(client, player, 1, true, players)
  }
}

module.exports = GetLeaderboardLocalOkMessage
