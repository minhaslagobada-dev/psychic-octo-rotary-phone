'use strict'
const { FriendService, FriendError } = require('../../../../Logic/FriendService')
const FacebookBindOKMessage = require('../../Server/Friend/Events/FacebookBindOKMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class FacebookConnect extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
    this.facebook_id = ''
    this.facebook_token = ''
  }

  decode () {
    this.read_Vint()
    this.facebook_id = this.read_string()
    this.facebook_token = this.read_string()
  }

  process () {
    let progression
    try {
      progression = FriendService.set_facebook(
        this.player, this.facebook_id, this.facebook_token, true
      )
    } catch (error) {
      if (error instanceof FriendError || error instanceof TypeError || error instanceof ValueError) {
        return { linked: false, error: String(error.message !== undefined ? error.message : error) }
      }
      throw error
    }
    new FacebookBindOKMessage(this.client, this.player).send()
    return { linked: true, progression }
  }
}

module.exports = FacebookConnect
