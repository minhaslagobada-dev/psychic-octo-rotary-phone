'use strict'
// Port of validate_header_native.py.
const { NativeV13 } = require('./emulate_v13')
const R = require('./lib/research')
const { C } = R
R.main(async () => {
  const n = await NativeV13.create(); const state = {}; const m = R.memory(n)
  const word = m.u32; const put = m.put32; const pp = m.put64
  n.hooks.set(0x2966c8, () => state.tileMap)
  n.hooks.set(0x3226e8, () => 0)
  n.hooks.set(0x11997c, () => (state.tile.IsDestructible === 'true' ? 1 : 0))
  n.hooks.set(0x53de84, () => (state.tile.IsDestructibleNormalWeapon === 'true' && (state.tile.BlocksMovement === 'true' || state.tile.BlocksProjectiles === 'true') ? 1 : 0))
  const tile = () => {
    const x = Number(n.uc.reg_read(C.UC_ARM64_REG_W1)); const y = Number(n.uc.reg_read(C.UC_ARM64_REG_W2)); const v = state.v
    const code = [...v.grid[y]][x]
    state.tile = Object.prototype.hasOwnProperty.call(state.defs, code) ? state.defs[code] : state.defs['.']; return state.tilePtr
  }
  n.hooks.set(0x14c61c, tile)
  const stop = (uc, a, size, d) => uc.emu_stop()
  n.uc.hook_add(C.UC_HOOK_CODE, stop, null, 0x139888, 0x139888)
  n.prepare_hooks()
  const vectors = R.vectors('header-vectors.json')
  for (const v of vectors) {
    n.heap = 0x10000000; const manager = n.alloc(0x100); const battle = n.alloc(0x200); const mapMeta = n.alloc(0x100); const tiles = n.alloc(0x80); const tileptr = n.alloc(16); const stream = n.alloc(0x30); const payload = n.alloc(4096); const players = n.alloc(16); const parray = n.alloc(v.capacity * 8); const extra = n.alloc(16)
    for (const [a, size] of [[manager, 0x100], [battle, 0x200], [mapMeta, 0x100], [stream, 0x30], [extra, 16]]) n.uc.mem_write(a, Buffer.alloc(size))
    pp(battle + 0xc8, mapMeta); put(battle + 0xfc, v.mode); put(mapMeta + 0x40, [...v.grid[0]].length); pp(tileptr + 8, mapMeta)
    pp(players, parray); put(players + 0xc, v.capacity)
    for (let i = 0; i < v.capacity; i++) { const p = n.alloc(0x100); n.uc.mem_write(p, Buffer.alloc(0x100)); put(p + 0x20, i); pp(parray + i * 8, p) }
    const data = Buffer.from(v.hex, 'hex'); n.uc.mem_write(payload, data); pp(stream + 24, payload); put(stream + 12, data.length)
    const defs = {}; for (const t of v.tiles) defs[t.TileCode] = t
    Object.assign(state, { v, defs, tileMap: tiles, tilePtr: tileptr })
    n.uc.reg_write(C.UC_ARM64_REG_SP, 0x201ff000); n.uc.reg_write(C.UC_ARM64_REG_LR, 0x40000000)
    ;[manager, stream, players, 0, battle, extra].forEach((arg, i) => n.uc.reg_write(C.UC_ARM64_REG_X0 + i, arg))
    try {
      n.uc.emu_start(0x139398, 0x40000000, 0, 300000)
      const consumed = word(stream + 8) * 8 + word(stream + 16)
      R.assert(Number(n.uc.reg_read(C.UC_ARM64_REG_PC)) === 0x139888, R.hex(n.uc.reg_read(C.UC_ARM64_REG_PC)))
      R.assert(consumed === v.bits, [consumed, v.bits])
      R.assert(Number(n.uc.reg_read(C.UC_ARM64_REG_W0)) === 0, 'Native object count misaligned')
    } catch (e) { R.print(v.name, v.mode, 'FAIL', R.errorMessage(e)); throw e }
  }
  R.print('Native v13 world header decode passed:', vectors.length, 'locations')
})
