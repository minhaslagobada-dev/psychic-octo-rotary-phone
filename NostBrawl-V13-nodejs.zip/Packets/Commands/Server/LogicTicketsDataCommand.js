'use strict'

const LogicBuyItem = require('./LogicBuyItem')

class LogicTicketsDataCommand extends LogicBuyItem {
  constructor (client, player, count) {
    super(
      client,
      player,
      [{ type: 3, amount: Math.trunc(count) }],
      player.trophy_road
    )
  }
}

module.exports = LogicTicketsDataCommand
