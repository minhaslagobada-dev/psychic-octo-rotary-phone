'use strict'

const crypto = require('crypto')

// Assinatura de chamadas internas loja↔jogo, mesmo disciplina do SCID
// (X-SCID-*): timestamp + nonce + HMAC-SHA256 sobre método/caminho/corpo,
// relay protegido por janela de 5 minutos e nonce único em memória.

const WINDOW_SECONDS = 300
const seenNonces = new Map()

function cleanupNonces (now) {
  for (const [nonce, at] of seenNonces) {
    if (now - at > WINDOW_SECONDS * 2) {
      seenNonces.delete(nonce)
    }
  }
}

function sign (key, method, path, timestamp, nonce, body) {
  const payload = Buffer.concat([
    Buffer.from(String(method).toUpperCase()),
    Buffer.from('|'),
    Buffer.from(String(path)),
    Buffer.from('|'),
    Buffer.from(String(timestamp)),
    Buffer.from('|'),
    Buffer.from(String(nonce)),
    Buffer.from('|'),
    Buffer.from(body || Buffer.alloc(0))
  ])
  return crypto.createHmac('sha256', Buffer.from(String(key), 'utf-8'))
    .update(payload)
    .digest('hex')
}

function verify (key, method, path, headers, body, now = null) {
  now = now === null ? Math.trunc(Date.now() / 1000) : now
  const timestamp = Number.parseInt(String(headers['x-store-timestamp'] || ''), 10)
  const nonce = String(headers['x-store-nonce'] || '')
  const signature = String(headers['x-store-signature'] || '').toLowerCase()
  if (!Number.isFinite(timestamp) || Math.abs(now - timestamp) > WINDOW_SECONDS) {
    return 'stale'
  }
  if (!nonce || nonce.length > 64 || !/^[0-9a-f]{64}$/.test(signature)) {
    return 'malformed'
  }
  cleanupNonces(now)
  if (seenNonces.has(nonce)) {
    return 'replay'
  }
  const expected = sign(key, method, path, timestamp, nonce, body)
  const a = Buffer.from(expected)
  const b = Buffer.from(signature)
  if (a.length !== b.length || !crypto.timingSafeEqual(a, b)) {
    return 'bad_signature'
  }
  seenNonces.set(nonce, now)
  return null
}

function headers (key, method, path, body) {
  const timestamp = Math.trunc(Date.now() / 1000)
  const nonce = crypto.randomBytes(16).toString('hex')
  return {
    'Content-Type': 'application/json',
    'X-Store-Timestamp': String(timestamp),
    'X-Store-Nonce': nonce,
    'X-Store-Signature': sign(key, method, path, timestamp, nonce, body || Buffer.alloc(0))
  }
}

module.exports = { sign, verify, headers, WINDOW_SECONDS }
