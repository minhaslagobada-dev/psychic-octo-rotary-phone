'use strict'

const AvatarNameCheckResponseMessage = require('../../Server/Home/AvatarNameCheckResponseMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class AvatarNameCheckRequestMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.player.name = this.read_string()
  }

  process () {
    new AvatarNameCheckResponseMessage(this.client, this.player).send()
  }
}

module.exports = AvatarNameCheckRequestMessage
