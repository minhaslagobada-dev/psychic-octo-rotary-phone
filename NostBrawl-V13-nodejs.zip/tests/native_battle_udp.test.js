'use strict'
const assert = require('node:assert/strict')
const dgram = require('node:dgram')
const { once } = require('node:events')
const { NativeBattleRuntime } = require('../Logic/Battle/NativeBattleRuntime')
const { nativeVisionPayload } = require('../Logic/Battle/NativeVision')
const { BattleTransport } = require('../Logic/Battle/Network/BattleTransport')
const { Reader, encodeInput, envelope, readEnvelope } = require('../Logic/Battle/Network/V13BattleCodec')
function receive (socket) {
  return new Promise((resolve, reject) => {
    const timer = setTimeout(() => { socket.off('message', done); reject(new Error('UDP response timed out')) }, 2000)
    const done = packet => { clearTimeout(timer); resolve(packet) }
    socket.once('message', done)
  })
}
async function main () {
  const runtime = new NativeBattleRuntime()
  const transport = new BattleTransport({ BindIP: '127.0.0.1', Port: 0, AdvertiseHost: '127.0.0.1' })
  const client = dgram.createSocket('udp4')
  const player = { logged_in: true, low_id: 1 }
  const tcp = { remoteAddress: '127.0.0.1', localAddress: '127.0.0.1' }
  try {
    await transport.start(); client.bind(0, '127.0.0.1'); await once(client, 'listening')
    const session = transport.attach(player, tcp)
    await runtime.create('udp', 'Gemgrab1', 17, [{ hero: 'ShotgunGirl', team: 0, accountId: 1, name: 'UDP native', powerLevel: 1 }])
    const payload = encodeInput({ tick: 0, sequence: 1, inputs: [{ counter: 1, category: 1, code: 100, x: 3150, y: 6150 }] })
    const accepted = once(transport, 'input')
    client.send(Buffer.concat([session.header, envelope(10555, payload)]), transport.gateway.port, '127.0.0.1')
    const [owner] = await accepted
    assert.equal(owner, session)
    const commands = session.input.drain()
    assert.equal(commands.length, 1)
    await runtime.input('udp', 0, encodeInput({ tick: 0, sequence: 1, inputs: commands }))
    let state
    for (let tick = 0; tick < 150; tick++) {
      const frame = await runtime.frame('udp'); state = frame.state
      const wire = nativeVisionPayload(frame.vision[0], session.input.lastAcknowledged)
      const packetPromise = receive(client)
      assert(transport.send(session, 24109, wire))
      const packet = await packetPromise
      assert.deepEqual(packet.subarray(0, 10), session.header)
      const message = readEnvelope(packet.subarray(10)); assert.equal(message.type, 24109)
      const reader = new Reader(message.payload)
      assert.equal(reader.vint(), tick); assert.equal(reader.vint(), 1)
      assert.equal(reader.vint(), 0); assert.equal(reader.vint(), 0)
      const length = reader.take(4).readInt32BE()
      assert.equal(reader.take(length).toString('hex'), frame.vision[0].hex); reader.end()
    }
    const actor = state.objects.find(object => object.id === state.players[0].characterId)
    assert.equal(actor.x, 3150); assert.equal(actor.y, 6150)
    assert.equal(transport.gateway.metrics.sent, 150)
    assert.equal(transport.gateway.metrics.malformed, 0)
    await runtime.destroy('udp')
    transport.release(player, tcp, 'battle-ended')
    assert.equal(player.udp_session, null)
    assert.equal(transport.gateway.sessions.size, 0)
    console.log('Real local UDP: authenticated input -> original native movement -> 150 original snapshots received byte-for-byte -> session cleanup')
  } finally {
    client.close(); await transport.close(); await runtime.close()
  }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
