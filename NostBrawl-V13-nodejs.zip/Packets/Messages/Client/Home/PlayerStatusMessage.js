'use strict'
const PresenceService = require('../../../../Logic/PresenceService')
const { BSMessageReader } = require('../../../../Utils/Reader')

class PlayerStatusMessage extends BSMessageReader {
  static get NATIVE_STATUSES () {
    return new Set([-1, 1, 2, 3, 4, 5, 7, 8, 10, 11])
  }

  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
  }

  decode () {
    this.enable_native_v13()
    this.status = this.read_Vint()
    this.ensure_end()
    if (!PlayerStatusMessage.NATIVE_STATUSES.has(this.status)) {
      throw new Error('Estado de presença inválido')
    }
  }

  process () {
    if (!PresenceService.set_status(this.player, this.status, this.client, true)) {
      throw new Error('Sessão de presença substituída')
    }
    PresenceService.publish(this.player)
    return this.status
  }
}

module.exports = PlayerStatusMessage
