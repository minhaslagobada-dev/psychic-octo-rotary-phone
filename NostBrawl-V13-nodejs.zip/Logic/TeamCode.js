'use strict'

const { ValueError } = require('../Utils/Errors')

class TeamCode {
  static get PREFIX () { return 'X' }
  static get ALPHABET () { return 'QWERTYUPASDFGHJKLZCVBNM23456789' }
  static get MAX_LOW_ID () { return 0x7fffffff }
  static get MAX_VALUE () { return TeamCode.MAX_LOW_ID * 256 + 0xff }

  static to_code (highId, lowId) {
    highId = Number(highId)
    lowId = Number(lowId)
    if (!Number.isInteger(highId) || !Number.isInteger(lowId)) {
      throw new ValueError('Código de equipe inválido')
    }
    if (!(highId >= 0 && highId < 256) || !(lowId >= 0 && lowId <= TeamCode.MAX_LOW_ID)) {
      throw new ValueError('Código de equipe inválido')
    }
    let value = lowId * 256 + highId
    let encoded = ''
    const base = TeamCode.ALPHABET.length
    while (value) {
      const index = value % base
      value = (value - index) / base
      encoded = TeamCode.ALPHABET[index] + encoded
    }
    return TeamCode.PREFIX + encoded
  }

  static to_id (code) {
    if (typeof code !== 'string' || !(code.length >= 1 && code.length < 14)) {
      throw new ValueError('Código de equipe inválido')
    }
    if (!code.startsWith(TeamCode.PREFIX)) {
      throw new ValueError('Código de equipe inválido')
    }
    let value = 0
    const base = TeamCode.ALPHABET.length
    for (const character of code.slice(1)) {
      const index = TeamCode.ALPHABET.indexOf(character)
      if (index < 0) {
        throw new ValueError('Código de equipe inválido')
      }
      value = value * base + index
      if (value > TeamCode.MAX_VALUE) {
        throw new ValueError('Código de equipe inválido')
      }
    }
    const highId = value & 0xff
    const lowId = Math.floor(value / 256)
    return [highId, lowId]
  }
}

module.exports = TeamCode
