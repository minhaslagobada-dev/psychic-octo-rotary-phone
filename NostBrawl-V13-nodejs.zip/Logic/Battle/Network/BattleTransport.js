'use strict'

const net = require('net')
const { EventEmitter } = require('events')
const { performance } = require('perf_hooks')
const { UdpGateway } = require('./UdpGateway')
const { InputBuffer } = require('./InputBuffer')
const { decodeInput } = require('./V13BattleCodec')

class BattleTransport extends EventEmitter {
  constructor (settings = {}) {
    super()
    this.settings = settings
    if (settings.AdvertiseHost && !net.isIPv4(settings.AdvertiseHost)) throw new Error('Battle.AdvertiseHost must be a public or LAN IPv4 address; v13 does not resolve hostnames')
    this.gateway = new UdpGateway(settings)
    this.gateway.on('transportError', error => this.emit('transportError', error))
    this.gateway.on('sendError', error => this.emit('transportError', error))
    this.gateway.on('input', (session, input) => this.accept(session, input))
    this.gateway.on('release', (session, reason) => {
      if (session.input) session.input.clear()
      if (session.player.udp_session === session) session.player.udp_session = null
      this.emit('release', session, reason)
    })
  }

  async start () { await this.gateway.start(); return this }

  attach (player, client) {
    if (!player.logged_in) throw new Error('Battle transport requires login')
    const current = player.udp_session
    if (current && !current.closed && current.client === client && this.gateway.sessions.get(current.key) === current) {
      current.lastSeen = performance.now()
      return current
    }
    const session = this.gateway.createSession(player, client)
    session.input = new InputBuffer()
    session.host = this.settings.AdvertiseHost || String(client.localAddress || '').replace(/^::ffff:/, '')
    if (!net.isIPv4(session.host) || session.host === '0.0.0.0') {
      this.gateway.release(session, 'invalid-address')
      throw new Error('Configure Battle.AdvertiseHost with the IPv4 address clients can reach')
    }
    player.udp_session = session
    return session
  }

  accept (session, input) {
    if (session.closed || !session.player.logged_in) return false
    session.lastSeen = performance.now()
    session.input.push(input.inputs)
    session.client.lastBattleActivity = Date.now()
    this.emit('input', session, input)
    return true
  }

  acceptTcp (player, client, bytes) {
    const session = player.udp_session
    if (!session || session.closed || session.client !== client) return false
    return this.accept(session, decodeInput(bytes))
  }

  send (session, type, payload) { return this.gateway.send(session, type, payload) }
  release (player, client, reason = 'disconnect') {
    const session = player.udp_session
    if (session && session.client === client) return this.gateway.release(session, reason)
    return false
  }
  async close () { await this.gateway.close() }
}

module.exports = { BattleTransport }
