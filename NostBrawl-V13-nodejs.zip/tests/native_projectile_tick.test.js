'use strict'
const fs = require('node:fs')
const path = require('node:path')
const assert = require('node:assert/strict')
const { positionAtTick } = require('../Native/V13/ProjectilePosition')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const vectors = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'projectile-tick-vectors.json')))
for (const v of vectors) {
  assert.equal(v.state, 0, v.name + ' must remain in flight on open terrain')
  assert.deepEqual(positionAtTick(v.data, v.flight, v.tick), { x: v.x, y: v.y, z: v.z }, JSON.stringify(v))
}
console.log('Native projectile tick on controlled open terrain:', vectors.length, 'positions matched; this does not certify obstacle/enemy collisions')
