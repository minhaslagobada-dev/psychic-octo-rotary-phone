'use strict'
// Port of probe_attack_configuration.py.
// Full original CharacterServer attack configuration; no gameplay hooks.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); t.initialize_schema(0x449b0c)
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const manager = t.alloc(0x80); const battle = t.alloc(0x400); p(manager + 0x50, battle); w(battle + 0x18, 100)
  const records = []
  const player = t.alloc(0x100); const skin = t.alloc(0x100); const players = t.alloc(8); p(players, player); p(player + 0x30, skin); p(battle + 0x78, players)
  const override = t.alloc(0x200); p(override + 8, t.rows[0]); p(skin + 0xe0, override)
  const overrideDefinition = R.zipDict(t.names, t.records[0])
  const invisMeta = t.alloc(0x200); w(invisMeta + 0xb8, 3)
  const ints = [0x7c, 0xbc, 0xc0, 0xc4, 0xc8, 0xcc, 0xd0, 0xd4, 0xe0, 0xe4, 0xe8, 0xf0, 0xf4, 0xf8, 0x180, 0x184, 0x1dc, 0x2fc]
  const bytes = [0x140, 0x188, 0x1d5, 0x206]
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row); const meta = t.alloc(0x200); p(meta + 8, t.rows[i]); n.uc.mem_write(meta + 0x90, Buffer.from([d.Indirect === 'true' ? 1 : 0]))
    for (const target of [[3500, 5000], [3000, 4500], [3000, 2000], [5317, 8429]]) {
      for (const immediate of [0, 1]) {
        for (const twoGuns of [0, 1]) {
          for (const isSuper of [0, 1]) {
            for (const variant of ['base', 'interruptInvisibility', 'skinOverride']) {
              const owner = t.alloc(0x400); p(owner, 0x72dc10); p(owner + 0x18, manager); w(owner + 0x3c, variant === 'skinOverride' ? 0 : -1); w(owner + 0x30, 3000); w(owner + 0x34, 4500); w(owner + 0x7c, 17)
              const invis = t.alloc(0x30); p(invis, invisMeta); w(invis + 0xc, 50)
              if (variant === 'interruptInvisibility') {
                n.uc.mem_write(owner + 0x1cc, Buffer.from([1])); n.uc.mem_write(owner + 0x3a0, Buffer.from([1]))
                const skills = t.alloc(8); p(skills, invis); p(owner + 0x130, skills); w(owner + 0x13c, 1)
              }
              n.uc.mem_write(0x201ff000, R.pack('Q', 60, 2, 5, meta, immediate, twoGuns, 37, isSuper))
              n.call(0x3fdff8, owner, target[0], target[1], 30, 22, 3, 300, 100)
              const i32 = {}; for (const off of ints) i32[R.hex(off)] = get(owner + off)
              const u8 = {}; for (const off of bytes) u8[R.hex(off)] = m.u8(owner + off)
              records.push({
                projectile: d, variant, override: overrideDefinition, afterInvisibilityMs: get(invis + 0xc), resolvedProjectileIsOverride: m.u64(owner + 0xd8) === override,
                input: { target, bonusDamage: 30, range: 22, attackCount: 3, damage: 300, attackIntervalMs: 100, spread: 60, pattern: 2, bullets: 5, executeFirstImmediately: Boolean(immediate), twoGuns: Boolean(twoGuns), rangeBonus: 37, isSuper: Boolean(isSuper) },
                output: { i32, u8 }
              })
            }
          }
        }
      }
    }
  })
  R.writeJson('attack-configuration-vectors.json', records)
  R.print('Original full attack configuration:', records.length, 'cases; no gameplay hooks')
})
