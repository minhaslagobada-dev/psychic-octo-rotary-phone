'use strict'
// Round-trip compatibility against the binary fixtures captured from the
// reference Python server (pyserver/extracted/tests/fixtures).
const assert = require('assert')
const fs = require('fs')
const path = require('path')

process.chdir(path.join(__dirname, '..'))

const FIXTURES = path.join(__dirname, 'fixtures')
const fixture = (name) => fs.readFileSync(path.join(FIXTURES, name))

let passed = 0
function check (name, fn) {
  fn()
  passed += 1
  console.log(`ok - ${name}`)
}

// --------------------------------------------------------------------------
// LoginOk (20104) wire layout, native V13
// --------------------------------------------------------------------------
check('loginok bytes match loginok_v13.bin', () => {
  const LoginOkMessage = require('../Packets/Messages/Server/Login/LoginOkMessage')
  const player = { high_id: 1, low_id: 2, token: 'token' }
  const message = new LoginOkMessage(null, player)
  message.encode()
  assert.deepStrictEqual(message.buffer, fixture('loginok_v13.bin'))
})

// --------------------------------------------------------------------------
// V13 session crypto, ciphertext vectors from the reference build
// --------------------------------------------------------------------------
check('crypto fixtures round-trip (login/loginok/ownhome/keepalive)', () => {
  const { Crypto, CryptoError, Nonce } = require('../Core/Crypto')
  const cryptoBox = new Crypto({ Enabled: true })

  const login = fixture('crypto_login.bin')
  assert.deepStrictEqual(cryptoBox.decrypt(10101, login), Buffer.from('raw-login-payload'))
  const expectedNonce = Buffer.alloc(24)
  for (let index = 0; index < 24; index++) expectedNonce[index] = 24 + index
  assert.deepStrictEqual(Buffer.from(cryptoBox.decryptNonce.toBuffer()), expectedNonce)

  const encryptNonce = Buffer.alloc(24)
  for (let index = 0; index < 24; index++) encryptNonce[index] = 48 + index
  cryptoBox.encryptNonce = new Nonce(encryptNonce)
  const sharedEn = Buffer.alloc(32)
  for (let index = 0; index < 32; index++) sharedEn[index] = 72 + index
  cryptoBox.shared_en = sharedEn

  assert.deepStrictEqual(cryptoBox.encrypt(20104, Buffer.from('login-ok')), fixture('crypto_loginok.bin'))
  assert.deepStrictEqual(cryptoBox.encrypt(24101, Buffer.from('own-home')), fixture('crypto_ownhome.bin'))
  assert.deepStrictEqual(cryptoBox.decrypt(10108, fixture('crypto_keepalive.bin')), Buffer.from('keepalive'))

  const raw = new Crypto({ Enabled: false })
  assert.deepStrictEqual(raw.decrypt(10101, Buffer.from('plain')), Buffer.from('plain'))
  assert.deepStrictEqual(raw.encrypt(20104, Buffer.from('plain')), Buffer.from('plain'))

  const tampered = Buffer.from(login)
  tampered[tampered.length - 1] ^= 1
  assert.throws(() => new Crypto({ Enabled: true }).decrypt(10101, tampered), CryptoError)
})

// --------------------------------------------------------------------------
// Leaderboard (24403) global players vs the reference capture
// --------------------------------------------------------------------------
check('leaderboard bytes match leaderboard_v13.bin', () => {
  const GetLeaderboardGlobalOkMessage = require('../Packets/Messages/Server/Leaderboard/TopGlobalPlayersDataMessage')
  const player = { low_id: 55113832, region: 'PT' }
  const entries = [{
    low_id: 55113832,
    name: 'ABC',
    trophies: 0,
    profile_icon: 0,
    name_color: 0,
    club_id: 0,
    club_name: '',
    player_experience: 0,
    online: 0
  }]
  const message = new GetLeaderboardGlobalOkMessage(null, player, entries)
  message.encode()
  assert.deepStrictEqual(message.buffer, fixture('leaderboard_v13.bin'))
})

// --------------------------------------------------------------------------
// OwnHomeData (24101) full envelope vs the reference capture
// --------------------------------------------------------------------------
check('own home data bytes match own_home_data.bin', () => {
  const HOME_TIMESTAMP = 1793897003
  const EventSlots = require('../Logic/EventSlots')
  const { EventRotation } = require('../Logic/EventRotation')
  const ShopService = require('../Logic/ShopService')
  const OwnHomeDataMessage = require('../Packets/Messages/Server/Home/OwnHomeDataMessage')

  const fixedHomeEvents = () => {
    const values = [[7, 2, 10], [32, 0, 10], [24, 0, 10], [0, 0, 10], [30, 0, 2]]
    return values.map(([mapId, modifier, tokens], index) => ({
      slot: index + 1,
      map_id: mapId,
      modifier,
      tokens,
      claimed: false
    }))
  }

  const patched = []
  const patch = (target, property, replacement) => {
    patched.push([target, property, target[property]])
    target[property] = replacement
  }
  patch(Date, 'now', () => HOME_TIMESTAMP * 1000)
  patch(EventRotation, 'snapshot', () => fixedHomeEvents())
  patch(EventRotation, 'seconds_to_next_day', () => 49020)
  patch(EventSlots.prototype, 'Timer', () => 49020)
  patch(ShopService, 'encode_home', (writer) => writer.v(0))

  try {
    const player = {
      high_id: 1,
      low_id: 42,
      name: 'Wire',
      trophies: 999,
      highest_trophies: 999,
      trophy_road: 7,
      exp_points: 11,
      profile_icon: 2,
      brawlers_skins: { 0: 29, 1: 0 },
      UnlockedSkins: { Skins: [29, 0] },
      tokensAnim: 1,
      trophiesAnim: 2,
      bigTokensAnim: 3,
      tokensdoubler: 1000,
      brawler_id: 0,
      battle_tokens: 200,
      brawlers_id: [0, 1],
      card_unlock_id: [10, 12],
      BrawlersUnlockedState: { 0: 1, 1: 0 },
      brawlers_trophies: { 0: 12, 1: 13 },
      brawlers_trophies_in_rank: { 0: 22, 1: 23 },
      brawlers_upgradium: { 0: 32, 1: 33 },
      Brawler_level: { 0: 2, 1: 9 },
      Brawler_starPower: { 0: 76, 1: 80 },
      progression: { brawlerNewTag: { 0: 0, 1: 1 } },
      gems: 969,
      gold: 100,
      brawl_boxes: 899,
      big_boxes: 4,
      star_points: 5,
      player_experience: 77,
      tutorial: 2
    }
    const message = new OwnHomeDataMessage(null, player)
    message.encode()
    const expected = fixture('own_home_data.bin')
    if (!message.buffer.equals(expected)) {
      const firstDiff = message.buffer.findIndex((byte, index) => byte !== expected[index])
      throw new assert.AssertionError({
        message: `own_home_data mismatch at byte ${firstDiff} (ours=${message.buffer.length}B, expected=${expected.length}B, ours[${firstDiff}]=${message.buffer[firstDiff]} expected=${expected[firstDiff]})`
      })
    }
  } finally {
    for (const [target, property, original] of patched.reverse()) {
      target[property] = original
    }
  }
})

console.log(`\nFIXTURES ROUND-TRIP OK: ${passed} passed`)
