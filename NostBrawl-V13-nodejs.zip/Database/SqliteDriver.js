'use strict'
// SQLite driver resolver with zero native requirements on modern Node.
//
// Resolution order:
//   1. `node:sqlite` (built into Node >= 22.5, stable on 24) — no native
//      addon, no install scripts; works in hosting panels that block them.
//   2. `better-sqlite3` (native addon) — fallback for Node 18..21.
//
// Both expose an almost identical API (exec, prepare -> get/all/run, close).
// This module normalizes the small differences: constructor option shape
// (`readonly` vs `readOnly`) and the run() info object (`lastInsertRowid`
// may come back as bigint under node:sqlite when readBigInts is enabled).

function coerceInfo (info) {
  if (info && typeof info === 'object') {
    if (typeof info.lastInsertRowid === 'bigint') {
      info.lastInsertRowid = Number(info.lastInsertRowid)
    }
    if (typeof info.changes === 'bigint') {
      info.changes = Number(info.changes)
    }
  }
  return info
}

function adaptStatement (stmt) {
  const run = stmt.run.bind(stmt)
  stmt.run = (...args) => coerceInfo(run(...args))
  // better-sqlite3 compatibility: .raw() makes get()/all() return arrays
  // (values in column order) instead of objects.
  stmt.raw = () => ({
    all: (...args) => stmt.all(...args).map((row) => (Array.isArray(row) ? row : Object.values(row))),
    get: (...args) => {
      const row = stmt.get(...args)
      if (row === undefined) return undefined
      return Array.isArray(row) ? row : Object.values(row)
    },
    run: (...args) => coerceInfo(run(...args)),
    iterate: (...args) => {
      const iterator = stmt.iterate(...args)
      return (function * () {
        for (const row of iterator) {
          yield Array.isArray(row) ? row : Object.values(row)
        }
      })()
    }
  })
  return stmt
}

function adaptDatabase (db) {
  const prepare = db.prepare.bind(db)
  db.prepare = (sql) => adaptStatement(prepare(sql))

  // better-sqlite3 exposes `.inTransaction`; node:sqlite has `.isTransaction`
  // (Node >= 23.4) or nothing on older 22.x — bridge the gap.
  if (!('inTransaction' in db)) {
    if ('isTransaction' in db) {
      Object.defineProperty(db, 'inTransaction', {
        configurable: true,
        enumerable: false,
        get () { return this.isTransaction }
      })
    } else {
      let inTransaction = false
      const exec = db.exec.bind(db)
      db.exec = (sql) => {
        const keyword = /^\s*(BEGIN(?:\s+\w+)?|COMMIT|ROLLBACK|END)\b/i.exec(sql)
        const result = exec(sql)
        if (keyword) {
          if (/^BEGIN/i.test(keyword[1])) inTransaction = true
          else inTransaction = false
        }
        return result
      }
      Object.defineProperty(db, 'inTransaction', {
        configurable: true,
        enumerable: false,
        get () { return inTransaction }
      })
    }
  }
  return db
}

let DRIVER = null

function resolveDriver () {
  if (DRIVER !== null) {
    return DRIVER
  }

  // 1. Built-in node:sqlite — preferred (no native compilation at all).
  try {
    const { DatabaseSync } = require('node:sqlite')
    if (typeof DatabaseSync === 'function') {
      DRIVER = {
        name: 'node:sqlite',
        open (databasePath, options = {}) {
          const nativeOptions = {}
          if (options.readonly === true || options.readOnly === true) {
            nativeOptions.readOnly = true
          }
          const db = new DatabaseSync(databasePath, nativeOptions)
          return adaptDatabase(db)
        }
      }
      return DRIVER
    }
  } catch (error) { /* Node < 22.5: no built-in sqlite */ }

  // 2. better-sqlite3 — needs its native binding compiled.
  let bs3
  try {
    bs3 = require('better-sqlite3')
  } catch (error) {
    throw new Error(
      'Nenhum driver SQLite disponível. Use Node.js >= 22.5 (recomendado: 24 LTS) ' +
      'para o driver nativo `node:sqlite`, ou compile o better-sqlite3 ' +
      '(npm install-scripts approve better-sqlite3 && npm rebuild better-sqlite3). ' +
      `Detalhe: ${error.message}`
    )
  }
  DRIVER = {
    name: 'better-sqlite3',
    open (databasePath, options = {}) {
      return bs3(databasePath, options)
    }
  }
  return DRIVER
}

function openDatabase (databasePath, options = {}) {
  return resolveDriver().open(databasePath, options)
}

function driverName () {
  return resolveDriver().name
}

module.exports = { openDatabase, resolveDriver, driverName }
