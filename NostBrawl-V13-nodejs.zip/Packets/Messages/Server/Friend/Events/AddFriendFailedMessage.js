'use strict'
const Writer = require('../../../../../Utils/Writer')

class AddFriendFailedMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 20112
    this.player = player
  }

  encode () {
    this.writeInt(3)
  }
}

module.exports = AddFriendFailedMessage
