'use strict'
const Status = require('../../Packets/Messages/Server/Battle/MatchMakingStatusMessage')
const Cancelled = require('../../Packets/Messages/Server/Battle/MatchMakingCancelledMessage')
const { ValueError } = require('../../Utils/Errors')
const { GameRoomService } = require('../GameRoomService')
const signature = room => JSON.stringify([room.map_id, room.practice, room.members.map(m => [m.low_id, m.team, m.brawler_id, m.skin_id])])
module.exports = {
  queuePrivateRoom (player, room, members, mode) {
    const existing = this.privateRooms.get(room.id)
    if (existing) return existing
    if (this.accounts.size + this.matchmaker.players.size + this.privatePlayers.size + members.length > this.maxPlayers) throw new ValueError('Servidor de batalhas cheio')
    for (const m of members) {
      if (m.player.pendingBattleResult) { require('./ResultOutbox').ResultOutbox.send(m.player, m.client); return null }
      if (this.accounts.has(m.player.low_id) || this.matchmaker.players.has(m.player.low_id) || this.privatePlayers.has(m.player.low_id)) throw new ValueError('Jogador já está em fila ou batalha')
      this.assets.hero(m.player.brawler_id)
    }
    const capacities = mode.cooperative ? [mode.capacity] : mode.teamCapacities || Array(mode.capacity / mode.teamSize).fill(mode.teamSize)
    const groups = capacities.map(() => [])
    members.forEach((member, i) => {
      let team = capacities.length <= 2 ? Number(room.members[i].team) || 0 : Math.floor(i / mode.teamSize)
      if (!groups[team] || groups[team].length >= capacities[team]) team = groups.findIndex((g, t) => g.length < capacities[t])
      if (team < 0) throw new ValueError('Sala excede a capacidade do modo')
      groups[team].push({ ...member, brawlerId: member.player.brawler_id, skinId: member.player.skin_id || 0,
        powerLevel: Math.max(0, Math.min(9, Number((member.player.Brawler_level || {})[member.player.brawler_id]) || 0)) })
    })
    const ticket = { roomId: room.id, player, members, mapId: room.map_id, mode, joinedAt: this.matchmaker.now(), signature: signature(room),
      selected: groups.flatMap((party, team) => party.length ? [{ team, ticket: { members: party } }] : []) }
    this.privateRooms.set(room.id, ticket)
    for (const m of members) this.privatePlayers.set(m.player.low_id, ticket)
    this.notifyPrivateRoom(ticket)
    return ticket
  },
  notifyPrivateRoom (ticket) {
    const remaining = Math.max(0, Math.ceil((ticket.joinedAt + 15000 - this.matchmaker.now()) / 1000))
    for (const m of ticket.members) this.deliver(() => new Status(m.client, m.player, remaining, ticket.members.length, ticket.mode.capacity).send())
  },
  removePrivateRoom (ticket, cancelled = false) {
    this.privateRooms.delete(ticket.roomId)
    for (const m of ticket.members) {
      this.privatePlayers.delete(m.player.low_id)
      if (cancelled) {
        this.deliver(() => GameRoomService.set_ready(m.player, false))
        if (!m.client.destroyed) this.deliver(() => new Cancelled(m.client, m.player).send())
      }
    }
  },
  pollPrivateRooms () {
    for (const ticket of Array.from(this.privateRooms.values())) {
      const current = GameRoomService.get(ticket.roomId)
      if (!current || signature(current) !== ticket.signature || !current.members.every(m => m.ready) || ticket.members.some(m => m.client.destroyed || !m.player.logged_in)) {
        this.removePrivateRoom(ticket, true); continue
      }
      if (ticket.members.length === ticket.mode.capacity || this.matchmaker.now() >= ticket.joinedAt + 15000) {
        const world = this.start(ticket.selected, ticket.mapId)
        world.practice = true
        this.removePrivateRoom(ticket)
        GameRoomService.begin_battle(ticket.player)
      } else if (this.metrics.steps % 20 === 0) this.notifyPrivateRoom(ticket)
    }
  }
}
