'use strict'

class PresenceService {
  static init () {
    this._clients = null
    return this
  }

  static bind_clients (clients) {
    PresenceService._clients = clients
  }

  static status (lowId, persisted = 0, clients = null) {
    const registry = clients === null || clients === undefined ? PresenceService._clients : clients
    if (registry === null || registry === undefined || registry === undefined) {
      try {
        return Math.trunc(Number(persisted || 0))
      } catch (error) {
        return 0
      }
    }
    const recipient = (registry.Clients || {})[String(Math.trunc(lowId))]
    if (recipient === undefined || recipient === null) {
      return 0
    }
    try {
      return Math.trunc(Number(recipient.Status || 0))
    } catch (error) {
      return 0
    }
  }

  static elapsed (status, lastActivityAt, now = null) {
    if (![0, 6].includes(Math.trunc(status))) {
      return 0
    }
    if (lastActivityAt === null || lastActivityAt === undefined) {
      return -1
    }
    now = now === null || now === undefined ? Math.floor(Date.now() / 1000) : Math.trunc(now)
    return Math.min(0x7fffffff, Math.max(0, now - Math.trunc(lastActivityAt)))
  }

  static record_activity (player, client) {
    const registry = player.ClientDict !== undefined && player.ClientDict ? player.ClientDict : PresenceService._clients
    const recipient = registry === null || registry === undefined ? null : (registry.Clients || {})[String(Math.trunc(player.low_id ?? 0))]
    if (recipient === null || recipient === undefined || recipient.SocketInfo !== client) {
      return false
    }
    const now = Math.floor(Date.now() / 1000)
    if (recipient.LastActivity !== now) {
      const DataBase = require('../Database/DatabaseManager')
      DataBase.record_activity(player, now)
      recipient.LastActivity = now
    }
    player.last_activity_at = now
    return true
  }

  static set_status (player, status, client = null, persist = false) {
    status = Math.trunc(status)
    const registry = player.ClientDict !== undefined && player.ClientDict ? player.ClientDict : PresenceService._clients
    const recipient = registry === null || registry === undefined ? null : (registry.Clients || {})[String(Math.trunc(player.low_id ?? 0))]
    if (client !== null && registry !== null && registry !== undefined &&
        (recipient === null || recipient === undefined || recipient.SocketInfo !== client)) {
      return false
    }
    if (persist) {
      const DataBase = require('../Database/DatabaseManager')
      const now = Math.floor(Date.now() / 1000)
      if (!DataBase.update_presence(player, status, now)) {
        throw new Error('Conta não encontrada ao atualizar presença')
      }
      player.last_activity_at = now
      if (recipient !== null && recipient !== undefined) {
        recipient.LastActivity = now
      }
    }
    player.online = status
    if (recipient !== null && recipient !== undefined) {
      if (Math.trunc(recipient.Status || 0) !== status) {
        recipient.StatusSince = Math.floor(Date.now() / 1000)
      }
      recipient.Status = status
    }
    return true
  }

  static social_peers (accountId) {
    const DataBase = require('../Database/DatabaseManager')
    accountId = Math.trunc(accountId)
    return DataBase._connection((connection) => {
      const rows = connection.prepare(
        'SELECT friend_id AS f FROM friend_relations WHERE owner_id = ? AND state = 4 ' +
        'UNION SELECT other.player_id AS f FROM club_members own ' +
        'JOIN club_members other ON own.club_id = other.club_id ' +
        'WHERE own.player_id = ? AND other.player_id <> ?'
      ).all(accountId, accountId, accountId)
      return rows.map((row) => Math.trunc(row.f)).sort((a, b) => a - b)
    })
  }

  static _related (subjectId, recipientId) {
    const DataBase = require('../Database/DatabaseManager')
    return DataBase._connection((connection) => {
      const row = connection.prepare(
        'SELECT 1 AS one FROM friend_relations WHERE owner_id = ? AND friend_id = ? AND state = 4 ' +
        'UNION SELECT 1 AS one FROM club_members a JOIN club_members b ON a.club_id = b.club_id ' +
        'WHERE a.player_id = ? AND b.player_id = ? LIMIT 1'
      ).get(recipientId, subjectId, recipientId, subjectId)
      return row !== undefined
    })
  }

  static sync_subject (sender, subjectId, recipientId) {
    const FriendOnlineStatusEntryMessage = require('../Packets/Messages/Server/Friend/FriendOnlineStatusEntryMessage')
    subjectId = Math.trunc(subjectId)
    recipientId = Math.trunc(recipientId)
    if (subjectId <= 0 || recipientId <= 0 || subjectId === recipientId) {
      return false
    }
    const registry = sender.ClientDict !== undefined && sender.ClientDict ? sender.ClientDict : PresenceService._clients
    if (registry === null || registry === undefined) {
      return false
    }
    const clients = registry.Clients || {}
    const recipient = clients[String(recipientId)]
    if (recipient === undefined || recipient === null) {
      return false
    }
    if (clients[String(recipientId)] !== recipient) {
      return false
    }
    const subject = clients[String(subjectId)]
    const status = subject ? Math.trunc(subject.Status || 0) : 0
    const since = subject ? Math.trunc(subject.StatusSince !== undefined ? subject.StatusSince : Math.floor(Date.now() / 1000)) : 0
    const permitted = PresenceService._related(subjectId, recipientId)
    const eligible = status >= 0 && status < 12 && Boolean((1 << status) & 0xfbe)
    const remove = new FriendOnlineStatusEntryMessage(null, sender, subjectId)
    try {
      const length = remove._send_payload(recipient.SocketInfo, recipient.Crypto !== undefined ? recipient.Crypto : null, remove._encode_payload())
      remove._log_sent(length)
      if (permitted && eligible) {
        const elapsed = Math.min(0x7fffffff, Math.max(0, Math.floor(Date.now() / 1000) - since))
        const update = new FriendOnlineStatusEntryMessage(null, sender, subjectId, status, elapsed)
        const updateLength = update._send_payload(recipient.SocketInfo, recipient.Crypto !== undefined ? recipient.Crypto : null, update._encode_payload())
        update._log_sent(updateLength)
      }
    } catch (error) {
      return false
    }
    return true
  }

  static sync_view (player) {
    const owner = Math.trunc(player.low_id ?? 0)
    return PresenceService.social_peers(owner).reduce(
      (total, subject) => total + (PresenceService.sync_subject(player, subject, owner) ? 1 : 0),
      0
    )
  }

  static sync_pair (player, otherId) {
    const owner = Math.trunc(player.low_id ?? 0)
    otherId = Math.trunc(otherId)
    return [
      PresenceService.sync_subject(player, otherId, owner),
      PresenceService.sync_subject(player, owner, otherId)
    ]
  }

  static publish (player) {
    const { ClubService } = require('./ClubService')
    const { FriendService } = require('./FriendService')
    const owner = Math.trunc(player.low_id ?? 0)
    return {
      friends: FriendService.push_presence(player),
      club: ClubService.push_presence(player),
      social_status: PresenceService.social_peers(owner).reduce(
        (total, peer) => total + (PresenceService.sync_subject(player, owner, peer) ? 1 : 0),
        0
      )
    }
  }
}

PresenceService._clients = null

module.exports = PresenceService
