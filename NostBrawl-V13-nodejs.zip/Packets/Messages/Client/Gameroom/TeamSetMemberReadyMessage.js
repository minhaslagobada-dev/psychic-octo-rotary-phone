'use strict'
const { BattleInstanceService } = require('../../../../Logic/BattleInstances')
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService } = require('../../../../Logic/GameRoomService')
const MatchMakingCancelledMessage = require('../../Server/Battle/MatchMakingCancelledMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamSetMemberReadyMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.ready = false
    this.unknown = 0
  }

  decode () {
    this.ready = this.read_boolean()
    this.unknown = this.read_Vint()
    this.ensure_end()
  }

  process () {
    const room = GameRoomService.set_ready(this.player, this.ready)
    if (room === null) {
      return null
    }
    if (this.player.battleCoordinator) {
      GameRoomGateway.broadcast_data(this.player, room, this.client)
      if (!this.ready) this.player.battleCoordinator.cancel(this.player, this.client)
      else this.player.battleCoordinator.readyRoom(this.player, room)
      return room
    }
    if (this.ready) {
      BattleInstanceService.begin(this.player)
    }
    GameRoomGateway.broadcast_data(this.player, room, this.client)
    if (this.ready) {
      this.player.map_id = 15
      this.player.mmplayers = 1
      new MatchMakingCancelledMessage(this.client, this.player).send()
    }
    return room
  }
}

module.exports = TeamSetMemberReadyMessage
