'use strict'
// Port of probe_skill_range.py.
// Original charged-aim casting range bonus, actual native skill CSV.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/skills.csv')); t.initialize_schema(0x13da8c)
  R.assert(m.i32(0x82bc7c) === 40)
  const records = []
  t.records.forEach((row, i) => {
    const meta = t.alloc(0x200); t.ptr(meta + 8, t.rows[i])
    for (const elapsed of [-1, 0, 1, 19, 20, 39, 40, 80]) {
      const value = R.signed32(n.call(0x378534, meta, R.u32(elapsed)))
      records.push({ definition: R.zipDict(t.names, row), elapsed, bonus: value })
    }
  })
  R.writeJson('skill-range-vectors.json', records)
  R.print('Original skill casting range bonus:', records.length, 'cases')
})
