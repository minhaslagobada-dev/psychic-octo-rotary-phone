'use strict'
const { readRows } = require('./CsvRows')
const Skins = require('./Skins')

class Characters {
  static get_brawlers_id () {
    const rows = readRows('GameAssets/csv_logic/characters.csv')
    const ids = []
    for (let brawlerId = 0; brawlerId < rows.length; brawlerId++) {
      const row = rows[brawlerId]
      if (
        row.length > 20 &&
        row[20] === 'Hero' &&
        row[2].toLowerCase() !== 'true' &&
        row[1].toLowerCase() !== 'true'
      ) {
        ids.push(brawlerId)
      }
    }
    return ids
  }

  static get_brawler_id_by_name (name) {
    const rows = readRows('GameAssets/csv_logic/characters.csv')
    for (let brawlerId = 0; brawlerId < rows.length; brawlerId++) {
      const row = rows[brawlerId]
      if (
        row.length > 20 &&
        row[0] === name &&
        row[20] === 'Hero' &&
        row[2].toLowerCase() !== 'true' &&
        row[1].toLowerCase() !== 'true'
      ) {
        return brawlerId
      }
    }
    throw new Error(`Brawler desconhecido: ${name}`)
  }

  static get_brawler_by_skin_id (skinId) {
    return Skins.getBrawler(skinId)
  }
}

module.exports = Characters
