'use strict'

const Skins = require('../../../Files/CsvLogic/Skins')
const RewardDelivery = require('../../../Logic/RewardDelivery')
const { RewardError } = require('../../../Logic/Rewards')
const SkinPurchase = require('../../../Logic/SkinPurchase')
const { ValueError } = require('../../../Utils/Errors')

class LogicBuySkinCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    reader.skin_reference = reader.readScId()
    if (reader.skin_reference[0] !== 29 || reader.skin_reference[1] < 0) {
      throw new ValueError(`Invalid skin DataReference: ${reader.skin_reference}`)
    }
    reader.skin_id = reader.skin_reference[1]
    reader.brawler_id = Skins.getBrawler(reader.skin_id)
  }

  static process (reader) {
    let result
    try {
      result = SkinPurchase.purchase(
        reader.player, reader.skin_id, reader.brawler_id
      )
    } catch (error) {
      if (error instanceof RewardError || error instanceof ValueError) {
        return String(error.message)
      }
      throw error
    }
    const rewards = RewardDelivery.displays(result.rewardDetails)
    RewardDelivery.send(reader.client, reader.player, {
      kind: 'item', rewards
    })
    return result
  }
}

module.exports = LogicBuySkinCommand
