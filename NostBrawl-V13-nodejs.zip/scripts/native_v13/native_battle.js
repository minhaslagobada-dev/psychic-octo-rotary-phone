'use strict'
// Port of native_battle.py.
// Original battle constructor, location/map selection and player registration.
//
// These are research bindings to original functions, not a complete online
// server. No character, player or mode structure is synthesized in this binding.
const C = require('./lib/unicorn_const')
const { ValueError, RuntimeError, StopIteration, truthy, isInt } = require('./lib/pycompat')

function definitionOf (table, name) {
  const index = table.records.findIndex(row => row[0] === name)
  if (index < 0) throw new StopIteration()
  const definition = {}
  const row = table.records[index]
  table.names.forEach((column, i) => { if (i < row.length) definition[column] = row[i] })
  return definition
}

class NativeBattle {
  constructor (data, location, kind = 1, seed = 17) {
    this.data = data; this.native = data.native; this.csv = data.csv.get(15)
    this.pointer = this.csv.alloc(0x400)
    this.native.call(0x4328f8, this.pointer, kind)
    this.manager = data.ptr(this.pointer)
    this.native.call(0x201398, this.manager, this.pointer)
    this.native.call(0x425ef8, this.pointer, data.named(15, location))
    this.native.call(0x13a028, this.pointer, seed)
    this.csv.ptr(0xab42d0, data.named(27, 'Open'))
    this.native.call(0x1e7b14, this.pointer, 0, 1, 0, { count: 20000000 })
    this.closed = false
  }

  add_player (hero, team, { name = 'Native player', account_id = 1, bot = false, power_level = null, star_card = null, skin = null } = {}) {
    const identity = this.csv.alloc(8); this.csv.word(identity, 0); this.csv.word(identity + 4, account_id)
    const display = this.csv.alloc(24); this.csv.string(display, name)
    let upgrades = 0; let star = 0; let skin_pointer = 0
    if (truthy(star_card)) {
      const definition = definitionOf(this.data.csv.get(23), star_card)
      if (definition.Target !== hero || definition.MetaType !== '4') throw new ValueError('Star card does not belong to this hero')
      star = this.data.named(23, star_card)
    }
    if (power_level !== null || star) {
      if (!(isInt(power_level) || typeof power_level === 'boolean') || !(Number(power_level) >= 1 && Number(power_level) <= 9)) throw new ValueError('Native upgrade level must be 1..9')
      upgrades = this.csv.alloc(16); this.native.call(0x4c1b14, upgrades, Number(power_level), star)
    }
    if (truthy(skin)) {
      const definition = definitionOf(this.data.csv.get(29), skin)
      if (definition.Character !== hero) throw new ValueError('Skin does not belong to this hero')
      skin_pointer = this.data.named(29, skin)
    }
    const player = this.native.call(0x2021bc, this.pointer, identity, this.data.named(16, hero), upgrades, team, display, bot ? 1 : 0, skin_pointer, { count: 3000000 })
    this.native.call(0x467ef4, display); this.native.free(display); this.native.free(identity)
    return player
  }

  setup (fill_bots = true) {
    this.native.call(0x3e0cfc, this.pointer, 0, fill_bots ? 1 : 0, { count: 20000000 })
  }

  // Decode and dispatch an original v13 ClientInputMessage payload.
  input_packet (player_index, payload) {
    if (!(player_index >= 0 && player_index < this.data.word(this.pointer + 0x68))) throw new ValueError('Unknown native player index')
    if (!payload || !payload.length || payload.length > 8192) throw new ValueError('Invalid native input packet length')
    const player = this.data.ptr(this.data.ptr(this.pointer + 0x78) + player_index * 8)
    if (this.native.uc.mem_read(player + 0x59, 1)[0]) throw new ValueError('External input cannot control a native bot')
    const message = this.csv.alloc(0x60); this.native.call(0x3a50ac, message)
    const stream = message + 0x10
    // The native constructor owns an initial (possibly zero-length) array.
    // Release it before installing the network payload's owned buffer.
    const previous = this.data.ptr(stream + 0x20)
    if (previous) this.native.free(previous)
    const buffer = this.csv.alloc(payload.length); this.native.uc.mem_write(buffer, payload)
    this.csv.ptr(stream + 0x20, buffer); this.csv.word(stream + 0x10, payload.length); this.csv.word(stream + 0x14, 0); this.csv.word(stream + 0x18, payload.length)
    this._decode_input_message(message)
    if (this.data.word(stream + 0x14) !== payload.length) {
      this._destroy_input_message(message)
      throw new ValueError('Native input decoder left trailing bytes')
    }
    this.native.call(0x118500, this.pointer, message, this.data.word(player + 0x28), { count: 3000000 })
    this._destroy_input_message(message)
  }

  _destroy_input_message (message) {
    // As with other Piranha messages, the last virtual method performs
    // explicit content destruction; the deleting destructor frees self.
    this.native.call(0x3c414c, message)
    this.native.call(0x540200, message)
  }

  _decode_input_message (message) {
    const n = this.native
    if (!('_input_scratch_capture' in n)) {
      n._input_scratch_capture = null
      const observe = (uc, address, size, unused) => {
        if (n._input_scratch_capture !== null) n._input_scratch_capture.push(Number(uc.reg_read(C.UC_ARM64_REG_X22)))
      }
      n._input_scratch_hook = n.uc.hook_add(C.UC_HOOK_CODE, observe, null, 0x31831c, 0x31831c)
    }
    const scratch = []; n._input_scratch_capture = scratch
    try {
      n.call(0x31828c, message, { count: 3000000 })
    } finally {
      n._input_scratch_capture = null
      // The original decoder allocates a temporary entry, then addInput
      // copies it (0x14e040). Reclaim only those observed temporaries;
      // message destruction separately owns the retained copies.
      for (const entry of scratch) n.free(entry)
    }
  }

  // Use the original client-message writer for automated client tests.
  encode_input_packet (commands, counter = 1) {
    const message = this.csv.alloc(0x60); this.native.call(0x3a50ac, message)
    this.csv.word(message + 0x4c, this.data.word(this.pointer + 0x18))
    this.csv.word(message + 0x50, 0); this.csv.word(message + 0x54, counter)
    commands.forEach((command, index) => {
      const entry = this.csv.alloc(0x1c); this.native.call(0x1d2a68, entry)
      const values = [counter + index, 1, command.code, command.x ?? 0, command.y ?? 0, command.targetId ?? 0]
      values.forEach((value, offset) => this.csv.word(entry + offset * 4, value))
      this.native.uc.mem_write(entry + 24, Buffer.from([command.flag ? 1 : 0]))
      this.native.call(0x14e040, message, entry)
      this.native.free(entry)
    })
    this.native.call(0x287328, message, { count: 3000000 })
    const stream = message + 0x10; const length = this.data.word(stream + 0x14)
    if (!(length > 0 && length <= 8192)) throw new RuntimeError('Invalid original encoded input length')
    const payload = this.native.uc.mem_read(this.data.ptr(stream + 0x20), length)
    this._destroy_input_message(message)
    return payload
  }

  step (tick) {
    // Time is an explicit oracle input; all gameplay/object updates stay native.
    this.csv.word(this.pointer + 0x18, tick)
    this.native.call(0x4cba34, this.pointer, { count: 20000000 })
  }

  // Original game-over check, update, vision encoding and tick increment.
  frame () {
    if (!this.streams) {
      const count = this.data.word(this.pointer + 0x6c)
      this.streams = []; const array = this.csv.alloc(Math.max(8, count * 8)); this.stream_array = array; this.stream_list = this.csv.alloc(16)
      this.csv.ptr(this.stream_list, array); this.csv.word(this.stream_list + 8, count); this.csv.word(this.stream_list + 12, count)
      for (let i = 0; i < count; i++) {
        const stream = this.csv.alloc(0x28); this.native.call(0x23aec8, stream, 10)
        this.csv.ptr(array + i * 8, stream); this.streams.push(stream)
      }
    }
    const frame_tick = this.data.word(this.pointer + 0x18)
    this.native.call(0x42f218, this.pointer, this.stream_list, 0, { count: 20000000 })
    const snapshots = []
    for (const stream of this.streams) {
      const bits = this.data.word(stream + 8) * 8 + this.data.word(stream + 0x10)
      if (bits < 0 || bits > 1000000) throw new RuntimeError('Invalid native snapshot bit cursor')
      snapshots.push({ tick: frame_tick, bits, hex: this.native.uc.mem_read(this.data.ptr(stream + 0x18), Math.floor((bits + 7) / 8)).toString('hex') })
    }
    return snapshots
  }

  close () {
    if (this.closed) return
    this.native.call(0x110958, this.pointer, { count: 20000000 })
    this.native.call(0x56671c, this.pointer, { count: 20000000 })
    this.native.free(this.pointer)
    if (this.streams) {
      for (const stream of this.streams) {
        // BitStream owns its buffer through explicit destruct(), not its
        // virtual deleting destructor. Follow the native caller order.
        this.native.call(0x16806c, stream)
        this.native.call(0x54193c, stream)
      }
      this.native.free(this.stream_array); this.native.free(this.stream_list)
    }
    this.closed = true
  }

  describe () {
    const d = this.data; const p = this.pointer
    const objects = []
    const count = d.word(this.manager + 0xc)
    for (let i = 0; i < count; i++) {
      const obj = d.ptr(d.ptr(this.manager) + i * 8); const meta = d.ptr(obj + 0x10)
      const data_id = d.word(meta + 0x20)
      const record = { id: d.word(obj + 8), dataId: data_id, team: d.word(obj + 0x40), x: d.word(obj + 0x30), y: d.word(obj + 0x34) }
      if (data_id >= 16000000 && data_id < 17000000) { record.hp = d.word(obj + 0xb0); record.state = d.word(obj + 0x78) }
      objects.push(record)
    }
    const players = []
    const playerCount = d.word(p + 0x68)
    for (let i = 0; i < playerCount; i++) {
      const player = d.ptr(d.ptr(p + 0x78) + i * 8)
      const skin = d.ptr(player + 0x30); const upgrades = d.ptr(player + 0xc0)
      players.push({
        index: d.word(player + 0x20),
        team: d.word(player + 0x24),
        characterId: d.word(player + 0x28),
        bot: Boolean(this.native.uc.mem_read(player + 0x59, 1)[0]),
        alive: Boolean(this.native.uc.mem_read(player + 0x58, 1)[0]),
        lastKillerIndex: d.word(player + 0xd8),
        score: d.word(player + 0x40),
        superCharge: d.word(player + 0x60),
        name: d.string(player + 8),
        skinDataId: skin ? d.word(skin + 0x20) : null,
        powerLevel: upgrades ? d.word(upgrades) : null
      })
    }
    const mode = d.word(p + 0xe8)
    const ended = Boolean(this.native.uc.mem_read(p + 0xa3, 1)[0]); let mvp = -1
    if (ended && [0, 2, 3, 5].includes(mode)) {
      mvp = Number(this.native.call(0x2250bc, p) & 0xffffffffn)
      if (mvp >= 0x80000000) mvp -= 0x100000000
    }
    const scores = [0, 2, 3, 5].includes(mode) ? [0, 1].map(team => Number(this.native.call(0x395ae0, p, team) & 0xffffffffn)) : null
    return { tick: d.word(p + 0x18), headerSlots: d.word(p + 0x84), mvpIndex: mvp, nativeMode: mode, ended: Boolean(this.native.uc.mem_read(p + 0xa3, 1)[0]), forcedWinner: d.word(p + 0x10c), countdown: d.word(p + 0xd8), teamScores: scores, players, objects }
  }
}

module.exports = { NativeBattle }
