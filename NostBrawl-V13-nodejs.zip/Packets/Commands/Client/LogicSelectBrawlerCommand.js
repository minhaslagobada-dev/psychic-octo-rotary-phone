'use strict'

const Cards = require('../../../Files/CsvLogic/Cards')
const Characters = require('../../../Files/CsvLogic/Characters')
const Skins = require('../../../Files/CsvLogic/Skins')
const { RewardError, RewardTransaction } = require('../../../Logic/Rewards')
const { ValueError } = require('../../../Utils/Errors')

class LogicSelectBrawlerCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    reader.brawler_reference = reader.readScId()
    if (reader.brawler_reference[0] !== 16 || reader.brawler_reference[1] < 0) {
      throw new ValueError(
        `Invalid brawler DataReference: ${reader.brawler_reference}`
      )
    }
    reader.brawler_id = reader.brawler_reference[1]
    if (!Characters.get_brawlers_id().includes(reader.brawler_id)) {
      throw new ValueError(`Invalid brawler ID: ${reader.brawler_id}`)
    }
  }

  static process (reader) {
    try {
      const brawler = Math.trunc(reader.brawler_id)
      const states = reader.player.BrawlersUnlockedState || {}
      const state = states[String(brawler)] !== undefined ? states[String(brawler)] : states[brawler]
      if ((state || 0) !== 1) {
        throw new RewardError('O brawler precisa estar desbloqueado')
      }

      const selected = reader.player.brawlers_skins || {}
      let skin = Math.trunc(Number(
        (selected[String(brawler)] !== undefined ? selected[String(brawler)] : selected[brawler]) || 0
      )) || 0
      if (skin) {
        const owned = (reader.player.UnlockedSkins || {}).Skins || []
        if (!owned.includes(skin) || Skins.getBrawler(skin) !== brawler) {
          skin = 0
        }
      }

      const transaction = new RewardTransaction(reader.player)
      transaction.set_value('brawler_id', 'brawlerID', brawler)
      transaction.set_value('skin_id', 'skinID', skin)
      transaction.set_value(
        'starpower', 'starpower',
        new Cards().get_spg_by_brawler_id(brawler, 4)
      )
      transaction.commit()
      return { brawler, skin }
    } catch (error) {
      if (error instanceof RewardError || error instanceof TypeError || error instanceof ValueError) {
        return String(error.message)
      }
      throw error
    }
  }
}

module.exports = LogicSelectBrawlerCommand
