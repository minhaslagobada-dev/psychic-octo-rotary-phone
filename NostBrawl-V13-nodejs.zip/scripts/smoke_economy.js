'use strict'
const path = require('path')
process.chdir(path.resolve(__dirname, '..'))

const DataBase = require('../Database/DatabaseManager')
const { Players } = require('../Logic/Player')
const { DailyRewards } = require('../Logic/DailyRewards')
const SeasonService = require('../Logic/SeasonService')
const ShopService = require('../Logic/ShopService')
const TrophyRoad = require('../Logic/TrophyRoad')
const BoxInventory = require('../Logic/BoxInventory')
const { open_boxes } = require('../Logic/BoxService')
const NotificationFactory = require('../Logic/NotificationFactory')

function check (label, condition) {
  if (!condition) {
    console.error(`FAIL ${label}`)
    process.exit(1)
  }
  console.log(`ok ${label}`)
}

const lowId = 900001
const token = 'smoke_token_' + lowId
const player = {
  token,
  low_id: lowId,
  high_id: 0,
  name: 'SmokeTester',
  gems: 5000,
  gold: 200,
  tickets: 3,
  tokensdoubler: 0,
  battle_tokens: 200,
  brawl_boxes: 0,
  big_boxes: 0,
  trophies: 120,
  highest_trophies: 120,
  player_experience: 99999,
  trophy_road: 1,
  tutorial: 2,
  profile_icon: 0,
  brawler_id: 0,
  skin_id: 0,
  starpower: 0,
  name_color: 0,
  star_points: 0,
  progression: {}
}
DataBase.createAccount({ player })
check('createAccount', player.low_id === lowId)

const loaded = { token, low_id: lowId }
DataBase.loadAccount({ player: loaded })
check('loadAccount name', loaded.name === 'SmokeTester')
check('loadAccount gems', loaded.gems === 5000)
check('loadAccount brawlers unlocked state', typeof loaded.BrawlersUnlockedState === 'object' && loaded.BrawlersUnlockedState !== null)

const daily = DailyRewards.sync_player(loaded)
check('daily sync', daily.remaining === 200 && daily.persisted === true)

const season = SeasonService.sync(loaded)
check('season sync', season.enabled === true && season.remaining > 0)

const shop = ShopService.get_state(loaded)
check('shop offers generated', Array.isArray(shop.offers) && shop.offers.length >= 1)

const purchase = ShopService.purchase(loaded, 0, 0)
check('shop free_box purchase', purchase.offerKey === 'free_box' && Array.isArray(purchase.responses))
check('free_box flagged purchased', ShopService.get_state(loaded).offers[0].purchased === true)

const road = TrophyRoad.claim(loaded, 0)
check('trophy road claim position 1', road.claimedPosition === 1 && loaded.trophy_road === 2)

const before = BoxInventory.count(loaded, 10)
const opened = open_boxes(loaded, 1)
check('open_boxes gems source', opened.openingSource === 'currency' && loaded.gems === 5000 - 30)
check('open_boxes rewards', Array.isArray(opened.rewards) && opened.rewards.length >= 1)
console.log('  rewards:', opened.rewardNames.join(', '), '->', opened.rewards.join(', '))

const ensured = NotificationFactory.ensure_star_shelly(loaded)
check('star shelly notification added', ensured === true)
const skinClaim = NotificationFactory.claim_next_skin(loaded)
check('star shelly claimed', skinClaim.skin === 52 && skinClaim.alreadyOwned === false)
check('skin persisted in memory', loaded.UnlockedSkins.Skins.includes(52))

const reloaded = { token, low_id: lowId }
DataBase.loadAccount({ player: reloaded })
check('persistence gems', reloaded.gems === loaded.gems)
check('persistence trophy road', reloaded.trophy_road === 2)
check('persistence skins', reloaded.UnlockedSkins.Skins.includes(52))
check('persistence shop state day', ShopService.get_state(reloaded).day === shop.day)

const OwnHomeDataMessage = require('../Packets/Messages/Server/Home/OwnHomeDataMessage')
const home = new OwnHomeDataMessage(null, reloaded)
home.encode()
const raw = home.getRaw()
check('OwnHomeData encode bytes', raw.length > 64)
console.log('  own home data size:', raw.length)

console.log('SMOKE ECONOMY OK')
