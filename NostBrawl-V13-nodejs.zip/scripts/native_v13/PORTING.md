# Port 1:1 Python → Node.js

Todos os 64 scripts Python do projeto (`scripts/native_v13/*.py` e
`scripts/package_battles.py`) foram portados para JavaScript com o mesmo nome
(`*.js`). O servidor, o processo de batalha, os testes, a auditoria e o
empacotamento rodam apenas com Node.js 18+; não há mais Python, `venv`, `pip` ou
`requirements.txt`.

## Dependências

| Python                       | Node.js                                                                  |
|------------------------------|--------------------------------------------------------------------------|
| `unicorn==2.1.4`             | `lib/unicorn.js`: backend `native` (libunicorn 2.1.4 via `koffi`) ou `wasm` (`@alexaltea/unicorn-js` 2.1.4) |
| `unicorn.*_const`            | `lib/unicorn_const.js` (gerado das constantes da 2.1.4)                    |
| `capstone==5.0.9`            | `@alexaltea/capstone-js` (opcional; só ferramentas de pesquisa)           |
| `pyelftools`                 | `lib/elf.js` (ELF, símbolos, relocações, `.eh_frame`)                     |
| `ctypes` + `snprintf` da libc| `native_libc.js` (printf compatível com glibc, testado por fuzzing)       |
| `zipfile`                    | `lib/zip.js`                                                               |
| `json`, `csv`, `repr`, `int` | `lib/pycompat.js` e `lib/research.js` (mesma saída byte a byte)           |

## Variáveis de ambiente

* `LIBG_V13`: caminho da `libg.so` v13 (padrão `Native/V13/libg.so`; em Python era obrigatório).
* `UNICORN_BACKEND=auto|native|wasm`: `auto` (padrão) tenta a libunicorn nativa e cai para WebAssembly.
* `UNICORN_LIB`: caminho explícito para uma `libunicorn` 2.x.
* `UNICORN_DEBUG=1`: mostra por que o backend nativo não foi usado.
* `NODE_BINARY`: executável Node usado para o processo de batalha (padrão: o Node atual).
* As demais (`V13_RESEARCH_DIR`, `V13_VECTOR_DIR`, `V13_*_TICKS`, `V13_ENEMY`...) mantêm o significado original.

A `libunicorn` para `linux-x64` está em `Native/unicorn/linux-x64/`. Em outras
plataformas, `npm run setup:native` baixa o wheel oficial `unicorn==2.1.4` do
PyPI, confere o SHA-256 e extrai somente a biblioteca (nenhum Python é
executado). Sem ela, o backend WebAssembly é usado automaticamente.

## Verificação de paridade

Cada script foi executado lado a lado com o original Python sobre a mesma
`libg.so`. Arquivos gerados e saída padrão foram comparados byte a byte:

* `battle_worker`: sessão de 1.119 requisições (backends nativo e wasm) e sessão
  Battle Royale de 21.004 requisições: saídas idênticas.
* Todas as sondas `probe_*`, `validate_*`, `inspect_native_schema`,
  `test_native_memory`, incluindo as variantes por variável de ambiente usadas
  pela auditoria: saídas idênticas (campos de tempo de execução excluídos).
* `native.js` (CLI `dump/calls/refs/ptr`) e `package_battles.js`: idênticos.
* `native_libc.js`: 40.000 formatos aleatórios comparados ao `snprintf` da glibc.

`profile_battle_frames.js` usa o profiler do V8 (`.cpuprofile`, abre no Chrome
DevTools) no lugar de `cProfile/pstats`; é a única saída que não é igual por
natureza.
