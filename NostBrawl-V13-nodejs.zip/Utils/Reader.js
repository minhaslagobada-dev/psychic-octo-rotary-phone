'use strict'
const { ValueError } = require('./Errors')

function zigzagDecode (n) {
  return n % 2 === 0 ? n / 2 : -((n - 1) / 2) - 1
}

class BSMessageReader {
  constructor (initialBytes) {
    this.buffer = initialBytes != null ? Buffer.from(initialBytes) : Buffer.alloc(0)
    this._payload_length = this.buffer.length
    this._offset = 0
    this.native_v13 = false
    this._bit_index = 0
    this._bit_buffer = 0
  }

  enable_native_v13 () {
    this.native_v13 = true
    this._bit_index = 0
    this._bit_buffer = 0
    return this
  }

  tell () {
    return this._offset
  }

  read (length) {
    const end = Math.min(this._offset + length, this.buffer.length)
    const data = this.buffer.subarray(this._offset, end)
    this._offset = end
    return data
  }

  peek (length) {
    return this.buffer.subarray(this._offset, this._offset + length)
  }

  _read_exact (length) {
    if (this.native_v13) {
      this._bit_index = 0
    }
    if (length < 0) {
      throw new ValueError(`Negative field length: ${length}`)
    }
    const remaining = Math.max(0, this._payload_length - this.tell())
    if (length > remaining) {
      throw new ValueError(`Unexpected end of message: wanted ${length} bytes, got ${remaining}`)
    }
    const data = this.read(length)
    if (data.length !== length) {
      throw new ValueError(`Unexpected end of message: wanted ${length} bytes, got ${data.length}`)
    }
    return data
  }

  read_byte () {
    return this._read_exact(1)[0]
  }

  read_boolean () {
    if (this.native_v13) {
      if (this._bit_index === 0) {
        const data = this.read(1)
        if (data.length !== 1) {
          throw new ValueError('Unexpected end of packed V13 booleans')
        }
        this._bit_buffer = data[0]
      }
      const value = (this._bit_buffer & (1 << this._bit_index)) !== 0
      this._bit_index = (this._bit_index + 1) & 7
      return value
    }

    const value = this.read_byte()
    if (value !== 0 && value !== 1) {
      throw new ValueError('Booleano inválido')
    }
    return value !== 0
  }

  ensure_end () {
    if (this.read(1).length !== 0) {
      throw new ValueError('Mensagem contém dados residuais')
    }
  }

  read_Vint () {
    if (this.native_v13) {
      return this._read_native_vint()
    }
    const n = this._read_varint(true)
    return zigzagDecode(n)
  }

  _read_native_vint () {
    const first = this.read_byte()
    const negative = (first & 0x40) !== 0
    let result = first & 0x3F
    if ((first & 0x80) === 0) {
      if (negative) {
        result |= -1 << 6
      }
      return BSMessageReader._signed32(result)
    }

    for (let group = 1; group < 4; group++) {
      const byte = this.read_byte()
      result |= (byte & 0x7F) << (6 + (group - 1) * 7)
      if ((byte & 0x80) === 0) {
        if (negative) {
          result |= -1 << (6 + group * 7)
        }
        return BSMessageReader._signed32(result)
      }
    }

    result = (result + ((this.read_byte() & 0x1F) << 27)) >>> 0
    if (negative) {
      result = (result | 0x80000000) >>> 0
    }
    return BSMessageReader._signed32(result)
  }

  static _signed32 (value) {
    value = value >>> 0
    return value & 0x80000000 ? value - 0x100000000 : value
  }

  read_short (length = 2) {
    const data = this._read_exact(length)
    let value = 0
    for (const byte of data) value = value * 256 + byte
    return value
  }

  read_int (length = 4) {
    const data = this._read_exact(length)
    let value = 0
    for (const byte of data) value = value * 256 + byte
    return value
  }

  _read_varint (rotate = true) {
    let result = 0
    let shift = 0
    while (true) {
      if (shift >= 35) {
        throw new ValueError('Variable integer is too long')
      }

      let byte = this.read_byte()
      if (rotate && shift === 0) {
        const seventh = (byte & 0x40) >> 6
        const msb = (byte & 0x80) >> 7
        let n = byte << 1
        n = n & ~0x181
        byte = n | (msb << 7) | seventh
      }
      result += (byte & 0x7F) * 2 ** shift
      shift += 7
      if ((byte & 0x80) === 0) {
        break
      }
    }
    return result
  }

  read_rrsint32 () {
    if (this.native_v13) {
      return this._read_native_vint()
    }
    const n = this._read_varint(true)
    return zigzagDecode(n)
  }

  readScId () {
    const a = this.read_Vint()
    const b = a !== 0 ? this.read_Vint() : -1
    return [a, b]
  }

  readLogicLong () {
    if (this.native_v13) {
      return [this.read_int(), this.read_int()]
    }
    return [this.read_Vint(), this.read_Vint()]
  }

  read_string () {
    const length = this.read_int()
    if (length === 0xFFFFFFFF) {
      return ''
    }
    return this._read_exact(length).toString('utf-8')
  }

  peek_int (length = 4) {
    const data = this.peek(length).subarray(0, length)
    let value = 0
    for (const byte of data) value = value * 256 + byte
    return value
  }

  get payloadLength () {
    return this._payload_length
  }

  atEnd () {
    return this._offset >= this._payload_length
  }
}

module.exports = { BSMessageReader }
