'use strict'

const { ClubService } = require('../../../../Logic/ClubService')
const Writer = require('../../../../Utils/Writer')
const Config = require('../../../../Utils/Config')

class JoinableAllianceListMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 24304
    this.version = 11
    this.player = player
  }

  _log_sent (packetLength) {
    super._log_sent(packetLength)
    if (Config.GetValue().ShowPacketsInLog) {
      console.log(
        `Server | JoinableAllianceListMessage version=${this.version}; ` +
        `raw payload: ${this.buffer.toString('hex')}`
      )
    }
  }

  encode () {
    const clubs = ClubService.list_clubs(1, 100, 2, 30)
    this.writeVint(clubs.length)
    for (const club of clubs) {
      this.writeInt(0)
      this.writeInt(club.id)
      this.writeString(club.name)
      this.writeVint(8)
      this.writeVint(club.badge_id)
      this.writeVint(club.type)
      this.writeVint(club.member_count)
      this.writeVint(club.trophies)
      this.writeVint(club.required_trophies)
      this.writeVint(0)
      this.writeVint(club.online_count)
    }
  }
}

module.exports = JoinableAllianceListMessage
