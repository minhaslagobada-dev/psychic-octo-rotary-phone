'use strict'

const fs = require('fs')

const Characters = require('../Files/CsvLogic/Characters')
const { readDictRows } = require('../Files/CsvLogic/CsvRows')
const { RewardError } = require('./Rewards')

let shopItemsCache = null
let dailyDefinitionsCache = null
let billingPackagesCache = null

class ShopCatalog {
  static get GOLD_OFFERS () {
    return [
      { Amount: 150, Cost: 20 },
      { Amount: 400, Cost: 50 },
      { Amount: 1200, Cost: 140 },
      { Amount: 2600, Cost: 280 }
    ]
  }

  static get TOKEN_DOUBLER () { return { Amount: 1000, Cost: 50 } }
  static get BOX_TYPES () { return { 0: 10, 6: 10, 10: 11, 14: 12, 15: 10 } }
  static get CURRENCIES () { return { 0: 'gems', 1: 'gold', 2: 'starpoints' } }

  static _integer (value, defaultValue = 0) {
    try {
      const parsed = Number(value)
      if (Number.isNaN(parsed) || !Number.isFinite(parsed)) {
        return defaultValue
      }
      return Math.trunc(parsed)
    } catch (error) {
      return defaultValue
    }
  }

  static _boolean (value) {
    return String(value || '').trim().toUpperCase() === 'TRUE'
  }

  static shop_items () {
    if (shopItemsCache !== null) {
      return shopItemsCache
    }
    const rows = readDictRows('GameAssets/csv_client/shop_items.csv').slice(1)
    const result = {}
    for (const row of rows) {
      const offerId = ShopCatalog._integer(row.OfferType, -1)
      if (offerId >= 0) {
        result[offerId] = row.Name
      }
    }
    shopItemsCache = result
    return result
  }

  static validate_item (item) {
    if (typeof item !== 'object' || item === null || Array.isArray(item)) {
      throw new Error('Invalid shop item')
    }
    const offerId = ShopCatalog._integer(item.offerId, -1)
    if (!(offerId in ShopCatalog.shop_items())) {
      throw new Error(`Unknown offer item: ${offerId}`)
    }
    const amount = ShopCatalog._integer(item.amount, -1)
    const value = ShopCatalog._integer(item.value, -1)
    if (amount < 1 || value < 0) {
      throw new Error('Invalid shop item amount')
    }
    let target = item.target
    if (target !== null && target !== undefined) {
      if (!Array.isArray(target) || target.length !== 2) {
        throw new Error('Invalid shop item target')
      }
      target = [Math.trunc(target[0]), Math.trunc(target[1])]
      if (target[0] <= 0 || target[1] < 0) {
        throw new Error('Invalid shop item target')
      }
    } else {
      target = null
    }
    if (offerId === 0 && value !== 1) {
      throw new Error('FreeBox requires Value 1')
    }
    if (offerId === 8) {
      if (target === null || target[0] !== 16) {
        throw new Error('HeroPower requires a brawler reference')
      }
      if (!Characters.get_brawlers_id().includes(target[1])) {
        throw new Error('Invalid HeroPower brawler')
      }
    }
    if ((offerId === 3 || offerId === 5) && (target === null || target[0] !== 16)) {
      throw new Error('Brawler offer requires a character reference')
    }
    if ([2, 3, 4, 5].includes(offerId) && amount !== 1) {
      throw new Error('Unique rewards require Amount 1')
    }
    return {
      offerId,
      value,
      target,
      amount
    }
  }

  static daily_definitions () {
    if (dailyDefinitionsCache !== null) {
      return dailyDefinitionsCache
    }
    const config = JSON.parse(fs.readFileSync('JSON/shop.json', 'utf-8'))
    const daily = config.daily || []
    const once = config.once || []
    if (!daily.length) {
      throw new Error('The shop catalog is empty')
    }
    if (!Array.isArray(once)) {
      throw new Error('Invalid one-time shop catalog')
    }
    for (const definition of daily.concat(once)) {
      ShopCatalog.validate_definition(definition)
    }
    dailyDefinitionsCache = config
    return config
  }

  static validate_definition (definition) {
    let items = definition.items || []
    if (!(items.length >= 1 && items.length <= 3)) {
      throw new Error('An offer requires between one and three items')
    }
    definition.items = items.map((item) => ShopCatalog.validate_item(item))
    const currency = ShopCatalog._integer(definition.currency, -1)
    const price = ShopCatalog._integer(definition.price, -1)
    const original = ShopCatalog._integer(
      definition.originalPrice !== undefined ? definition.originalPrice : price, -1
    )
    if (!(currency in ShopCatalog.CURRENCIES) || price < 0 || original < price) {
      throw new Error('Invalid offer price')
    }
    if (!String(definition.key || '')) {
      throw new Error('An offer requires a stable key')
    }
    const display = ShopCatalog._integer(definition.display, 0)
    if (![0, 1].includes(display)) {
      throw new Error('Invalid offer display')
    }
    definition.currency = currency
    definition.price = price
    definition.originalPrice = original
    definition.display = display
    return definition
  }

  static billing_packages () {
    if (billingPackagesCache !== null) {
      return billingPackagesCache
    }
    const rows = readDictRows('GameAssets/csv_client/billing_packages.csv').slice(1)
    const packages = {}
    for (const row of rows) {
      const name = row.Name || ''
      const packageType = ShopCatalog._integer(row.Type, 0)
      const diamonds = ShopCatalog._integer(row.Diamonds, 0)
      if (!name || ![1, 2, 3].includes(packageType) || diamonds < 1) {
        continue
      }
      packages[name] = {
        name,
        tid: row.TID || '',
        type: packageType,
        disabled: ShopCatalog._boolean(row.Disabled),
        android: ShopCatalog._boolean(row.ExistsAndroid),
        diamonds,
        order: ShopCatalog._integer(row.Order, 0),
        starterPackNumber: ShopCatalog._integer(row.StarterPackNumber, 0),
        bigBoxCount: ShopCatalog._integer(row.BigBoxCount, 0),
        xpLevelReq: ShopCatalog._integer(row.XpLevelReq, 0)
      }
    }
    billingPackagesCache = packages
    return packages
  }

  static billing_package (values) {
    const matches = []
    const packages = ShopCatalog.billing_packages()
    for (const value of values) {
      if (value in packages) {
        const found = packages[value]
        if (!matches.some((existing) => existing === found)) {
          matches.push(found)
        }
      }
    }
    if (matches.length !== 1) {
      throw new RewardError('Pacote de billing desconhecido ou ambíguo')
    }
    const found = matches[0]
    if (found.disabled || !found.android) {
      throw new RewardError('Pacote de billing indisponível')
    }
    return found
  }
}

module.exports = ShopCatalog
