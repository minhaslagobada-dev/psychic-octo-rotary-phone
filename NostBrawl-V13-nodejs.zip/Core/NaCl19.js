'use strict'
const crypto = require('crypto')

const MASK32 = 0xFFFFFFFF
const FIELD_PRIME = (1n << 255n) - 19n
const POLY_PRIME = (1n << 130n) - 5n
const SIGMA = Buffer.from('expand 32-byte k', 'latin1')

class VerificationError extends Error {
  constructor (message) {
    super(message)
    this.name = 'VerificationError'
  }
}

function bufferToBigIntLE (buffer) {
  let value = 0n
  for (let index = buffer.length - 1; index >= 0; index--) {
    value = (value << 8n) | BigInt(buffer[index])
  }
  return value
}

function bigIntToBufferLE (value, length) {
  const out = Buffer.alloc(length)
  let current = BigInt(value)
  for (let index = 0; index < length; index++) {
    out[index] = Number(current & 0xFFn)
    current >>= 8n
  }
  return out
}

function mod (value, prime) {
  const result = value % prime
  return result < 0n ? result + prime : result
}

function modPow (base, exponent, prime) {
  let result = 1n
  let b = mod(base, prime)
  let e = exponent
  while (e > 0n) {
    if (e & 1n) result = (result * b) % prime
    b = (b * b) % prime
    e >>= 1n
  }
  return result
}

function rotl32 (value, shift) {
  value = value >>> 0
  return ((value << shift) | (value >>> (32 - shift))) >>> 0
}

function words (data) {
  const out = []
  for (let index = 0; index < data.length; index += 4) {
    out.push(data.readUInt32LE(index))
  }
  return out
}

function salsa19Core (input16, key32, constant16 = SIGMA, hsalsa = false) {
  if (input16.length !== 16 || key32.length !== 32 || constant16.length !== 16) {
    throw new Error('Invalid Salsa19 input size')
  }

  const constants = words(constant16)
  const key = words(key32)
  const inputWords = words(input16)
  let x = new Array(16).fill(0)

  for (let index = 0; index < 4; index++) {
    x[5 * index] = constants[index]
    x[1 + index] = key[index]
    x[6 + index] = inputWords[index]
    x[11 + index] = key[4 + index]
  }

  const initial = x.slice()

  for (let round = 0; round < 19; round++) {
    const w = new Array(16).fill(0)
    for (let column = 0; column < 4; column++) {
      const t = [0, 1, 2, 3].map((index) => x[(5 * column + 4 * index) % 16])
      t[1] ^= rotl32(t[0] + t[3], 7)
      t[2] ^= rotl32(t[1] + t[0], 9)
      t[3] ^= rotl32(t[2] + t[1], 13)
      t[0] ^= rotl32(t[3] + t[2], 18)
      for (let index = 0; index < 4; index++) t[index] = t[index] >>> 0
      for (let index = 0; index < 4; index++) {
        w[4 * column + (column + index) % 4] = t[index]
      }
    }
    x = w
  }

  let output
  if (hsalsa) {
    for (let index = 0; index < 16; index++) {
      x[index] = (x[index] + initial[index]) >>> 0
    }
    for (let index = 0; index < 4; index++) {
      x[5 * index] = (x[5 * index] - constants[index]) >>> 0
      x[6 + index] = (x[6 + index] - inputWords[index]) >>> 0
    }
    output = [0, 1, 2, 3].map((index) => x[5 * index])
    for (let index = 0; index < 4; index++) output.push(x[6 + index])
  } else {
    output = x.map((value, index) => (value + initial[index]) >>> 0)
  }

  const result = Buffer.alloc(output.length * 4)
  for (let index = 0; index < output.length; index++) {
    result.writeUInt32LE(output[index] >>> 0, index * 4)
  }
  return result
}

function xsalsa19Xor (data, nonce24, key32) {
  if (nonce24.length !== 24 || key32.length !== 32) {
    throw new Error('XSalsa19 requires a 24-byte nonce and a 32-byte key')
  }

  const subkey = salsa19Core(nonce24.subarray(0, 16), key32, SIGMA, true)
  const counter = Buffer.alloc(16)
  nonce24.copy(counter, 0, 16, 24)
  const result = Buffer.alloc(data.length)

  for (let offset = 0; offset < data.length; offset += 64) {
    const stream = salsa19Core(counter, subkey, SIGMA, false)
    const block = data.subarray(offset, Math.min(offset + 64, data.length))
    for (let index = 0; index < block.length; index++) {
      result[offset + index] = block[index] ^ stream[index]
    }
    const value = (counter.readBigUInt64LE(8) + 1n) & 0xFFFFFFFFFFFFFFFFn
    counter.writeBigUInt64LE(value, 8)
  }

  return result
}

function poly1305 (message, key32) {
  if (key32.length !== 32) {
    throw new Error('Poly1305 requires a 32-byte one-time key')
  }

  let r = bufferToBigIntLE(key32.subarray(0, 16))
  r &= 0x0FFFFFFC0FFFFFFC0FFFFFFC0FFFFFFFn
  const s = bufferToBigIntLE(key32.subarray(16, 32))
  let accumulator = 0n

  for (let offset = 0; offset < message.length; offset += 16) {
    const chunk = message.subarray(offset, Math.min(offset + 16, message.length))
    const number = bufferToBigIntLE(Buffer.concat([chunk, Buffer.from([1])]))
    accumulator = ((accumulator + number) * r) % POLY_PRIME
  }

  return bigIntToBufferLE((accumulator + s) & ((1n << 128n) - 1n), 16)
}

function secretbox (message, nonce24, key32) {
  const ciphertext = xsalsa19Xor(Buffer.concat([Buffer.alloc(32), message]), nonce24, key32).subarray(32)
  const polyKey = xsalsa19Xor(Buffer.alloc(32), nonce24, key32)
  return Buffer.concat([poly1305(ciphertext, polyKey), ciphertext])
}

function secretboxOpen (ciphertext, nonce24, key32) {
  if (ciphertext.length < 16) {
    throw new VerificationError('Ciphertext is too short')
  }

  const signature = ciphertext.subarray(0, 16)
  const encrypted = ciphertext.subarray(16)
  const polyKey = xsalsa19Xor(Buffer.alloc(32), nonce24, key32)
  const expected = poly1305(encrypted, polyKey)
  if (signature.length !== expected.length || !crypto.timingSafeEqual(signature, expected)) {
    throw new VerificationError('Ciphertext failed verification')
  }
  return xsalsa19Xor(Buffer.concat([Buffer.alloc(32), encrypted]), nonce24, key32).subarray(32)
}

function scalarmult (scalar32, point32) {
  if (scalar32.length !== 32 || point32.length !== 32) {
    throw new Error('Curve25519 values must contain 32 bytes')
  }

  const scalar = Buffer.from(scalar32)
  scalar[0] &= 248
  scalar[31] &= 127
  scalar[31] |= 64

  const point = Buffer.from(point32)
  point[31] &= 127
  const x1 = bufferToBigIntLE(point)
  let x2 = 1n
  let z2 = 0n
  let x3 = x1
  let z3 = 1n
  let swap = 0

  for (let bitIndex = 254; bitIndex >= 0; bitIndex--) {
    const bit = (scalar[bitIndex >> 3] >> (bitIndex & 7)) & 1
    swap ^= bit
    if (swap) {
      const tx = x2; x2 = x3; x3 = tx
      const tz = z2; z2 = z3; z3 = tz
    }
    swap = bit

    const a = mod(x2 + z2, FIELD_PRIME)
    const aa = mod(a * a, FIELD_PRIME)
    const b = mod(x2 - z2, FIELD_PRIME)
    const bb = mod(b * b, FIELD_PRIME)
    const e = mod(aa - bb, FIELD_PRIME)
    const c = mod(x3 + z3, FIELD_PRIME)
    const d = mod(x3 - z3, FIELD_PRIME)
    const da = mod(d * a, FIELD_PRIME)
    const cb = mod(c * b, FIELD_PRIME)
    x3 = mod((da + cb) ** 2n, FIELD_PRIME)
    z3 = mod(x1 * mod((da - cb) ** 2n, FIELD_PRIME), FIELD_PRIME)
    x2 = mod(aa * bb, FIELD_PRIME)
    z2 = mod(e * (aa + 121665n * e), FIELD_PRIME)
  }

  if (swap) {
    const tx = x2; x2 = x3; x3 = tx
    const tz = z2; z2 = z3; z3 = tz
  }

  const result = mod(x2 * modPow(z2, FIELD_PRIME - 2n, FIELD_PRIME), FIELD_PRIME)
  return bigIntToBufferLE(result, 32)
}

function scalarmultBase (scalar32) {
  const base = Buffer.alloc(32)
  base[0] = 9
  return scalarmult(scalar32, base)
}

function boxBeforenm (publicKey32, privateKey32) {
  const shared = scalarmult(privateKey32, publicKey32)
  return salsa19Core(Buffer.alloc(16), shared, SIGMA, true)
}

module.exports = {
  MASK32,
  FIELD_PRIME,
  POLY_PRIME,
  SIGMA,
  VerificationError,
  secretbox,
  secretboxOpen,
  scalarmult,
  scalarmultBase,
  boxBeforenm
}
