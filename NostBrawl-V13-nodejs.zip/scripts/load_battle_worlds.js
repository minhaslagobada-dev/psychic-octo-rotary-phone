'use strict'
// Real UDP peers and the production coordinator/world at 20 Hz. This measures
// server processing and delivery, not the APK's rendering or a public network.
const assert = require('node:assert/strict')
const dgram = require('node:dgram')
const { performance, monitorEventLoopDelay } = require('node:perf_hooks')
const { BattleTransport } = require('../Logic/Battle/Network/BattleTransport')
const { BattleCoordinator } = require('../Logic/Battle/BattleCoordinator')
const { encodeInput, envelope, readEnvelope } = require('../Logic/Battle/Network/V13BattleCodec')
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms))
async function main () {
  const count = 200; const seconds = Number(process.argv[2] || 10)
  assert(seconds >= 1 && seconds <= 60)
  const transport = new BattleTransport({ BindIP: '127.0.0.1', Port: 0, AdvertiseHost: '127.0.0.1', MaxPlayers: count, SessionTimeoutMs: 30000 })
  let coordinator; const peers = []; const sessions = []; const errors = []
  const received = new Uint32Array(count); const lag = monitorEventLoopDelay({ resolution: 10 })
  let sent = 0
  try {
    await transport.start(); coordinator = new BattleCoordinator(transport, { MaxPlayers: count })
    coordinator.on('battleError', error => errors.push(error.stack)); transport.on('transportError', error => errors.push(error.message))
    for (let i = 0; i < count; i++) {
      const peer = dgram.createSocket('udp4'); peers.push(peer); peer.on('error', error => errors.push(error.message))
      await new Promise(resolve => peer.bind(0, '127.0.0.1', resolve))
      const player = { low_id: i + 1, high_id: 0, logged_in: true, brawler_id: coordinator.assets.heroes[i % coordinator.assets.heroes.length].id, skin_id: 0, name: 'Load ' + i, Brawler_level: {} }
      const client = { remoteAddress: '127.0.0.1', localAddress: '127.0.0.1', write: () => true }
      coordinator.enqueue([{ player, client }], 13)
      const session = transport.attach(player, client); sessions.push(session)
      peer.on('message', bytes => {
        try { assert(bytes.length <= 1400); assert.equal(readEnvelope(bytes.subarray(10)).type, 24109); received[i]++ } catch (error) { errors.push(error.message) }
      })
    }
    // Stop automatic polling while building all 20 complete worlds; restart
    // the same production tick scheduler after clients have bound UDP endpoints.
    coordinator.step()
    assert.equal(coordinator.worlds.size, 20)
    lag.enable(); const start = performance.now()
    for (let tick = 0; tick < seconds * 20; tick++) {
      for (let i = 0; i < count; i++) {
        const world = coordinator.accounts.get(i + 1); const char = world.characters.get(i + 1)
        const commands = tick === 0 ? [{ counter: 0, category: 1, code: 102, x: 0, y: 0 }] : [
          { counter: tick * 2, category: 1, code: 100, x: world.map.logicWidth / 2 | 0, y: world.map.logicHeight / 2 | 0 },
          { counter: tick * 2 + 1, category: 1, code: char.skills[0].definition.id, x: world.map.logicWidth - char.x | 0, y: world.map.logicHeight - char.y | 0, flag: true }
        ]
        peers[i].send(Buffer.concat([sessions[i].header, envelope(10555, encodeInput({ tick, inputs: commands }))]), transport.gateway.port, '127.0.0.1', error => { if (error) errors.push(error.message) })
        sent++
      }
      await sleep(Math.max(0, start + (tick + 1) * 50 - performance.now()))
    }
    await sleep(100); lag.disable()
    assert.equal(errors.length, 0, errors.join('\n'))
    assert(Array.from(received).every(n => n > seconds * 10), 'Every player must receive at least 10 snapshots per second')
    assert.equal(coordinator.accounts.size, 200)
    assert.equal(coordinator.metrics.failures, 0)
    const output = { scope: 'production combat world + UDP, local test peers', players: count, battles: coordinator.worlds.size, seconds, sentInputs: sent,
      snapshotsReceived: received.reduce((a, b) => a + b, 0), minimumSnapshotsPerPlayer: Math.min(...received),
      eventLoopP99Ms: +(lag.percentile(99) / 1e6).toFixed(3), rssMiB: +(process.memoryUsage().rss / 1048576).toFixed(2), metrics: coordinator.metrics }
    console.log(JSON.stringify(output, null, 2))
  } finally {
    lag.disable(); if (coordinator) coordinator.close()
    for (const peer of peers) { try { peer.close() } catch (_) {} }
    await transport.close()
    assert.equal(transport.gateway.sessions.size, 0)
    if (coordinator) assert.equal(coordinator.accounts.size, 0)
  }
}
main().catch(error => { console.error(error); process.exitCode = 1 })
