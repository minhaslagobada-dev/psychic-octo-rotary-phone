'use strict'
// Prepares the Node.js-only native v13 engine (no Python, venv or pip).
//
// The ARM64 libg.so is emulated by Unicorn 2.1.4 through one of two backends:
//   native: libunicorn 2.x loaded with koffi (fast; needs the shared library)
//   wasm:   @alexaltea/unicorn-js (pure WebAssembly; works everywhere, slower)
// This script checks both and, when the native library for this platform is
// missing, downloads the official unicorn 2.1.4 wheel from PyPI (a plain zip)
// and extracts only libunicorn into Native/unicorn/<platform>-<arch>/.
// Use --no-download to skip the download, --force to replace an existing lib.
const fs = require('node:fs')
const path = require('node:path')
const https = require('node:https')
const { ZipReader } = require('./native_v13/lib/zip')

const root = path.resolve(__dirname, '..')
const args = new Set(process.argv.slice(2))
const platform = `${process.platform}-${process.arch}`
const destination = path.join(root, 'Native', 'unicorn', platform)
const names = process.platform === 'win32' ? ['unicorn.dll'] : process.platform === 'darwin' ? ['libunicorn.2.dylib', 'libunicorn.dylib'] : ['libunicorn.so.2', 'libunicorn.so']

function has (module) { try { require.resolve(module, { paths: [root] }); return true } catch (_) { return false } }
function isMusl () {
  if (process.platform !== 'linux') return false
  try { return !process.report.getReport().header.glibcVersionRuntime } catch (_) { return false }
}
// PyPI wheel platform tag fragment for this host.
function wheelTag () {
  const key = platform + (isMusl() ? '-musl' : '')
  return {
    'linux-x64': /manylinux.*x86_64/,
    'linux-arm64': /manylinux.*aarch64/,
    'linux-ia32': /manylinux.*i686/,
    'linux-x64-musl': /musllinux.*x86_64/,
    'linux-arm64-musl': /musllinux.*aarch64/,
    'darwin-x64': /macosx.*x86_64/,
    'darwin-arm64': /macosx.*arm64/,
    'win32-x64': /win_amd64/,
    'win32-ia32': /win32/
  }[key]
}
function get (url, redirects = 5) {
  return new Promise((resolve, reject) => {
    https.get(url, { headers: { 'User-Agent': 'NostBrawl-setup-native' } }, response => {
      if (response.statusCode >= 300 && response.statusCode < 400 && response.headers.location && redirects > 0) {
        response.resume(); resolve(get(new URL(response.headers.location, url).toString(), redirects - 1)); return
      }
      if (response.statusCode !== 200) { response.resume(); reject(new Error(`HTTP ${response.statusCode} for ${url}`)); return }
      const chunks = []
      response.on('data', chunk => chunks.push(chunk)); response.on('end', () => resolve(Buffer.concat(chunks))); response.on('error', reject)
    }).on('error', reject)
  })
}

async function download () {
  const tag = wheelTag()
  if (!tag) throw new Error(`No unicorn 2.1.4 wheel is published for ${platform}`)
  const release = JSON.parse(await get('https://pypi.org/pypi/unicorn/2.1.4/json'))
  const wheel = release.urls.find(file => file.packagetype === 'bdist_wheel' && tag.test(file.filename))
  if (!wheel) throw new Error(`No unicorn 2.1.4 wheel matches ${platform}`)
  console.log('Downloading', wheel.filename)
  const archive = await get(wheel.url)
  const sha256 = require('node:crypto').createHash('sha256').update(archive).digest('hex')
  if (wheel.digests && wheel.digests.sha256 && wheel.digests.sha256 !== sha256) throw new Error('Wheel checksum mismatch')
  const zip = new ZipReader(archive)
  const libraries = zip.namelist().filter(name => /(^|\/)lib\/(lib)?unicorn[^/]*\.(so(\.\d+)*|dylib|dll)$/.test(name))
  if (!libraries.length) throw new Error('libunicorn was not found inside ' + wheel.filename)
  fs.mkdirSync(destination, { recursive: true })
  for (const name of libraries) {
    const file = path.join(destination, path.basename(name))
    fs.writeFileSync(file, zip.read(name), { mode: 0o755 })
    console.log('Extracted', path.relative(root, file))
  }
  // Keep the soname the loader expects next to the unversioned name.
  if (process.platform === 'linux' && !fs.existsSync(path.join(destination, 'libunicorn.so.2')) && fs.existsSync(path.join(destination, 'libunicorn.so'))) fs.copyFileSync(path.join(destination, 'libunicorn.so'), path.join(destination, 'libunicorn.so.2'))
}

async function main () {
  console.log('Native v13 engine setup for', platform, '(Node.js only)')
  if (!has('@alexaltea/unicorn-js')) throw new Error('Missing @alexaltea/unicorn-js; run npm install first')
  console.log('  wasm backend: @alexaltea/unicorn-js available')
  if (!has('koffi')) {
    console.log('  native backend: koffi is not installed (optional dependency); the wasm backend will be used')
    return
  }
  const existing = process.env.UNICORN_LIB || names.map(name => path.join(destination, name)).find(file => fs.existsSync(file))
  if (existing && !args.has('--force')) console.log('  native backend: using', existing)
  else if (args.has('--no-download')) console.log('  native backend: libunicorn not found in', path.relative(root, destination), '- the wasm backend will be used')
  else {
    try { await download() } catch (error) {
      console.log('  native backend unavailable:', error.message, '- the wasm backend will be used')
      return
    }
  }
  // Prove the selected backend really opens an ARM64 engine.
  process.env.UNICORN_BACKEND = 'native'
  try {
    const { loadUnicorn, Uc } = require('./native_v13/lib/unicorn')
    const C = require('./native_v13/lib/unicorn_const')
    await loadUnicorn()
    const uc = new Uc(C.UC_ARCH_ARM64, C.UC_MODE_ARM)
    if (uc.close) uc.close()
    console.log('  native backend: libunicorn loaded through koffi')
  } catch (error) {
    console.log('  native backend failed to load:', error.message, '- the wasm backend will be used (UNICORN_BACKEND=auto)')
  }
  console.log('Native v13 engine ready. npm start runs it with Node.js; no Python is required.')
}
main().catch(error => { console.error(error.message); process.exit(1) })
