'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const frames = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'character-obstacle-vectors.json')))
const assets = new BattleAssets()
const grid = assets.maps.get('Tutorial').rows
for (const hero of assets.heroes) {
  const sequence = frames.filter(frame => frame.name === hero.Name)
  assert.equal(sequence.length, 100, hero.Name)
  const radius = Number(hero.CollisionRadius)
  for (const [i, frame] of sequence.entries()) {
    assert.equal(frame.tick, 150 + i)
    assert.equal(frame.hp, Number(hero.Hitpoints), hero.Name)
    for (let y = 0; y < grid.length; y++) for (let x = 0; x < grid[y].length; x++) {
      const tile = assets.tileCodes.get(grid[y][x])
      if (!tile || tile.BlocksMovement !== 'true') continue
      const nearestX = Math.max(x * 300, Math.min(frame.x, (x + 1) * 300))
      const nearestY = Math.max(y * 300, Math.min(frame.y, (y + 1) * 300))
      const distanceSquared = (frame.x - nearestX) ** 2 + (frame.y - nearestY) ** 2
      assert(distanceSquared >= radius ** 2, `${hero.Name} overlaps ${grid[y][x]} at ${x},${y}, tick ${frame.tick}`)
    }
  }
  assert(sequence.some(frame => frame.x < 2400), `${hero.Name} must detour around the wall`)
  assert.deepEqual([sequence.at(-1).x, sequence.at(-1).y], sequence[0].target, hero.Name)
}
assert.equal(frames.length, assets.heroes.length * 100)
console.log(`Original native obstacle movement: ${frames.length} frames, ${assets.heroes.length} heroes reached target around Tutorial walls without radius overlap`)
