'use strict'
// Port of probe_projectile_launch.py.
// Execute original launch initializer, with a non-character origin fixture.
// No gameplay hooks. This isolates timing from hero CSV data and spread RNG.
const path = require('node:path')
const { NativeV13 } = require('./emulate_v13')
const { NativeCsv } = require('./native_csv')
const { NativeOpenMap } = require('./native_open_map')
const R = require('./lib/research')
R.main(async () => {
  const n = await NativeV13.create(); n.decrypt(); const root = R.ROOT; const m = R.memory(n)
  const t = new NativeCsv(n, path.join(root, 'GameAssets/csv_logic/projectiles.csv')); t.initialize_schema(0x449b0c)
  const terrain = new NativeOpenMap(n, root)
  const w = (a, v) => t.word(a, v); const p = (a, v) => t.ptr(a, v); const get = m.i32
  const battle = t.alloc(0x100); p(battle + 0x70, terrain.pointer)
  const manager = t.alloc(0x80); p(manager + 0x50, battle)
  const origin = t.alloc(0x400)
  // Actual projectile vtable returns type 1: excludes hero-specific muzzle metadata.
  p(origin, 0x74e558); w(origin + 0x30, 3000); w(origin + 0x34, 4500)
  w(origin + 0x3c, 1); w(origin + 0x40, 2)
  const records = []
  t.records.forEach((row, i) => {
    const d = R.zipDict(t.names, row); const meta = t.alloc(0x200); p(meta + 8, t.rows[i])
    n.uc.mem_write(meta + 0x90, Buffer.from([d.Indirect === 'true' ? 1 : 0, d.ConstantFlyTime === 'true' ? 1 : 0]))
    w(meta + 0x94, R.int0(d.Speed)); w(meta + 0xa0, R.int0(d.Gravity))
    for (const start of [[3000, 4500], [0, 12000]]) {
      for (const end of [[3500, 5000], [3000, 4500], [5317, 8429]]) {
        for (const reduction of [0, 100, R.int0(d.Speed), R.int0(d.Speed) + 100]) {
          const obj = t.alloc(0x120); n.call(0x4d30d0, obj, meta); p(obj + 0x18, manager)
          // Arguments beyond x7 occupy the original caller's stack.
          const stack = 0x201ff000
          n.uc.mem_write(stack, R.pack('Q', 0, 100, 123, 456, reduction, 0, 0))
          n.call(0x20308c, obj, start[0], start[1], 0, origin, end[0], end[1], 0)
          records.push({
            name: d.Name, speed: R.int0(d.Speed), constantFlyTime: d.ConstantFlyTime === 'true',
            start, target: end, speedReduction: reduction, launch: get(obj + 0x20), finish: get(obj + 0x24),
            progressStep: get(obj + 0xcc), actualStart: [get(obj + 0x60), get(obj + 0x64)], initialZ: get(obj + 0x70)
          })
        }
      }
    }
  })
  R.writeJson('projectile-launch-vectors.json', records)
  R.print('Original projectile launch initializer:', records.length, 'cases; controlled non-character origin, no gameplay hooks')
})
