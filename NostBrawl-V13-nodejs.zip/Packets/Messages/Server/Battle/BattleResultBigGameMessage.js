'use strict'
const { apply_battle_result_rewards } = require('../../../../Logic/BattleResultAdapter')
const BattleResultMessage = require('./BattleResultMessage')

class BattleResultBigGameMessage extends BattleResultMessage {
  static get GAME_MODE () { return 4 }

  _get_rewards (battleId) {
    if (battleId === null || battleId === undefined) {
      return apply_battle_result_rewards(this.player, 4)
    }
    return apply_battle_result_rewards(this.player, 4, battleId)
  }
}

module.exports = BattleResultBigGameMessage
