'use strict'
const { sqrt, distance } = require('./Math')
const f = Math.fround
const div = (a, b) => b === 0 ? 0 : Math.trunc(a / b)
const mul = Math.imul
const add = (a, b) => (a + b) | 0
const scale = (a, b) => div(mul(a, b), 1000)
const fcvtzs = value => Number.isNaN(value) ? 0 : value >= 2147483647 ? 2147483647 : value <= -2147483648 ? -2147483648 : Math.trunc(value)
// Transcribed from ProjectileServer::getPosAtTick0x350c04..0x351128.
// Flight ending/deployment ticks are inputs from the native shoot routine;
// this function does not invent a lifetime, speed or fuse for a projectile.
function positionAtTick (data, state, tick) {
  const start = { x: state.start[0], y: state.start[1] }
  const target = { x: state.end[0], y: state.end[1] }
  const elapsed = tick - state.launch; const duration = state.finish - state.launch
  const dx = target.x - start.x; const dy = target.y - start.y
  const squared = add(mul(dx, dx), mul(dy, dy))
  const length = Math.max(1, sqrt(squared))
  let result, height
  if (elapsed > duration) {
    result = { ...target }; height = data.gravity ? 0 : state.z
  } else if (data.bounce > 0) {
    const progressNumerator = mul(elapsed, 1000)
    const progress = div(progressNumerator, duration)
    const span = data.bounce * 10; const pivot = 1000 - span
    const extension = div(mul(span, length), 1500)
    const extended = { x: add(target.x, div(mul(extension, dx), length)), y: add(target.y, div(mul(extension, dy), length)) }
    const afterPivot = progress - pivot
    if (afterPivot > 0) {
      result = {}
      for (const axis of ['x', 'y']) {
        const delta = extended[axis] - start[axis]
        const anchor = div(add(mul(span, start[axis]), mul(pivot, extended[axis])), 1000)
        const finish = add(add(start[axis], div(mul(delta, pivot), 1000)), div(mul(delta, span), 2000))
        result[axis] = div(add(mul(anchor, span - afterPivot), mul(finish, afterPivot)), span)
      }
      height = 0
    } else {
      result = { x: div(add(mul(1000 - progress, start.x), mul(progress, extended.x)), 1000),
        y: div(add(mul(1000 - progress, start.y), mul(progress, extended.y)), 1000) }
      const firstDuration = div(mul(pivot, duration), 1000)
      const firstProgress = div(progressNumerator, firstDuration)
      height = scale(1000 - firstProgress, state.z)
    }
  } else {
    const remaining = duration - elapsed
    result = { x: add(div(mul(elapsed, target.x), duration), div(mul(remaining, start.x), duration)),
      y: add(div(mul(elapsed, target.y), duration), div(mul(remaining, start.y), duration)) }
    height = data.gravity ? div(mul(state.z, remaining), duration) : state.z
  }
  if (data.gravity) {
    let coefficient = f(f(-data.gravity) / (data.constantFlyTime ? f(1000) : f(f(sqrt(length)) * f(40))))
    const speed = Math.max(f(0.1), f(f(data.speed) * f(0.1)))
    let flight, time, arc
    if (data.bounce > 0) {
      const offset = div(mul(sqrt(squared), data.bounce), 150)
      const pivot = { x: target.x - div(mul(offset, dx), sqrt(squared)), y: target.y - div(mul(offset, dy), sqrt(squared)) }
      const px = target.x - pivot.x; const py = target.y - pivot.y
      const dot = add(mul(px, result.x - pivot.x), mul(py, result.y - pivot.y))
      if (dot >= 0) {
        flight = Math.max(f(0.1), f(f(distance(pivot, target)) / speed))
        time = f(f(distance(pivot, result)) / speed)
      } else {
        flight = Math.max(f(0.1), f(f(distance(start, pivot)) / speed))
        time = f(f(distance(start, result)) / speed)
      }
      arc = f(f(time * coefficient) * f(time - flight))
    } else {
      const d = f(distance(start, target))
      flight = Math.max(f(0.1), f(d / speed))
      time = f(f(distance(start, result)) / speed)
      if (data.constantFlyTime) coefficient = f(f(coefficient * f(2000000)) / f(d * d))
      arc = f(f(f(time - flight) * time) * coefficient)
    }
    height = add(height, fcvtzs(f(arc * f(300))))
  }
  return { ...result, z: Math.max(0, Math.min(3000, height)) }
}
module.exports = { positionAtTick }
