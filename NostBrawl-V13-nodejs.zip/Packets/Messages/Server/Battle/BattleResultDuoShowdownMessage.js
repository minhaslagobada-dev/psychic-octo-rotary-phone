'use strict'
const { apply_battle_result_rewards } = require('../../../../Logic/BattleResultAdapter')
const BattleResultMessage = require('./BattleResultMessage')

class BattleResultDuoShowdownMessage extends BattleResultMessage {
  static get GAME_MODE () { return 5 }

  _get_rewards (battleId) {
    if (battleId === null || battleId === undefined) {
      return apply_battle_result_rewards(this.player, 5)
    }
    return apply_battle_result_rewards(this.player, 5, battleId)
  }
}

module.exports = BattleResultDuoShowdownMessage
