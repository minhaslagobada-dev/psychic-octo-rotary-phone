'use strict'
const Writer = require('../../../../../Utils/Writer')

class AllianceLeaveOkMessage extends Writer {
  constructor (client, player) {
    super(client)
    this.id = 24333
    this.version = 11
    this.player = player
  }

  encode () {
    this.writeVint(80)
  }
}

module.exports = AllianceLeaveOkMessage
