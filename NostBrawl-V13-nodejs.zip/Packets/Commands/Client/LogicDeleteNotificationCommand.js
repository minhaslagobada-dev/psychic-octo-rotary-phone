'use strict'

const NotificationFactory = require('../../../Logic/NotificationFactory')
const LogicChangeResourcesCommand = require('../Server/LogicChangeResourcesCommand')
const LogicSkinDataCommand = require('../Server/LogicSkinDataCommand')

class LogicDeleteNotificationCommand {
  static decode (reader) {
    for (let index = 0; index < 4; index++) {
      reader.read_Vint()
    }
    reader.notification_action = reader.read_Vint()
  }

  static process (reader) {
    const nextType = NotificationFactory.next_pending_type(reader.player)
    if (nextType === NotificationFactory.SKIN_REWARD_TYPE) {
      let result
      try {
        result = NotificationFactory.claim_next_skin(reader.player)
      } catch (error) {
        if (error instanceof TypeError || error instanceof Error) {
          return String(error.message)
        }
        throw error
      }
      new LogicSkinDataCommand(
        reader.client,
        reader.player,
        result.skin,
        result.brawlerReward !== undefined ? result.brawlerReward : null
      ).send()
      return result
    }

    if (nextType === NotificationFactory.SEASON_END_TYPE) {
      let result
      try {
        result = NotificationFactory.claim_next_season(reader.player)
      } catch (error) {
        if (error instanceof TypeError || error instanceof Error) {
          return String(error.message)
        }
        throw error
      }
      const entries = Object.entries(result.resources).sort(
        (a, b) => Number(a[0]) - Number(b[0])
      )
      for (const [resource, amount] of entries) {
        if (amount) {
          new LogicChangeResourcesCommand(
            reader.client, reader.player, Number(resource), amount
          ).send()
        }
      }
      return result
    }
    return null
  }
}

module.exports = LogicDeleteNotificationCommand
