'use strict'

const Writer = require('../../../../Utils/Writer')
const { ValueError } = require('../../../../Utils/Errors')

class FriendOnlineStatusEntryMessage extends Writer {
  constructor (client, player, subjectId, status = null, elapsed = 0) {
    super(client)
    this.enable_native_v13()
    this.id = 24555
    this.player = player
    this.subject_id = Math.trunc(subjectId)
    this.status = status === null || status === undefined ? null : Math.trunc(status)
    this.elapsed = Math.trunc(elapsed)
    if (!(this.subject_id > 0 && this.subject_id <= 0x7fffffff)) {
      throw new ValueError('Conta de presença inválida')
    }
    if (this.status !== null && !(this.elapsed >= 0 && this.elapsed <= 0x7fffffff)) {
      throw new ValueError('Duração de presença inválida')
    }
  }

  encode () {
    this.writeLong(0, this.subject_id)
    this.writeBoolean(this.status !== null)
    if (this.status !== null) {
      this.writeLong(0, this.subject_id)
      this.writeVint(this.status)
      this.writeVint(this.elapsed)
      this.writeBoolean(false)
    }
  }
}

module.exports = FriendOnlineStatusEntryMessage
