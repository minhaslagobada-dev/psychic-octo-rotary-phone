'use strict'
const Writer = require('../../../../Utils/Writer')
class AuthoritativeVisionUpdateMessage extends Writer {
  constructor (client, player, payload) {
    super(client)
    this.enable_native_v13()
    this.player = player; this.id = 24109
    if (!Buffer.isBuffer(payload) || !payload.length) throw new TypeError('A native world snapshot is required')
    this.payload = payload
  }
  encode () { this.writeBytes(this.payload) }
}
module.exports = AuthoritativeVisionUpdateMessage
