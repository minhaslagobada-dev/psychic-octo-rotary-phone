'use strict'
const assert = require('node:assert/strict')
const fs = require('node:fs')
const path = require('node:path')
const { BattleAssets } = require('../Logic/Battle/World/BattleAssets')
if (!process.env.V13_RESEARCH_DIR) throw new Error('Set V13_RESEARCH_DIR to native oracle output')
const frames = JSON.parse(fs.readFileSync(path.join(process.env.V13_RESEARCH_DIR, 'character-movement-vectors.json')))
const assets = new BattleAssets()
const names = new Set()
for (const hero of assets.heroes) {
  const sequence = frames.filter(frame => frame.name === hero.Name)
  assert.equal(sequence.length, 30, hero.Name)
  let previous = sequence[0].origin[0]
  for (const [i, frame] of sequence.entries()) {
    assert.equal(frame.tick, 150 + i)
    assert.equal(frame.hp, Number(hero.Hitpoints), hero.Name)
    assert.equal(frame.y, frame.origin[1], hero.Name)
    assert(frame.x >= previous && frame.x <= frame.target[0], hero.Name)
    const distance = frame.target[0] - frame.origin[0]
    const duration = Math.max(1, Math.trunc(distance * 20 / Number(hero.Speed)))
    const progress = Math.min(1000, Math.trunc((i + 1) * 1000 / duration))
    assert.equal(frame.x, frame.origin[0] + Math.trunc(distance * progress / 1000), hero.Name)
    previous = frame.x
  }
  assert.equal(previous, sequence[0].target[0], hero.Name)
  names.add(hero.Name)
}
assert.equal(frames.length, names.size * 30)
console.log(`Original native movement: ${frames.length} frames, ${names.size} heroes; real Tutorial map/pathfinder, straight corridor only`)
