'use strict'
const { GameRoomGateway } = require('../../../../Logic/GameRoomGateway')
const { GameRoomService, GameRoomFullError } = require('../../../../Logic/GameRoomService')
const TeamErrorMessage = require('../../Server/Gameroom/TeamErrorMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class TeamInvitationResponseMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.enable_native_v13()
    this.player = player
    this.client = client
    this.response_type = 0
    this.inviter_high_id = 0
    this.inviter_id = 0
    this.mute_sender = false
  }

  decode () {
    this.response_type = this.read_Vint()
    this.inviter_high_id = this.read_int()
    this.inviter_id = this.read_int()
    this.mute_sender = this.read_boolean()
    this.ensure_end()
  }

  process () {
    if (this.inviter_high_id !== 0) {
      return null
    }
    if (![1, 2, 3].includes(this.response_type)) {
      return null
    }
    const accepted = this.response_type === 1
    let previous = accepted ? GameRoomService.for_player(this.player) : null
    let room
    let invite
    try {
      if (accepted) {
        ;[room, invite] = GameRoomService.accept_invite_from(
          this.player, this.inviter_id, this.mute_sender
        )
      } else {
        ;[room, invite] = GameRoomService.decline_invite_from(
          this.player, this.inviter_id, this.mute_sender
        )
      }
    } catch (error) {
      if (error instanceof GameRoomFullError) {
        new TeamErrorMessage(this.client, this.player, 2).send()
        return null
      }
      throw error
    }
    if (room === null) {
      return null
    }
    if (accepted) {
      if (previous !== null && previous.id !== room.id) {
        GameRoomGateway.send_left(
          this.player, this.player.low_id, 0, this.client
        )
        previous = GameRoomService.get(previous.id)
        if (previous !== null) {
          GameRoomGateway.broadcast_data_and_stream(
            this.player, previous
          )
        }
      }
      GameRoomGateway.broadcast_data_and_stream(
        this.player, room, this.client
      )
      GameRoomService.sync_presence(
        this.player, GameRoomService.TEAM_PRESENCE
      )
    } else {
      GameRoomGateway.broadcast_data(this.player, room)
    }
    return { room, invite, accepted }
  }
}

module.exports = TeamInvitationResponseMessage
