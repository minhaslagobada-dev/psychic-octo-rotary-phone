'use strict'

const { EventRotation } = require('./EventRotation')

class EventSlots {
  Timer () {
    return EventRotation.seconds_to_next_day()
  }

  loadEvents () {
    const player = this.player !== undefined ? this.player : null
    return EventRotation.legacy_events(player)
  }
}

module.exports = EventSlots
