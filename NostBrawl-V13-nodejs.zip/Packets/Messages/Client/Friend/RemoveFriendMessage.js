'use strict'
const { FriendService, FriendError } = require('../../../../Logic/FriendService')
const PresenceService = require('../../../../Logic/PresenceService')
const FriendListMessage = require('../../Server/Friend/FriendListMessage')
const { BSMessageReader } = require('../../../../Utils/Reader')

class RemoveFriendMessage extends BSMessageReader {
  constructor (client, player, initialBytes) {
    super(initialBytes)
    this.player = player
    this.client = client
    this.high_id = 0
    this.low_id = 0
  }

  decode () {
    this.high_id = this.read_int()
    this.low_id = this.read_int()
    this.ensure_end()
  }

  process () {
    let result
    try {
      if (this.high_id !== 0) {
        throw new FriendError('Conta de amizade inexistente')
      }
      result = FriendService.remove(this.player, this.low_id)
    } catch (error) {
      if (error instanceof FriendError || error instanceof TypeError || error instanceof ValueError) {
        return { removed: false, error: String(error.message !== undefined ? error.message : error) }
      }
      throw error
    }
    new FriendListMessage(
      this.client, this.player, result.entries, true
    ).send()
    new FriendListMessage(
      null, this.player, result.reverse_entries, true
    ).sendWithLowID(result.friend_id)
    PresenceService.sync_pair(this.player, result.friend_id)
    return result
  }
}

module.exports = RemoveFriendMessage
