'use strict'

const Cards = require('../../../Files/CsvLogic/Cards')
const Skins = require('../../../Files/CsvLogic/Skins')
const { RewardError, RewardTransaction } = require('../../../Logic/Rewards')
const { ValueError } = require('../../../Utils/Errors')

class LogicSelectSkinCommand {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    reader.skin_reference = reader.readScId()
    if (reader.skin_reference[0] !== 29 || reader.skin_reference[1] < 0) {
      throw new ValueError(`Invalid skin DataReference: ${reader.skin_reference}`)
    }
    reader.skin_id = reader.skin_reference[1]
  }

  static process (reader) {
    try {
      const skin = Math.trunc(
        reader.skin_id !== undefined ? reader.skin_id : reader.player.skin_id
      )
      if (skin !== 0 && !Skins.get_skins_id().includes(skin)) {
        throw new RewardError('Skin inválida')
      }
      const brawler = (
        skin === 0 ? Math.trunc(reader.player.brawler_id) : Math.trunc(Skins.getBrawler(skin))
      )
      const states = reader.player.BrawlersUnlockedState || {}
      const state = states[String(brawler)] !== undefined ? states[String(brawler)] : states[brawler]
      if ((state || 0) !== 1) {
        throw new RewardError('O brawler precisa estar desbloqueado')
      }
      if (skin !== 0) {
        const owned = (reader.player.UnlockedSkins || {}).Skins || []
        if (!owned.includes(skin)) {
          throw new RewardError('A skin precisa estar desbloqueada')
        }
      }

      const selected = structuredClone(reader.player.brawlers_skins || {})
      selected[String(brawler)] = skin
      const starpower = new Cards().get_spg_by_brawler_id(brawler, 4)
      const transaction = new RewardTransaction(reader.player)
      transaction.set_value('skin_id', 'skinID', skin)
      transaction.set_value('brawler_id', 'brawlerID', brawler)
      transaction.set_value('brawlers_skins', 'brawlersSkins', selected)
      transaction.set_value('starpower', 'starpower', starpower)
      transaction.commit()
      return { skin, brawler }
    } catch (error) {
      if (error instanceof RewardError || error instanceof TypeError || error instanceof ValueError) {
        return String(error.message)
      }
      throw error
    }
  }
}

module.exports = LogicSelectSkinCommand
