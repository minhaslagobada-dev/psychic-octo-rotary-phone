'use strict'
const div = (a, b) => Math.trunc(a / b) | 0
const percent = (d, key) => Number(d[key]) || 100
// Native ProjectileServer::getScale at0x3009c8. Separate truncations matter.
function scaleAtProgress (definition, progress) {
  const start = percent(definition, 'ScaleStart'); const end = percent(definition, 'ScaleEnd')
  if (start === 100 && end === 100) return 100
  return (div(Math.imul(start, (1000 - progress) | 0), 1000) + div(Math.imul(end, progress), 1000)) | 0
}
// Native 0x474ed4. Damage is biased by150 progress units before interpolation.
// This returns the projectile calculation, before character damage reductions.
function damageAtProgress (definition, progress, damage) {
  const start = percent(definition, 'DamagePercentStart'); const end = percent(definition, 'DamagePercentEnd')
  if (start === 100 && end === 100) return damage | 0
  const adjusted = Math.max(0, Math.min(1000, (progress + (end > start ? 150 : -150)) | 0))
  const first = div(Math.imul(Math.imul(start, damage), 1000 - adjusted), 100000)
  const second = div(Math.imul(Math.imul(end, damage), adjusted), 100000)
  return (first + second) | 0
}
module.exports = { scaleAtProgress, damageAtProgress }
