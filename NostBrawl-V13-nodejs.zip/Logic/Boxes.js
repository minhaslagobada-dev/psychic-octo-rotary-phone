'use strict'

class Boxes {
  static get_box_type (boxId) {
    if (boxId === 0 || boxId === 5) {
      return 10
    }
    if (boxId === 1 || boxId === 4) {
      return 12
    }
    if (boxId === 3) {
      return 11
    }
    if (boxId === 10 || boxId === 11 || boxId === 12) {
      return boxId
    }
    throw new Error(`Caixa inválida: ${boxId}`)
  }

  static get_generation_type (boxId) {
    const boxType = Boxes.get_box_type(boxId)
    return { 10: 1, 12: 3, 11: 10 }[boxType]
  }
}

module.exports = Boxes
