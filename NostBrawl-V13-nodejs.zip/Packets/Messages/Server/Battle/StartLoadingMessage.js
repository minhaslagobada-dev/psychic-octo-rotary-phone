'use strict'
const { BattleParticipants } = require('../../../../Logic/Battle/BattleParticipants')
const Writer = require('../../../../Utils/Writer')

class StartLoadingMessage extends Writer {
  constructor (client, player, room = null, participants = null) {
    super(client)
    this.enable_native_v13()
    this.id = 20559
    this.client = client
    this.player = player
    this.room = room
    this.participants = participants
  }

  encode () {
    let entries = this.participants
    if (entries === null || entries === undefined) {
      entries = BattleParticipants.build(this.room, this.player)
    }
    const ownIndex = BattleParticipants.own_index(entries, this.player)
    const own = entries[ownIndex]
    this.writeInt(entries.length)
    this.writeInt(ownIndex)
    this.writeInt(own.team)
    this.writeInt(entries.length)
    for (const entry of entries) {
      // v13 BattlePlayer.decode 0x3fba9c first calls LogicLong.decode
      // (0x3e67fc): two fixed int32 fields precede the name string.
      this.writeInt(entry.bot ? 0 : Math.trunc(entry.high_id || 0))
      this.writeInt(entry.bot ? 0 : Math.trunc(entry.low_id || 0))
      this.writeString(entry.name)
      this.writeVint(entry.index)
      this.writeVint(entry.team)
      this.writeVint(0)
      this.writeInt(0)
      this.writeScId(16, entry.brawler_id)
      this.writeScId(29, entry.skin_id)
      this.writeBoolean(false)
    }
    this.writeInt(0)
    this.writeInt(0)
    this.writeInt(this.room && Number.isInteger(this.room.battle_seed) ? this.room.battle_seed : Math.floor(Date.now() / 1000))
    const mapId = Math.trunc(
      this.room !== null && this.room !== undefined && this.room.map_id !== undefined
        ? this.room.map_id
        : (this.player.map_id !== undefined ? this.player.map_id : 7)
    )
    this.writeVint(this.room && Number.isInteger(this.room.loading_game_type)
      ? this.room.loading_game_type : BattleParticipants.loading_game_type(entries))
    this.writeVint(1)
    this.writeVint(3)
    this.writeBoolean(false)
    this.writeVint(0)
    this.writeVint(19)
    this.writeScId(15, mapId)
  }
}

module.exports = StartLoadingMessage
