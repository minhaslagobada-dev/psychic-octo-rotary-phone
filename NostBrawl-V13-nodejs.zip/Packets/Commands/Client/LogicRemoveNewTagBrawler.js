'use strict'

const { RewardTransaction } = require('../../../Logic/Rewards')
const { ValueError } = require('../../../Utils/Errors')

class LogicRemoveNewTagBrawler {
  static decode (reader) {
    reader.read_Vint()
    reader.read_Vint()
    reader.readLogicLong()
    const reference = reader.readScId()
    if (reference[0] !== 16 || reference[1] < 0) {
      throw new ValueError(`Invalid brawler DataReference: ${reference}`)
    }
    reader.brawler_id = reference[1]

    reader.new_tag_state = reader.read_int()
  }

  static process (reader) {
    const progression = reader.player.progression || {}
    const tags = (typeof progression === 'object' && progression !== null && !Array.isArray(progression))
      ? progression.brawlerNewTag || {}
      : {}
    const key = String(reader.brawler_id)
    const current = tags[key] !== undefined ? tags[key] : tags[reader.brawler_id]
    if ((current || 0) !== 1) {
      return { brawler: reader.brawler_id, changed: false }
    }
    const updated = Object.assign({}, tags)
    updated[key] = 0
    const transaction = new RewardTransaction(reader.player)
    transaction.set_progression_value('brawlerNewTag', updated)
    transaction.commit()
    return { brawler: reader.brawler_id, changed: true }
  }
}

module.exports = LogicRemoveNewTagBrawler
